import { Mastra } from '@mastra/core';
import { registerApiRoute } from '@mastra/core/server';
import { PostgresStore } from '@mastra/pg';
import { Observability, SamplingStrategyType } from '@mastra/observability';
import { LangfuseExporter } from '@mastra/langfuse';
import { createWorkflow, createStep } from '@mastra/core/workflows';
import { z } from 'zod';
import { AsyncLocalStorage } from 'async_hooks';
import { parseBuffer } from 'music-metadata';
import { createOpenAI } from '@ai-sdk/openai';
import { generateText as generateText$1 } from 'ai';
import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { randomUUID, createHash } from 'crypto';
import { Pool } from 'pg';
import { Agent } from '@mastra/core/agent';
import { createTool } from '@mastra/core/tools';
import fs from 'fs';
import path from 'path';
import os from 'os';
import { Memory } from '@mastra/memory';
import { decode } from '@auth/core/jwt';
import { createClient } from 'redis';


// -- Shims --
import cjsUrl from 'node:url';
import cjsPath from 'node:path';
import cjsModule from 'node:module';
const __filename = cjsUrl.fileURLToPath(import.meta.url);
const __dirname = cjsPath.dirname(__filename);
const require = cjsModule.createRequire(import.meta.url);
const storage = new PostgresStore({
  id: "videogen",
  connectionString: process.env.DATABASE_URL
});

const langfuseEnabled = !!process.env.LANGFUSE_PUBLIC_KEY && !!process.env.LANGFUSE_SECRET_KEY;
const observability = langfuseEnabled ? new Observability({
  configs: {
    default: {
      serviceName: "videoGen",
      exporters: [
        new LangfuseExporter({
          publicKey: process.env.LANGFUSE_PUBLIC_KEY,
          secretKey: process.env.LANGFUSE_SECRET_KEY,
          ...process.env.LANGFUSE_BASE_URL && {
            baseUrl: process.env.LANGFUSE_BASE_URL
          },
          realtime: false
        })
      ],
      sampling: {
        type: SamplingStrategyType.RATIO,
        probability: 0.1 
      }
    }
  }
}) : void 0;

const DEFAULT_AI_MODEL = process.env.DEFAULT_AI_MODEL || process.env.DEEPSEEK_MODEL || "deepseek-chat";
function hasText(value) {
  return typeof value === "string" && value.trim().length > 0;
}
function resolveTextProvider(options) {
  const deepseekKey = process.env.DEEPSEEK_API_KEY?.trim() || options.apiKey?.trim() || "";
  const requestedModel = options.model?.trim() || DEFAULT_AI_MODEL;
  if (hasText(deepseekKey)) {
    return {
      provider: "openrouter",
      apiKey: deepseekKey,
      model: requestedModel
    };
  }
  const googleKey = process.env.GOOGLE_API_KEY?.trim() || "";
  const serverXaiKey = process.env.XAI_API_KEY?.trim() || "";
  if (hasText(googleKey)) {
    return {
      provider: "gemini",
      apiKey: googleKey,
      model: requestedModel.startsWith("gemini") ? requestedModel : process.env.GEMINI_MODEL || "gemini-2.5-flash"
    };
  }
  if (hasText(serverXaiKey)) {
    return {
      provider: "xai",
      apiKey: serverXaiKey,
      model: requestedModel.startsWith("grok") ? requestedModel : process.env.XAI_MODEL || "grok-3"
    };
  }
  throw new Error("No AI provider configured. Set DEEPSEEK_API_KEY (recommended) or GOOGLE_API_KEY or XAI_API_KEY.");
}

function createOpenRouterModel(modelId, apiKey) {
  const deepseekKey = process.env.DEEPSEEK_API_KEY?.trim() || apiKey?.trim();
  const deepseek = createOpenAI({
    baseURL: "https://api.deepseek.com/v1",
    apiKey: deepseekKey || "missing-deepseek-api-key"
  });
  return deepseek.chat(modelId ?? process.env.DEFAULT_AI_MODEL ?? "deepseek-chat");
}
async function generateWithOpenRouter(params) {
  const deepseekKey = process.env.DEEPSEEK_API_KEY?.trim() || params.apiKey?.trim();
  if (!deepseekKey) {
    throw new Error("No DeepSeek API key configured. Set DEEPSEEK_API_KEY or pass a per-request apiKey.");
  }
  const modelId = params.model?.trim() || process.env.DEFAULT_AI_MODEL || "deepseek-chat";
  const model = createOpenRouterModel(modelId, deepseekKey);
  const systemParts = [];
  const messages = [];
  for (const msg of params.messages) {
    if (msg.role === "system") {
      systemParts.push(msg.content);
    } else {
      messages.push({
        role: msg.role === "assistant" ? "assistant" : "user",
        content: msg.content
      });
    }
  }
  const system = systemParts.join("\n\n");
  const result = await generateText$1({
    model,
    system: system || void 0,
    messages,
    maxOutputTokens: params.maxTokens ?? 1e3,
    temperature: params.temperature
  });
  return {
    text: result.text,
    provider: "openrouter",
    model: modelId,
    usage: {
      totalTokens: result.usage?.totalTokens
    }
  };
}

const GOOGLE_PROJECT_ID = () => process.env.GOOGLE_PROJECT_ID || "";
const GOOGLE_LOCATION = () => process.env.GOOGLE_LOCATION || "us-central1";
const DEFAULT_SAFETY_SETTINGS = [
  { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "OFF" },
  { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "OFF" },
  { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "OFF" },
  { category: "HARM_CATEGORY_HARASSMENT", threshold: "OFF" }
];
function splitMessages(messages) {
  const systemText = messages.filter((message) => message.role === "system" && message.content?.trim()).map((message) => message.content.trim()).join("\n\n");
  const contents = messages.filter((message) => message.role !== "system" && message.content?.trim()).map((message) => ({
    role: message.role === "assistant" ? "model" : "user",
    parts: [{ text: message.content }]
  }));
  return {
    systemInstruction: systemText ? { parts: [{ text: systemText }] } : void 0,
    contents
  };
}
function extractText$2(data) {
  const candidate = data?.candidates?.[0];
  const parts = candidate?.content?.parts ?? [];
  const text = parts.map((part) => part?.text).filter((value) => typeof value === "string" && value.trim().length > 0).join("\n").trim();
  if (!text) {
    const finishReason = candidate?.finishReason || "UNKNOWN";
    const blockReason = data?.promptFeedback?.blockReason;
    throw new Error(
      `Gemini response had no text content (finishReason=${finishReason}${blockReason ? `, blockReason=${blockReason}` : ""}, parts=${parts.length})`
    );
  }
  return text;
}
function shouldDisableThinking(model) {
  return /gemini-2\.5-flash(-lite)?/i.test(model);
}
async function generateWithGemini(config, params) {
  const { systemInstruction, contents } = splitMessages(params.messages);
  if (contents.length === 0) {
    throw new Error("Gemini request requires at least one non-system message.");
  }
  const projectId = GOOGLE_PROJECT_ID();
  const location = GOOGLE_LOCATION();
  if (!projectId) {
    throw new Error("GOOGLE_PROJECT_ID is required for Vertex Gemini text generation.");
  }
  const url = `https://${location}-aiplatform.googleapis.com/v1/projects/${projectId}/locations/${location}/publishers/google/models/${config.model}:generateContent?key=${config.apiKey}`;
  const body = {
    ...systemInstruction ? { systemInstruction } : {},
    contents,
    generationConfig: {
      temperature: params.temperature ?? 1,
      maxOutputTokens: params.maxTokens ?? 1e3,
      topP: 0.95,
      ...shouldDisableThinking(config.model) ? {
        thinkingConfig: {
          thinkingBudget: 0
        }
      } : {}
    },
    safetySettings: DEFAULT_SAFETY_SETTINGS,
    ...params.enableWebSearch ? { tools: [{ googleSearch: {} }] } : {}
  };
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });
  const raw = await response.text();
  if (!response.ok) {
    throw new Error(`Gemini API error ${response.status}: ${raw.slice(0, 400)}`);
  }
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error("Failed to parse Gemini response as JSON");
  }
  return {
    text: extractText$2(data),
    provider: "gemini",
    model: config.model,
    usage: {
      totalTokens: data?.usageMetadata?.totalTokenCount
    }
  };
}

const X_AI_API_URL = "https://api.x.ai/v1/chat/completions";
async function generateWithXai(config, params) {
  const response = await fetch(X_AI_API_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${config.apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: config.model,
      messages: params.messages,
      max_tokens: params.maxTokens ?? 1e3,
      temperature: params.temperature
    })
  });
  const raw = await response.text();
  if (!response.ok) {
    throw new Error(`x.ai API error ${response.status}: ${raw.slice(0, 400)}`);
  }
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error("Failed to parse x.ai response as JSON");
  }
  const text = data?.choices?.[0]?.message?.content;
  if (!text) {
    throw new Error("x.ai response had no content");
  }
  return {
    text,
    provider: "xai",
    model: config.model,
    usage: {
      totalTokens: data?.usage?.total_tokens
    }
  };
}

async function generateText(params) {
  const config = resolveTextProvider({
    apiKey: params.apiKey,
    model: params.model
  });
  if (config.provider === "openrouter") {
    return generateWithOpenRouter(params);
  }
  if (config.provider === "gemini") {
    return generateWithGemini(config, params);
  }
  return generateWithXai(config, params);
}

const tokenStore = new AsyncLocalStorage();
function getTokenTotal() {
  const store = tokenStore.getStore();
  return store?.total ?? 0;
}
async function withTokenTracking(fn) {
  return tokenStore.run({ total: 0 }, async () => {
    const result = await fn();
    return { result, tokensUsed: tokenStore.getStore().total };
  });
}
async function callAIWithTracking(params) {
  const result = await generateText({
    messages: params.messages,
    apiKey: params.apiKey,
    model: params.model,
    maxTokens: params.maxTokens,
    temperature: params.temperature
  });
  const tokensUsed = result.usage.totalTokens ?? 0;
  const store = tokenStore.getStore();
  if (store) store.total += tokensUsed;
  console.log(
    "[callAIWithTracking] provider:",
    result.provider,
    "model:",
    result.model,
    "tokens:",
    tokensUsed,
    "total:",
    store?.total ?? 0
  );
  return result.text;
}
const LANG_NAMES = {
  en: "English",
  es: "Spanish",
  fr: "French",
  de: "German",
  pt: "Portuguese",
  ar: "Arabic",
  hi: "Hindi",
  ja: "Japanese",
  ko: "Korean",
  zh: "Chinese",
  it: "Italian",
  nl: "Dutch",
  tr: "Turkish",
  ru: "Russian",
  pl: "Polish",
  sv: "Swedish",
  no: "Norwegian",
  da: "Danish",
  fi: "Finnish",
  cs: "Czech",
  ro: "Romanian",
  el: "Greek",
  hu: "Hungarian",
  th: "Thai",
  vi: "Vietnamese",
  id: "Indonesian",
  ms: "Malay",
  uk: "Ukrainian"
};
function languageName(code) {
  return LANG_NAMES[code] || code;
}
function parseJSON(raw) {
  let str = raw.trim();
  if (str.startsWith("```json")) str = str.slice(7);
  else if (str.startsWith("```")) str = str.slice(3);
  if (str.endsWith("```")) str = str.slice(0, -3);
  str = str.trim();
  const firstObject = str.indexOf("{");
  const firstArray = str.indexOf("[");
  const startCandidates = [firstObject, firstArray].filter((index) => index >= 0);
  const start = startCandidates.length > 0 ? Math.min(...startCandidates) : -1;
  if (start >= 0 && start < str.length) {
    const openChar = str[start];
    const closeChar = openChar === "{" ? "}" : "]";
    let depth = 0;
    let inString = false;
    let escaping = false;
    for (let i = start; i < str.length; i++) {
      const char = str[i];
      if (inString) {
        if (escaping) {
          escaping = false;
          continue;
        }
        if (char === "\\") {
          escaping = true;
          continue;
        }
        if (char === '"') {
          inString = false;
        }
        continue;
      }
      if (char === '"') {
        inString = true;
        continue;
      }
      if (char === openChar) {
        depth++;
        continue;
      }
      if (char === closeChar) {
        depth--;
        if (depth === 0) {
          str = str.slice(start, i + 1);
          break;
        }
      }
    }
  }
  return JSON.parse(str);
}
function setNestedValue(obj, dotPath, value) {
  const parts = dotPath.replace(/\[(\d+)\]/g, ".$1").split(".");
  const result = obj && typeof obj === "object" ? JSON.parse(JSON.stringify(obj)) : {};
  let cursor = result;
  for (let i = 0; i < parts.length - 1; i++) {
    const key = parts[i];
    const nextKey = parts[i + 1];
    const nextIsIndex = /^\d+$/.test(nextKey);
    const existing = cursor[key];
    if (existing == null || typeof existing !== "object") {
      cursor[key] = nextIsIndex ? [] : {};
    }
    cursor = cursor[key];
  }
  cursor[parts[parts.length - 1]] = value;
  return result;
}
function getNestedValue(obj, dotPath) {
  const parts = dotPath.replace(/\[(\d+)\]/g, ".$1").split(".");
  let cursor = obj;
  for (const part of parts) {
    if (cursor == null) return void 0;
    cursor = cursor[part];
  }
  return cursor;
}
const CUSTOM_PLUGIN_TOP_LEVEL_FIELDS = /* @__PURE__ */ new Set(["audioSrc", "duration", "audioLoop", "title"]);
function resolveBlockDataPath(block, path) {
  const blockType = typeof block === "string" ? block : block?.type;
  if (blockType !== "custom-plugin") return path;
  if (path.startsWith("pluginData.")) return path;
  const root = path.match(/^[^[.]+/)?.[0] ?? path;
  if (CUSTOM_PLUGIN_TOP_LEVEL_FIELDS.has(root)) return path;
  return `pluginData.${path}`;
}
function getBlockNestedValue(block, path) {
  return getNestedValue(block, resolveBlockDataPath(block, path));
}
function setBlockNestedValue(block, path, value) {
  return setNestedValue(block, resolveBlockDataPath(block, path), value);
}
function isResolvedAssetUrl(value) {
  if (value.startsWith("data:")) return true;
  if (!value.startsWith("http")) return false;
  const v = value.toLowerCase();
  if (v.includes("example.com") || v.includes("example_") || v.includes("/placeholder") || v.includes("your-domain") || v.includes("picsum.photos/seed/placeholder")) {
    return false;
  }
  return true;
}
function expandTemplatePaths(normalizedFields, dataObject) {
  const result = [];
  for (const field of normalizedFields) {
    const templateMatch = field.path.match(/^([^[]+)\[\]\.(.+)$/);
    if (templateMatch) {
      const [, arrayName, nestedField] = templateMatch;
      const arr = dataObject?.[arrayName];
      if (!Array.isArray(arr)) continue;
      for (let i = 0; i < arr.length; i++) {
        const concretePath = `${arrayName}[${i}].${nestedField}`;
        const leafValue = nestedField.includes(".") ? getNestedValue(arr[i], nestedField) : arr[i]?.[nestedField];
        const leafStr = typeof leafValue === "string" ? leafValue.trim() : "";
        if (leafStr && isResolvedAssetUrl(leafStr)) continue;
        const desc = leafStr || field.description;
        const bgRemoval = field.removeBackground !== void 0 ? field.removeBackground : arr[i]?.removeBackground ?? false;
        result.push({ path: concretePath, description: desc, type: field.type, removeBackground: bgRemoval });
      }
    } else {
      const leafValue = getNestedValue(dataObject, field.path);
      const leafStr = typeof leafValue === "string" ? leafValue.trim() : "";
      if (leafStr && isResolvedAssetUrl(leafStr)) continue;
      const desc = leafStr || field.description;
      const bgRemoval = field.removeBackground ?? false;
      result.push({ path: field.path, description: desc, type: field.type, removeBackground: bgRemoval });
    }
  }
  return result;
}
function fitRolesToBlocks(roles, blockCount) {
  if (blockCount === roles.length) return [...roles];
  if (blockCount < roles.length) {
    if (blockCount === 1) return [roles[0]];
    if (blockCount === 2) return [roles[0], roles[roles.length - 1]];
    const result2 = [roles[0]];
    const middleSlots = blockCount - 2;
    const middleRoles = roles.slice(1, -1);
    const step = middleRoles.length / middleSlots;
    for (let i2 = 0; i2 < middleSlots; i2++) {
      result2.push(middleRoles[Math.round(i2 * step)]);
    }
    result2.push(roles[roles.length - 1]);
    return result2;
  }
  const result = [...roles];
  const middleStart = 1;
  const middleEnd = roles.length - 1;
  let i = middleStart;
  while (result.length < blockCount) {
    result.splice(result.length - 1, 0, roles[i]);
    i = i >= middleEnd - 1 ? middleStart : i + 1;
  }
  return result;
}
function extractAudioFields(obj, prefix = "") {
  const fields = [];
  if (!obj || typeof obj !== "object") return fields;
  if (Array.isArray(obj)) {
    obj.forEach((item, i) => {
      fields.push(...extractAudioFields(item, `${prefix}[${i}]`));
    });
  } else {
    for (const [key, val] of Object.entries(obj)) {
      const path = prefix ? `${prefix}.${key}` : key;
      if (key === "audioSrc" && typeof val === "string" && val.trim()) {
        fields.push({ path, text: val.trim() });
      } else if (val && typeof val === "object") {
        fields.push(...extractAudioFields(val, path));
      }
    }
  }
  return fields;
}
function mergeParallaxLayers(filledBlock, originalBlock) {
  if (filledBlock.type !== "parallax-story") return filledBlock;
  if (!Array.isArray(originalBlock.layers)) return filledBlock;
  const aiLayers = Array.isArray(filledBlock.layers) ? filledBlock.layers : [];
  const mergedLayers = originalBlock.layers.map((templateLayer, i) => {
    const aiLayer = aiLayers[i] ?? {};
    return {
      ...templateLayer,
      ...aiLayer
    };
  });
  return {
    ...filledBlock,
    layers: mergedLayers
  };
}
const WORDS_PER_SECOND = 2.1;
const AUDIO_TAIL_SECS = 2;
async function getAudioDurationSeconds(audioSrc) {
  try {
    let buf;
    let mime = "";
    if (audioSrc.startsWith("data:audio")) {
      const [header, base64] = audioSrc.split(",");
      if (!base64) return 0;
      mime = header?.split(":")[1]?.split(";")[0] ?? "";
      buf = Buffer.from(base64, "base64");
    } else if (audioSrc.startsWith("http")) {
      const response = await fetch(audioSrc, { signal: AbortSignal.timeout(1e4) });
      if (!response.ok) {
        console.warn(`[getAudioDurationSeconds] fetch failed: HTTP ${response.status}`);
        return 0;
      }
      buf = Buffer.from(await response.arrayBuffer());
      mime = response.headers.get("content-type") || "audio/wav";
    } else {
      return 0;
    }
    const metadata = await parseBuffer(buf, { mimeType: mime || void 0 });
    const duration = metadata.format.duration ?? 0;
    console.log(`[getAudioDurationSeconds] ${duration.toFixed(2)}s (${mime}, ${buf.length} bytes)`);
    return duration;
  } catch (e) {
    console.warn("[getAudioDurationSeconds] failed:", e);
    return 0;
  }
}
function postProcessParallaxLayers(block, { originalBlock }) {
  return mergeParallaxLayers(block, originalBlock);
}
async function postProcessAudioDuration(block, _ctx) {
  const audioFields = extractAudioFields(block);
  if (audioFields.length === 0) return block;
  let maxSecs = 0;
  for (const { path, text } of audioFields) {
    const parts = path.replace(/\[(\d+)\]/g, ".$1").split(".");
    let val = block;
    for (const p of parts) val = val?.[p];
    let secs = 0;
    if (typeof val === "string" && (val.startsWith("data:audio") || val.startsWith("http"))) {
      secs = await getAudioDurationSeconds(val);
    }
    if (secs === 0 && text && !text.startsWith("data:") && !text.startsWith("http")) {
      secs = text.trim().split(/\s+/).length / WORDS_PER_SECOND;
    }
    const secsWithTail = secs + AUDIO_TAIL_SECS;
    if (secsWithTail > maxSecs) maxSecs = secsWithTail;
  }
  const rounded = Math.ceil(maxSecs * 10) / 10;
  const blockDur = block.duration ?? 0;
  const finalSecs = rounded > AUDIO_TAIL_SECS ? rounded : blockDur;
  const hasTtsAudio = audioFields.some(({ path }) => {
    const parts = path.replace(/\[(\d+)\]/g, ".$1").split(".");
    let val = block;
    for (const p of parts) val = val?.[p];
    return typeof val === "string" && (val.startsWith("data:audio") || val.startsWith("http"));
  });
  const updates = {};
  if (finalSecs > 0 && finalSecs !== block.duration) {
    console.log(`[postProcessAudioDuration] ${block.type} duration ${block.duration}s \u2192 ${finalSecs}s`);
    updates.duration = finalSecs;
  }
  if (hasTtsAudio && block.audioLoop !== false) {
    updates.audioLoop = false;
  }
  return Object.keys(updates).length > 0 ? { ...block, ...updates } : block;
}
const BLOCK_POST_PROCESSORS = [
  postProcessParallaxLayers,
  postProcessAudioDuration
];
async function applyBlockPostProcessors(blocks, templateBlocks, videoMeta) {
  return Promise.all(blocks.map(async (block, i) => {
    const ctx = { originalBlock: templateBlocks[i] ?? {}, videoMeta, index: i };
    let b = block;
    for (const fn of BLOCK_POST_PROCESSORS) b = await fn(b, ctx);
    return b;
  }));
}
const ENGAGEMENT_THRESHOLD = 7;
const MAX_DIRECTOR_LOOPS = 3;

var utils = /*#__PURE__*/Object.freeze({
  __proto__: null,
  AUDIO_TAIL_SECS: AUDIO_TAIL_SECS,
  ENGAGEMENT_THRESHOLD: ENGAGEMENT_THRESHOLD,
  MAX_DIRECTOR_LOOPS: MAX_DIRECTOR_LOOPS,
  WORDS_PER_SECOND: WORDS_PER_SECOND,
  applyBlockPostProcessors: applyBlockPostProcessors,
  callAIWithTracking: callAIWithTracking,
  expandTemplatePaths: expandTemplatePaths,
  extractAudioFields: extractAudioFields,
  fitRolesToBlocks: fitRolesToBlocks,
  getBlockNestedValue: getBlockNestedValue,
  getNestedValue: getNestedValue,
  getTokenTotal: getTokenTotal,
  languageName: languageName,
  mergeParallaxLayers: mergeParallaxLayers,
  parseJSON: parseJSON,
  resolveBlockDataPath: resolveBlockDataPath,
  setBlockNestedValue: setBlockNestedValue,
  setNestedValue: setNestedValue,
  withTokenTracking: withTokenTracking
});

async function enrichVideoMeta(params) {
  console.log("[enrich_video_meta] \u25B6 filling missing videoMeta fields");
  const provided = params.partialVideoMeta ?? {};
  const alreadySet = Object.keys(provided).filter((k) => provided[k] !== void 0);
  try {
    const response = await callAIWithTracking({
      messages: [
        {
          role: "system",
          content: `You are a video metadata generator. Fill in any missing videoMeta fields.

Valid values:
- aspectRatio: "16:9" | "9:16" | "1:1" | "4:5"  (default "9:16" for social/mobile)
- theme: "dark_modern" | "light_clean" | "gradient_vibrant" | "minimal_bw"
- fps: 24 | 30 | 60  (default 30)
- intro: { title (string), subtitle (string), duration (1-5) }
- outro: { title (string), subtitle (string), duration (1-5) }
- audioTracks: [] (leave empty unless story explicitly mentions background music)
- subtitleTrack: optional object { entries: [{startTime, endTime, text}], style: {textStyle, fontSize, ...}, enabled } \u2014 leave out unless user requests subtitles
- textOverlayTracks: [] optional array of persistent text overlays (watermarks, lower thirds). Each: { id, text, textStyle, fontSize, textPosition, textColor, opacity, startTime, endTime (null=forever), enabled }

DO NOT change already-provided fields: ${alreadySet.join(", ") || "none"}
Pick theme and aspectRatio that best fit the story's tone and platform.
${params.language !== "en" ? `LANGUAGE: All viewer-facing text (intro title/subtitle, outro title/subtitle) MUST be in ${languageName(params.language)}.` : ""}
Return complete JSON only, no markdown.`
        },
        {
          role: "user",
          content: `Story: "${params.userStory}"
Already provided: ${JSON.stringify(provided, null, 2)}
Return complete videoMeta JSON.`
        }
      ],
      apiKey: params.apiKey,
      maxTokens: 600,
      model: params.model
    });
    const aiMeta = parseJSON(response);
    const videoMeta = { ...aiMeta, ...provided };
    console.log("[enrich_video_meta] \u2705 videoMeta:", JSON.stringify(videoMeta));
    return videoMeta;
  } catch (e) {
    console.warn("[enrich_video_meta] \u26A0\uFE0F failed, using defaults:", e.message);
    return {
      aspectRatio: "9:16",
      theme: "dark_modern",
      fps: 30,
      audioTracks: [],
      textOverlayTracks: [],
      intro: { title: "", subtitle: "", duration: 2 },
      outro: { title: "", subtitle: "", duration: 2 },
      ...provided
    };
  }
}

const ARC_PATTERNS = {
  documentary: {
    name: "documentary",
    description: "Biographical, sports, or historical stories about a person, team, or event",
    roles: ["hook", "context", "build-up", "climax", "proof", "resolution"],
    defaultTone: "cinematic, inspiring, emotionally building toward a peak moment"
  },
  listicle: {
    name: "listicle",
    description: "Rankings, top-N lists, countdowns, comparisons between multiple entities",
    roles: ["intro", "item", "item", "item", "item", "summary"],
    defaultTone: "energetic, punchy, fast-paced \u2014 each item lands like a reveal"
  },
  tutorial: {
    name: "tutorial",
    description: "How-to guides, step-by-step instructions, educational or explainer content",
    roles: ["intro", "step", "step", "step", "step", "recap"],
    defaultTone: "clear, instructional, reassuring \u2014 builds confidence step by step"
  },
  product_pitch: {
    name: "product_pitch",
    description: "Product launches, feature showcases, app demos, sales or marketing content",
    roles: ["problem", "solution", "feature", "feature", "social_proof", "cta"],
    defaultTone: "confident, persuasive, building excitement toward a strong CTA"
  },
  biography: {
    name: "biography",
    description: "Individual life stories, career journeys, founder stories, personal narratives",
    roles: ["origin", "rise", "challenge", "triumph", "legacy", "inspiration"],
    defaultTone: "personal, emotional, nostalgic \u2014 earns the emotion through specific detail"
  },
  news: {
    name: "news",
    description: "Current events, announcements, breaking news, press releases",
    roles: ["headline", "context", "detail", "detail", "impact", "conclusion"],
    defaultTone: "authoritative, neutral, informative \u2014 facts first, then significance"
  },
  motivational: {
    name: "motivational",
    description: "Inspirational content, self-improvement, fitness journeys, mindset shifts",
    roles: ["problem", "struggle", "turning_point", "triumph", "principle", "cta"],
    defaultTone: "intense, uplifting, urgent \u2014 creates a desire to act"
  },
  comparison: {
    name: "comparison",
    description: "Versus content, head-to-head reviews, side-by-side analysis of two+ things",
    roles: ["intro", "contender_a", "contender_b", "round", "round", "verdict"],
    defaultTone: "analytical, balanced, building to a decisive verdict"
  },
  mini_doc: {
    name: "mini_doc",
    description: "Short-form documentary: single focused topic, tight emotional arc, social media format",
    roles: ["hook", "context", "tension", "resolution", "cta"],
    defaultTone: "cinematic, tight, every second earns its place"
  },
  explainer: {
    name: "explainer",
    description: 'Concept explainers, "what is X", science or finance breakdowns, ELI5 content',
    roles: ["hook_question", "analogy", "detail", "detail", "summary", "insight"],
    defaultTone: "curious, clear, surprising \u2014 makes complex things feel simple"
  },
  event_recap: {
    name: "event_recap",
    description: 'Sports match recaps, event summaries, "what happened" recaps',
    roles: ["teaser", "setup", "key_moment", "key_moment", "result", "reaction"],
    defaultTone: "exciting, play-by-play energy, relives the moment"
  },
  brand_story: {
    name: "brand_story",
    description: 'Company or brand origin stories, "why we exist" narratives, mission-driven content',
    roles: ["problem_in_world", "founder_moment", "mission", "proof", "values", "cta"],
    defaultTone: "purposeful, warm, authentic \u2014 values over hype"
  },
  reaction: {
    name: "reaction",
    description: "Commentary, reaction content, hot takes, opinion pieces, response videos",
    roles: ["hook", "claim", "evidence", "counter", "verdict", "takeaway"],
    defaultTone: "bold, opinionated, conversational \u2014 like talking to a friend who knows their stuff"
  },
  transformation: {
    name: "transformation",
    description: "Before/after, glow-ups, makeover journeys, progress reveals",
    roles: ["before", "catalyst", "process", "struggle", "reveal", "impact"],
    defaultTone: "dramatic, building anticipation \u2014 the reveal is everything"
  },
  mystery: {
    name: "mystery",
    description: 'True crime, unsolved mysteries, conspiracy deep-dives, "what really happened"',
    roles: ["hook_question", "clue", "clue", "twist", "reveal", "aftermath"],
    defaultTone: "suspenseful, eerie, slow-burn tension \u2014 keeps you guessing"
  },
  storytime: {
    name: "storytime",
    description: 'Personal anecdotes, "story time" narratives, real experiences, viral moments',
    roles: ["setup", "inciting_incident", "escalation", "climax", "fallout", "lesson"],
    defaultTone: "casual, gripping, conversational \u2014 like the best storyteller at a party"
  },
  review: {
    name: "review",
    description: "Product reviews, movie/game reviews, honest opinions, tier lists",
    roles: ["intro", "first_impression", "deep_dive", "pros", "cons", "verdict"],
    defaultTone: "honest, analytical, entertaining \u2014 earns trust through detail"
  },
  day_in_life: {
    name: "day_in_life",
    description: 'Day-in-the-life, routine breakdowns, behind-the-scenes, "what I do" content',
    roles: ["morning", "routine", "highlight", "challenge", "wind_down", "reflection"],
    defaultTone: "intimate, relatable, authentic \u2014 makes viewers feel like they were there"
  },
  myth_busting: {
    name: "myth_busting",
    description: `Debunking myths, fact vs fiction, "things you didn't know", misconceptions`,
    roles: ["myth_intro", "common_belief", "evidence", "truth", "implications", "takeaway"],
    defaultTone: 'confident, surprising, "actually..." energy \u2014 flips assumptions'
  },
  countdown: {
    name: "countdown",
    description: "Dramatic countdowns, tension-building reveals, best-of lists with buildup",
    roles: ["teaser", "entry", "entry", "entry", "runner_up", "winner"],
    defaultTone: "escalating excitement, each entry bigger than the last \u2014 saves the best for last"
  }
};
const CONSISTENCY_LENS_CONFIGS = {
  character: {
    description: "Ensures named people look consistent across all images \u2014 same face, clothing, and emotional arc.",
    whenToSelect: "The video features one or more named people as recurring subjects (biography, founder story, athlete journey, etc.)",
    visualStyleDirective: "Include a CHARACTER SHEET for every named person: full name, age, physical traits (hair color/length, eye color, build), signature clothing that stays locked across ALL blocks, and their emotional baseline expression. Every image must feel like a frame from the same film about the same person.",
    storyBibleDirective: "Include: SUBJECT (full name + 1-sentence identity), TIMELINE (key dates/milestones referenced across blocks \u2014 keep numbers consistent), CHARACTER STATE PER BLOCK (brief emotional note per narrative stage), RECURRING MOTIFS (visual or verbal callbacks), TONE ANCHOR (the single emotional truth the video must leave viewers with).",
    contentGeneratorHint: `CHARACTER LENS \u2014 CRITICAL:
- IMAGE FIELDS: Always show the named subject using the character sheet from visualStyleGuide \u2014 same clothing, same build, same face. Depict their emotional state for this block's role (body language, posture, expression, environment lighting).
- For "origin/childhood" moments: use era-appropriate props but keep facial features consistent.
- NEVER show an anonymous silhouette or generic crowd when the subject should be present.
- TEXT FIELDS: Use the subject's actual name \u2014 no pronouns without clear antecedents.`
  },
  concept: {
    description: "Ensures diagrams, artifacts, and notation stay visually consistent \u2014 same colors, same style, same terminology.",
    whenToSelect: "The video explains an idea, mechanism, process, or abstract concept (science, finance, engineering, how-things-work, etc.)",
    visualStyleDirective: "Include an ARTIFACT/DIAGRAM PALETTE: the core visual representation of the concept (diagram type, color coding for elements, annotation style \u2014 handwritten vs clean sans-serif vs code-comment). Specify whether visuals are diagrams/illustrations vs real-world photography \u2014 pick ONE and stay consistent. Define colors for recurring diagram elements (e.g. inputs = green, outputs = red).",
    storyBibleDirective: "Include: CORE CONCEPT (the idea in one plain-English sentence), KEY TERMS (3-5 domain terms used consistently \u2014 no synonyms mid-video), CONCEPT STEPS (ordered list with 2-word labels if tutorial/explainer), COMPLEXITY FLOOR (minimum assumed viewer knowledge \u2014 all content stays above this level).",
    contentGeneratorHint: `CONCEPT LENS \u2014 CRITICAL:
- IMAGE FIELDS: Show the ARTIFACT \u2014 diagram, equation, physical equipment, interface screenshot, or annotated illustration. If a diagram color palette was defined in visualStyleGuide, reference those exact colors in your description.
- For step-by-step blocks: show the specific sub-diagram or tool for THAT step \u2014 not the full concept re-drawn.
- Prefer diagrams and labeled illustrations over stock photos of people for abstract concepts.
- TEXT FIELDS: Use the exact key terms from the storyBible \u2014 no improvised synonyms.`
  },
  event_history: {
    description: "Anchors images in specific geography, era, and faction colors \u2014 maps, locations, and chronological flow.",
    whenToSelect: "The video covers a historical event, geographic story, political/military situation, sports match, or any content where WHERE and WHEN are central.",
    visualStyleDirective: 'Include an EVENT GEOGRAPHY PALETTE: primary location(s) with visual description (architecture, landscape, era), faction/side color assignments if multiple factions exist (e.g. "Team A = red and gold, Team B = navy and white"), map/geography visual style (satellite vs illustrated vs infographic \u2014 pick one), era/period visual cues (year or decade, confirming details like clothing/vehicles/technology).',
    storyBibleDirective: "Include: EVENT TIMELINE (key dates or sequence markers in order), FACTIONS/ACTORS (named entities with their one-sentence role), GEOGRAPHIC ANCHOR (primary and secondary locations referenced), CONFIRMED OUTCOME (the result \u2014 content must never contradict this), STAKES (what was at risk and for whom \u2014 used as the emotional through-line).",
    contentGeneratorHint: `EVENT/HISTORY LENS \u2014 CRITICAL:
- IMAGE FIELDS: Establish LOCATION first (recognizable geographic or architectural context). Apply faction color coding from visualStyleGuide to any uniforms, flags, banners, or team equipment. Make the era/date visually obvious (aged film grain for historical, breaking-news style for modern events).
- For key-moment blocks: depict the EXACT moment \u2014 not a generic crowd shot.
- TEXT FIELDS: Use exact faction names, dates, and location names from the storyBible.`
  },
  product: {
    description: "Locks product appearance, brand colors, and specs so they never drift across blocks.",
    whenToSelect: "The video is about a product, service, app, or brand \u2014 features, launches, comparisons, reviews, or origin stories.",
    visualStyleDirective: "Include a PRODUCT VISUAL IDENTITY: product name and exact appearance (color, shape, material, key visual features), brand color palette (primary + accent), product photography style (clean studio background vs lifestyle vs UI screenshot \u2014 pick ONE), and for comparison arcs: the exact comparison axis and how it will be visualized (side-by-side, chart, table).",
    storyBibleDirective: "Include: PRODUCT NAME (exact spelling and capitalization), KEY SPECS (3-5 critical features/numbers that must stay consistent), PRICE/OFFER (exact terms if relevant), TARGET CUSTOMER (one sentence), UNIQUE SELLING POINT (the single differentiator), CALL TO ACTION (exact wording of the desired action).",
    contentGeneratorHint: `PRODUCT LENS \u2014 CRITICAL:
- IMAGE FIELDS: Show the PRODUCT using the exact description from visualStyleGuide \u2014 same color, same form factor, every time. Feature blocks: show the specific feature being described (not the whole product). Social proof blocks: product IN USE. CTA block: clean studio shot, logo visible.
- VIDEO FIELDS: NEVER write character-driven or emotional scenes (no "person looking stressed", no "man at desk reacting", no story expressions). ALWAYS describe what the PRODUCT or INTERFACE looks like in action \u2014 UI screens, dashboards, data visualizations, architecture flows, feature demos. The narrative role defines the MOOD of the product shot, not a human character's emotion.
- For comparison arcs: show both products at the same scale, same camera angle.
- TEXT FIELDS: Product name spelled exactly as in storyBible. All specs must match exactly \u2014 never approximate.`
  },
  motivational: {
    description: "Defines a visual intensity escalation map \u2014 energy, color temperature, and camera feeling must build block by block.",
    whenToSelect: "The video is designed to inspire action, build energy, or drive emotional transformation (motivational speech, fitness journey, transformation story, countdown, etc.)",
    visualStyleDirective: "Include a VISUAL INTENSITY SCALE: opening block visual energy (dark, low-light, muted colors, tight composition), ending block visual energy (explosive brightness, wide open frame, golden light, triumph), color temperature arc (cold/blue-grey early \u2192 warming to gold/orange at climax), and camera energy progression (close/claustrophobic early \u2192 wide/epic at peak).",
    storyBibleDirective: "Include: CENTRAL STRUGGLE (the universal human challenge this video addresses), TRANSFORMATION MILESTONE (the exact turning point \u2014 every block leads toward or radiates from it), UNIVERSAL PRINCIPLE (the 1-sentence truth this video communicates), CALL TO ACTION (specific, actionable), ESCALATION MAP (block-by-block intensity labels: struggle \u2192 rock bottom \u2192 spark \u2192 rise \u2192 triumph \u2192 call).",
    contentGeneratorHint: `MOTIVATIONAL LENS \u2014 CRITICAL:
- IMAGE FIELDS: Visual intensity MUST match this block's escalation map position from storyBible. Early blocks: dark, tight, constraining compositions \u2014 shadows, small figure in large negative space. Mid blocks: dynamic, liminal \u2014 figure at threshold, motion blur, breaking through. Late blocks: wide, bright, open \u2014 expansive sky, peak/summit, explosive movement, golden light. CTA block: direct eye contact, bright, action-forward.
- NEVER use bland stock-looking images \u2014 every image should have emotional charge matching the escalation stage.
- spokenScript rhythm: early blocks use longer sentences; late blocks use 3-5 word punches.`
  }
};
const VISUAL_STYLE_PRESETS = {
  "photorealistic": { name: "Photorealistic", description: "Cinematic photography", promptPrefix: "Hyperrealistic cinematic photography, shallow depth of field, dramatic lighting, film grain, 8K detail" },
  "anime": { name: "Anime", description: "Japanese anime style", promptPrefix: "Anime art style, cel-shaded, vibrant saturated colors, dynamic composition, soft ambient lighting, Studio Ghibli meets modern anime" },
  "3d-cinematic": { name: "3D Cinematic", description: "3D rendered movie quality", promptPrefix: "3D cinematic render, Pixar-quality, volumetric lighting, dramatic shadows, rich textures, depth of field" },
  "cartoon": { name: "Cartoon", description: "Bold cartoon illustration", promptPrefix: "Bold cartoon illustration style, thick outlines, flat vibrant colors, exaggerated expressions, clean vector art" },
  "watercolor": { name: "Watercolor", description: "Soft watercolor painting", promptPrefix: "Soft watercolor painting, flowing brushstrokes, muted pastel palette, organic textures, dreamy ethereal mood" },
  "comic-book": { name: "Comic Book", description: "Marvel/DC comic panels", promptPrefix: "Comic book art style, bold ink outlines, halftone dots, dramatic shading, dynamic action poses, vivid saturated colors" },
  "pixel-art": { name: "Pixel Art", description: "Retro pixel art", promptPrefix: "Retro pixel art, 16-bit style, limited color palette, crisp pixels, nostalgic game aesthetic" },
  "oil-painting": { name: "Oil Painting", description: "Classical oil painting", promptPrefix: "Classical oil painting, rich impasto brushwork, warm chiaroscuro lighting, Renaissance-inspired composition" },
  "neon-cyberpunk": { name: "Neon Cyberpunk", description: "Futuristic neon aesthetic", promptPrefix: "Cyberpunk neon aesthetic, glowing neon lights, dark moody atmosphere, rain-slicked surfaces, holographic accents, purple and cyan palette" },
  "vintage-film": { name: "Vintage Film", description: "Retro film photography", promptPrefix: "Vintage film photography, warm sepia undertones, light leaks, soft vignette, 1970s color grading, analog film grain" },
  "minimalist": { name: "Minimalist", description: "Clean minimal design", promptPrefix: "Minimalist design, clean lines, generous whitespace, limited color palette, geometric shapes, modern typography-driven" },
  "dark-moody": { name: "Dark & Moody", description: "Dark dramatic atmosphere", promptPrefix: "Dark moody atmosphere, deep shadows, rim lighting, desaturated tones with selective color, cinematic noir feeling" }
};
Object.entries(VISUAL_STYLE_PRESETS).map(([id, v]) => ({ id, ...v }));

async function selectArc(params) {
  console.log("[select_arc] \u25B6 choosing narrative arc");
  const catalog = { ...ARC_PATTERNS, ...params.arcPatternCatalog };
  if (params.preferredArc) {
    const forced = catalog[params.preferredArc];
    if (forced) {
      console.log(`[select_arc] \u2705 using caller-forced arc: "${forced.name}"`);
      return forced;
    }
    console.warn(`[select_arc] \u26A0\uFE0F preferredArc "${params.preferredArc}" not found in catalog \u2014 falling back to AI selection`);
  }
  const blockTypes = params.templateBlocks.map((b) => b.type).join(", ");
  const arcList = Object.values(catalog).map((a) => `- "${a.name}": ${a.description}`).join("\n");
  try {
    const response = await callAIWithTracking({
      messages: [
        {
          role: "system",
          content: `You are a video narrative strategist.
Pick the best narrative arc for the given story and block types.

Available arcs:
${arcList}

Return ONLY this JSON, no markdown:
{
  "arc": "<arc_name>",
  "reason": "<one sentence why this arc fits best>"
}`
        },
        {
          role: "user",
          content: `Story: "${params.userStory}"
Block types in this video (${params.templateBlocks.length} blocks): ${blockTypes}

Which arc fits best?`
        }
      ],
      apiKey: params.apiKey,
      maxTokens: 200,
      model: params.model
    });
    const parsed = parseJSON(response);
    const arcName = parsed.arc;
    const selected = catalog[arcName] ?? catalog["documentary"] ?? ARC_PATTERNS["documentary"];
    console.log(`[select_arc] \u2705 selected: "${arcName}" \u2014 ${parsed.reason}`);
    return selected;
  } catch (e) {
    console.warn("[select_arc] \u26A0\uFE0F failed, defaulting to documentary:", e.message);
    return catalog["documentary"] ?? ARC_PATTERNS["documentary"];
  }
}

function createSemaphore(max) {
  let active = 0;
  const queue = [];
  return {
    async acquire() {
      if (active < max) {
        active++;
        return;
      }
      await new Promise((resolve) => queue.push(resolve));
      active++;
    },
    release() {
      active--;
      if (queue.length > 0) queue.shift()();
    }
  };
}
let DEEPGRAM_API_KEY = process.env.DEEPGRAM_API_KEY || "4df63a77e2307626aa8e020a6c0d3d912b3f51a1";
const DEEPGRAM_TTS_URL = "https://api.deepgram.com/v1/speak";
const DEEPGRAM_STATIC_VOICES = [
  { id: "aura-2-thalia-en", name: "Thalia", gender: "F", style: "Natural \xB7 Conversational", provider: "deepgram", language: "en" },
  { id: "aura-2-andromeda-en", name: "Andromeda", gender: "F", style: "Professional \xB7 Clear", provider: "deepgram", language: "en" },
  { id: "aura-2-helena-en", name: "Helena", gender: "F", style: "Warm \xB7 Friendly", provider: "deepgram", language: "en" },
  { id: "aura-2-stella-en", name: "Stella", gender: "F", style: "Bright \xB7 Energetic", provider: "deepgram", language: "en" },
  { id: "aura-2-luna-en", name: "Luna", gender: "F", style: "Soft \xB7 Calm", provider: "deepgram", language: "en" },
  { id: "aura-2-aurora-en", name: "Aurora", gender: "F", style: "Smooth \xB7 Engaging", provider: "deepgram", language: "en" },
  { id: "aura-2-odysseus-en", name: "Odysseus", gender: "M", style: "Deep \xB7 Authoritative", provider: "deepgram", language: "en" },
  { id: "aura-2-orion-en", name: "Orion", gender: "M", style: "Clear \xB7 Professional", provider: "deepgram", language: "en" },
  { id: "aura-2-helios-en", name: "Helios", gender: "M", style: "Warm \xB7 Confident", provider: "deepgram", language: "en" },
  { id: "aura-2-zeus-en", name: "Zeus", gender: "M", style: "Strong \xB7 Commanding", provider: "deepgram", language: "en" },
  { id: "aura-2-apollo-en", name: "Apollo", gender: "M", style: "Smooth \xB7 Charismatic", provider: "deepgram", language: "en" }
];
const deepgramProvider = {
  name: "Deepgram",
  async synthesize(text, voiceId) {
    const response = await fetch(`${DEEPGRAM_TTS_URL}?model=${voiceId}`, {
      method: "POST",
      headers: {
        "Authorization": `Token ${DEEPGRAM_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ text })
    });
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.err_msg || `Deepgram API error: ${response.status}`);
    }
    const buf = Buffer.from(await response.arrayBuffer());
    const mime = response.headers.get("content-type") || "audio/wav";
    return `data:${mime};base64,${buf.toString("base64")}`;
  },
  async fetchVoices() {
    return DEEPGRAM_STATIC_VOICES;
  }
};
const LANG_NAME_TO_CODE = {
  english: "en",
  spanish: "es",
  french: "fr",
  german: "de",
  portuguese: "pt",
  arabic: "ar",
  hindi: "hi",
  japanese: "ja",
  korean: "ko",
  chinese: "zh",
  italian: "it",
  dutch: "nl",
  turkish: "tr",
  russian: "ru",
  polish: "pl",
  swedish: "sv",
  norwegian: "no",
  danish: "da",
  finnish: "fi",
  czech: "cs",
  romanian: "ro",
  greek: "el",
  hungarian: "hu",
  thai: "th",
  vietnamese: "vi",
  indonesian: "id",
  malay: "ms",
  tagalog: "tl",
  filipino: "fil",
  ukrainian: "uk"
};
function normalizeLanguageCode(raw) {
  if (!raw) return void 0;
  const lower = raw.toLowerCase().trim();
  if (lower.length <= 3) return lower;
  return LANG_NAME_TO_CODE[lower] ?? lower;
}
let ELEVENLABS_API_KEY = process.env.ELEVENLABS_API_KEY || "sk_7ae1f6d1a8c36a76cb4df6d1e6175193c6444dd2544d8258";
const ELEVENLABS_TTS_URL = "https://api.elevenlabs.io/v1/text-to-speech";
const elevenlabsSemaphore = createSemaphore(2);
const elevenlabsProvider = {
  name: "ElevenLabs",
  async synthesize(text, voiceId) {
    await elevenlabsSemaphore.acquire();
    try {
      const response = await fetch(`${ELEVENLABS_TTS_URL}/${voiceId}`, {
        method: "POST",
        headers: {
          "xi-api-key": ELEVENLABS_API_KEY,
          "Content-Type": "application/json",
          "Accept": "audio/mpeg"
        },
        body: JSON.stringify({
          text,
          model_id: "eleven_v3",
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.75,
            style: 0,
            use_speaker_boost: true
          }
        })
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.detail?.message || `ElevenLabs API error: ${response.status}`);
      }
      const buf = Buffer.from(await response.arrayBuffer());
      const mime = response.headers.get("content-type") || "audio/mpeg";
      return `data:${mime};base64,${buf.toString("base64")}`;
    } finally {
      elevenlabsSemaphore.release();
    }
  },
  async fetchVoices() {
    try {
      const res = await fetch("https://api.elevenlabs.io/v1/voices", {
        headers: { "xi-api-key": ELEVENLABS_API_KEY }
      });
      if (!res.ok) throw new Error(`ElevenLabs voices API: ${res.status}`);
      const data = await res.json();
      const voices = (data.voices ?? []).map((v) => ({
        id: v.voice_id,
        name: v.name,
        gender: v.labels?.gender === "female" ? "F" : "M",
        style: [v.labels?.description, v.labels?.use_case].filter(Boolean).join(" \xB7 ") || "Versatile",
        provider: "elevenlabs",
        accent: v.labels?.accent || void 0,
        language: normalizeLanguageCode(v.labels?.language || v.fine_tuning?.language),
        previewUrl: v.preview_url || void 0,
        premium: true
      }));
      console.log(`[TTS] Fetched ${voices.length} ElevenLabs voices`);
      return voices;
    } catch (e) {
      console.error("[TTS] Failed to fetch ElevenLabs voices:", e);
      return [];
    }
  }
};
let CARTESIA_API_KEY = process.env.CARTESIA_API_KEY || "";
const CARTESIA_TTS_URL = "https://api.cartesia.ai/tts/bytes";
const CARTESIA_STATIC_VOICES = [
  { id: "694f9389-aac1-45b6-b726-9d9369183238", name: "Barbershop Man", gender: "M", style: "Casual \xB7 Friendly", provider: "cartesia", language: "en" },
  { id: "a0e99841-438c-4a64-b679-ae501e7d6091", name: "Helpful Woman", gender: "F", style: "Clear \xB7 Professional", provider: "cartesia", language: "en" },
  { id: "bf991597-6c13-47e4-8411-91ec2de5c466", name: "Movieman", gender: "M", style: "Deep \xB7 Cinematic", provider: "cartesia", language: "en" },
  { id: "79a125e8-cd45-4c13-8a67-188112f4dd22", name: "British Lady", gender: "F", style: "Refined \xB7 British", provider: "cartesia", language: "en", accent: "british" },
  { id: "95856005-0332-41b0-935f-352e296aa0df", name: "Classy British Man", gender: "M", style: "Polished \xB7 British", provider: "cartesia", language: "en", accent: "british" },
  { id: "63ff761f-c1e8-414b-b969-d1833d1c870c", name: "Southern Man", gender: "M", style: "Warm \xB7 Southern", provider: "cartesia", language: "en", accent: "southern" },
  { id: "b7d50908-b17c-442d-ad8d-810c63997ed9", name: "California Girl", gender: "F", style: "Bright \xB7 Conversational", provider: "cartesia", language: "en", accent: "american" },
  { id: "41534e16-2966-4c6b-9670-111411def906", name: "Nonfiction Man", gender: "M", style: "Authoritative \xB7 Clear", provider: "cartesia", language: "en" },
  { id: "2ee87190-8f84-4925-97da-e52547f9462c", name: "Newsman", gender: "M", style: "Professional \xB7 News", provider: "cartesia", language: "en" },
  { id: "156fb8d2-335b-4950-9cb3-a2d33befec77", name: "Calm Lady", gender: "F", style: "Soft \xB7 Calming", provider: "cartesia", language: "en" }
];
const cartesiaSemaphore = createSemaphore(2);
const cartesiaProvider = {
  name: "Cartesia",
  async synthesize(text, voiceId) {
    if (!CARTESIA_API_KEY) throw new Error("CARTESIA_API_KEY not configured");
    await cartesiaSemaphore.acquire();
    try {
      const response = await fetch(CARTESIA_TTS_URL, {
        method: "POST",
        headers: {
          "X-API-Key": CARTESIA_API_KEY,
          "Cartesia-Version": "2024-06-10",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model_id: "sonic-2",
          transcript: text,
          voice: { mode: "id", id: voiceId },
          output_format: { container: "mp3", encoding: "mp3", sample_rate: 44100 },
          language: "en"
        })
      });
      if (!response.ok) {
        const err = await response.text();
        throw new Error(`Cartesia TTS error ${response.status}: ${err}`);
      }
      const buf = Buffer.from(await response.arrayBuffer());
      return `data:audio/mpeg;base64,${buf.toString("base64")}`;
    } finally {
      cartesiaSemaphore.release();
    }
  },
  async fetchVoices() {
    if (!CARTESIA_API_KEY) return CARTESIA_STATIC_VOICES;
    try {
      const res = await fetch("https://api.cartesia.ai/voices", {
        headers: {
          "X-API-Key": CARTESIA_API_KEY,
          "Cartesia-Version": "2024-06-10"
        }
      });
      if (!res.ok) return CARTESIA_STATIC_VOICES;
      const data = await res.json();
      const voices = (data ?? []).filter((v) => v.is_public).map((v) => ({
        id: v.id,
        name: v.name,
        gender: v.description?.toLowerCase().includes("female") || v.description?.toLowerCase().includes("woman") || v.description?.toLowerCase().includes("girl") || v.description?.toLowerCase().includes("lady") ? "F" : "M",
        style: v.description || "Natural",
        provider: "cartesia",
        language: v.language || "en"
      }));
      return voices.length > 0 ? voices : CARTESIA_STATIC_VOICES;
    } catch {
      return CARTESIA_STATIC_VOICES;
    }
  }
};
const GEMINI_TTS_VOICES = [
  { id: "Zephyr", name: "Zephyr", gender: "F", style: "Bright", provider: "gemini", language: "en" },
  { id: "Puck", name: "Puck", gender: "M", style: "Upbeat", provider: "gemini", language: "en" },
  { id: "Charon", name: "Charon", gender: "M", style: "Informative", provider: "gemini", language: "en" },
  { id: "Kore", name: "Kore", gender: "F", style: "Firm", provider: "gemini", language: "en" },
  { id: "Fenrir", name: "Fenrir", gender: "M", style: "Excitable", provider: "gemini", language: "en" },
  { id: "Leda", name: "Leda", gender: "F", style: "Youthful", provider: "gemini", language: "en" },
  { id: "Orus", name: "Orus", gender: "M", style: "Firm", provider: "gemini", language: "en" },
  { id: "Aoede", name: "Aoede", gender: "F", style: "Breezy", provider: "gemini", language: "en" },
  { id: "Callirrhoe", name: "Callirrhoe", gender: "F", style: "Easy-going", provider: "gemini", language: "en" },
  { id: "Autonoe", name: "Autonoe", gender: "F", style: "Bright", provider: "gemini", language: "en" },
  { id: "Enceladus", name: "Enceladus", gender: "M", style: "Breathy", provider: "gemini", language: "en" },
  { id: "Iapetus", name: "Iapetus", gender: "M", style: "Clear", provider: "gemini", language: "en" },
  { id: "Umbriel", name: "Umbriel", gender: "M", style: "Easy-going", provider: "gemini", language: "en" },
  { id: "Algieba", name: "Algieba", gender: "M", style: "Smooth", provider: "gemini", language: "en" },
  { id: "Despina", name: "Despina", gender: "F", style: "Smooth", provider: "gemini", language: "en" },
  { id: "Erinome", name: "Erinome", gender: "F", style: "Clear", provider: "gemini", language: "en" },
  { id: "Algenib", name: "Algenib", gender: "M", style: "Gravelly", provider: "gemini", language: "en" },
  { id: "Rasalgethi", name: "Rasalgethi", gender: "M", style: "Informative", provider: "gemini", language: "en" },
  { id: "Laomedeia", name: "Laomedeia", gender: "F", style: "Upbeat", provider: "gemini", language: "en" },
  { id: "Achernar", name: "Achernar", gender: "F", style: "Soft", provider: "gemini", language: "en" },
  { id: "Alnilam", name: "Alnilam", gender: "M", style: "Firm", provider: "gemini", language: "en" },
  { id: "Schedar", name: "Schedar", gender: "M", style: "Even", provider: "gemini", language: "en" },
  { id: "Gacrux", name: "Gacrux", gender: "M", style: "Mature", provider: "gemini", language: "en" },
  { id: "Pulcherrima", name: "Pulcherrima", gender: "F", style: "Forward", provider: "gemini", language: "en" },
  { id: "Achird", name: "Achird", gender: "M", style: "Friendly", provider: "gemini", language: "en" },
  { id: "Zubenelgenubi", name: "Zubenelgenubi", gender: "M", style: "Casual", provider: "gemini", language: "en" },
  { id: "Vindemiatrix", name: "Vindemiatrix", gender: "F", style: "Gentle", provider: "gemini", language: "en" },
  { id: "Sadachbia", name: "Sadachbia", gender: "M", style: "Lively", provider: "gemini", language: "en" },
  { id: "Sadaltager", name: "Sadaltager", gender: "M", style: "Knowledgeable", provider: "gemini", language: "en" },
  { id: "Sulafat", name: "Sulafat", gender: "F", style: "Warm", provider: "gemini", language: "en" }
];
const TTS_PROVIDERS = {
  deepgram: deepgramProvider,
  elevenlabs: elevenlabsProvider,
  cartesia: cartesiaProvider
};
let cachedVoices = null;
let cacheTimestamp = 0;
const CACHE_TTL = 10 * 60 * 1e3;
const voiceProviderMap = /* @__PURE__ */ new Map();
async function fetchAllVoices() {
  const now = Date.now();
  if (cachedVoices && now - cacheTimestamp < CACHE_TTL) {
    return cachedVoices;
  }
  const results = await Promise.all(
    Object.values(TTS_PROVIDERS).map((p) => p.fetchVoices())
  );
  cachedVoices = results.flat();
  cacheTimestamp = now;
  voiceProviderMap.clear();
  for (const v of cachedVoices) voiceProviderMap.set(v.id, v.provider);
  return cachedVoices;
}
const GEMINI_VOICE_IDS = new Set(GEMINI_TTS_VOICES.map((v) => v.id));
new Set(CARTESIA_STATIC_VOICES.map((v) => v.id));
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function getVoiceProvider(voiceId) {
  if (voiceProviderMap.has(voiceId)) return voiceProviderMap.get(voiceId);
  if (voiceId.startsWith("aura-")) return "deepgram";
  if (GEMINI_VOICE_IDS.has(voiceId)) return "gemini";
  if (UUID_REGEX.test(voiceId)) return "cartesia";
  return "elevenlabs";
}
async function generateTTS(text, voiceId) {
  if (!text.trim()) return "";
  const vid = voiceId;
  const providerKey = getVoiceProvider(vid);
  const provider = TTS_PROVIDERS[providerKey];
  if (!provider) throw new Error(`Unknown TTS provider: ${providerKey}`);
  console.log(`[TTS] ${provider.name} \u2192 ${vid}`);
  return provider.synthesize(text, vid);
}

var deepgramTts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  TTS_PROVIDERS: TTS_PROVIDERS,
  fetchAllVoices: fetchAllVoices,
  generateTTS: generateTTS,
  getVoiceProvider: getVoiceProvider
});

const CF_ACCOUNT_ID = () => process.env.CF_ACCOUNT_ID || "b878fc219459718a59845347272b20fa";
const CF_API_TOKEN = () => process.env.CF_API_TOKEN || "cfut_pqzbocksXk5wMBMTyRIRs4UNDMn1pnlbWsivdxfld5f618c8";
const RUNWARE_API_KEY = () => process.env.RUNWARE_API_KEY || "";
const BG_REMOVAL_API_URL = () => process.env.BG_REMOVAL_API_URL || "https://sybppqk12a.execute-api.us-east-1.amazonaws.com/remove-bg-asset";
const DEFAULT_TTS_VOICE = "aura-2-thalia-en";
const IMAGE_PLACEHOLDER = "https://picsum.photos/seed/default/800/1200";
async function uploadImageBuffer(buffer, ext, dataUrlFallback) {
  const region = process.env.LAMBDA_REGION || "us-east-1";
  const siteUrl = process.env.LAMBDA_SITE_URL || "";
  const bucketMatch = siteUrl.match(/https:\/\/([^.]+)\.s3\./);
  const bucket = bucketMatch?.[1] || process.env.S3_BUCKET || "";
  if (bucket) {
    const s3 = new S3Client({
      region,
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID || "",
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || ""
      },
      requestHandler: { requestTimeout: 3e4, connectionTimeout: 1e4 }
    });
    const contentType = "image/jpeg";
    const key = `generated-images/${randomUUID()}.${ext}`;
    try {
      await s3.send(
        new PutObjectCommand({ Bucket: bucket, Key: key, Body: buffer, ContentType: contentType }),
        { abortSignal: AbortSignal.timeout(3e4) }
      );
    } catch (e) {
      console.warn(`[media:image] \u26A0\uFE0F S3 upload failed (${e.message}) \u2014 falling back to data URL`);
      return dataUrlFallback;
    }
    const signedUrl = await getSignedUrl(s3, new GetObjectCommand({ Bucket: bucket, Key: key }), { expiresIn: 7 * 24 * 60 * 60 });
    console.log("[media:image] \u2705 uploaded to S3");
    return signedUrl;
  }
  console.log("[media:image] \u2705 returning base64 data URL (no S3)");
  return dataUrlFallback;
}
async function tryCloudflare(description, width, height) {
  try {
    const url = `https://api.cloudflare.com/client/v4/accounts/${CF_ACCOUNT_ID()}/ai/run/@cf/black-forest-labs/flux-1-schnell`;
    const res = await fetch(url, {
      method: "POST",
      headers: { "Authorization": `Bearer ${CF_API_TOKEN()}`, "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: description, num_steps: 8, width, height }),
      signal: AbortSignal.timeout(3e4)
    });
    if (!res.ok) {
      console.warn(`[media:image] \u26A0\uFE0F Cloudflare ${res.status} \u2014 will try Runware`);
      return null;
    }
    const json = await res.json();
    const b64 = json?.result?.image;
    if (!b64) {
      console.warn("[media:image] \u26A0\uFE0F Cloudflare: no image in response");
      return null;
    }
    console.log("[media:image] \u2705 Cloudflare succeeded");
    return b64;
  } catch (e) {
    console.warn("[media:image] \u26A0\uFE0F Cloudflare error:", e.message, "\u2014 will try Runware");
    return null;
  }
}
async function tryRunware(description, width, height) {
  const apiKey = RUNWARE_API_KEY();
  if (!apiKey) {
    console.warn("[media:image] \u26A0\uFE0F Runware skipped: RUNWARE_API_KEY is not set");
    return null;
  }
  try {
    const res = await fetch("https://api.runware.ai/v1", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify([{
        taskType: "imageInference",
        model: "runware:100@1",
        numberResults: 1,
        width,
        height,
        steps: 4,
        CFGScale: 1,
        scheduler: "FlowMatchEulerDiscreteScheduler",
        includeCost: true,
        checkNSFW: true,
        outputType: ["URL"],
        outputQuality: 85,
        positivePrompt: description,
        taskUUID: randomUUID()
      }]),
      signal: AbortSignal.timeout(12e4)
    });
    if (!res.ok) {
      const err = await res.text().catch(() => "");
      console.warn(`[media:image] \u26A0\uFE0F Runware ${res.status}:`, err.slice(0, 200));
      return null;
    }
    const json = await res.json();
    const result = json?.data?.[0];
    if (!result?.imageURL) {
      console.warn("[media:image] \u26A0\uFE0F Runware: no imageURL in response");
      return null;
    }
    if (result.NSFWContent) {
      console.warn("[media:image] \u26A0\uFE0F Runware flagged NSFW content");
      return null;
    }
    console.log(`[media:image] \u2705 Runware succeeded${typeof result.cost === "number" ? ` ($${result.cost})` : ""}`);
    return result.imageURL;
  } catch (e) {
    console.warn("[media:image] \u26A0\uFE0F Runware error:", e.message);
    return null;
  }
}
async function generateImage(description, width = 768, height = 1344) {
  console.log("[media:image] \u25B6", description?.slice(0, 100));
  if (!description?.trim()) {
    console.warn("[media:image] \u26A0\uFE0F empty description");
    return IMAGE_PLACEHOLDER;
  }
  const cfB64 = await tryCloudflare(description, width, height);
  if (cfB64) {
    const buffer = Buffer.from(cfB64, "base64");
    return uploadImageBuffer(buffer, "jpg", `data:image/jpeg;base64,${cfB64}`);
  }
  const runwareUrl = await tryRunware(description, width, height);
  if (runwareUrl) {
    return runwareUrl;
  }
  console.error("[media:image] \u274C all providers failed \u2014 returning placeholder");
  return IMAGE_PLACEHOLDER;
}
async function generateBgRemovedImage(description) {
  console.log("[media:image-bg] \u25B6", description?.slice(0, 100));
  if (!description?.trim()) {
    console.warn("[media:image-bg] \u26A0\uFE0F empty description");
    return IMAGE_PLACEHOLDER;
  }
  const imageUrl = await generateImage(description);
  if (imageUrl === IMAGE_PLACEHOLDER) return IMAGE_PLACEHOLDER;
  return removeBackgroundFromUrl(imageUrl);
}
async function removeBackgroundFromUrl(imageUrl) {
  try {
    console.log(`[media:rmbg] \u25B6 downloading ${imageUrl.slice(0, 80)}...`);
    const imgRes = await fetch(imageUrl, { signal: AbortSignal.timeout(15e3) });
    if (!imgRes.ok) {
      console.warn(`[media:rmbg] \u26A0\uFE0F download failed HTTP ${imgRes.status}`);
      return imageUrl;
    }
    const imageBase64 = Buffer.from(await imgRes.arrayBuffer()).toString("base64");
    const callRmbgApi = async () => {
      console.log(`[media:rmbg] \u25B6 sending to bg-removal API...`);
      return fetch(BG_REMOVAL_API_URL(), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ imageBase64 }),
        signal: AbortSignal.timeout(6e4)
      });
    };
    let res = await callRmbgApi();
    if (!res.ok) {
      console.warn(`[media:rmbg] \u26A0\uFE0F first call HTTP ${res.status} \u2014 cold start? waiting 45s and retrying...`);
      await new Promise((r) => setTimeout(r, 45e3));
      res = await callRmbgApi();
    }
    if (!res.ok) {
      console.warn(`[media:rmbg] \u26A0\uFE0F retry also failed HTTP ${res.status}`);
      return imageUrl;
    }
    const data = await res.json();
    const signedUrl = data?.output?.signedUrl;
    if (signedUrl) {
      console.log(`[media:rmbg] \u2705 bg removed: ${signedUrl.slice(0, 80)}`);
      return signedUrl;
    }
    console.warn("[media:rmbg] \u26A0\uFE0F no signedUrl in response, falling back");
    return imageUrl;
  } catch (e) {
    console.error(`[media:rmbg] \u274C ${e.message}`);
    return imageUrl;
  }
}
function prewarmBgRemoval() {
  const url = BG_REMOVAL_API_URL();
  console.log(`[media:rmbg] \u{1F525} pre-warm ping to ${url.slice(0, 60)}...`);
  fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ prewarm: true }),
    signal: AbortSignal.timeout(3e4)
  }).then((res) => console.log(`[media:rmbg] \u{1F525} pre-warm done HTTP ${res.status}`)).catch(() => {
  });
}
const SERPER_API_KEY = () => process.env.SERPER_API_KEY || "b6e71757c42328c5dfd373af4811deae8275d53b";
async function searchWebImage(query, opts) {
  const key = SERPER_API_KEY();
  if (!query?.trim()) return null;
  let q = query;
  if (opts?.autoScreenshot && !q.toLowerCase().includes("screenshot")) {
    q += " screenshot";
  }
  const minW = opts?.minWidth ?? 0;
  const doSearch = async (searchQuery) => {
    console.log("[media:web-search] \u{1F50D}", searchQuery.slice(0, 100));
    const res = await fetch("https://google.serper.dev/images", {
      method: "POST",
      headers: { "X-API-KEY": key, "Content-Type": "application/json" },
      body: JSON.stringify({ q: searchQuery, num: 10 })
    });
    if (!res.ok) {
      console.error(`[media:web-search] \u274C HTTP ${res.status}`);
      return null;
    }
    const data = await res.json();
    const images = data.images ?? [];
    const candidates = minW > 0 ? images.filter((img) => (img.imageWidth ?? 0) >= minW) : images;
    const best = candidates[0]?.imageUrl ?? images[0]?.imageUrl ?? null;
    return best;
  };
  try {
    let url = await doSearch(q);
    if (url) {
      console.log(`[media:web-search] \u2705 found: ${url.slice(0, 80)}`);
      return url;
    }
    const words = q.split(/\s+/);
    if (words.length > 2) {
      const simpler = words.slice(0, -1).join(" ");
      console.log("[media:web-search] \u{1F504} retrying with simpler query");
      url = await doSearch(simpler);
      if (url) {
        console.log(`[media:web-search] \u2705 found on retry: ${url.slice(0, 80)}`);
        return url;
      }
    }
    console.warn("[media:web-search] \u26A0\uFE0F no results for query");
    return null;
  } catch (e) {
    console.error("[media:web-search] \u274C", e.message);
    return null;
  }
}
async function searchWeb(query) {
  const key = SERPER_API_KEY();
  if (!query?.trim()) return { snippets: [] };
  try {
    console.log("[media:web-research] \u{1F50E}", query.slice(0, 100));
    const res = await fetch("https://google.serper.dev/search", {
      method: "POST",
      headers: { "X-API-KEY": key, "Content-Type": "application/json" },
      body: JSON.stringify({ q: query, num: 5 })
    });
    if (!res.ok) {
      console.error(`[media:web-research] \u274C HTTP ${res.status}`);
      return { snippets: [] };
    }
    const data = await res.json();
    const snippets = (data.organic || []).slice(0, 5).map((r) => r.snippet).filter(Boolean);
    const answerBox = data.answerBox?.snippet || data.answerBox?.answer;
    const knowledgeGraph = data.knowledgeGraph?.description;
    console.log(`[media:web-research] \u2705 ${snippets.length} snippets${answerBox ? " + answerBox" : ""}${knowledgeGraph ? " + knowledgeGraph" : ""}`);
    return { snippets, answerBox, knowledgeGraph };
  } catch (e) {
    console.error("[media:web-research] \u274C", e.message);
    return { snippets: [] };
  }
}
async function searchNews(query) {
  const key = SERPER_API_KEY();
  if (!query?.trim()) return [];
  try {
    console.log("[media:news-search] \u{1F4F0}", query.slice(0, 100));
    const res = await fetch("https://google.serper.dev/news", {
      method: "POST",
      headers: { "X-API-KEY": key, "Content-Type": "application/json" },
      body: JSON.stringify({ q: query, num: 5 })
    });
    if (!res.ok) return [];
    const data = await res.json();
    return (data.news || []).slice(0, 5).map((n) => ({
      title: n.title || "",
      snippet: n.snippet || "",
      date: n.date || ""
    }));
  } catch (e) {
    console.error("[media:news-search] \u274C", e.message);
    return [];
  }
}
async function uploadAudioToS3(base64DataUri) {
  try {
    const region = process.env.LAMBDA_REGION || "us-east-1";
    const siteUrl = process.env.LAMBDA_SITE_URL || "";
    const bucketMatch = siteUrl.match(/https:\/\/([^.]+)\.s3\./);
    const bucket = bucketMatch?.[1] || process.env.S3_BUCKET || "";
    if (!bucket) {
      console.warn("[media:audio:s3] \u26A0\uFE0F no S3 bucket \u2014 returning base64");
      return base64DataUri;
    }
    const matches = base64DataUri.match(/^data:audio\/(\w+);base64,(.+)$/);
    if (!matches) {
      console.warn("[media:audio:s3] \u26A0\uFE0F invalid base64 data URI format");
      return base64DataUri;
    }
    const mimeType = matches[1];
    const base64Data = matches[2];
    const buffer = Buffer.from(base64Data, "base64");
    const ext = mimeType === "mpeg" || mimeType === "mp3" ? "mp3" : "wav";
    const s3 = new S3Client({
      region,
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID || "",
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || ""
      }
    });
    const key = `tts-audio/${randomUUID()}.${ext}`;
    console.log(`[media:audio:s3] \u{1F4E4} uploading audio to S3 (${(buffer.length / 1024).toFixed(1)}KB)...`);
    await s3.send(new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: buffer,
      ContentType: `audio/${ext === "mp3" ? "mpeg" : ext}`
    }));
    const signedUrl = await getSignedUrl(
      s3,
      new GetObjectCommand({ Bucket: bucket, Key: key }),
      { expiresIn: 7 * 24 * 60 * 60 }
      // 7 days
    );
    console.log(`[media:audio:s3] \u2705 uploaded to S3: s3://${bucket}/${key}`);
    return signedUrl;
  } catch (e) {
    console.error(`[media:audio:s3] \u274C ${e.message} \u2014 falling back to base64`);
    return base64DataUri;
  }
}
async function generateAudio(text, voice) {
  if (!text?.trim()) return "";
  try {
    const base64 = await generateTTS(text, voice || DEFAULT_TTS_VOICE);
    if (!base64) return "";
    return await uploadAudioToS3(base64);
  } catch (e) {
    console.error("[media:audio] \u274C", e.message);
    return "";
  }
}
async function proxyImageToS3(sourceUrl) {
  try {
    const region = process.env.LAMBDA_REGION || "us-east-1";
    const siteUrl = process.env.LAMBDA_SITE_URL || "";
    const bucketMatch = siteUrl.match(/https:\/\/([^.]+)\.s3\./);
    const bucket = bucketMatch?.[1] || process.env.S3_BUCKET || "";
    if (!bucket) {
      console.warn("[media:proxy] \u26A0\uFE0F no S3 bucket \u2014 returning original URL");
      return sourceUrl;
    }
    console.log(`[media:proxy] \u{1F4E6} downloading ${sourceUrl.slice(0, 80)}...`);
    const res = await fetch(sourceUrl, { signal: AbortSignal.timeout(15e3) });
    if (!res.ok) {
      console.warn(`[media:proxy] \u26A0\uFE0F HTTP ${res.status} \u2014 returning original`);
      return sourceUrl;
    }
    const buffer = Buffer.from(await res.arrayBuffer());
    const contentType = res.headers.get("content-type") || "image/jpeg";
    const ext = contentType.includes("png") ? "png" : contentType.includes("webp") ? "webp" : "jpg";
    const s3 = new S3Client({
      region,
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID || "",
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || ""
      }
    });
    const key = `proxied-images/${randomUUID()}.${ext}`;
    await s3.send(new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: buffer,
      ContentType: contentType
    }));
    const signedUrl = await getSignedUrl(
      s3,
      new GetObjectCommand({ Bucket: bucket, Key: key }),
      { expiresIn: 7 * 24 * 60 * 60 }
    );
    console.log(`[media:proxy] \u2705 proxied to S3: s3://${bucket}/${key}`);
    return signedUrl;
  } catch (e) {
    console.error(`[media:proxy] \u274C ${e.message} \u2014 returning original URL`);
    return sourceUrl;
  }
}
async function regenerateSingleImage(description, removeBackground) {
  try {
    const webUrl = await searchWebImage(description, { minWidth: 800 });
    if (webUrl) {
      console.log(`[regenerate-image] \u{1F50D} web hit, using real photo`);
      if (removeBackground) {
        const bgRemoved = await removeBackgroundFromUrl(webUrl);
        return { url: bgRemoved };
      }
      const proxied = await proxyImageToS3(webUrl);
      return { url: proxied };
    }
    console.log(`[regenerate-image] \u{1F50D} web miss, falling back to AI generation`);
  } catch (e) {
    console.warn(`[regenerate-image] \u26A0\uFE0F web search errored, falling back: ${e.message}`);
  }
  const url = removeBackground ? await generateBgRemovedImage(description) : await generateImage(description);
  return { url };
}

var mediaService = /*#__PURE__*/Object.freeze({
  __proto__: null,
  generateAudio: generateAudio,
  generateBgRemovedImage: generateBgRemovedImage,
  generateImage: generateImage,
  prewarmBgRemoval: prewarmBgRemoval,
  proxyImageToS3: proxyImageToS3,
  regenerateSingleImage: regenerateSingleImage,
  removeBackgroundFromUrl: removeBackgroundFromUrl,
  searchNews: searchNews,
  searchWeb: searchWeb,
  searchWebImage: searchWebImage
});

async function planMediaStrategy(params) {
  const arcName = params.selectedArc?.name ?? params.preferredArc ?? "";
  const blockSummary = params.templateBlocks.map((b, i) => `[${i}] ${b.type}`).join(", ");
  console.log(`[planner] \u25B6 planning media strategy for arc="${arcName}", blocks: ${blockSummary}`);
  let strategy;
  try {
    const strategyRaw = await callAIWithTracking({
      messages: [
        {
          role: "system",
          content: `You are a video production planner. Given a topic, arc, and block layout, output a JSON media strategy.

Decide:
1. Whether the topic needs web research (current facts, real people, real products, how-to steps) or is purely creative/fictional
2. Whether news search is relevant (only for current events, recent happenings)
3. For EACH block, whether images should come from web search, AI generation, or auto (try web first, fall back to AI)
4. For web search blocks, what style of search queries work best (screenshot, photo, diagram)
5. Whether autoScreenshot should be enabled (only for software tutorials showing UI)

Output ONLY valid JSON matching this schema:
{
  "needsResearch": boolean,
  "needsNewsSearch": boolean,
  "researchQueries": ["specific search query 1", ...max 3],
  "topicType": "factual" | "creative" | "mixed",
  "blockStrategies": [
    {
      "blockIndex": 0,
      "blockType": "the block type",
      "imageSource": "web_search" | "ai_generation" | "auto",
      "searchQueryStyle": "screenshot" | "photo" | "diagram" | null,
      "autoScreenshot": false,
      "minWidth": 800,
      "reasoning": "one line why"
    }
  ]
}

Guidelines (WEB-FIRST POLICY):
- DEFAULT: imageSource = "auto" for every image block \u2014 try web search first, fall back to AI generation only on miss. Real photos almost always look better than AI-generated ones for any subject that exists in the real world.
- Use imageSource = "ai_generation" ONLY for: surreal/dreamlike visuals that explicitly cannot exist as a real photo, abstract data viz, fictional characters, or stylized mood backgrounds where photorealism would hurt. These are rare \u2014 when in doubt, pick "auto".
- searchQueryStyle (only affects search query phrasing, not whether to search):
  * "screenshot" \u2192 software tutorials, UI walkthroughs (also set autoScreenshot: true)
  * "diagram" \u2192 technical concepts, architecture visuals
  * "photo" \u2192 everything else (default)
- News/event_recap \u2192 needsNewsSearch: true
- Set needsResearch: true when the topic involves real facts, people, products, places, or events (which is most topics \u2014 be liberal here)
- "video" block type \u2192 ALWAYS use ai_generation (videos are generated, not searched)

Return valid JSON only, no markdown wrapping.`
        },
        {
          role: "user",
          content: `Topic: "${params.userStory}"
Arc: ${arcName || "not yet selected"}
Blocks: ${blockSummary}

Produce the media strategy JSON.`
        }
      ],
      apiKey: params.apiKey,
      maxTokens: 800,
      model: params.model
    });
    strategy = parseJSON(strategyRaw);
    console.log(`[planner] \u2705 strategy: topicType=${strategy.topicType}, needsResearch=${strategy.needsResearch}, needsNews=${strategy.needsNewsSearch}`);
  } catch (e) {
    console.error(`[planner] \u274C strategy LLM failed: ${e.message}, using fallback`);
    strategy = {
      needsResearch: false,
      needsNewsSearch: false,
      researchQueries: [],
      topicType: "creative",
      blockStrategies: params.templateBlocks.map((b, i) => ({
        blockIndex: i,
        blockType: b.type,
        // Web-first fallback: try search before AI generation. resolve-media
        // automatically falls back to AI if search returns nothing.
        imageSource: "auto",
        searchQueryStyle: "photo",
        autoScreenshot: false,
        minWidth: 800,
        reasoning: "fallback \u2014 planner failed, defaulting to web-first"
      }))
    };
  }
  let researchContext = "";
  if (strategy.needsResearch) {
    try {
      const parts = [];
      if (strategy.needsNewsSearch) {
        const news = await searchNews(params.userStory);
        if (news.length > 0) {
          parts.push("RECENT NEWS:\n" + news.map((n) => `- ${n.title}: ${n.snippet} (${n.date})`).join("\n"));
        }
      }
      const queries = strategy.researchQueries.length > 0 ? strategy.researchQueries : [params.userStory];
      const results = await Promise.all(queries.map((q) => searchWeb(q)));
      for (const research of results) {
        if (research.answerBox) parts.push(`ANSWER: ${research.answerBox}`);
        if (research.knowledgeGraph) parts.push(`OVERVIEW: ${research.knowledgeGraph}`);
        if (research.snippets.length > 0)
          parts.push("KEY FACTS:\n" + research.snippets.map((s) => `- ${s}`).join("\n"));
      }
      researchContext = parts.join("\n\n");
      if (researchContext.length > 1500) researchContext = researchContext.slice(0, 1500) + "...";
      console.log(`[planner] \u2705 ${researchContext.length} chars of research context`);
    } catch (e) {
      console.error(`[planner] \u274C research failed: ${e.message}`);
    }
  } else {
    console.log("[planner] \u23ED skipping research (creative/fictional topic)");
  }
  return { mediaStrategy: strategy, researchContext };
}
async function planMediaStrategyViaAgent(params) {
  const arcName = params.selectedArc?.name ?? params.preferredArc ?? "";
  const blockSummary = params.templateBlocks.map((b, i) => `[${i}] ${b.type}`).join(", ");
  console.log(`[planner-agent] \u25B6 running agent for arc="${arcName}", blocks: ${blockSummary}`);
  try {
    const { plannerAgent } = await Promise.resolve().then(function () { return planner_agent; });
    const result = await plannerAgent.generate(
      [{
        role: "user",
        content: JSON.stringify({
          userStory: params.userStory,
          arc: arcName,
          blocks: params.templateBlocks.map((b, i) => ({ index: i, type: b.type }))
        })
      }],
      { maxSteps: 10 }
    );
    const text = result.text?.trim();
    if (!text) throw new Error("planner agent emitted no text");
    const strategy = parseJSON(text);
    if (!strategy || !Array.isArray(strategy.blockStrategies)) {
      throw new Error("planner agent output missing blockStrategies");
    }
    if (strategy.blockStrategies.length !== params.templateBlocks.length) {
      throw new Error(
        `planner agent returned ${strategy.blockStrategies.length} block strategies, expected ${params.templateBlocks.length}`
      );
    }
    console.log(`[planner-agent] \u2705 topicType=${strategy.topicType}, needsResearch=${strategy.needsResearch}, needsNews=${strategy.needsNewsSearch}`);
    let researchContext = "";
    if (strategy.needsResearch) {
      try {
        const parts = [];
        if (strategy.needsNewsSearch) {
          const news = await searchNews(params.userStory);
          if (news.length > 0) {
            parts.push("RECENT NEWS:\n" + news.map((n) => `- ${n.title}: ${n.snippet} (${n.date})`).join("\n"));
          }
        }
        const queries = strategy.researchQueries.length > 0 ? strategy.researchQueries : [params.userStory];
        const results = await Promise.all(queries.map((q) => searchWeb(q)));
        for (const research of results) {
          if (research.answerBox) parts.push(`ANSWER: ${research.answerBox}`);
          if (research.knowledgeGraph) parts.push(`OVERVIEW: ${research.knowledgeGraph}`);
          if (research.snippets.length > 0)
            parts.push("KEY FACTS:\n" + research.snippets.map((s) => `- ${s}`).join("\n"));
        }
        researchContext = parts.join("\n\n");
        if (researchContext.length > 1500) researchContext = researchContext.slice(0, 1500) + "...";
        console.log(`[planner-agent] \u2705 ${researchContext.length} chars of research context`);
      } catch (e) {
        console.error(`[planner-agent] \u274C research gather failed: ${e.message}`);
      }
    }
    return { mediaStrategy: strategy, researchContext };
  } catch (e) {
    console.error(`[planner-agent] \u274C agent failed (${e?.message ?? e}) \u2014 falling back to LLM-only planner`);
    return planMediaStrategy(params);
  }
}

class RunContext {
  constructor() {
    this.docs = /* @__PURE__ */ new Map();
  }
  write(name, content) {
    this.docs.set(name, content);
  }
  read(name) {
    return this.docs.get(name) ?? null;
  }
  append(name, content) {
    const existing = this.docs.get(name) ?? "";
    this.docs.set(name, existing + "\n" + content);
  }
  readAll() {
    return Object.fromEntries(this.docs);
  }
}
const runContextStorage = new AsyncLocalStorage();
function getRunContext() {
  return runContextStorage.getStore() ?? null;
}

async function runDirector(params) {
  const loopCount = params.directorLoopCount + 1;
  console.log(`[director_agent] \u25B6 attempt ${loopCount}`);
  const arcCatalogMerged = { ...ARC_PATTERNS, ...params.arcPatternCatalog };
  const styleCatalogMerged = { ...VISUAL_STYLE_PRESETS, ...params.visualStyleCatalog };
  let arc = params.selectedArc ?? null;
  if (!arc && params.preferredArc) {
    arc = arcCatalogMerged[params.preferredArc] ?? null;
    if (arc) console.log(`[director_agent] using preferred arc: "${arc.name}"`);
  }
  if (params.customArc?.roles?.length) {
    arc = { name: "custom", description: "Claude-defined custom arc", roles: params.customArc.roles, defaultTone: params.customArc.defaultTone };
    console.log(`[director_agent] \u{1F3A8} using custom arc from MCP: ${arc.roles.join(" \u2192 ")}`);
  }
  const blockTypes = params.templateBlocks.map((b) => b.type).join(", ");
  let arcInstruction;
  if (arc) {
    const roles = fitRolesToBlocks(arc.roles, params.templateBlocks.length);
    const blockList = params.templateBlocks.map((b, i) => `  Block ${i + 1} (${b.type}): role = "${roles[i]}"`).join("\n");
    arcInstruction = `SELECTED ARC: "${arc.name}"
ARC DESCRIPTION: ${arc.description}
OVERALL TONE: ${arc.defaultTone}

Block sequence with assigned roles:
${blockList}

Return a JSON object with:
{
  "selectedArc": "${arc.name}",
  "narrativePlan": [ ...exactly ${params.templateBlocks.length} brief objects... ]
}`;
  } else {
    const arcCatalog = Object.values(arcCatalogMerged).map((a) => `- "${a.name}": ${a.description} (tone: ${a.defaultTone})`).join("\n");
    arcInstruction = `AVAILABLE ARCS (pick the best one for this story):
${arcCatalog}

Block types in this video (${params.templateBlocks.length} blocks): ${blockTypes}

First choose the best arc, then assign its roles to blocks using the arc's role sequence.

Return a JSON object with:
{
  "selectedArc": "<arc_name you chose>",
  "reason": "<one sentence why>",
  "narrativePlan": [ ...exactly ${params.templateBlocks.length} brief objects... ]
}`;
  }
  const iterationLog = getRunContext()?.read("iteration-log.md");
  const feedbackSection = iterationLog ? `

ITERATION HISTORY (all previous attempts \u2014 address ALL unresolved issues):
${iterationLog}

Do NOT simply add more adjectives \u2014 rewrite angles, key messages, and scripts to fix the structural issues. Make it GRIPPING.` : params.engagementFeedback ? `

PREVIOUS ATTEMPT FEEDBACK (you MUST address these issues):
${params.engagementFeedback}

Your previous scripts were scored ${params.engagementScore}/10. Fix the specific issues above.
Do NOT simply add more adjectives \u2014 rewrite the angles, key messages, and scripts
to address the structural feedback. Make it GRIPPING.` : "";
  const researchSection = params.researchContext ? `

WEB RESEARCH (current facts \u2014 prefer these over your training data):
${params.researchContext}` : "";
  const presetStyle = params.preferredVisualStyle && params.preferredVisualStyle !== "custom" ? styleCatalogMerged[params.preferredVisualStyle] : null;
  const visualStyleInstruction = presetStyle ? `The user selected visual style: "${presetStyle.name}". Base prompt: "${presetStyle.promptPrefix}".
Your visualStyleGuide MUST start with this base prompt, then ADD character/setting descriptions specific to this story.` : params.customVisualPrompt ? `The user described their desired visual style: "${params.customVisualPrompt}".
Your visualStyleGuide MUST incorporate this description as the foundation, then ADD character/setting descriptions specific to this story.` : `Choose a visual style that best fits this story.`;
  const lensMenu = Object.entries(CONSISTENCY_LENS_CONFIGS).map(([key, cfg]) => `- "${key}": ${cfg.description} Use when: ${cfg.whenToSelect}`).join("\n");
  const lensConditionals = Object.entries(CONSISTENCY_LENS_CONFIGS).map(
    ([key, cfg]) => `IF you select "${key}":
  visualStyleGuide must include: ${cfg.visualStyleDirective}
  storyBible must include: ${cfg.storyBibleDirective}`
  ).join("\n\n");
  const lensSection = `
CONSISTENCY LENSES \u2014 pick 1-3 that apply to THIS specific topic (not just the arc name):
${lensMenu}

${lensConditionals}

Return your chosen lenses as: "selectedLenses": ["lens1", ...]
`;
  try {
    const response = await callAIWithTracking({
      messages: [
        {
          role: "system",
          content: `You are a world-class video director and storyteller. Plan a coherent, emotionally
GRIPPING narrative arc across all blocks \u2014 like a director planning each shot in a film
that will go viral.

IMPORTANT \u2014 CHECK FOR EXPLICIT USER SCENES FIRST:
Read the Story/Topic below carefully. If it contains scene-by-scene descriptions (e.g. "Scene 1: ..., Scene 2: ...", "Block 1: ...", numbered scenes like "1. ..., 2. ...", or clearly distinct per-block instructions separated by line breaks or markers), then:
- You are in FAITHFUL EXECUTION MODE, not creative mode
- Your job is to MAP each user scene to exactly one block, preserving the user's exact intent
- Use the user's exact scene text as the \`spokenScript\` for that block \u2014 do NOT rewrite or rephrase it
- Use the user's scene description as the \`angle\` and \`keyMessage\`
- Use the user's visual description as \`visualMood\` \u2014 do not override with your own mood
- DO NOT add dramatic hooks, storytelling tension, or cinematic techniques that contradict or replace the user's scenes
- The user's words are the final authority \u2014 your role is faithful execution, not creative interpretation
If the story does NOT contain explicit per-block scene descriptions (it reads like a general topic, concept, or narrative idea), proceed with full creative direction below.

${arcInstruction}

Each narrativePlan entry must have:
- narrativeRole: the role from the arc
- angle: the SPECIFIC, CONCRETE aspect of the story THIS block covers (names, numbers, moments \u2014 NOT vague)
- tone: emotional tone (inspiring | intense | factual | emotional | humorous | dramatic | calm | urgent)
- keyMessage: the ONE powerful sentence this block must communicate
- visualMood: visual direction (lighting, setting, color palette, mood)
- spokenScript: the ACTUAL narration text to be spoken aloud via TTS (write it as if you're speaking directly to the viewer \u2014 conversational, punchy, emotional. NOT essay prose.)
- transitionIn: how this connects FROM the previous block (first block: "opening shot")
- transitionOut: how this leads INTO the next (last block: "closing call to action")

CRITICAL RULES:
- spokenScript must be the REAL narration \u2014 written for the ear, not the eye
- Each block covers a UNIQUE angle \u2014 zero repetition
- The emotional arc must EVOLVE (not stay flat)
- Start with a HOOK that grabs in 2 seconds
- End with a STRONG call to action or memorable closer

STORYTELLING TECHNIQUES for spokenScript:
- HOOK: Open with a question, a shocking stat, or a "what if" \u2014 never a bland topic statement
- SPECIFICITY: Replace "he succeeded" with "he scored 183 off 148 balls in 43\xB0C heat"
- SENSORY LANGUAGE: Include what you see, hear, feel \u2014 not abstractions
- TENSION: Every block needs a micro-conflict or unanswered question pulling to the next
- CONVERSATIONAL: Write like telling a friend. Use "you", contractions, fragments.
- PACING: Short sentences for drama. Longer ones to build. Then punch.
${lensSection}
${visualStyleInstruction}

Also return these three fields alongside narrativePlan:
- "visualStyleGuide": A reusable visual prompt prefix (under 100 words) prepended to EVERY image description for visual consistency. Follow the IF-you-select directives above for your chosen lenses.
- "storyBible": A shared context doc (under 150 words) that every block's content generator will see. Follow the IF-you-select directives above for your chosen lenses.
- "selectedLenses": Array of the consistency lens names you chose (e.g. ["character", "concept"]). Can be empty [].${feedbackSection}${researchSection}
${params.language !== "en" ? `
LANGUAGE: ALL spokenScript, keyMessage, and angle fields MUST be written in ${languageName(params.language)}. Internal fields (narrativeRole, transitionIn, transitionOut, visualMood) stay in English.` : ""}
No markdown wrapping. Return valid JSON only.`
        },
        {
          role: "user",
          content: `Story/Topic: "${params.userStory}"

${arc ? `Arc tone: ${arc.defaultTone}` : "Pick the best arc and plan the narrative."}

Plan ${params.templateBlocks.length} blocks. Make every second count \u2014 this needs to GRIP the viewer.`
        }
      ],
      apiKey: params.apiKey,
      maxTokens: 3e3,
      model: params.model
    });
    const parsed = parseJSON(response);
    let resolvedArc = arc;
    if (!resolvedArc && parsed.selectedArc) {
      resolvedArc = arcCatalogMerged[parsed.selectedArc] ?? arcCatalogMerged["documentary"] ?? ARC_PATTERNS["documentary"];
      console.log(`[director_agent] AI selected arc: "${resolvedArc.name}" \u2014 ${parsed.reason || ""}`);
    }
    if (!resolvedArc) resolvedArc = arcCatalogMerged["documentary"] ?? ARC_PATTERNS["documentary"];
    let plan = parsed.narrativePlan ?? parsed;
    if (!Array.isArray(plan)) plan = [];
    if (plan.length > params.templateBlocks.length) {
      console.warn(`[director_agent] \u26A0\uFE0F plan length ${plan.length} > templateBlocks ${params.templateBlocks.length} \u2014 truncating`);
      plan = plan.slice(0, params.templateBlocks.length);
    }
    if (plan.length < params.templateBlocks.length) {
      console.warn(`[director_agent] \u26A0\uFE0F plan length ${plan.length} < templateBlocks ${params.templateBlocks.length} \u2014 padding with fallbacks`);
      const padRoles = fitRolesToBlocks(resolvedArc.roles, params.templateBlocks.length);
      while (plan.length < params.templateBlocks.length) {
        const i = plan.length;
        plan.push({
          narrativeRole: padRoles[i],
          angle: `Aspect ${i + 1} of ${params.userStory}`,
          tone: "engaging",
          keyMessage: `Block ${i + 1}: cover a unique angle of ${params.userStory}`,
          visualMood: "cinematic, high contrast, dramatic lighting",
          spokenScript: "natural, engaging narration that builds on the previous block",
          transitionIn: i === 0 ? "opening shot" : "continues from previous block",
          transitionOut: i === params.templateBlocks.length - 1 ? "closing call to action" : "leads into next block"
        });
      }
    }
    console.log(`[director_agent] \u2705 arc="${resolvedArc.name}" attempt=${loopCount}`);
    plan.forEach((p, i) => {
      console.log(`  Block ${i + 1} (${params.templateBlocks[i]?.type}): [${p.narrativeRole}] ${p.keyMessage}`);
    });
    console.log(`[director_agent] \u{1F3A8} visualStyleGuide: ${String(parsed.visualStyleGuide || "").slice(0, 100)}`);
    console.log(`[director_agent] \u{1F4D6} storyBible: ${String(parsed.storyBible || "").slice(0, 100)}`);
    const parsedLenses = (parsed.selectedLenses ?? []).filter((l) => l in CONSISTENCY_LENS_CONFIGS);
    console.log(`[director_agent] \u{1F50D} selectedLenses: ${parsedLenses.join(", ") || "(none)"}`);
    return {
      selectedArc: resolvedArc,
      narrativePlan: plan,
      directorLoopCount: loopCount,
      visualStyleGuide: parsed.visualStyleGuide || "",
      storyBible: parsed.storyBible || "",
      selectedLenses: parsedLenses
    };
  } catch (e) {
    console.warn("[director_agent] \u26A0\uFE0F failed, using fallback plan:", e.message);
    const fallbackArc = arc ?? arcCatalogMerged["documentary"] ?? ARC_PATTERNS["documentary"];
    const roles = fitRolesToBlocks(fallbackArc.roles, params.templateBlocks.length);
    const fallback = params.templateBlocks.map((b, i) => ({
      narrativeRole: roles[i],
      angle: `Aspect ${i + 1} of ${params.userStory}`,
      tone: i === 0 ? "hook" : i === params.templateBlocks.length - 1 ? "urgent" : "engaging",
      keyMessage: `Block ${i + 1} [${roles[i]}]: Cover a unique angle of ${params.userStory}`,
      visualMood: "cinematic, high contrast, dramatic lighting",
      spokenScript: "natural, engaging narration that builds on the previous block",
      transitionIn: i === 0 ? "opening shot" : "continues from previous block",
      transitionOut: i === params.templateBlocks.length - 1 ? "closing call to action" : "leads into next block"
    }));
    return {
      selectedArc: fallbackArc,
      narrativePlan: fallback,
      visualStyleGuide: "cinematic, high contrast, dramatic lighting, film grain, 8K detail",
      storyBible: `Topic: ${params.userStory}. General cinematic storytelling approach.`,
      directorLoopCount: loopCount,
      selectedLenses: []
    };
  }
}

async function evaluateEngagement(params) {
  const plan = params.narrativePlan ?? [];
  if (plan.length === 0) {
    return { engagementScore: 0, engagementFeedback: "No narrative plan to evaluate." };
  }
  const blockCount = plan.length;
  const dimensions = [
    { key: "hookStrength", prompt: "Does block 1 grab attention in 2 seconds? Is there a question, surprising fact, or emotional provocation?" },
    { key: "specificity", prompt: 'Are scripts full of concrete details (names, numbers, moments) or vague platitudes like "he worked hard"?' },
    { key: "scriptQuality", prompt: "Do the spokenScripts sound natural spoken aloud? Are they punchy, conversational, with rhythm \u2014 or do they read like essays?" }
  ];
  if (blockCount >= 2) {
    dimensions.push({ key: "emotionalProgression", prompt: "Does the tone evolve across blocks? Is there tension, contrast, peaks and valleys \u2014 or is it flat?" });
  }
  if (blockCount >= 3) {
    dimensions.push({ key: "distinctness", prompt: "Does each block cover genuinely different ground, or do they repeat the same idea in different words?" });
  }
  const dimensionList = dimensions.map((d, i) => `${i + 1}. ${d.key}: ${d.prompt}`).join("\n");
  const scoresShape = `{ ${dimensions.map((d) => `"${d.key}": N`).join(", ")} }`;
  const scripts = plan.map(
    (p, i) => `Block ${i + 1} [${p.narrativeRole}]: "${p.spokenScript}" (key: ${p.keyMessage})`
  ).join("\n");
  try {
    const response = await callAIWithTracking({
      messages: [
        {
          role: "system",
          content: `You are a ruthlessly honest video engagement consultant who has analyzed
thousands of viral short-form videos.

\u26A0\uFE0F HARD CONSTRAINT \u2014 THE BLOCK COUNT IS FIXED AT ${blockCount}.
You are evaluating quality WITHIN the given structure. You MUST NOT recommend
adding, removing, splitting, or merging blocks. The user chose this structure
deliberately. Score only what's achievable at this block count.

Score this narrative plan on ${dimensions.length} dimensions (0-10 each):

${dimensionList}

Calculate overallScore as the average of the dimensions above (do not penalize
for "missing" dimensions \u2014 they were intentionally excluded because this is a
${blockCount}-block video). Set pass=true if overallScore >= ${ENGAGEMENT_THRESHOLD}.
If pass=false, write specific, actionable feedback pointing to EXACT blocks and
what to fix WITHIN the existing ${blockCount}-block structure.

Return ONLY this JSON (no markdown):
{
  "scores": ${scoresShape},
  "overallScore": N,
  "pass": true/false,
  "feedback": "string \u2014 specific issues and which blocks to fix (empty if pass=true). Never suggest changing block count."
}${params.language !== "en" ? `

NOTE: The scripts are written in ${languageName(params.language)}. Evaluate engagement quality regardless of language. Write your feedback in English.` : ""}`
        },
        {
          role: "user",
          content: `Story: "${params.userStory}"

Narrative plan to evaluate:
${scripts}

Be honest. A 7 is good enough. Only fail if there are clear structural weaknesses.`
        }
      ],
      apiKey: params.apiKey,
      maxTokens: 500,
      model: params.model
    });
    const result = parseJSON(response);
    const score = Number(result.overallScore) || 0;
    const feedback = result.feedback || "";
    console.log(`[evaluateEngagement] score: ${score}/10 pass: ${result.pass} (attempt ${params.directorLoopCount}/${MAX_DIRECTOR_LOOPS})`);
    if (!result.pass && feedback) {
      console.log(`[evaluateEngagement] feedback: ${feedback.slice(0, 200)}`);
    }
    return { engagementScore: score, engagementFeedback: feedback };
  } catch (e) {
    console.warn("[evaluateEngagement] \u26A0\uFE0F eval failed, passing by default:", e.message);
    return { engagementScore: ENGAGEMENT_THRESHOLD, engagementFeedback: "" };
  }
}

const RESPONSE_FORMAT_TEMPLATES = {
  "tower-chart-3d": `{
  "title": "string",
  "subtitle": "string | null",
  "items": [
    {
      "rank": 1,
      "name": "string",
      "value": 0,
      "valueFormatted": "string | null",
      "subtitle": "string | null",
      "image": "string | null"
    }
  ]
}`,
  "stat": `{
  "heading": "string",
  "value": "string",
  "subtext": "string"
}`,
  "text": `{
  "content": "string"
}`,
  "quote": `{
  "text": "string",
  "author": "string"
}`,
  "image": `{
  "src": "string",
  "alt": "string",
  "caption": "string"
}`,
  "motivational-image": `{
  "imageSrc": "string",
  "text": "string",
  "audioSrc": "string"
}`,
  "testimonial": `{
  "quote": "string",
  "author": "string",
  "role": "string",
  "company": "string"
}`,
  "list": `{
  "title": "string",
  "items": ["string"]
}`,
  "top-players": `{
  "title": "string",
  "subtitle": "string",
  "backgroundImage": "vivid wide-scene description",
  "audioSrc": "narration text for the whole block",
  "players": [
    { "rank": 1, "name": "string", "subtitle": "position \u2022 key stat (e.g. 'India \u2022 15,921 runs')", "image": "vivid portrait description" },
    { "rank": 2, "name": "string", "subtitle": "position \u2022 key stat", "image": "vivid portrait description" },
    { "rank": 3, "name": "string", "subtitle": "position \u2022 key stat", "image": "vivid portrait description" },
    { "rank": 4, "name": "string", "subtitle": "position \u2022 key stat", "image": "vivid portrait description" },
    { "rank": 5, "name": "string", "subtitle": "position \u2022 key stat", "image": "vivid portrait description" }
  ]
}`,
  "timeline": `{
  "title": "string",
  "events": [
    { "year": "string", "title": "string", "description": "string" }
  ]
}`,
  "callout": `{
  "title": "string",
  "content": "string",
  "variant": "info"
}`,
  "parallax-story": `{
  "title": "string",
  "subtitle": "string",
  "text": "string",
  "audioSrc": "string",
  "layers": [
    {
      "name": "background",
      "image": "vivid wide-scene description",
      "depth": 90,
      "parallaxFactor": 0.3,
      "motionDirection": "right",
      "removeBackground": false
    },
    {
      "name": "midground",
      "image": "vivid description of mid-depth element",
      "depth": 50,
      "parallaxFactor": 0.7,
      "motionDirection": "left",
      "removeBackground": true
    },
    {
      "name": "subject",
      "image": "vivid description of the main foreground subject",
      "depth": 15,
      "parallaxFactor": 1.2,
      "motionDirection": "zoom-in",
      "removeBackground": true
    }
  ]
}`,
  "video": `{
  "src": "",
  "caption": "string",
  "text": "string - narration displayed as subtitle overlay",
  "audioSrc": "string - MUST be identical to text"
}`,
  html: `{
  "htmlContent": "string - complete HTML document with inline <style> and <script>",
  "title": "string",
  "audioSrc": "string - REQUIRED narration text to be spoken aloud via TTS"
}`,
  diagram: `{
  "diagramType": "flowchart | hierarchy | sequence | mindmap | network",
  "title": "string",
  "nodes": [
    { "id": "string", "label": "string", "type": "default|decision|start|end|process", "color": "hex" }
  ],
  "edges": [
    { "from": "string", "to": "string", "label": "string", "style": "arrow|solid|dashed" }
  ],
  "layout": "vertical | horizontal | radial",
  "primaryColor": "hex",
  "audioSrc": "string - REQUIRED narration text to be spoken aloud via TTS"
}`
};
function getResponseFormatTemplate(blockType) {
  return RESPONSE_FORMAT_TEMPLATES[blockType] || "";
}
const BLOCK_SCHEMAS = {
  stat: {
    contentFields: ["heading", "value", "subtext", "audioSrc"],
    textFields: "heading (string - label), value (string - the metric), subtext (string - context)",
    imageFields: "",
    audioFields: "audioSrc (string - narrate the stat aloud)",
    example: '{"heading":"Test Centuries","value":"27","subtext":"Most by an Indian batter","audioSrc":"Virat Kohli has scored 27 centuries in Test cricket, the most by any Indian batter."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  text: {
    contentFields: ["content", "audioSrc"],
    textFields: "content (string - full paragraph)",
    imageFields: "",
    audioFields: "audioSrc (string - content read aloud)",
    example: '{"content":"Virat Kohli is widely regarded as one of the greatest batsmen of all time.","audioSrc":"Virat Kohli is widely regarded as one of the greatest batsmen of all time."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  quote: {
    contentFields: ["text", "author", "audioSrc"],
    textFields: "text (string - the quote), author (string)",
    imageFields: "",
    audioFields: "audioSrc (string - read quote with attribution aloud)",
    example: '{"text":"Self-belief and hard work will always earn you success.","author":"Virat Kohli","audioSrc":"Virat Kohli once said: Self-belief and hard work will always earn you success."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  image: {
    contentFields: ["src", "alt", "caption", "audioSrc"],
    textFields: "alt (string), caption (string)",
    imageFields: "src (string - vivid visual description of the image)",
    audioFields: "audioSrc (string - narrate what is shown)",
    example: '{"src":"Virat Kohli raising bat in celebration at packed Wankhede Stadium","alt":"Kohli century celebration","caption":"100th international century","audioSrc":"Virat Kohli celebrates yet another century, raising his bat to the roaring crowd."}',
    normalizedFields: [
      { path: "src", type: "image", description: "vivid visual description of the image", removeBackground: false },
      { path: "audioSrc", type: "audio", description: "" }
    ]
  },
  "motivational-image": {
    contentFields: ["imageSrc", "text", "audioSrc"],
    textFields: `text: REQUIRED string \u2014 the narration script spoken aloud AND displayed as subtitles (2-4 sentences, natural spoken language)
imageSrc: REQUIRED string (vivid visual description of background image)`,
    imageFields: "imageSrc (string - vivid visual scene description)",
    audioFields: 'audioSrc: REQUIRED string \u2014 MUST be identical to the "text" field so subtitles match the audio exactly',
    example: '{"imageSrc":"Athlete sprinting on track at golden hour, dramatic side lighting","text":"Champions are not born. They are forged in the moments when they want to quit but keep going.","audioSrc":"Champions are not born. They are forged in the moments when they want to quit but keep going."}',
    normalizedFields: [
      { path: "imageSrc", type: "image", description: "vivid visual scene description", removeBackground: false },
      { path: "audioSrc", type: "audio", description: "" }
    ]
  },
  testimonial: {
    contentFields: ["quote", "author", "role", "company", "avatar", "audioSrc"],
    textFields: `quote: REQUIRED string
author: REQUIRED string
role: optional string
company: optional string`,
    imageFields: "avatar: optional string \u2014 describe person appearance",
    audioFields: "audioSrc: optional string \u2014 read testimonial aloud",
    example: '{"quote":"Changed the game.","author":"John Smith","role":"Coach","avatar":"Professional in blazer"}',
    normalizedFields: [
      { path: "avatar", type: "image", description: "describe person appearance", removeBackground: false },
      { path: "audioSrc", type: "audio", description: "" }
    ]
  },
  list: {
    contentFields: ["title", "items", "audioSrc"],
    textFields: `title: REQUIRED string
items: REQUIRED array of strings (each item is a list bullet point)`,
    imageFields: "",
    audioFields: "audioSrc: optional string \u2014 read list aloud",
    example: `{"title":"Kohli Records","items":["50+ ODI centuries","Fastest to 10000 ODI runs"],"audioSrc":"Here are some of Virat Kohli's greatest records."}`,
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  timeline: {
    contentFields: ["title", "events", "audioSrc"],
    textFields: `title: REQUIRED string
events: REQUIRED array of objects (chronological order), each with:
  - year: REQUIRED string or number
  - title: REQUIRED string
  - description: optional string`,
    imageFields: "",
    audioFields: "audioSrc: optional string \u2014 narrate timeline",
    example: '{"title":"Kohli Journey","events":[{"year":"2008","title":"IPL Debut","description":"RCB"},{"year":"2011","title":"World Cup","description":"Winner"}]}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  callout: {
    contentFields: ["title", "content", "variant", "audioSrc"],
    textFields: `title: REQUIRED string
content: REQUIRED string
variant: REQUIRED string (one of: info, warning, success, error)`,
    imageFields: "",
    audioFields: "audioSrc: optional string \u2014 read callout aloud",
    example: '{"title":"Did You Know?","content":"Only player to avg 50+ all formats","variant":"info"}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  "icon-list": {
    contentFields: ["title", "items", "audioSrc"],
    textFields: "title (string), items (array of {icon, title, description})",
    imageFields: "",
    audioFields: "audioSrc (string - narrate the list)",
    example: '{"title":"Why Kohli is GOAT","items":[{"icon":"\u{1F3CF}","title":"Run Machine","description":"50+ centuries across formats"},{"icon":"\u{1F4AA}","title":"Fitness Icon","description":"Transformed Indian cricket culture"}],"audioSrc":"Here is why Virat Kohli is considered the GOAT."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  comparison: {
    contentFields: ["title", "items", "audioSrc"],
    textFields: "title (string), items (array of {label, value, color})",
    imageFields: "",
    audioFields: "audioSrc (string - narrate the comparison)",
    example: '{"title":"Batting Averages","items":[{"label":"Kohli","value":57},{"label":"Root","value":50},{"label":"Smith","value":61}],"audioSrc":"Comparing batting averages of the top batsmen of this generation."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  "line-chart": {
    contentFields: ["title", "subtitle", "data", "labels", "xAxisLabel", "yAxisLabel", "unit", "showDataLabels", "audioSrc"],
    textFields: 'title (string), subtitle (string \u2014 context for the chart), data (number[] \u2014 y-axis values), labels (string[] \u2014 x-axis labels, same length as data), xAxisLabel (string \u2014 x-axis title), yAxisLabel (string \u2014 y-axis title), unit (string \u2014 suffix like "$", "%", "K"), showDataLabels (boolean \u2014 show value at each point)',
    imageFields: "",
    audioFields: "audioSrc (string - narrate the trend)",
    example: '{"title":"Revenue Growth","subtitle":"Quarterly performance 2024","data":[120,185,210,340],"labels":["Q1","Q2","Q3","Q4"],"xAxisLabel":"Quarter","yAxisLabel":"Revenue","unit":"K","showDataLabels":true,"audioSrc":"Revenue grew from 120K to 340K over four quarters."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  "pie-chart": {
    contentFields: ["title", "subtitle", "segments", "showPercentage", "showLegend", "audioSrc"],
    textFields: "title (string), subtitle (string \u2014 context), segments (array of {label, value, color}), showPercentage (boolean, default true), showLegend (boolean, default true)",
    imageFields: "",
    audioFields: "audioSrc (string - narrate the distribution)",
    example: '{"title":"Market Share","subtitle":"Global smartphone brands 2024","segments":[{"label":"Apple","value":28},{"label":"Samsung","value":20},{"label":"Xiaomi","value":13},{"label":"Others","value":39}],"audioSrc":"Apple leads with 28% market share."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  "whatsapp-chat": {
    contentFields: ["person1", "person2", "messages", "audioSrc"],
    textFields: "person1 ({name}), person2 ({name}), messages (array of {from: person1|person2, text, time})",
    imageFields: "",
    audioFields: "audioSrc (string - narrate the conversation context aloud)",
    example: '{"person1":{"name":"Fan"},"person2":{"name":"Kohli Bot"},"messages":[{"from":"person1","text":"Kohli is the best ever!","time":"10:30"},{"from":"person2","text":"Thanks! Hard work always pays off \u{1F3CF}","time":"10:31"}],"audioSrc":"A fan reaches out to Virat Kohli with a message of admiration."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  counter: {
    contentFields: ["label", "from", "to", "prefix", "suffix", "audioSrc"],
    textFields: "label (string), from (number), to (number), prefix (string), suffix (string)",
    imageFields: "",
    audioFields: "audioSrc (string - narrate the counter)",
    example: '{"label":"ODI Centuries","from":0,"to":50,"suffix":"+","audioSrc":"Virat Kohli has scored over fifty centuries in One Day Internationals."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  "progress-bar": {
    contentFields: ["label", "value", "audioSrc"],
    textFields: "label (string), value (number 0-100)",
    imageFields: "",
    audioFields: "audioSrc (string - narrate the stat)",
    example: '{"label":"Win Rate as Captain","value":58,"audioSrc":"Virat Kohli won 58 percent of his matches as Indian captain."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  "social-stats": {
    contentFields: ["platform", "username", "followers", "posts", "likes", "audioSrc"],
    textFields: "platform (instagram|twitter|youtube|tiktok|linkedin|facebook), username (string), followers (number), posts (number), likes (number)",
    imageFields: "",
    audioFields: "audioSrc (string - narrate the social stats aloud)",
    example: '{"platform":"instagram","username":"virat.kohli","followers":260000000,"posts":1200,"audioSrc":"Virat Kohli has over two hundred and sixty million followers on Instagram, making him one of the most followed athletes in the world."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  cta: {
    contentFields: ["text", "description", "audioSrc"],
    textFields: "text (string - button label), description (string - supporting text)",
    imageFields: "",
    audioFields: "audioSrc (string - read CTA aloud)",
    example: '{"text":"Follow Kohli","description":"Join 260M fans following the king of cricket","audioSrc":"Follow Virat Kohli and join two hundred and sixty million fans following the king of cricket."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  "gradient-text": {
    contentFields: ["text", "gradient", "audioSrc"],
    textFields: "text (string - headline), gradient (array of 2-3 hex colors)",
    imageFields: "",
    audioFields: "audioSrc (string - read text aloud)",
    example: '{"text":"King Kohli","gradient":["#FF6B35","#F7C59F"],"audioSrc":"King Kohli."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  "avatar-grid": {
    contentFields: ["title", "subtitle", "avatars", "audioSrc"],
    textFields: "title (string), subtitle (string), avatars (array of {name, role})",
    imageFields: "avatars[N].image (describe each person visually)",
    audioFields: "audioSrc (string - introduce the people shown)",
    example: `{"title":"Kohli's Era","avatars":[{"name":"Virat Kohli","role":"Batsman","image":"Virat Kohli in Indian cricket whites smiling"},{"name":"MS Dhoni","role":"Wicketkeeper","image":"MS Dhoni in yellow CSK jersey"}],"audioSrc":"Meet the legends of Indian cricket's golden era."}`,
    normalizedFields: [
      { path: "avatars[].image", type: "image", description: "describe person visually", removeBackground: false },
      { path: "audioSrc", type: "audio", description: "" }
    ]
  },
  countdown: {
    contentFields: ["title", "days", "hours", "minutes", "seconds", "audioSrc"],
    textFields: "title (string), days (number), hours (number), minutes (number), seconds (number)",
    imageFields: "",
    audioFields: "audioSrc (string - narrate the countdown context)",
    example: '{"title":"Next Kohli Test","days":5,"hours":12,"minutes":30,"seconds":0,"audioSrc":"Just five days until Virat Kohli takes the field again."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  "animated-bg": {
    contentFields: ["style", "primaryColor", "secondaryColor", "audioSrc"],
    textFields: "style (particles|waves|gradient|noise|geometric|aurora), primaryColor (hex), secondaryColor (hex)",
    imageFields: "",
    audioFields: "audioSrc (string - short atmospheric narration to accompany the visual)",
    example: '{"style":"particles","primaryColor":"#1a73e8","secondaryColor":"#ff4500","audioSrc":"A legendary career, defined by fire and precision."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  "parallax-story": {
    contentFields: ["title", "subtitle", "text", "audioSrc", "layers"],
    textFields: `title (string), subtitle (string)
text: REQUIRED string \u2014 the narration script spoken aloud AND displayed as subtitles (2-4 sentences, natural spoken language). This MUST be identical to audioSrc so subtitles match the audio exactly.`,
    imageFields: `layers[N].image (describe each parallax layer visually).
Each layer MUST have a "removeBackground" boolean. Rules:
  \u2022 EXACTLY ONE layer must have "removeBackground": false \u2014 the single backdrop layer (wide scene, environment, landscape). This is the only layer that will use the normal image API.
  \u2022 ALL other layers must have "removeBackground": true \u2014 characters, people, objects, elements floating over the background. These will be generated as transparent cut-outs using the background-removal API.
You decide which layer is the backdrop based on the story context.`,
    audioFields: 'audioSrc: REQUIRED string \u2014 MUST be identical to the "text" field so subtitles match the audio exactly',
    example: `{"title":"The Kohli Era","subtitle":"A legacy like no other","layers":[{"name":"background","image":"Cricket stadium aerial view at golden hour, full wide scene","depth":90,"parallaxFactor":0.3,"motionDirection":"right","removeBackground":false},{"name":"midground","image":"Cheering crowd at cricket stadium","depth":50,"parallaxFactor":0.7,"motionDirection":"left","removeBackground":true},{"name":"subject","image":"Virat Kohli in batting stance dramatic lighting full body","depth":15,"parallaxFactor":1.2,"motionDirection":"zoom-in","removeBackground":true}],"text":"From a Delhi boy to a global icon. Virat Kohli's journey is a story of relentless determination.","audioSrc":"From a Delhi boy to a global icon. Virat Kohli's journey is a story of relentless determination."}`,
    normalizedFields: [
      // removeBackground: undefined → data-driven per layer (read from layers[i].removeBackground at runtime)
      { path: "layers[].image", type: "image", description: "vivid parallax layer visual description", removeBackground: void 0 },
      { path: "audioSrc", type: "audio", description: "" }
    ]
  },
  "tower-chart-3d": {
    contentFields: ["title", "subtitle", "items"],
    textFields: "title (string), subtitle (string), items (array of {rank, name, value, valueFormatted, subtitle, image})",
    imageFields: "items[N].image (optional \u2014 describe visual for each item)",
    audioFields: "",
    example: '{"title":"Top Scorers","subtitle":"All-time leading run scorers","items":[{"rank":1,"name":"Sachin Tendulkar","value":15921,"valueFormatted":"15,921","subtitle":"Test Runs","image":"Sachin Tendulkar in Indian whites"}]}',
    normalizedFields: [
      { path: "items[].image", type: "image", description: "visual for this item", removeBackground: false }
    ]
  },
  "top-players": {
    contentFields: ["title", "subtitle", "backgroundImage", "audioSrc", "players"],
    textFields: 'title (string), subtitle (string), backgroundImage (string \u2014 vivid visual description of the background scene), players[].rank (integer starting at 1), players[].name (string), players[].subtitle (position \u2022 key stat, e.g. "India \u2022 15,921 runs")',
    imageFields: "backgroundImage (vivid wide scene description), players[N].image (describe each player visually \u2014 will have background removed)",
    audioFields: "audioSrc (narration text for the whole block)",
    example: '{"title":"Greatest Batsmen Ever","subtitle":"All-time Test run scorers","backgroundImage":"Cricket stadium at sunset, green pitch, packed stands","audioSrc":"Counting down the greatest batsmen of all time.","players":[{"rank":1,"name":"Sachin Tendulkar","subtitle":"India \u2022 15,921 runs","image":"Sachin Tendulkar in Indian whites, bat raised, close-up portrait"},{"rank":2,"name":"Ricky Ponting","subtitle":"Australia \u2022 13,378 runs","image":"Ricky Ponting in Australian whites, determined expression"},{"rank":3,"name":"Jacques Kallis","subtitle":"South Africa \u2022 13,289 runs","image":"Jacques Kallis in South Africa green jersey, confident pose"},{"rank":4,"name":"Rahul Dravid","subtitle":"India \u2022 13,288 runs","image":"Rahul Dravid in Indian whites, batting stance"},{"rank":5,"name":"Kumar Sangakkara","subtitle":"Sri Lanka \u2022 12,400 runs","image":"Kumar Sangakkara in Sri Lanka blue jersey, gloves on"}]}',
    normalizedFields: [
      { path: "backgroundImage", type: "image", description: "vivid wide scene background", removeBackground: false },
      { path: "players[].image", type: "image", description: "vivid player portrait", removeBackground: true },
      { path: "audioSrc", type: "audio", description: "" }
    ]
  },
  video: {
    contentFields: ["src", "caption", "text", "audioSrc"],
    textFields: "caption (string), text (string \u2014 narration subtitle overlay)",
    imageFields: "",
    audioFields: "audioSrc (string \u2014 MUST be identical to text)",
    example: '{"src":"Close-up of product dashboard on widescreen monitor, documents streaming into organized folders, clean dark UI with blue accent lights","caption":"Product Demo","text":"Watch how our product organizes your workflow effortlessly.","audioSrc":"Watch how our product organizes your workflow effortlessly."}',
    normalizedFields: [
      { path: "src", type: "video", description: "cinematic scene description for video generation" },
      { path: "audioSrc", type: "audio", description: "" }
    ]
  },
  html: {
    contentFields: ["htmlContent", "title", "audioSrc"],
    textFields: "title (string)",
    imageFields: "",
    audioFields: "audioSrc (string \u2014 REQUIRED narration text to be spoken aloud via TTS)",
    example: '{"htmlContent":"<!DOCTYPE html><html>...</html>","title":"Feature Slide","audioSrc":"Introducing our most powerful feature yet."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  diagram: {
    contentFields: ["diagramType", "title", "nodes", "edges", "layout", "primaryColor", "audioSrc"],
    textFields: "title (string), diagramType (flowchart|hierarchy|sequence|mindmap|network), layout (vertical|horizontal|radial)",
    imageFields: "",
    audioFields: "audioSrc (string \u2014 REQUIRED narration text)",
    example: '{"diagramType":"flowchart","title":"User Journey","layout":"vertical","primaryColor":"#6366f1","nodes":[{"id":"n1","label":"Start","type":"start","color":"#6366f1"},{"id":"n2","label":"Process","type":"process","color":"#8b5cf6"}],"edges":[{"from":"n1","to":"n2","label":"","style":"arrow"}],"audioSrc":"Here is the user journey flow."}',
    normalizedFields: [{ path: "audioSrc", type: "audio", description: "" }]
  },
  "custom-plugin": {
    contentFields: [],
    textFields: "",
    imageFields: "",
    audioFields: "",
    example: "{}"
  }
};

function getAspectRatioDimensions(ratio) {
  const ratios = {
    "16:9": { width: 1920, height: 1080 },
    "9:16": { width: 1080, height: 1920 },
    "1:1": { width: 1080, height: 1080 },
    "4:5": { width: 1080, height: 1350 }
  };
  return ratios[ratio] ?? ratios["9:16"];
}

async function generateContent(params) {
  console.log(`[generate_content] \u25B6 block ${params.blockIndex + 1}: ${params.blockType}`);
  const { width, height } = getAspectRatioDimensions(params.aspectRatio ?? "9:16");
  const orientation = width > height ? "landscape" : "portrait";
  const dimLabel = `${width}\xD7${height} ${orientation}`;
  const brief = params.narrativeBrief;
  if (params.blockType === "custom-plugin") {
    const genFields = params.originalBlock?.generationFields ?? [];
    const imagePaths = genFields.filter((f) => f.type === "image").map((f) => f.path);
    const audioPaths = genFields.filter((f) => f.type === "audio").map((f) => f.path);
    const mediaPathSet = /* @__PURE__ */ new Set([...imagePaths, ...audioPaths]);
    const META_KEYS = /* @__PURE__ */ new Set([
      "type",
      "generationFields",
      "pluginId",
      "blockIndex",
      "duration",
      "id",
      "pluginData",
      "margin",
      "enterAnimation",
      "exitAnimation",
      "animationDuration",
      "backgroundBlur",
      "borderWidth",
      "borderRadius",
      "shadowEnabled",
      "shadowColor",
      "shadowBlur"
    ]);
    const allContentKeys = Object.keys(params.originalBlock ?? {}).filter((k) => !META_KEYS.has(k));
    const textKeys = allContentKeys.filter((k) => !mediaPathSet.has(k));
    const storyContext = brief ? `
NARRATIVE BRIEF:
- Role:         ${brief.narrativeRole}
- Angle:        ${brief.angle}
- Tone:         ${brief.tone}
- Key message:  ${brief.keyMessage}
- Visual mood:  ${brief.visualMood}
${brief.spokenScript ? `
SPOKEN SCRIPT (use verbatim for any audio field):
"${brief.spokenScript}"` : ""}
` : "";
    const schemaDesc = params.schemaDescriptions ?? {};
    const descNote = (path) => schemaDesc[path] ? ` [${schemaDesc[path]}]` : "";
    const fieldInstructions = [
      textKeys.length > 0 && `TEXT FIELDS (fill with real, specific content grounded in the topic):
${textKeys.map((k) => `  ${k}${descNote(k)}`).join("\n")}`,
      imagePaths.length > 0 && `IMAGE FIELDS \u2014 write a vivid, CONTEXT-SPECIFIC visual description (NOT a URL). Derive the subject from the text fields you just filled \u2014 include real names, titles, products, people:
${imagePaths.map((p) => `  ${p}${descNote(p)}`).join("\n")}`,
      audioPaths.length > 0 && `AUDIO FIELDS (exact words to be spoken aloud${brief?.spokenScript ? " \u2014 copy the spoken script above word-for-word" : ""}):
${audioPaths.map((p) => `  ${p}${descNote(p)}`).join("\n")}`
    ].filter(Boolean).join("\n\n");
    const structureRef = Object.fromEntries(
      allContentKeys.map((k) => [
        k,
        mediaPathSet.has(k) ? "<descriptive text here \u2014 NOT a URL>" : params.originalBlock[k] ?? ""
      ])
    );
    try {
      const response = await callAIWithTracking({
        messages: [
          {
            role: "system",
            content: `You are a video content generator filling a custom plugin block.
${storyContext}
FIELD DEFINITIONS:
${fieldInstructions}

RULES:
1. Return a single flat JSON object with ALL fields filled. No markdown, no extra keys.
2. Image fields MUST be descriptive text, never URLs.
3. Be SPECIFIC \u2014 real names, numbers, facts.${params.language !== "en" ? `
4. LANGUAGE: viewer-facing text MUST be in ${languageName(params.language)}. JSON keys stay English.` : ""}

Structure reference (template defaults \u2014 replace with real content):
${JSON.stringify(structureRef, null, 2)}`
          },
          {
            role: "user",
            content: `Topic: "${params.userStory}"
${brief ? `Your job this block: ${brief.keyMessage}` : ""}

Generate the JSON content now.`
          }
        ],
        apiKey: params.apiKey,
        maxTokens: 1500,
        model: params.model
      });
      const rawContent = parseJSON(response);
      if (brief?.spokenScript) {
        for (const p of audioPaths) {
          if (rawContent[p] !== void 0) rawContent[p] = brief.spokenScript;
        }
        if (rawContent.audioSrc !== void 0) rawContent.audioSrc = brief.spokenScript;
      }
      console.log("[generate_content] \u2705 custom-plugin rawContent keys:", Object.keys(rawContent).join(", "));
      return { rawContent, error: null };
    } catch (e) {
      return { error: `generate_content (custom-plugin) failed: ${e.message}`, rawContent: {} };
    }
  }
  const schema = BLOCK_SCHEMAS[params.blockType];
  if (!schema) {
    console.warn(`[generate_content] No schema for: ${params.blockType}`);
    return { error: `Unknown block type: ${params.blockType}`, rawContent: {} };
  }
  const narrativeContext = brief ? `
NARRATIVE BRIEF FROM DIRECTOR:
- Role in story:        ${brief.narrativeRole}
- Specific angle:       ${brief.angle}
- Tone:                 ${brief.tone}
- Key message:          ${brief.keyMessage}
- Visual mood:          ${brief.visualMood}
- Connection from prev: ${brief.transitionIn}
- Lead into next:       ${brief.transitionOut}

SPOKEN SCRIPT (use this EXACT text for any audioSrc / TTS field \u2014 do NOT rewrite it):
"${brief.spokenScript}"

IMPORTANT: Stay on your assigned angle. Do NOT repeat content from other blocks.
Your ONE job: "${brief.keyMessage}"
For any audioSrc field, copy the SPOKEN SCRIPT above word-for-word.
` : "";
  const storyBibleContext = params.storyBible ? `
STORY BIBLE (shared facts \u2014 use these consistently, do NOT contradict):
${params.storyBible}
` : "";
  const runPlan = getRunContext()?.read("plan.md");
  const runPlanContext = runPlan ? `
RUN PLAN:
${runPlan}
` : "";
  const lensHints = (params.selectedLenses ?? []).map((lens) => CONSISTENCY_LENS_CONFIGS[lens]?.contentGeneratorHint).filter(Boolean).join("\n\n");
  const lensHintSection = lensHints ? `
CONSISTENCY RULES FOR THIS VIDEO:
${lensHints}
` : "";
  const blockStrategy = params.mediaStrategy?.blockStrategies?.find((b) => b.blockIndex === params.blockIndex);
  const useWebSearch = blockStrategy && params.blockType !== "video" ? blockStrategy.imageSource !== "ai_generation" : false;
  const queryStyleHint = blockStrategy?.searchQueryStyle ?? "photo";
  const imageFieldInstruction = useWebSearch ? `IMAGE FIELDS (write a SEARCH QUERY to find a real ${queryStyleHint} on the web \u2014 be specific, include product names, UI names, years):
  ${schema.imageFields}` : `IMAGE FIELDS (write vivid visual description \u2014 NOT a URL. IMPORTANT: Ground your description in the ACTUAL CONTENT above \u2014 extract specific names, numbers, quotes, product names, dates, or key phrases from the Research Context, Story Bible, and Narrative Brief and include them as TEXT VISIBLY IN THE SCENE. Do not write generic aesthetic descriptions. Example: instead of "a product on dark background", write "the XYZ app dashboard on dark background with bold text '50K users' overlaid"):
  ${schema.imageFields}`;
  const schemaDescription = [
    schema.textFields && `TEXT FIELDS (fill with real content):
  ${schema.textFields}`,
    schema.imageFields && imageFieldInstruction,
    schema.audioFields && `AUDIO/TTS FIELDS (write exact words to be spoken aloud):
  ${schema.audioFields}`
  ].filter(Boolean).join("\n\n");
  try {
    if (params.blockType === "html") {
      let stripMarkdown2 = function(html) {
        let result = html.trim();
        if (result.startsWith("```html")) result = result.slice(7);
        else if (result.startsWith("```")) result = result.slice(3);
        if (result.endsWith("```")) result = result.slice(0, -3);
        return result.trim();
      }, isHtmlComplete2 = function(html) {
        return html.trim().toLowerCase().endsWith("</html>");
      };
      console.log("[generate_content] \u{1F3A8} HTML block \u2014 using two-step raw-HTML generation");
      const conceptPrompt = brief ? `You are a creative director designing a HIGHLY GRAPHICAL animated slide for a short video.

STORY CONTEXT:
- Topic: "${params.userStory}"
- Role in story: ${brief.narrativeRole}
- Angle: ${brief.angle}
- Tone: ${brief.tone}
- Key message: ${brief.keyMessage}
- Visual mood: ${brief.visualMood}

Pick ONE concept that best communicates the key message as a visually rich slide:
- Product showcase (hero product + feature callouts + specs chips)
- App UI / dashboard showcase (charts + KPI tiles + sidebar)
- Before/After transformation (split screen with labels)
- Comparison showdown (2-column with animated bars)
- Timeline / roadmap (milestones + connecting line + pulsing nodes)
- Data story (big number + animated chart + annotations)
- Process slide (step cards + arrows + progress indicator)
- Social proof slide (logos wall + quote + rating badge)
- Pricing slide (tier columns + highlight + badge)
- Architecture diagram slide (nodes/edges but modern)
- "Keynote" quote slide (big type + kinetic background + accent shapes)

Return ONLY strict JSON (no markdown) with this schema:
{
  "concept": "one of the concepts above",
  "layout": "hero-left|hero-right|centered|split|grid|dashboard",
  "palette": { "bg": "#RRGGBB", "accent1": "#RRGGBB", "accent2": "#RRGGBB", "text": "#RRGGBB" },
  "headline": "6-10 words max",
  "subheadline": "short, optional",
  "bullets": ["3-5 short bullets max"],
  "badges": ["0-3 tiny label chips"],
  "heroGraphic": "describe the main graphic",
  "motionPlan": ["3-6 short animation beats tied to time (0-5s)"],
  "avoid": ["things to avoid that could clutter/crop"]
}

RULES:
- Must be readable in 3\u20135 seconds.
- Use large typography (min 48px headline).
- Prefer bold shapes, gradients, glow, shadows, and inline SVG icons.
- Design for ${dimLabel}.
- Avoid content that requires scrolling.` : `You are a creative director. Return ONLY strict JSON with keys: concept, layout, palette, headline, subheadline, bullets, badges, heroGraphic, motionPlan, avoid. Topic: "${params.userStory}"`;
      let conceptPlan = {};
      try {
        const conceptRaw = await callAIWithTracking({
          messages: [
            { role: "system", content: conceptPrompt },
            { role: "user", content: "Pick a strong concept and return the JSON plan now." }
          ],
          apiKey: params.apiKey,
          maxTokens: 900,
          model: params.model
        });
        conceptPlan = parseJSON(conceptRaw);
      } catch (e) {
        console.warn("[generate_content] \u26A0\uFE0F concept planner failed (non-fatal):", e);
      }
      const MAX_HTML_RETRIES = 3;
      let htmlContent = "";
      let htmlAttempts = 0;
      let isComplete = false;
      while (!isComplete && htmlAttempts < MAX_HTML_RETRIES) {
        htmlAttempts++;
        if (htmlAttempts === 1) {
          const htmlOnlySystemPrompt = brief ? `You are an expert HTML/CSS/JS developer creating a single-file animated slide for a video frame.

STORY CONTEXT:
- Topic: "${params.userStory}"
- Role in story: ${brief.narrativeRole}
- Angle: ${brief.angle}
- Tone: ${brief.tone}
- Key message: ${brief.keyMessage}
- Visual mood: ${brief.visualMood}

CONCEPT PLAN (use for layout / palette guidance):
${JSON.stringify(conceptPlan, null, 2)}
${lensHintSection}
OUTPUT RULES \u2014 CRITICAL:
1. Output ONLY the raw HTML document. No JSON, no markdown fences, no explanation before or after.
2. Start your response with exactly: <!DOCTYPE html>
3. End your response with exactly: </html>
4. The document must be 100% self-contained (inline CSS + inline JS, no external resources).
5. Optimised for a ${dimLabel} video frame.
6. Use CSS animations driven by window.__remotionTime (seconds, 0-based) for timeline sync.
7. Dark gradient backgrounds preferred; minimum 48px headline; minimum 24px body text.
8. HARD REQUIREMENTS:
   - 3 visual layers: background shapes + hero graphic + foreground text/callouts
   - At least 2 inline SVG icons
   - One mini SVG data viz (sparkline, radial meter, or area chart)
   - Staged entrance animations: 0\u20130.6s bg, 0.6\u20131.6s headline, 1.6\u20133.0s callouts, 3.0\u20135s loop
9. No scrolling; use flex/grid, not fixed pixel positioning.
10. MANDATORY FULL-FRAME CSS \u2014 always include in <style>:
    html, body { margin: 0; padding: 0; width: ${width}px; height: ${height}px; overflow: hidden; }
    Never use auto height or partial-width containers on the outermost elements.` : `You are an expert HTML/CSS/JS developer. Create a single-file animated slide for a video about: "${params.userStory}".
OUTPUT RULES:
1. Output ONLY the raw HTML. Start with <!DOCTYPE html>, end with </html>. No JSON, no markdown.
2. Self-contained, ${dimLabel}, dark background, large readable text, CSS animations.
3. MANDATORY FULL-FRAME CSS: html, body { margin:0; padding:0; width:${width}px; height:${height}px; overflow:hidden; }`;
          const rawHtmlResponse = await callAIWithTracking({
            messages: [
              { role: "system", content: htmlOnlySystemPrompt },
              { role: "user", content: "Generate the HTML document now. Output ONLY raw HTML starting with <!DOCTYPE html>." }
            ],
            apiKey: params.apiKey,
            maxTokens: 2500,
            model: params.model
          });
          htmlContent = stripMarkdown2(rawHtmlResponse);
        } else if (htmlAttempts === 2 && !isHtmlComplete2(htmlContent)) {
          const continuationResponse = await callAIWithTracking({
            messages: [
              { role: "system", content: "You are an HTML expert. Continue truncated HTML output exactly where it left off." },
              { role: "user", content: `The previous HTML was cut off mid-generation. Continue from exactly where it stopped.

PREVIOUS HTML (incomplete):
${htmlContent}

CRITICAL: Pick up from where it was cut off. MUST end with </html>. Output ONLY the continuation.` }
            ],
            apiKey: params.apiKey,
            maxTokens: 3e3,
            model: params.model
          });
          htmlContent = htmlContent + stripMarkdown2(continuationResponse);
        } else if (htmlAttempts === 3 && !isHtmlComplete2(htmlContent)) {
          const regenerationResponse = await callAIWithTracking({
            messages: [
              { role: "system", content: "You MUST output complete HTML. If you cannot fit everything, make it shorter but COMPLETE." },
              { role: "user", content: `Create a COMPLETE HTML slide for a video. You MUST output the ENTIRE document.
STORY: "${params.userStory}"
Key message: "${brief?.keyMessage ?? ""}"
RULES:
1. Output ONLY raw HTML, starting with <!DOCTYPE html> and ending with </html>
2. Keep it concise \u2014 max 150 lines. Focus on quality, not quantity.
3. Must include: dark gradient background, large headline, at least 1 SVG icon, CSS animations using window.__remotionTime
4. No external resources. Self-contained.
5. ${dimLabel} format. MANDATORY CSS: html, body { margin:0; padding:0; width:${width}px; height:${height}px; overflow:hidden; }` }
            ],
            apiKey: params.apiKey,
            maxTokens: 3e3,
            model: params.model
          });
          htmlContent = stripMarkdown2(regenerationResponse);
        }
        isComplete = isHtmlComplete2(htmlContent);
      }
      if (!htmlContent.includes("<") || !htmlContent.toLowerCase().includes("<!doctype")) {
        const retryResponse = await callAIWithTracking({
          messages: [
            { role: "system", content: "Output ONLY a complete HTML document starting with <!DOCTYPE html> and ending with </html>. No JSON, no markdown, no extra text." },
            { role: "user", content: `Create an animated HTML slide for a video about: "${params.userStory}". Key message: "${brief?.keyMessage ?? params.userStory}". Output raw HTML only. Make it COMPLETE.` }
          ],
          apiKey: params.apiKey,
          maxTokens: 3e3,
          model: params.model
        });
        htmlContent = stripMarkdown2(retryResponse);
      }
      if (!isHtmlComplete2(htmlContent)) {
        htmlContent = htmlContent + "\n</html>";
      }
      const htmlRawContent = {
        htmlContent,
        title: brief?.narrativeRole ?? "HTML Block",
        audioSrc: brief?.spokenScript ?? ""
      };
      console.log("[generate_content] \u2705 HTML two-step done. htmlContent length:", htmlContent.length);
      return { rawContent: htmlRawContent, error: null };
    }
    if (params.blockType === "diagram") {
      console.log("[generate_content] \u{1F4CA} Diagram block detected");
      const diagramDirectorPrompt = brief ? `You are a diagram content director for a video block. Design a visually rich diagram.

STORY: "${params.userStory}"
Role: ${brief.narrativeRole} | Angle: ${brief.angle} | Tone: ${brief.tone}
Key message: ${brief.keyMessage}
${lensHintSection}
DIAGRAM REQUIREMENTS:
- Pick diagramType: flowchart | hierarchy | sequence | mindmap | network
- Pick layout: vertical (flowchart/hierarchy) | horizontal (sequence) | radial (mindmap/network)
- 3\u20138 nodes, each with a SHORT label (1\u20134 words max)
- Use SEQUENTIAL IDs: "n1", "n2", "n3", etc.
- All edge "from" and "to" values MUST exactly match an existing node "id"
- Use distinct high-contrast hex colors per node
- node "type": start | process | decision | data | end | default
- Include 2\u20136 edges connecting the nodes logically
- Each edge "style": solid | dashed | arrow

Return ONLY valid JSON. No markdown.
Schema:
{
  "diagramType": "...",
  "title": "...",
  "layout": "...",
  "primaryColor": "#hex",
  "nodes": [{"id":"n1","label":"...","type":"start","color":"#hex"}, ...],
  "edges": [{"from":"n1","to":"n2","label":"optional","style":"arrow"}, ...],
  "audioSrc": "..."
}` : `You are a diagram content generator. Create a diagram for a video about: "${params.userStory}".
Use sequential node IDs: "n1", "n2", "n3", etc. All edge from/to values MUST match a node id exactly.
Return JSON: { diagramType, title, layout, primaryColor, nodes: [{id,label,type,color}], edges: [{from,to,label,style}], audioSrc }.`;
      const diagramDirectorResponse = await callAIWithTracking({
        messages: [
          { role: "system", content: diagramDirectorPrompt },
          { role: "user", content: `Generate the diagram JSON now. The narration (audioSrc) must be exactly: "${brief?.spokenScript || ""}"` }
        ],
        apiKey: params.apiKey,
        maxTokens: 1500,
        model: params.model
      });
      const diagramRawContent = parseJSON(diagramDirectorResponse);
      if (Array.isArray(diagramRawContent.nodes) && Array.isArray(diagramRawContent.edges)) {
        const validIds = new Set(diagramRawContent.nodes.map((n) => String(n.id)));
        diagramRawContent.edges = diagramRawContent.edges.filter(
          (e) => validIds.has(String(e.from)) && validIds.has(String(e.to))
        );
      }
      if (brief?.spokenScript) {
        diagramRawContent.audioSrc = brief.spokenScript;
      }
      return { rawContent: diagramRawContent, error: null };
    }
    let parallaxLayerHint = "";
    if (params.blockType === "parallax-story" && Array.isArray(params.originalBlock?.layers) && params.originalBlock.layers.length > 0) {
      const layerSummary = params.originalBlock.layers.map(
        (l, i) => `  Layer ${i} \u2014 name: "${l.name ?? `layer_${i}`}", depth: ${l.depth ?? i * 30}, parallaxFactor: ${l.parallaxFactor ?? 1}, motionDirection: "${l.motionDirection ?? "right"}", removeBackground: ${l.removeBackground ?? i > 0}`
      ).join("\n");
      parallaxLayerHint = `
PARALLAX LAYER STRUCTURE (MUST output exactly ${params.originalBlock.layers.length} layers in this order \u2014 only fill "image", keep all other fields as shown):
${layerSummary}
`;
    }
    const DEFAULT_ARRAY_COUNTS = {
      "top-players": { players: 5 },
      "avatar-grid": { avatars: 4 }
    };
    const entryIsEmpty = (entry) => {
      if (entry == null) return true;
      if (typeof entry !== "object") return entry === "" || entry === 0;
      return Object.values(entry).every(
        (v) => v == null || typeof v === "string" && v.trim() === ""
      );
    };
    const arrayCountHints = [];
    const seenArrayNames = /* @__PURE__ */ new Set();
    if (schema.normalizedFields) {
      for (const field of schema.normalizedFields) {
        const match = field.path.match(/^([^[]+)\[\]/);
        if (!match) continue;
        const arrayName = match[1];
        if (seenArrayNames.has(arrayName)) continue;
        seenArrayNames.add(arrayName);
        const arr = params.originalBlock?.[arrayName];
        const effectiveLength = Array.isArray(arr) ? arr.filter((e) => !entryIsEmpty(e)).length : 0;
        const defaultCount = DEFAULT_ARRAY_COUNTS[params.blockType]?.[arrayName] ?? 0;
        const count = Math.max(effectiveLength, defaultCount);
        if (count > 0) {
          arrayCountHints.push(`The "${arrayName}" array MUST have exactly ${count} entries. Each entry must have all required fields filled with real, specific data.`);
        }
      }
    }
    const arrayCountSection = arrayCountHints.length > 0 ? `
ARRAY COUNT CONSTRAINTS (MANDATORY):
${arrayCountHints.map((h) => `- ${h}`).join("\n")}
` : "";
    const response = await callAIWithTracking({
      messages: [
        {
          role: "system",
          content: `You are a video content generator filling a "${params.blockType}" block.
${runPlanContext}${narrativeContext}${storyBibleContext}${lensHintSection}${params.researchContext ? `
RESEARCH CONTEXT (use these current facts \u2014 prefer over training data):
${params.researchContext}
` : ""}${parallaxLayerHint}${arrayCountSection}
FIELD DEFINITIONS:
${schemaDescription}

RULES:
1. TEXT fields  \u2192 specific, real, engaging content matching your narrative angle
2. IMAGE fields \u2192 ${useWebSearch ? `a specific web search query to find a real ${queryStyleHint} (NOT an artistic description)` : `vivid visual description matching the visual mood: "${brief?.visualMood ?? "cinematic"}"`}
3. AUDIO fields \u2192 ${brief?.spokenScript ? "use the EXACT spoken script from the narrative brief above \u2014 copy it word for word" : `natural spoken script matching tone: "${brief?.tone ?? "engaging"}"`}
4. Return a single flat JSON object \u2014 no markdown, no extra keys
5. Be SPECIFIC \u2014 real names, real numbers, real facts${params.language !== "en" ? `
6. LANGUAGE: ALL viewer-facing text (text fields, audio/TTS fields, captions, quotes, list items) MUST be in ${languageName(params.language)}. JSON keys stay in English.` : ""}${params.blockType === "video" ? `
7. VIDEO src field \u2192 write a detailed cinematic scene description GROUNDED IN THE ACTUAL CONTENT above. Include specific names, places, products, or events from the Research Context, Story Bible, and Narrative Brief so the scene depicts the REAL subject. MATCH THE CONTENT TYPE: if the story is about a product/software/service \u2192 describe a UI, dashboard, or product-in-use scene (NOT a person reacting emotionally); if the story is about a person \u2192 describe that specific person; if the story is about a concept \u2192 describe the mechanism or visualization. NEVER write a generic mood shot or character emotional scene when the content is about a product or technical concept. NEVER write a filename, path, or URL.` : ""}

RESPONSE FORMAT (use this exact JSON structure):
${getResponseFormatTemplate(params.blockType)}

Example output format:
${schema.example}`
        },
        {
          role: "user",
          content: `Topic/Story: "${params.userStory}"
Block type: "${params.blockType}"
Block ${params.blockIndex + 1} of the video.
${brief ? `Your job this block: ${brief.keyMessage}` : ""}

Generate the JSON content object now.`
        }
      ],
      apiKey: params.apiKey,
      maxTokens: 1500,
      model: params.model
    });
    const rawContent = parseJSON(response);
    if (brief?.spokenScript) {
      if (rawContent.audioSrc !== void 0) {
        rawContent.audioSrc = brief.spokenScript;
      }
      if (params.blockType === "html" || params.blockType === "diagram") {
        rawContent.audioSrc = brief.spokenScript;
      }
    }
    if (brief?.spokenScript && rawContent.text !== void 0 && ["video", "parallax-story", "motivational-image"].includes(params.blockType)) {
      rawContent.text = brief.spokenScript;
    }
    console.log("[generate_content] \u2705 rawContent:", JSON.stringify(rawContent, null, 2));
    return { rawContent, error: null };
  } catch (e) {
    return { error: `generate_content failed: ${e.message}`, rawContent: {} };
  }
}

async function classifyMediaFields(params) {
  console.log(`[classify_media_fields] \u25B6 ${params.blockType}`);
  function injectAudioFallback(content) {
    const spokenScript = params.narrativeBrief?.spokenScript;
    if (!spokenScript) return content;
    const hasAudio = typeof content.audioSrc === "string" && content.audioSrc.trim().length > 0;
    if (hasAudio) return content;
    return { ...content, audioSrc: spokenScript };
  }
  let effectiveRawContent = params.rawContent ?? {};
  if (params.blockType === "parallax-story" && Array.isArray(params.originalBlock?.layers) && params.originalBlock.layers.length > 0 && (!Array.isArray(effectiveRawContent.layers) || effectiveRawContent.layers.length === 0)) {
    const cleanedLayers = params.originalBlock.layers.map((l) => {
      const img = l?.image;
      const isStaleUrl = typeof img === "string" && (img.startsWith("http") || img.startsWith("data:"));
      return isStaleUrl ? { ...l, image: l.name ?? `layer visual for ${params.originalBlock.title ?? params.blockType}` } : l;
    });
    effectiveRawContent = { ...params.originalBlock, ...effectiveRawContent, layers: cleanedLayers };
  }
  effectiveRawContent = injectAudioFallback(effectiveRawContent);
  if (!effectiveRawContent || Object.keys(effectiveRawContent).length === 0) {
    return { imageFields: [], audioFields: [], videoFields: [] };
  }
  const schema = BLOCK_SCHEMAS[params.blockType];
  let normalizedFields = null;
  if (params.blockType !== "custom-plugin" && schema?.normalizedFields) {
    normalizedFields = schema.normalizedFields;
  } else if (params.blockType === "custom-plugin" && Array.isArray(params.originalBlock?.generationFields)) {
    normalizedFields = params.originalBlock.generationFields;
  }
  if (normalizedFields) {
    const expanded = expandTemplatePaths(normalizedFields, effectiveRawContent);
    const imageFields = expanded.filter((f) => f.type === "image").map((f) => {
      const rawVal = getNestedValue(effectiveRawContent, f.path);
      const searchQuery = typeof rawVal === "string" && rawVal.trim() && !rawVal.startsWith("http") ? rawVal.trim() : f.description;
      return { path: f.path, description: f.description, removeBackground: f.removeBackground, searchQuery };
    });
    const audioFromNormalized = expanded.filter((f) => f.type === "audio").map((f) => ({ path: f.path, text: f.description }));
    let rawContentForAudio2 = effectiveRawContent;
    if ((params.blockType === "parallax-story" || params.blockType === "motivational-image") && params.rawContent?.text && (params.rawContent?.textMode === "overall" || params.blockType === "motivational-image")) {
      rawContentForAudio2 = { ...params.rawContent, audioSrc: params.rawContent.text };
    }
    const audioFields2 = [
      ...audioFromNormalized,
      ...extractAudioFields(rawContentForAudio2).filter(
        (af) => !audioFromNormalized.some((e) => e.path === af.path)
      )
    ];
    const videoFields2 = expanded.filter((f) => f.type === "video").map((f) => ({ path: f.path, prompt: f.description }));
    console.log(`[classify_media_fields] \u2705 normalized path \u2014 ${imageFields.length} images, ${audioFields2.length} audio, ${videoFields2.length} video`);
    return { imageFields, audioFields: audioFields2, videoFields: videoFields2, rawContent: effectiveRawContent };
  }
  let rawContentForAudio = effectiveRawContent;
  if ((params.blockType === "parallax-story" || params.blockType === "motivational-image") && params.rawContent?.text && (params.rawContent?.textMode === "overall" || params.blockType === "motivational-image")) {
    rawContentForAudio = { ...params.rawContent, audioSrc: params.rawContent.text };
  }
  const audioFields = extractAudioFields(rawContentForAudio);
  const videoFields = [];
  if (params.blockType === "video") {
    const src = params.rawContent?.src;
    if (!src || !src.startsWith("http") && !src.startsWith("data:")) {
      const prompt = src || params.rawContent?.caption || params.rawContent?.text || "";
      if (prompt) {
        videoFields.push({ path: "src", prompt });
      }
    }
  }
  if (!schema?.imageFields) {
    return { imageFields: [], audioFields, videoFields };
  }
  let contentForClassification = params.rawContent;
  if (params.blockType === "video") {
    const { src, ...rest } = params.rawContent;
    contentForClassification = rest;
  }
  try {
    const blockStrategy = params.mediaStrategy?.blockStrategies?.find((b) => b.blockIndex === (params.blockIndex ?? 0));
    const includeSearchQuery = params.blockType !== "video";
    const queryStyleHint = blockStrategy?.searchQueryStyle ?? "photo";
    const response = await callAIWithTracking({
      messages: [
        {
          role: "system",
          content: `You are a media field classifier for video blocks.

Given a block type, schema hints, and generated JSON content, identify:

IMAGE FIELDS \u2014 fields whose value is a visual description needing image generation.
   Defined image hints for this block: "${schema?.imageFields || "none"}"
   Also detect any field whose value looks like a visual scene description
   (not a URL, not a sentence of prose, but a visual description).
${params.blockType === "video" ? '\nIMPORTANT: Do NOT classify "src" as an image field \u2014 it is a video field handled separately.\n' : ""}
For nested array fields use dot notation: "avatars[0].image", "layers[1].image"

Return ONLY this JSON, no markdown:
{
  "imageFields": [{ "path": "dot.path", "description": "the visual description value"${includeSearchQuery ? ', "searchQuery": "specific web search query to find a real ' + queryStyleHint + '"' : ""} }]
}

Return empty array if nothing qualifies.${includeSearchQuery ? `

For every image field, also include a "searchQuery" \u2014 a specific web search query to find a real ${queryStyleHint}. Make queries very specific (include subject names, product names, year, location, etc.). The "description" is a fallback for AI generation only if web search returns nothing.` : ""}`
        },
        {
          role: "user",
          content: `Block type: "${params.blockType}"
Generated content:
${JSON.stringify(contentForClassification, null, 2)}`
        }
      ],
      apiKey: "",
      maxTokens: 800,
      model: ""
    });
    const classified = parseJSON(response);
    const imageFields = (classified.imageFields ?? []).filter(
      (f) => !(params.blockType === "video" && f.path === "src")
    );
    return { imageFields, audioFields, videoFields };
  } catch (e) {
    console.warn("[classify_media_fields] \u26A0\uFE0F image classification failed:", e.message);
    return { imageFields: [], audioFields, videoFields };
  }
}

async function resolveImages(params) {
  console.log(`[resolve_images] \u25B6 ENTERED \u2014 imageFields:`, JSON.stringify(params.imageFields));
  if (params.imageFields.length === 0) {
    return { resolvedUrls: {} };
  }
  const blockStrategy = params.mediaStrategy?.blockStrategies?.find((b) => b.blockIndex === params.blockIndex);
  const results = await Promise.all(
    params.imageFields.map(async ({ path, description, searchQuery, removeBackground }) => {
      const needsBgRemoval = removeBackground ?? false;
      if (searchQuery) {
        const webUrl = await searchWebImage(searchQuery, {
          minWidth: blockStrategy?.minWidth ?? 800,
          autoScreenshot: blockStrategy?.autoScreenshot ?? false
        });
        if (webUrl) {
          console.log(`[resolve_images] \u{1F50D} web hit "${path}": ${webUrl.slice(0, 80)}`);
          if (needsBgRemoval) {
            const bgRemoved = await removeBackgroundFromUrl(webUrl);
            return [path, bgRemoved];
          }
          const proxied = await proxyImageToS3(webUrl);
          return [path, proxied];
        }
        console.log(`[resolve_images] \u{1F50D} web miss "${path}", falling back to AI generation`);
      }
      const styledDescription = params.visualStyleGuide ? `${params.visualStyleGuide}. ${description}` : description;
      console.log(`[resolve_images] \u2192 generating "${path}" (bgRemoval=${needsBgRemoval}): ${styledDescription.slice(0, 120)}`);
      const TIMEOUT_MS = 9e4;
      const timeoutPromise = new Promise(
        (_, reject) => setTimeout(() => reject(new Error(`image timeout after ${TIMEOUT_MS / 1e3}s`)), TIMEOUT_MS)
      );
      const url = await Promise.race([
        needsBgRemoval ? generateBgRemovedImage(styledDescription) : generateImage(styledDescription),
        timeoutPromise
      ]).catch((e) => {
        console.warn(`[resolve_images] \u26A0\uFE0F "${path}" failed: ${e.message} \u2014 using placeholder`);
        return "https://picsum.photos/seed/placeholder/800/1200";
      });
      console.log(`[resolve_images] \u2705 "${path}": ${url.slice(0, 80)}`);
      return [path, url];
    })
  );
  return { resolvedUrls: Object.fromEntries(results) };
}
async function resolveAudio(params) {
  console.log(`[resolve_audio] \u25B6 ENTERED \u2014 audioFields:`, JSON.stringify(params.audioFields));
  if (params.audioFields.length === 0) {
    return { resolvedAudio: {} };
  }
  const results = await Promise.all(
    params.audioFields.map(async ({ path, text }) => {
      console.log(`[resolve_audio] \u2192 TTS for "${path}": ${text.slice(0, 80)}`);
      const audio = await generateAudio(text, params.preferredVoice ?? void 0);
      console.log(`[resolve_audio] \u2705 "${path}": audio length ${audio?.length ?? 0}`);
      return [path, audio];
    })
  );
  return { resolvedAudio: Object.fromEntries(results) };
}
async function resolveVideo(params) {
  console.log(`[resolve_video] \u25B6 ENTERED \u2014 videoFields:`, JSON.stringify(params.videoFields));
  console.log("[resolve_video] \u23ED\uFE0F deferring video generation to review step");
  return { resolvedUrls: {} };
}

const IntroOutroSchema = z.object({
  title: z.string().max(100).optional(),
  subtitle: z.string().max(200).optional(),
  logoUrl: z.string().url().optional(),
  duration: z.number().min(1).max(5).optional().default(2)
});
const ElementOverrideSchema = z.object({
  x: z.number().optional(),
  y: z.number().optional(),
  width: z.number().optional(),
  height: z.number().optional(),
  color: z.string().optional(),
  fontSize: z.number().optional(),
  fontWeight: z.union([z.string(), z.number()]).optional(),
  textAlign: z.enum(["left", "center", "right", "justify"]).optional(),
  src: z.string().optional()
});
const BlockCustomizationSchema = z.object({
  // Position/Alignment settings
  verticalAlign: z.enum(["top", "center", "bottom"]).default("center"),
  horizontalAlign: z.enum(["left", "center", "right"]).default("center"),
  // Animation settings
  enterAnimation: z.enum(["fade", "slide-up", "slide-down", "slide-left", "slide-right", "zoom", "bounce", "rotate", "flip", "none"]).default("fade"),
  exitAnimation: z.enum(["fade", "slide-up", "slide-down", "slide-left", "slide-right", "zoom", "bounce", "rotate", "flip", "none"]).default("fade"),
  animationDuration: z.number().min(0.1).max(2).default(0.5),
  // Background settings
  backgroundColor: z.string().optional(),
  backgroundImage: z.string().optional(),
  backgroundBlur: z.number().min(0).max(20).default(0),
  // Border settings
  borderColor: z.string().optional(),
  borderWidth: z.number().min(0).max(10).default(0),
  borderRadius: z.number().min(0).max(100).default(0),
  shadowEnabled: z.boolean().default(false),
  shadowColor: z.string().default("rgba(0,0,0,0.5)"),
  shadowBlur: z.number().min(0).max(50).default(20),
  // Spacing settings
  padding: z.number().min(0).max(100).optional(),
  margin: z.number().min(0).max(50).default(0),
  // Audio narration (TTS)
  audioSrc: z.string().optional(),
  // Per-element overrides (sub-element editor overlay)
  elementOverrides: z.record(z.string(), ElementOverrideSchema).optional()
});
const AudioTrackSchema = z.object({
  id: z.string().min(1),
  name: z.string().max(100).default("Audio Track"),
  src: z.string().min(1),
  // URL or file path to audio file
  volume: z.number().min(0).max(1).default(0.7),
  // Volume level 0-1
  startTime: z.number().min(0).default(0),
  // When audio starts in the video timeline (seconds)
  fadeIn: z.number().min(0).max(10).default(0),
  // Fade in duration in seconds
  fadeOut: z.number().min(0).max(10).default(0),
  // Fade out duration in seconds
  loop: z.boolean().default(true),
  // Whether to loop the audio
  muted: z.boolean().default(false)
  // Whether the track is muted
});
const VideoMetaSchema = z.object({
  aspectRatio: z.enum(["16:9", "9:16", "1:1", "4:5"]).default("9:16"),
  theme: z.enum(["dark_modern", "light_minimal", "bold_vibrant", "corporate"]).default("dark_modern"),
  fps: z.number().int().min(24).max(60).default(30),
  intro: IntroOutroSchema.optional(),
  outro: IntroOutroSchema.optional(),
  audioTracks: z.array(AudioTrackSchema).optional().default([]),
  subtitleTrack: z.lazy(() => SubtitleTrackSchema).optional(),
  textOverlayTracks: z.lazy(() => z.array(TextOverlayTrackSchema)).optional().default([])
});
const StatBlockSchema = z.object({
  type: z.literal("stat"),
  heading: z.string().min(1).max(100),
  value: z.string().min(1).max(50),
  subtext: z.string().optional()
}).merge(BlockCustomizationSchema);
const ComparisonItemSchema = z.object({
  label: z.string().min(1).max(50),
  value: z.number().min(0),
  color: z.string().optional()
});
const ComparisonBlockSchema = z.object({
  type: z.literal("comparison"),
  title: z.string().min(1).max(100).optional(),
  items: z.array(ComparisonItemSchema).min(2).max(6)
}).merge(BlockCustomizationSchema);
const TextBlockSchema = z.object({
  type: z.literal("text"),
  content: z.string().min(1).max(500),
  emphasis: z.enum(["low", "medium", "high"]).optional()
}).merge(BlockCustomizationSchema);
const ImageBlockSchema = z.object({
  type: z.literal("image"),
  src: z.string().url(),
  alt: z.string().max(200).optional(),
  caption: z.string().max(100).optional()
}).merge(BlockCustomizationSchema);
const QuoteBlockSchema = z.object({
  type: z.literal("quote"),
  text: z.string().min(1).max(300),
  author: z.string().max(100).optional()
}).merge(BlockCustomizationSchema);
const ListBlockSchema = z.object({
  type: z.literal("list"),
  title: z.string().min(1).max(100).optional(),
  items: z.array(z.string().min(1).max(200)).min(1).max(10),
  style: z.enum(["bullet", "numbered", "checkmarks"]).optional().default("bullet")
}).merge(BlockCustomizationSchema);
const TimelineEventSchema = z.object({
  year: z.string().max(20),
  title: z.string().min(1).max(100),
  description: z.string().max(200).optional()
});
const TimelineBlockSchema = z.object({
  type: z.literal("timeline"),
  title: z.string().min(1).max(100).optional(),
  events: z.array(TimelineEventSchema).min(2).max(8)
}).merge(BlockCustomizationSchema);
const CalloutBlockSchema = z.object({
  type: z.literal("callout"),
  title: z.string().min(1).max(100),
  content: z.string().min(1).max(300),
  variant: z.enum(["success", "warning", "info", "default"]).optional().default("default")
}).merge(BlockCustomizationSchema);
const IconItemSchema = z.object({
  icon: z.string().min(1).max(50),
  title: z.string().min(1).max(100),
  description: z.string().max(200).optional()
});
const IconListBlockSchema = z.object({
  type: z.literal("icon-list"),
  title: z.string().min(1).max(100).optional(),
  items: z.array(IconItemSchema).min(1).max(6)
}).merge(BlockCustomizationSchema);
const LineChartBlockSchema = z.object({
  type: z.literal("line-chart"),
  title: z.string().min(1).max(100).optional(),
  subtitle: z.string().max(200).optional(),
  data: z.array(z.number()).min(2).max(24),
  labels: z.array(z.string().max(20)).min(2).max(24).optional(),
  xAxisLabel: z.string().max(50).optional(),
  yAxisLabel: z.string().max(50).optional(),
  unit: z.string().max(10).optional(),
  showDataLabels: z.boolean().optional().default(false),
  lineColor: z.string().optional()
}).merge(BlockCustomizationSchema);
const PieSegmentSchema = z.object({
  label: z.string().min(1).max(50),
  value: z.number().min(0),
  color: z.string().optional()
});
const PieChartBlockSchema = z.object({
  type: z.literal("pie-chart"),
  title: z.string().min(1).max(100).optional(),
  subtitle: z.string().max(200).optional(),
  segments: z.array(PieSegmentSchema).min(2).max(8),
  showPercentage: z.boolean().optional().default(true),
  showLegend: z.boolean().optional().default(true)
}).merge(BlockCustomizationSchema);
const CodeBlockSchema = z.object({
  type: z.literal("code"),
  code: z.string().min(1).max(2e3),
  language: z.string().max(50).optional().default("javascript"),
  title: z.string().max(100).optional()
}).merge(BlockCustomizationSchema);
const TestimonialBlockSchema = z.object({
  type: z.literal("testimonial"),
  quote: z.string().min(1).max(400),
  author: z.string().min(1).max(100),
  role: z.string().max(100).optional(),
  company: z.string().max(100).optional(),
  avatar: z.string().url().optional()
}).merge(BlockCustomizationSchema);
const WhatsAppParticipantSchema = z.object({
  name: z.string().min(1).max(50),
  avatar: z.string().optional(),
  // URL or placeholder
  isOnline: z.boolean().optional().default(true)
});
const WhatsAppMessageSchema = z.object({
  from: z.enum(["person1", "person2"]),
  // person1 = sender (right/green), person2 = receiver (left/white)
  text: z.string().min(1).max(500),
  time: z.string().max(20).optional(),
  // e.g., "10:30 AM"
  showReadReceipt: z.boolean().optional().default(true)
});
const WhatsAppChatBlockSchema = z.object({
  type: z.literal("whatsapp-chat"),
  title: z.string().min(1).max(100).optional(),
  // Chat title/header override
  person1: WhatsAppParticipantSchema,
  // "You" - sender (right side, green bubbles)
  person2: WhatsAppParticipantSchema,
  // Other person (left side, white bubbles)
  messages: z.array(WhatsAppMessageSchema).min(1).max(50),
  // Up to 50 messages supported
  showTypingIndicator: z.boolean().optional().default(true),
  // Show typing before first message
  lastSeen: z.string().max(50).optional()
  // e.g., "last seen today at 10:30 AM"
}).merge(BlockCustomizationSchema);
z.object({
  text: z.string().min(1).max(500),
  position: z.enum(["top", "center", "bottom", "custom"]).default("center"),
  customPosition: z.object({
    x: z.number().min(0).max(100).optional(),
    // Percentage from left
    y: z.number().min(0).max(100).optional()
    // Percentage from top
  }).optional(),
  fontSize: z.enum(["small", "medium", "large", "xlarge", "xxlarge"]).default("large"),
  fontWeight: z.enum(["normal", "bold", "black"]).default("bold"),
  color: z.string().default("#FFFFFF"),
  // Text color
  shadow: z.boolean().default(true),
  // Text shadow for readability
  shadowColor: z.string().default("rgba(0,0,0,0.8)"),
  alignment: z.enum(["left", "center", "right"]).default("center"),
  animation: z.enum([
    "none",
    "fade",
    "slide-up",
    "slide-down",
    "slide-left",
    "slide-right",
    "zoom",
    "typewriter",
    "reveal"
  ]).default("fade"),
  animationDelay: z.number().min(0).max(5).default(0),
  // Delay before text animation starts
  stackOrder: z.number().int().min(0).max(10).optional()
  // Order in stack (0 = top, higher = bottom)
});
const ImageEffectSchema = z.enum([
  "none",
  // No animation
  "fade",
  // Simple fade in
  "slide-up",
  // Slide from bottom
  "slide-down",
  // Slide from top
  "slide-left",
  // Slide from right
  "slide-right",
  // Slide from left
  "zoom-in",
  // Zoom from small to normal
  "zoom-out",
  // Zoom from large to normal
  "ken-burns",
  // Slow zoom and pan (cinematic)
  "blur",
  // Blur to clear
  "rotate",
  // Rotate in
  "bounce"
  // Bounce in
]);
const ColorOverlaySchema = z.object({
  enabled: z.boolean().default(false),
  color: z.string().default("#000000"),
  opacity: z.number().min(0).max(1).default(0.4),
  // 0 = transparent, 1 = solid
  animation: z.enum(["none", "fade", "pulse"]).default("fade")
});
const FontFamilySchema = z.enum([
  "inter",
  // Inter (default, clean modern)
  "roboto",
  // Roboto
  "montserrat",
  // Montserrat (bold, impactful)
  "oswald",
  // Oswald (condensed, strong)
  "playfair",
  // Playfair Display (elegant serif)
  "bebas",
  // Bebas Neue (display, all-caps)
  "poppins",
  // Poppins (friendly, rounded)
  "raleway"
  // Raleway (thin, stylish)
]);
const TextStyleSchema = z.enum([
  "default",
  // Simple fade in with shadow
  "quote",
  // Italic with left border
  "typing",
  // Typewriter effect
  "words",
  // Word by word (slide+fade per word)
  "glow",
  // Glowing text effect
  "outline",
  // Outlined text (transparent fill)
  "bold-glow",
  // Bold with glow
  "shadow",
  // Drop shadow effect
  "shorts",
  // YouTube Shorts: groups pop in with spring bounce + thick stroke
  "three-line",
  // 3-line teleprompter: dim-top / COLORED-CENTER / dim-bottom
  "cinematic",
  // Letter-spacing collapse + elegant fade from bottom
  "neon",
  // Neon glow flicker entrance + pulse
  "karaoke",
  // Group visible, each word highlights one by one (CapCut style)
  "karaoke-full"
  // All words visible at once, current word highlighted
]);
const SubtitleEntrySchema = z.object({
  startTime: z.number().min(0),
  // seconds from video start
  endTime: z.number().min(0),
  // seconds from video start
  text: z.string().min(1).max(500)
});
const SubtitleStyleSchema = z.object({
  textStyle: TextStyleSchema.default("shorts"),
  fontSize: z.enum(["small", "medium", "large", "xlarge", "xxlarge"]).default("large"),
  fontWeight: z.enum(["normal", "bold", "black"]).default("bold"),
  textColor: z.string().default("#FFFFFF"),
  textPosition: z.enum(["top", "center", "bottom"]).default("bottom"),
  textAlign: z.enum(["left", "center", "right"]).default("center"),
  fontFamily: FontFamilySchema.default("inter"),
  wordsPerGroup: z.number().min(1).max(5).default(3),
  wordsPerSecond: z.number().min(0.5).max(8).default(3),
  highlightColor: z.string().default("#00FF88"),
  subtitleBackground: z.enum(["none", "pill", "bar"]).default("none")
});
const SubtitleTrackSchema = z.object({
  entries: z.array(SubtitleEntrySchema).min(1),
  style: SubtitleStyleSchema.optional(),
  enabled: z.boolean().default(true)
});
const TextOverlayTrackSchema = z.object({
  id: z.string().min(1),
  text: z.string().min(1).max(500),
  textStyle: TextStyleSchema.default("default"),
  fontSize: z.enum(["small", "medium", "large", "xlarge", "xxlarge"]).default("medium"),
  fontWeight: z.enum(["normal", "bold", "black"]).default("normal"),
  textColor: z.string().default("#FFFFFF"),
  textAlign: z.enum(["left", "center", "right"]).default("center"),
  textPosition: z.enum(["top", "center", "bottom"]).default("bottom"),
  fontFamily: FontFamilySchema.default("inter"),
  opacity: z.number().min(0).max(1).default(1),
  startTime: z.number().min(0).default(0),
  // seconds — when to start showing
  endTime: z.number().min(0).nullable().default(null),
  // null = show until end
  enabled: z.boolean().default(true),
  // Optional subtitle-style animation
  wordsPerGroup: z.number().min(1).max(5).optional(),
  wordsPerSecond: z.number().min(0.5).max(8).optional(),
  highlightColor: z.string().optional(),
  subtitleBackground: z.enum(["none", "pill", "bar"]).default("none")
});
const MotivationalImageBlockSchema = z.object({
  type: z.literal("motivational-image"),
  // Image source
  imageSrc: z.string().min(1),
  imageAlt: z.string().max(200).optional(),
  // Image animation effect
  imageEffect: ImageEffectSchema.default("fade"),
  imageEffectDuration: z.number().min(0.5).max(5).default(1.5),
  // Text — for subtitle styles (shorts/three-line), this IS the spoken script (same as audioSrc)
  text: z.string().min(1).max(1e3).optional(),
  textStyle: TextStyleSchema.default("default"),
  fontSize: z.enum(["small", "medium", "large", "xlarge", "xxlarge"]).default("xlarge"),
  fontWeight: z.enum(["normal", "bold", "black"]).default("bold"),
  textColor: z.string().default("#FFFFFF"),
  textAlign: z.enum(["left", "center", "right"]).default("center"),
  textPosition: z.enum(["top", "center", "bottom"]).default("center"),
  textAnimationDelay: z.number().min(0).max(5).default(0.3),
  fontFamily: FontFamilySchema.default("inter"),
  // Subtitle-style options (for 'shorts', 'three-line' styles)
  wordsPerGroup: z.number().min(1).max(5).default(3),
  wordsPerSecond: z.number().min(0.5).max(8).default(3),
  highlightColor: z.string().default("#00FF88"),
  subtitleBackground: z.enum(["none", "pill", "bar"]).default("none"),
  // Overlay type (replaces/extends colorOverlay)
  overlayType: z.enum(["none", "solid", "gradient-bottom", "gradient-top", "vignette"]).default("gradient-bottom"),
  // Optional color overlay (legacy, kept for backwards compat)
  colorOverlay: ColorOverlaySchema.optional(),
  // Optional background color
  backgroundColor: z.string().default("#000000"),
  // Image fit options
  imageFit: z.enum(["cover", "contain", "fill"]).default("cover"),
  imagePosition: z.enum(["center", "top", "bottom", "left", "right"]).default("center"),
  // Audio support (optional)
  audioSrc: z.string().optional(),
  audioVolume: z.number().min(0).max(1).default(0.7),
  duration: z.number().min(1).max(120).optional()
}).merge(BlockCustomizationSchema);
const CounterBlockSchema = z.object({
  type: z.literal("counter"),
  label: z.string().max(100),
  from: z.number().default(0),
  to: z.number().default(100),
  duration: z.number().min(1).max(10).default(3),
  prefix: z.string().max(20).optional(),
  suffix: z.string().max(20).optional(),
  decimals: z.number().min(0).max(5).default(0),
  color: z.string().default("#3B82F6"),
  animationStyle: z.enum(["linear", "easeOut", "easeInOut", "bounce"]).default("easeOut")
}).merge(BlockCustomizationSchema);
const ProgressBarBlockSchema = z.object({
  type: z.literal("progress-bar"),
  label: z.string().max(100).optional(),
  value: z.number().min(0).max(100).default(75),
  color: z.string().default("#10B981"),
  backgroundColor: z.string().default("#1F2937"),
  height: z.enum(["small", "medium", "large"]).default("medium"),
  showPercentage: z.boolean().default(true),
  animated: z.boolean().default(true),
  stripes: z.boolean().default(false)
}).merge(BlockCustomizationSchema);
const QRCodeBlockSchema = z.object({
  type: z.literal("qr-code"),
  data: z.string().min(1).max(500),
  title: z.string().max(100).optional(),
  subtitle: z.string().max(200).optional(),
  size: z.enum(["small", "medium", "large"]).default("medium"),
  fgColor: z.string().default("#000000"),
  bgColor: z.string().default("#FFFFFF")
}).merge(BlockCustomizationSchema);
const VideoBlockSchema = z.object({
  type: z.literal("video"),
  src: z.string().default(""),
  autoPlay: z.boolean().default(true),
  loop: z.boolean().default(false),
  muted: z.boolean().default(true),
  controls: z.boolean().default(false),
  caption: z.string().max(200).optional(),
  // ── Optional text overlay (motivational-image style) ──
  text: z.string().max(1e3).optional(),
  textStyle: TextStyleSchema.optional(),
  fontSize: z.enum(["small", "medium", "large", "xlarge", "xxlarge"]).optional(),
  fontWeight: z.enum(["normal", "bold", "black"]).optional(),
  textColor: z.string().optional(),
  textAlign: z.enum(["left", "center", "right"]).optional(),
  textPosition: z.enum(["top", "center", "bottom"]).optional(),
  textAnimationDelay: z.number().min(0).max(5).optional(),
  fontFamily: FontFamilySchema.optional(),
  // ── Word effects ──
  wordsPerGroup: z.number().min(1).max(5).optional(),
  wordsPerSecond: z.number().min(0.5).max(8).optional(),
  highlightColor: z.string().optional(),
  subtitleBackground: z.enum(["none", "pill", "bar"]).optional(),
  // ── Overlay ──
  overlayType: z.enum(["none", "solid", "gradient-bottom", "gradient-top", "vignette"]).optional(),
  colorOverlay: ColorOverlaySchema.optional(),
  // ── Video display ──
  videoFit: z.enum(["cover", "contain", "fill"]).optional(),
  // ── Narration audio (TTS voice-over) ──
  audioSrc: z.string().optional(),
  audioVolume: z.number().min(0).max(1).optional(),
  // ── Audio overlay (separate from video audio & narration) ──
  overlayAudioSrc: z.string().optional(),
  overlayAudioVolume: z.number().min(0).max(1).optional()
}).merge(BlockCustomizationSchema);
const AvatarGridBlockSchema = z.object({
  type: z.literal("avatar-grid"),
  title: z.string().max(100).optional(),
  subtitle: z.string().max(200).optional(),
  avatars: z.array(z.object({
    name: z.string().max(50),
    role: z.string().max(100).optional(),
    image: z.string().optional()
  })).min(1).max(12),
  layout: z.enum(["grid", "carousel", "stacked"]).default("grid"),
  columns: z.number().min(2).max(6).default(3)
}).merge(BlockCustomizationSchema);
const SocialStatsBlockSchema = z.object({
  type: z.literal("social-stats"),
  platform: z.enum(["twitter", "instagram", "youtube", "tiktok", "linkedin", "facebook"]),
  username: z.string().max(50),
  followers: z.number().min(0),
  posts: z.number().min(0).optional(),
  likes: z.number().min(0).optional(),
  verified: z.boolean().default(false),
  showGrowth: z.boolean().default(true),
  growthPercentage: z.number().optional()
}).merge(BlockCustomizationSchema);
const CTABlockSchema = z.object({
  type: z.literal("cta"),
  text: z.string().max(50),
  description: z.string().max(200).optional(),
  buttonStyle: z.enum(["primary", "secondary", "outline", "ghost"]).default("primary"),
  color: z.string().default("#3B82F6"),
  size: z.enum(["small", "medium", "large"]).default("large"),
  icon: z.string().optional(),
  pulse: z.boolean().default(true)
}).merge(BlockCustomizationSchema);
const GradientTextBlockSchema = z.object({
  type: z.literal("gradient-text"),
  text: z.string().max(200),
  gradient: z.array(z.string()).min(2).max(5).default(["#3B82F6", "#8B5CF6"]),
  angle: z.number().min(0).max(360).default(45),
  animate: z.boolean().default(true),
  animationSpeed: z.number().min(1).max(10).default(3),
  fontSize: z.enum(["small", "medium", "large", "xlarge", "xxlarge"]).default("xlarge"),
  fontWeight: z.enum(["normal", "bold", "black"]).default("bold")
}).merge(BlockCustomizationSchema);
const AnimatedBackgroundBlockSchema = z.object({
  type: z.literal("animated-bg"),
  style: z.enum(["particles", "waves", "gradient", "noise", "geometric", "aurora"]),
  primaryColor: z.string().default("#3B82F6"),
  secondaryColor: z.string().default("#8B5CF6"),
  speed: z.number().min(0.5).max(5).default(1),
  intensity: z.number().min(0.1).max(1).default(0.5),
  overlay: z.boolean().default(false),
  overlayOpacity: z.number().min(0).max(1).default(0.3)
}).merge(BlockCustomizationSchema);
const CountdownBlockSchema = z.object({
  type: z.literal("countdown"),
  title: z.string().max(100).optional(),
  targetDate: z.string().optional(),
  // ISO date string
  days: z.number().min(0).optional(),
  hours: z.number().min(0).max(23).optional(),
  minutes: z.number().min(0).max(59).optional(),
  seconds: z.number().min(0).max(59).optional(),
  style: z.enum(["modern", "classic", "minimal", "flip"]).default("modern"),
  color: z.string().default("#FFFFFF"),
  showLabels: z.boolean().default(true)
}).merge(BlockCustomizationSchema);
const WeatherBlockSchema = z.object({
  type: z.literal("weather-block"),
  location: z.string().max(100).default("San Francisco"),
  temperature: z.number().default(72),
  unit: z.enum(["F", "C"]).default("F"),
  condition: z.enum(["sunny", "partly-cloudy", "cloudy", "rainy", "stormy", "snowy", "windy", "foggy", "night-clear", "night-cloudy"]).default("partly-cloudy"),
  description: z.string().max(100).optional(),
  humidity: z.number().min(0).max(100).default(65),
  windSpeed: z.number().min(0).default(12),
  highTemp: z.number().optional(),
  lowTemp: z.number().optional(),
  showForecast: z.boolean().default(true),
  showDetails: z.boolean().default(true),
  cardStyle: z.enum(["glass", "solid", "minimal", "gradient"]).default("glass"),
  accentColor: z.string().default("#38BDF8"),
  animateIcon: z.boolean().default(true)
}).merge(BlockCustomizationSchema);
const TowerItemSchema = z.object({
  rank: z.number().int().min(1),
  name: z.string().max(100),
  value: z.number().min(0),
  valueFormatted: z.string().max(50).optional(),
  // e.g., "155M", "$2.5B"
  color: z.string().optional(),
  image: z.string().optional(),
  // Optional image URL for the item
  subtitle: z.string().max(100).optional()
  // e.g., "2009", "Nintendo"
});
const TowerChart3DBlockSchema = z.object({
  type: z.literal("tower-chart-3d"),
  // Title and description
  title: z.string().max(100).default("Top Rankings"),
  subtitle: z.string().max(200).optional(),
  // Data - array of items to display (required, no presets)
  items: z.array(TowerItemSchema).min(1).max(50),
  // Visual settings
  towerStyle: z.enum(["boxes", "cylinders", "hexagons"]).default("boxes"),
  towerSpacing: z.number().min(2).max(10).default(5),
  // Spacing between towers
  baseHeight: z.number().min(1).max(5).default(2),
  // Minimum height for smallest value
  maxHeight: z.number().min(10).max(50).default(25),
  // Maximum height for largest value
  // Colors
  gradientStart: z.string().default("#3B82F6"),
  gradientEnd: z.string().default("#8B5CF6"),
  useGradientByRank: z.boolean().default(true),
  // Color by rank position
  showValueLabels: z.boolean().default(true),
  showRankNumbers: z.boolean().default(true),
  // Camera animation
  cameraDistance: z.number().min(10).max(50).default(20),
  cameraPauseDuration: z.number().min(0.2).max(2).default(0.4),
  // Pause at each rank (seconds)
  cameraMoveSpeed: z.number().min(0.3).max(3).default(0.8),
  // Speed between ranks (seconds)
  cameraAngle: z.number().min(0).max(90).default(30),
  // Viewing angle (degrees)
  // Animation direction
  animationDirection: z.enum(["top-to-bottom", "bottom-to-top"]).default("top-to-bottom"),
  // Camera movement direction
  // Scene settings
  backgroundColor: z.string().default("#0a0a1a"),
  groundColor: z.string().default("#151525"),
  showGround: z.boolean().default(true),
  ambientIntensity: z.number().min(0.3).max(2).default(0.6),
  showLabels3D: z.boolean().default(true),
  // Background Preset - Built-in 3D environments
  backgroundPreset: z.enum([
    "none",
    // No background, just stars
    "cyber-grid",
    // Neon grid floor with glow
    "mountain-range",
    // Distant mountain silhouettes
    "ocean-waves",
    // Animated ocean/water plane
    "forest-trees",
    // Stylized low-poly trees
    "city-skyline",
    // Distant city buildings
    "abstract-waves",
    // Abstract wave/mesh terrain
    "space-station",
    // Space station interior feel
    // Advanced presets
    "aurora-borealis",
    // Northern lights effect
    "volcanic-inferno",
    // Lava pools and volcanic environment
    "crystal-caves",
    // Crystalline formations with reflections
    "desert-dunes",
    // Sand dunes with heat shimmer
    "neon-tokyo",
    // Cyberpunk Japanese city aesthetic
    "floating-islands",
    // Sky islands with waterfalls
    "deep-ocean",
    // Underwater environment with bubbles
    "galaxy-nebula",
    // Colorful space clouds
    "matrix-rain",
    // Digital rain effect
    "ice-glacier",
    // Frozen environment with ice formations
    "steampunk-gears",
    // Industrial Victorian machinery
    "alien-planet",
    // Extraterrestrial landscape
    "tron-grid",
    // Iconic Tron-style light grid
    // Immersive Environment Presets - Towers appear WITHIN these
    "football-stadium",
    // Full stadium with field, towers on field
    "race-track",
    // F1 style circuit with grandstands
    "concert-stage",
    // Music festival with stage and lights
    "castle-grounds",
    // Medieval castle with courtyard
    "airport-runway",
    // Planes and terminal
    "theme-park",
    // Amusement park with rides
    "ancient-ruins",
    // Temple/pillars environment
    "zen-garden",
    // Japanese peaceful garden
    "ski-resort",
    // Snowy mountain slopes
    "vineyard"
    // Rolling hills with grape vines
  ]).default("cyber-grid"),
  // Animation
  introAnimation: z.enum(["fade", "zoom", "slide-up", "none"]).default("fade"),
  itemRevealDelay: z.number().min(0).max(0.5).default(0.05),
  // Delay between item reveals
  // Custom 3D Model (optional GLB file path)
  customModelPath: z.string().optional(),
  // Path to custom GLB model in /models folder
  customModelPosition: z.object({
    x: z.number().default(0),
    y: z.number().default(35),
    z: z.number().default(-60)
  }).optional(),
  customModelScale: z.number().min(0.1).max(10).default(2),
  customModelRotation: z.number().min(0).max(360).default(0)
}).merge(BlockCustomizationSchema);
const BarRaceItemSchema = z.object({
  name: z.string().max(100),
  value: z.number().min(0),
  valueFormatted: z.string().max(50).optional(),
  // e.g., "155M", "$2.5B"
  color: z.string().optional(),
  image: z.string().optional(),
  // Optional image/flag URL
  data: z.array(z.number()).optional()
  // Time-series data for animation (optional)
});
const BarRace3DBlockSchema = z.object({
  type: z.literal("bar-race-3d"),
  // Title and description
  title: z.string().max(100).default("Bar Race"),
  subtitle: z.string().max(200).optional(),
  // Data - array of items with optional time-series
  items: z.array(BarRaceItemSchema).min(2).max(20),
  // Race settings
  raceDuration: z.number().min(1).max(30).default(10),
  // Total duration of the race animation
  barHeight: z.number().min(0.5).max(3).default(1.5),
  // Height of each bar
  barMaxWidth: z.number().min(10).max(50).default(30),
  // Maximum bar width (value)
  barSpacing: z.number().min(0.5).max(2).default(0.8),
  // Vertical spacing between bars
  barDepth: z.number().min(0.5).max(3).default(1.5),
  // Depth of each bar
  // Colors
  gradientStart: z.string().default("#3B82F6"),
  gradientEnd: z.string().default("#8B5CF6"),
  useGradientByValue: z.boolean().default(true),
  // Color by value magnitude
  // Labels
  showValueLabels: z.boolean().default(true),
  showNameLabels: z.boolean().default(true),
  showRankNumbers: z.boolean().default(true),
  // Animation
  animationDirection: z.enum(["top-to-bottom", "bottom-to-top", "winner-focus"]).default("top-to-bottom"),
  positionTransitionSpeed: z.number().min(0.1).max(1).default(0.3),
  // Speed of position changes
  valueGrowSpeed: z.number().min(0.5).max(3).default(1),
  // Speed of value bar growing
  // Camera
  cameraDistance: z.number().min(10).max(50).default(25),
  cameraAngle: z.number().min(0).max(90).default(45),
  cameraFollowTop: z.number().min(1).max(10).default(5),
  // How many top items to keep in view
  // Scene
  backgroundColor: z.string().default("#0a0a1a"),
  groundColor: z.string().default("#151525"),
  showGround: z.boolean().default(true),
  ambientIntensity: z.number().min(0.3).max(2).default(0.6),
  // Background Preset
  backgroundPreset: z.enum([
    "none",
    "cyber-grid",
    "neon-tokyo",
    "tron-grid",
    "galaxy-nebula",
    "matrix-rain"
  ]).default("cyber-grid"),
  // Winner celebration
  showWinnerEffect: z.boolean().default(true),
  winnerDuration: z.number().min(0.5).max(3).default(1.5)
  // Duration of winner celebration
}).merge(BlockCustomizationSchema);
const ParallaxLayerSchema = z.object({
  id: z.string().optional(),
  // Unique identifier
  name: z.string().max(50),
  // Layer name (e.g., "Foreground", "Trees", "Sky")
  image: z.string().min(1),
  // Image URL for this layer
  depth: z.number().min(0).max(100).default(50),
  // 0 = closest (moves most), 100 = farthest (moves least)
  parallaxFactor: z.number().min(0).max(5).default(1),
  // Multiplier for parallax effect
  cameraIntensity: z.number().min(0).max(2).default(1),
  // How much camera movement affects this layer (0 = static, 1 = normal, 2 = double)
  scale: z.number().min(0.5).max(3).default(1),
  // Initial scale of the layer
  opacity: z.number().min(0).max(1).default(1),
  // Layer opacity
  positionX: z.number().min(-100).max(100).default(0),
  // Horizontal offset (%)
  positionY: z.number().min(-100).max(100).default(0),
  // Vertical offset (%)
  rotation: z.number().min(-45).max(45).default(0),
  // Rotation in degrees
  blur: z.number().min(0).max(20).default(0),
  // Blur amount
  blendMode: z.enum(["normal", "multiply", "screen", "overlay", "lighten", "darken"]).default("normal"),
  // Individual layer motion controls
  motionEnabled: z.boolean().default(true),
  // Whether this layer has its own motion
  motionDirection: z.enum([
    "none",
    "left",
    "right",
    "up",
    "down",
    "diagonal-tl-br",
    "diagonal-tr-bl",
    "diagonal-bl-tr",
    "diagonal-br-tl",
    "zoom-in",
    "zoom-out",
    "rotate-cw",
    "rotate-ccw",
    "float",
    "pulse"
  ]).default("right"),
  motionSpeed: z.number().min(0).max(5).default(1),
  // Speed of individual layer motion
  motionIntensity: z.number().min(0).max(3).default(1),
  // How much the layer moves
  motionOscillate: z.boolean().default(false),
  // Whether motion should oscillate back and forth
  motionOscillateSpeed: z.number().min(0.5).max(5).default(1),
  // Oscillation frequency
  // Animation settings per layer
  animationIn: z.enum(["none", "fade", "slide-left", "slide-right", "slide-up", "slide-down", "zoom-in", "zoom-out", "rotate-in", "flip-x", "flip-y", "bounce", "blur-in"]).default("fade"),
  animationOut: z.enum(["none", "fade", "slide-left", "slide-right", "slide-up", "slide-down", "zoom-in", "zoom-out", "rotate-out", "flip-x", "flip-y", "bounce"]).default("fade"),
  animationDelay: z.number().min(0).max(5).default(0),
  // Delay before animation starts
  animationDuration: z.number().min(0.1).max(5).default(1),
  // Duration of entrance animation
  animationEasing: z.enum(["linear", "ease", "ease-in", "ease-out", "ease-in-out", "bounce", "elastic"]).default("ease-out"),
  // Image fit option - control whether image is cropped or not
  imageFit: z.enum(["cover", "contain", "fill"]).default("cover"),
  // How image fits the layer
  imagePosition: z.enum(["center", "top", "bottom", "left", "right"]).default("center"),
  // Image position when using contain
  removeBackground: z.boolean().default(false)
  // true = generate without background (transparent cut-out)
});
const CameraMovementSchema = z.enum([
  "none",
  // Static camera
  "pan-left",
  // Camera pans left (layers move right at different speeds)
  "pan-right",
  // Camera pans right (layers move left at different speeds)
  "pan-up",
  // Camera pans up
  "pan-down",
  // Camera pans down
  "zoom-in",
  // Camera zooms in
  "zoom-out",
  // Camera zooms out
  "diagonal-tl-br",
  // Diagonal pan top-left to bottom-right
  "diagonal-tr-bl",
  // Diagonal pan top-right to bottom-left
  "orbit",
  // Circular/orbital camera movement
  "breathing",
  // Subtle in-out breathing motion
  "custom"
  // Custom keyframe-based movement
]);
const ParallaxEffectSchema = z.enum([
  "none",
  "particles",
  // Floating particles (dust, snow, leaves)
  "light-rays",
  // God rays / volumetric light
  "fog",
  // Atmospheric fog/mist
  "rain",
  // Rain overlay
  "snow",
  // Snowfall
  "bokeh",
  // Bokeh light spots
  "film-grain",
  // Vintage film grain
  "vignette",
  // Darkened edges
  "chromatic",
  // Chromatic aberration
  "glow"
  // Glow/bloom effect
]);
const StoryTextSchema = z.object({
  text: z.string().max(500),
  position: z.enum(["top", "center", "bottom", "custom"]).default("center"),
  customX: z.number().min(0).max(100).default(50),
  // Percentage
  customY: z.number().min(0).max(100).default(50),
  // Percentage
  fontSize: z.enum(["small", "medium", "large", "xlarge", "xxlarge"]).default("large"),
  fontWeight: z.enum(["normal", "bold", "black"]).default("bold"),
  color: z.string().default("#FFFFFF"),
  shadow: z.boolean().default(true),
  shadowColor: z.string().default("rgba(0,0,0,0.8)"),
  textAlign: z.enum(["left", "center", "right"]).default("center"),
  animation: z.enum(["none", "fade", "slide-up", "slide-down", "typewriter", "glow", "pulse"]).default("fade"),
  animationDelay: z.number().min(0).max(10).default(0.5),
  duration: z.number().min(0.5).max(30).default(3),
  // How long text stays visible
  startTime: z.number().min(0).max(60).default(0)
  // When text appears (seconds)
});
const ParallaxStoryBlockSchema = z.object({
  type: z.literal("parallax-story"),
  // Story title and metadata
  title: z.string().max(100).optional(),
  subtitle: z.string().max(200).optional(),
  // Parallax layers (ordered back to front)
  layers: z.array(ParallaxLayerSchema).min(1).max(10),
  // Camera settings
  cameraMovement: CameraMovementSchema.default("pan-right"),
  cameraSpeed: z.number().min(0.1).max(5).default(1),
  // Speed multiplier
  cameraIntensity: z.number().min(0).max(2).default(1),
  // How intense the movement is
  // Visual effects
  effects: z.array(ParallaxEffectSchema).default([]),
  effectIntensity: z.number().min(0).max(1).default(0.5),
  // Story text overlays (multiple text elements with timing)
  textOverlays: z.array(StoryTextSchema).optional(),
  // Overall text - single text with advanced styles (like motivational image)
  textMode: z.enum(["none", "overlays", "overall"]).default("none"),
  // Which text mode to use
  text: z.string().max(500).optional(),
  // Main text for "overall" mode
  textStyle: TextStyleSchema.default("default"),
  textFontSize: z.enum(["small", "medium", "large", "xlarge", "xxlarge"]).default("xlarge"),
  textFontWeight: z.enum(["normal", "bold", "black"]).default("bold"),
  textColor: z.string().default("#FFFFFF"),
  textAlign: z.enum(["left", "center", "right"]).default("center"),
  textPosition: z.enum(["top", "center", "bottom"]).default("center"),
  textAnimationDelay: z.number().min(0).max(5).default(0.3),
  fontFamily: FontFamilySchema.default("inter"),
  wordsPerGroup: z.number().min(1).max(5).default(3),
  wordsPerSecond: z.number().min(0.5).max(8).default(3),
  highlightColor: z.string().default("#00FF88"),
  subtitleBackground: z.enum(["none", "pill", "bar"]).default("none"),
  // Color grading
  colorGrade: z.enum(["none", "cinematic", "vintage", "cold", "warm", "noir", "sepia", "neon"]).default("none"),
  colorIntensity: z.number().min(0).max(1).default(0.5),
  // Background color (for letterboxing or blending)
  backgroundColor: z.string().default("#000000"),
  // Aspect ratio handling
  fitMode: z.enum(["cover", "contain", "stretch"]).default("cover"),
  // Animation settings
  introDuration: z.number().min(0.5).max(3).default(1),
  // Fade in duration
  outroDuration: z.number().min(0.5).max(3).default(1),
  // Fade out duration
  loopAnimation: z.boolean().default(false),
  // Whether to loop camera movement
  // Depth of field simulation
  dofEnabled: z.boolean().default(false),
  dofFocusDepth: z.number().min(0).max(100).default(50),
  // Which depth level is in focus
  dofBlurAmount: z.number().min(0).max(10).default(2),
  // Blur intensity
  // 3D perspective settings
  perspective: z.number().min(500).max(3e3).default(1e3),
  // CSS perspective value
  perspectiveOriginX: z.number().min(0).max(100).default(50),
  // %
  perspectiveOriginY: z.number().min(0).max(100).default(50),
  // %
  // Audio support
  audioSrc: z.string().optional(),
  // URL to audio file (mp3, wav, etc.)
  audioVolume: z.number().min(0).max(1).default(0.7),
  // Volume level 0-1
  audioFadeIn: z.number().min(0).max(5).default(0.5),
  // Fade in duration in seconds
  audioFadeOut: z.number().min(0).max(5).default(0.5),
  // Fade out duration in seconds
  audioLoop: z.boolean().default(true),
  // Whether to loop audio
  audioStartTime: z.number().min(0).default(0),
  // When audio starts (seconds from video start)
  audioDelay: z.number().min(0).default(0)
  // Delay before audio starts playing (seconds from scene start)
}).merge(BlockCustomizationSchema);
const TopPlayersPlayerSchema = z.object({
  rank: z.number().int().min(1),
  name: z.string().max(100),
  image: z.string().optional(),
  // URL (cutout) — generated via pipeline
  subtitle: z.string().max(200).optional()
  // e.g. "India • 13,000+ runs"
});
const TopPlayersBlockSchema = z.object({
  type: z.literal("top-players"),
  // Title / description
  title: z.string().max(100).optional(),
  subtitle: z.string().max(200).optional(),
  // Shared background image (stadium / ground / arena)
  backgroundImage: z.string().optional(),
  // Reveal order: 'top-last' = countdown (#10 → #1), 'top-first' = #1 first
  revealOrder: z.enum(["top-first", "top-last"]).default("top-last"),
  // Player entries (3-10)
  players: z.array(TopPlayersPlayerSchema).min(3).max(10),
  // Duration overrides
  duration: z.number().min(3).max(120).optional(),
  defaultPerPlayerSeconds: z.number().min(1).max(10).default(3)
}).merge(BlockCustomizationSchema);
const PricingPlanSchema = z.object({
  name: z.string().min(1).max(50),
  price: z.string().min(1).max(20),
  period: z.string().max(20).optional(),
  features: z.array(z.string().max(100)).min(1).max(8),
  highlighted: z.boolean().optional().default(false),
  ctaText: z.string().max(30).optional().default("Get Started")
});
const PricingTableBlockSchema = z.object({
  type: z.literal("pricing-table"),
  title: z.string().max(100).optional(),
  subtitle: z.string().max(200).optional(),
  plans: z.array(PricingPlanSchema).min(1).max(4)
}).merge(BlockCustomizationSchema);
const LogoItemSchema = z.object({
  src: z.string(),
  name: z.string().max(50)
});
const LogoWallBlockSchema = z.object({
  type: z.literal("logo-wall"),
  title: z.string().max(100).optional(),
  subtitle: z.string().max(200).optional(),
  logos: z.array(LogoItemSchema).min(2).max(20),
  columns: z.number().min(2).max(5).optional().default(4)
}).merge(BlockCustomizationSchema);
const ProcessStepSchema = z.object({
  number: z.number().min(1),
  title: z.string().min(1).max(80),
  description: z.string().max(200).optional(),
  icon: z.string().max(10).optional()
});
const ProcessStepsBlockSchema = z.object({
  type: z.literal("process-steps"),
  title: z.string().max(100).optional(),
  subtitle: z.string().max(200).optional(),
  steps: z.array(ProcessStepSchema).min(2).max(8)
}).merge(BlockCustomizationSchema);
const HtmlBlockSchema = z.object({
  type: z.literal("html"),
  htmlContent: z.string().max(5e4),
  title: z.string().max(100).optional(),
  backgroundColor: z.string().optional()
}).merge(BlockCustomizationSchema);
const DiagramNodeSchema = z.object({
  id: z.string().min(1).max(50),
  label: z.string().min(1).max(80),
  type: z.enum(["default", "decision", "start", "end", "process", "data"]).optional().default("default"),
  color: z.string().optional()
});
const DiagramEdgeSchema = z.object({
  from: z.string().min(1).max(50),
  to: z.string().min(1).max(50),
  label: z.string().max(50).optional(),
  style: z.enum(["solid", "dashed", "arrow"]).optional().default("arrow")
});
const DiagramBlockSchema = z.object({
  type: z.literal("diagram"),
  diagramType: z.enum(["flowchart", "hierarchy", "sequence", "mindmap", "network"]),
  title: z.string().max(100).optional(),
  nodes: z.array(DiagramNodeSchema).min(1).max(30),
  edges: z.array(DiagramEdgeSchema).min(0).max(50),
  layout: z.enum(["vertical", "horizontal", "radial"]).optional().default("vertical"),
  templateId: z.string().max(100).optional(),
  primaryColor: z.string().optional(),
  backgroundColor: z.string().optional()
}).merge(BlockCustomizationSchema);
const CustomPluginBlockSchema = z.object({
  type: z.literal("custom-plugin"),
  pluginId: z.string().min(1),
  // e.g. 'stat-block', 'my-custom-plugin'
  pluginData: z.record(z.string(), z.unknown())
  // plugin-specific props defined by schema.json
}).merge(BlockCustomizationSchema);
const ContentBlockSchema = z.discriminatedUnion("type", [
  StatBlockSchema,
  ComparisonBlockSchema,
  TextBlockSchema,
  ImageBlockSchema,
  QuoteBlockSchema,
  ListBlockSchema,
  TimelineBlockSchema,
  CalloutBlockSchema,
  IconListBlockSchema,
  LineChartBlockSchema,
  PieChartBlockSchema,
  CodeBlockSchema,
  TestimonialBlockSchema,
  WhatsAppChatBlockSchema,
  MotivationalImageBlockSchema,
  // New blocks
  CounterBlockSchema,
  ProgressBarBlockSchema,
  QRCodeBlockSchema,
  VideoBlockSchema,
  AvatarGridBlockSchema,
  SocialStatsBlockSchema,
  CTABlockSchema,
  GradientTextBlockSchema,
  AnimatedBackgroundBlockSchema,
  CountdownBlockSchema,
  WeatherBlockSchema,
  TowerChart3DBlockSchema,
  BarRace3DBlockSchema,
  ParallaxStoryBlockSchema,
  TopPlayersBlockSchema,
  PricingTableBlockSchema,
  LogoWallBlockSchema,
  ProcessStepsBlockSchema,
  HtmlBlockSchema,
  DiagramBlockSchema,
  // User plugin blocks
  CustomPluginBlockSchema
]);
z.object({
  videoMeta: VideoMetaSchema,
  contentBlocks: z.array(ContentBlockSchema).min(1).max(20),
  sourceTemplateId: z.string().optional()
});
const MotionProfileSchema = z.enum(["subtle", "dynamic", "energetic"]);
const AnimationPhaseSchema = z.object({
  enter: z.number().min(0).max(5),
  // Duration in seconds
  hold: z.number().min(0).max(55),
  // Duration in seconds (increased for long chats)
  exit: z.number().min(0).max(5)
  // Duration in seconds
});
const AIDecisionSchema = z.object({
  componentId: z.string(),
  motionProfile: MotionProfileSchema,
  duration: z.number().min(1).max(60),
  // Increased max for long chat conversations
  animation: AnimationPhaseSchema.optional(),
  props: z.record(z.unknown()).optional()
});
z.object({
  decisions: z.array(AIDecisionSchema),
  totalDuration: z.number(),
  suggestedTransitions: z.array(z.enum(["fade", "slide", "zoom", "wipe"])).optional()
});
z.object({
  id: z.string(),
  name: z.string(),
  supportedTypes: z.array(z.string()),
  defaultDuration: z.number(),
  defaultProps: z.record(z.unknown()).optional()
});

var index = /*#__PURE__*/Object.freeze({
  __proto__: null,
  AIDecisionSchema: AIDecisionSchema,
  AnimatedBackgroundBlockSchema: AnimatedBackgroundBlockSchema,
  AnimationPhaseSchema: AnimationPhaseSchema,
  AudioTrackSchema: AudioTrackSchema,
  AvatarGridBlockSchema: AvatarGridBlockSchema,
  BarRace3DBlockSchema: BarRace3DBlockSchema,
  BarRaceItemSchema: BarRaceItemSchema,
  BlockCustomizationSchema: BlockCustomizationSchema,
  CTABlockSchema: CTABlockSchema,
  CalloutBlockSchema: CalloutBlockSchema,
  CameraMovementSchema: CameraMovementSchema,
  CodeBlockSchema: CodeBlockSchema,
  ColorOverlaySchema: ColorOverlaySchema,
  ComparisonBlockSchema: ComparisonBlockSchema,
  ComparisonItemSchema: ComparisonItemSchema,
  ContentBlockSchema: ContentBlockSchema,
  CountdownBlockSchema: CountdownBlockSchema,
  CounterBlockSchema: CounterBlockSchema,
  CustomPluginBlockSchema: CustomPluginBlockSchema,
  DiagramBlockSchema: DiagramBlockSchema,
  DiagramEdgeSchema: DiagramEdgeSchema,
  DiagramNodeSchema: DiagramNodeSchema,
  ElementOverrideSchema: ElementOverrideSchema,
  FontFamilySchema: FontFamilySchema,
  GradientTextBlockSchema: GradientTextBlockSchema,
  HtmlBlockSchema: HtmlBlockSchema,
  IconItemSchema: IconItemSchema,
  IconListBlockSchema: IconListBlockSchema,
  ImageBlockSchema: ImageBlockSchema,
  ImageEffectSchema: ImageEffectSchema,
  IntroOutroSchema: IntroOutroSchema,
  LineChartBlockSchema: LineChartBlockSchema,
  ListBlockSchema: ListBlockSchema,
  LogoItemSchema: LogoItemSchema,
  LogoWallBlockSchema: LogoWallBlockSchema,
  MotionProfileSchema: MotionProfileSchema,
  MotivationalImageBlockSchema: MotivationalImageBlockSchema,
  ParallaxEffectSchema: ParallaxEffectSchema,
  ParallaxLayerSchema: ParallaxLayerSchema,
  ParallaxStoryBlockSchema: ParallaxStoryBlockSchema,
  PieChartBlockSchema: PieChartBlockSchema,
  PieSegmentSchema: PieSegmentSchema,
  PricingPlanSchema: PricingPlanSchema,
  PricingTableBlockSchema: PricingTableBlockSchema,
  ProcessStepSchema: ProcessStepSchema,
  ProcessStepsBlockSchema: ProcessStepsBlockSchema,
  ProgressBarBlockSchema: ProgressBarBlockSchema,
  QRCodeBlockSchema: QRCodeBlockSchema,
  QuoteBlockSchema: QuoteBlockSchema,
  SocialStatsBlockSchema: SocialStatsBlockSchema,
  StatBlockSchema: StatBlockSchema,
  StoryTextSchema: StoryTextSchema,
  SubtitleEntrySchema: SubtitleEntrySchema,
  SubtitleStyleSchema: SubtitleStyleSchema,
  SubtitleTrackSchema: SubtitleTrackSchema,
  TestimonialBlockSchema: TestimonialBlockSchema,
  TextBlockSchema: TextBlockSchema,
  TextOverlayTrackSchema: TextOverlayTrackSchema,
  TextStyleSchema: TextStyleSchema,
  TimelineBlockSchema: TimelineBlockSchema,
  TimelineEventSchema: TimelineEventSchema,
  TopPlayersBlockSchema: TopPlayersBlockSchema,
  TopPlayersPlayerSchema: TopPlayersPlayerSchema,
  TowerChart3DBlockSchema: TowerChart3DBlockSchema,
  TowerItemSchema: TowerItemSchema,
  VideoBlockSchema: VideoBlockSchema,
  VideoMetaSchema: VideoMetaSchema,
  WeatherBlockSchema: WeatherBlockSchema,
  WhatsAppChatBlockSchema: WhatsAppChatBlockSchema,
  WhatsAppMessageSchema: WhatsAppMessageSchema,
  WhatsAppParticipantSchema: WhatsAppParticipantSchema
});

async function mergeBlock(params) {
  console.log(`[merge_media] \u25B6 ${params.blockType}`);
  let origBlock = {};
  if (typeof params.originalBlock === "string") {
    try {
      const parsed = JSON.parse(params.originalBlock);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) origBlock = parsed;
    } catch {
    }
  } else if (params.originalBlock && typeof params.originalBlock === "object" && !Array.isArray(params.originalBlock)) {
    origBlock = params.originalBlock;
  }
  const rawContentIsEmpty = !params.rawContent || Object.keys(params.rawContent).length === 0;
  if (rawContentIsEmpty) {
    console.error(
      `[merge_media] \u274C rawContent is EMPTY for block ${params.blockIndex + 1} (${params.blockType}). Proceeding with resolved media so generated images/audio aren't discarded.`
    );
  }
  let content = rawContentIsEmpty ? {} : { ...params.rawContent };
  if (rawContentIsEmpty) {
    const staleMediaKeys = ["src", "imageSrc", "image", "url", "audioSrc", "videoSrc"];
    for (const k of staleMediaKeys) {
      if (k in origBlock) content[k] = "";
    }
    if (Array.isArray(origBlock.layers)) {
      content.layers = origBlock.layers.map((l) => ({
        ...l,
        image: typeof l.image === "string" && (l.image.startsWith("http") || l.image.startsWith("data:")) ? "" : l.image
      }));
    }
    if (params.narrativeBrief?.spokenScript) {
      content.audioSrc = params.narrativeBrief.spokenScript;
    }
  }
  for (const [path, url] of Object.entries(params.resolvedUrls)) {
    content = setNestedValue(content, path, url);
  }
  for (const [path, audio] of Object.entries(params.resolvedAudio)) {
    if (audio) {
      content = setNestedValue(content, path, audio);
    }
  }
  const { type: _stripped, ...contentWithoutType } = content;
  if (params.blockType === "tower-chart-3d") {
    try {
      const contentWithType = { ...contentWithoutType, type: params.blockType };
      const validated = TowerChart3DBlockSchema.parse(contentWithType);
      Object.assign(contentWithoutType, validated);
    } catch (e) {
      console.error("[merge_media] \u274C Schema validation failed for tower-chart-3d:", e);
    }
  }
  const schema = BLOCK_SCHEMAS[params.blockType];
  const useAllKeys = params.blockType === "custom-plugin" || !schema?.contentFields || schema.contentFields.length === 0;
  const allowedFields = new Set(useAllKeys ? Object.keys(contentWithoutType) : schema.contentFields);
  const pickedContent = {};
  for (const [key, val] of Object.entries(contentWithoutType)) {
    if (allowedFields.has(key)) {
      pickedContent[key] = val;
    }
  }
  let finalBlock;
  if (params.blockType === "custom-plugin") {
    const TOP_LEVEL = /* @__PURE__ */ new Set(["audioSrc", "duration", "audioLoop", "title"]);
    const pluginData = { ...origBlock.pluginData ?? {} };
    const topLevelOverrides = {};
    for (const [key, val] of Object.entries(pickedContent)) {
      if (TOP_LEVEL.has(key)) topLevelOverrides[key] = val;
      else pluginData[key] = val;
    }
    finalBlock = {
      ...origBlock,
      type: "custom-plugin",
      pluginId: origBlock.pluginId,
      ...topLevelOverrides,
      pluginData
    };
  } else {
    finalBlock = {
      ...origBlock,
      type: params.blockType,
      ...pickedContent
    };
    delete finalBlock.pluginData;
  }
  delete finalBlock._skeleton;
  delete finalBlock.blockIndex;
  delete finalBlock.generationFields;
  return { finalBlock };
}

const globalPool = globalThis;
const pool$1 = globalPool.pool ?? new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});
const db$1 = {
  query: async (text, params) => {
    const client = await pool$1.connect();
    try {
      return await client.query(text, params);
    } finally {
      client.release();
    }
  }
};

function extractNormalizedFields(schemaObj, sceneCode) {
  const fields = [];
  const seen = /* @__PURE__ */ new Set();
  function add(field) {
    if (!seen.has(field.path)) {
      seen.add(field.path);
      fields.push(field);
    }
  }
  const mediaEditors = /* @__PURE__ */ new Set(["image", "audio", "video"]);
  function collectSchemaFields(properties, prefix = "") {
    for (const [key, prop] of Object.entries(properties)) {
      const path = prefix ? `${prefix}.${key}` : key;
      if (mediaEditors.has(prop.editor)) {
        add({
          path,
          description: prop.description ?? prop.title ?? "",
          type: prop.editor,
          removeBackground: !!prop.removeBackground
        });
      }
      if (prop.type === "array" && prop.items?.properties) {
        for (const [nestedKey, nestedProp] of Object.entries(prop.items.properties)) {
          const nestedPath = `${path}[].${nestedKey}`;
          if (mediaEditors.has(nestedProp.editor)) {
            add({
              path: nestedPath,
              description: nestedProp.description ?? nestedProp.title ?? "",
              type: nestedProp.editor,
              removeBackground: !!nestedProp.removeBackground
            });
          }
          if (nestedProp.type === "object" && nestedProp.properties) {
            collectSchemaFields(nestedProp.properties, nestedPath);
          }
        }
      }
      if (prop.type === "object" && prop.properties) {
        collectSchemaFields(prop.properties, path);
      }
    }
  }
  const schemaProperties = schemaObj.properties ?? {};
  const pluginDataWrapper = schemaProperties.pluginData;
  if (pluginDataWrapper?.type === "object" && pluginDataWrapper.properties && Object.keys(schemaProperties).length === 1) {
    collectSchemaFields(pluginDataWrapper.properties);
  } else {
    collectSchemaFields(schemaProperties);
  }
  if (!(pluginDataWrapper?.type === "object" && pluginDataWrapper.properties && Object.keys(schemaProperties).length === 1)) {
    for (const [key, prop] of Object.entries(schemaObj.properties ?? {})) {
      if (mediaEditors.has(prop.editor)) {
        add({
          path: key,
          description: prop.description ?? prop.title ?? "",
          type: prop.editor,
          removeBackground: !!prop.removeBackground
        });
      }
      if (prop.type === "array" && prop.items?.properties) {
        for (const [nestedKey, nestedProp] of Object.entries(prop.items.properties)) {
          if (mediaEditors.has(nestedProp.editor)) {
            add({
              path: `${key}[].${nestedKey}`,
              description: nestedProp.description ?? nestedProp.title ?? "",
              type: nestedProp.editor,
              removeBackground: !!nestedProp.removeBackground
            });
          }
        }
      }
      if (prop.type === "object" && prop.properties) {
        for (const [nestedKey, nestedProp] of Object.entries(prop.properties)) {
          if (mediaEditors.has(nestedProp.editor)) {
            add({
              path: `${key}.${nestedKey}`,
              description: nestedProp.description ?? nestedProp.title ?? "",
              type: nestedProp.editor,
              removeBackground: !!nestedProp.removeBackground
            });
          }
        }
      }
    }
  }
  const elementRegex = /<[^>]+data-ai-type="(image|audio|video)"[^>]*>/g;
  let elementMatch;
  while ((elementMatch = elementRegex.exec(sceneCode)) !== null) {
    const fullElement = elementMatch[0];
    const type = elementMatch[1];
    const srcMatch = fullElement.match(/src=\{(?:data\.)?([\w.]+)\}/);
    const promptMatch = fullElement.match(/data-ai-prompt="([^"]*)"/);
    const removeBgMatch = fullElement.match(/data-ai-remove-bg="true"/);
    if (srcMatch) {
      add({
        path: srcMatch[1],
        description: promptMatch ? promptMatch[1] : "",
        type,
        removeBackground: !!removeBgMatch
      });
    }
  }
  return fields;
}
function convertLegacyGenerationFields(legacy) {
  const fields = [];
  for (const f of legacy.image ?? []) fields.push({ path: f.path, description: f.prompt, type: "image" });
  for (const f of legacy.audio ?? []) fields.push({ path: f.path, description: f.prompt, type: "audio" });
  for (const f of legacy.video ?? []) fields.push({ path: f.path, description: f.prompt, type: "video" });
  return fields;
}
function isLegacyGenerationFields(val) {
  return val !== null && typeof val === "object" && !Array.isArray(val) && "image" in val;
}

async function fillCustomPluginBlock(block, _brief, _userStory, _apiKey, _model) {
  if (!block.pluginId) {
    return { rawContent: block.pluginData ?? {}, generationFields: [] };
  }
  const result = await db$1.query(
    `SELECT schema_json, generation_fields FROM plugins WHERE id = $1`,
    [block.pluginId]
  );
  if (!result.rows[0]) {
    console.warn(`[fillCustomPlugin] Plugin not found: ${block.pluginId}`);
    return { rawContent: block.pluginData ?? {}, generationFields: [] };
  }
  let schema = {};
  try {
    schema = JSON.parse(result.rows[0].schema_json);
  } catch {
  }
  const schemaProperties = schema.properties ?? {};
  const pluginDataWrapper = schemaProperties.pluginData;
  const contentSchema = pluginDataWrapper?.type === "object" && pluginDataWrapper.properties && Object.keys(schemaProperties).length === 1 ? { properties: pluginDataWrapper.properties } : schema;
  let generationFields;
  const rawFields = result.rows[0].generation_fields;
  if (isLegacyGenerationFields(rawFields)) {
    generationFields = convertLegacyGenerationFields(rawFields);
  } else if (Array.isArray(rawFields)) {
    generationFields = rawFields;
  } else {
    generationFields = [];
  }
  if (generationFields.length === 0) {
    generationFields = extractNormalizedFields(contentSchema, "");
  }
  const arraySize = {};
  for (const f of generationFields) {
    const m = (f.path ?? "").match(/^([^[.]+)\[(\d+)\]/);
    if (!m) continue;
    const [, name, idxStr] = m;
    const need = parseInt(idxStr, 10) + 1;
    if (need > (arraySize[name] ?? 0)) arraySize[name] = need;
  }
  const seedForProp = (key, prop) => {
    if (prop?.default !== void 0) return prop.default;
    const t = prop?.type;
    if (t === "array") return Array.from({ length: arraySize[key] ?? 0 }, () => ({}));
    if (t === "object") return {};
    if (t === "number" || t === "integer") return 0;
    if (t === "boolean") return false;
    return "";
  };
  const schemaSeed = {};
  for (const [key, prop] of Object.entries(contentSchema.properties ?? {})) {
    schemaSeed[key] = seedForProp(key, prop);
  }
  const schemaDescriptions = {};
  for (const [key, prop] of Object.entries(contentSchema.properties ?? {})) {
    if (prop?.description) schemaDescriptions[key] = prop.description;
  }
  const blockPluginData = block.pluginData?.pluginData && typeof block.pluginData.pluginData === "object" && !Array.isArray(block.pluginData.pluginData) ? block.pluginData.pluginData : block.pluginData;
  const rawContent = { ...schemaSeed, ...blockPluginData ?? {} };
  return { rawContent, generationFields, schemaDescriptions };
}

const videoGenInputSchema = z.object({
  userStory: z.string(),
  templateBlocks: z.array(z.object({ type: z.string() }).passthrough()),
  partialVideoMeta: z.record(z.string(), z.any()),
  apiKey: z.string(),
  model: z.string().optional().default("google/gemini-2.5-flash"),
  preferredArc: z.string().nullable().optional(),
  preferredVoice: z.string().nullable().optional(),
  preferredVisualStyle: z.string().nullable().optional(),
  customVisualPrompt: z.string().nullable().optional(),
  customArc: z.object({ roles: z.array(z.string()), defaultTone: z.string() }).nullable().optional(),
  language: z.string().optional().default("en")
}).passthrough();
const videoGenOutputSchema = z.object({
  success: z.boolean(),
  selectedArc: z.string(),
  payload: z.object({
    videoMeta: z.record(z.string(), z.any()),
    contentBlocks: z.array(z.record(z.string(), z.any()))
  }),
  errors: z.array(z.string()),
  tokensUsed: z.number()
}).passthrough();
const enrichVideoMetaStep = createStep({
  id: "enrich-video-meta",
  inputSchema: videoGenInputSchema,
  outputSchema: z.object({}).passthrough(),
  execute: async ({ inputData }) => {
    const input = inputData;
    const language = input.language ?? "en";
    let arcPatternCatalog = {};
    let visualStyleCatalog = {};
    try {
      const [arcRows, styleRows] = await Promise.all([
        db$1.query("SELECT id, label, description, arc_pattern FROM story_arcs WHERE is_active = true"),
        db$1.query("SELECT id, label, prompt_prefix FROM visual_styles WHERE is_active = true")
      ]);
      for (const row of arcRows.rows) {
        if (row.arc_pattern?.roles && row.arc_pattern?.defaultTone) {
          arcPatternCatalog[row.id] = {
            name: row.id,
            description: row.description,
            roles: row.arc_pattern.roles,
            defaultTone: row.arc_pattern.defaultTone
          };
        }
      }
      for (const row of styleRows.rows) {
        if (row.prompt_prefix) {
          visualStyleCatalog[row.id] = { name: row.label, promptPrefix: row.prompt_prefix };
        }
      }
    } catch {
    }
    const videoMeta = await enrichVideoMeta({
      userStory: input.userStory,
      partialVideoMeta: input.partialVideoMeta,
      language,
      apiKey: input.apiKey,
      model: input.model
    });
    getRunContext()?.write("plan.md", [
      `# Run Plan`,
      `Story: ${input.userStory}`,
      `Language: ${language}`,
      `Blocks (${input.templateBlocks.length}): ${input.templateBlocks.map((b) => b.type).join(", ")}`
    ].join("\n"));
    return {
      input,
      videoMeta,
      arcPatternCatalog,
      visualStyleCatalog,
      language,
      errors: []
    };
  }
});
const selectArcStep = createStep({
  id: "select-arc",
  inputSchema: z.object({}).passthrough(),
  outputSchema: z.object({}).passthrough(),
  execute: async ({ inputData }) => {
    const data = inputData;
    const { input, arcPatternCatalog} = data;
    const selectedArc = await selectArc({
      userStory: input.userStory,
      templateBlocks: input.templateBlocks,
      preferredArc: input.preferredArc ?? null,
      arcPatternCatalog,
      apiKey: input.apiKey,
      model: input.model
    });
    const { mediaStrategy, researchContext } = await planMediaStrategyViaAgent({
      userStory: input.userStory,
      selectedArc,
      preferredArc: input.preferredArc ?? null,
      templateBlocks: input.templateBlocks,
      apiKey: input.apiKey,
      model: input.model
    });
    const ctx = getRunContext();
    if (mediaStrategy?.blockStrategies?.length) {
      ctx?.write("media-strategy.md", [
        `# Media Strategy`,
        `Arc: ${selectedArc?.name ?? "unknown"}`,
        ...mediaStrategy.blockStrategies.map(
          (s, i) => `Block ${i + 1}: imageSource=${s.imageSource}${s.searchQueryStyle ? `, style=${s.searchQueryStyle}` : ""}`
        )
      ].join("\n"));
    }
    return {
      ...data,
      selectedArc,
      mediaStrategy,
      researchContext
    };
  }
});
const directorEvaluateStep = createStep({
  id: "director-evaluate",
  inputSchema: z.object({}).passthrough(),
  outputSchema: z.object({}).passthrough(),
  execute: async ({ inputData }) => {
    const data = inputData;
    const { input, arcPatternCatalog, visualStyleCatalog, selectedArc, researchContext, language } = data;
    let directorResult;
    let engagementScore = 0;
    let engagementFeedback = "";
    let loopCount = 0;
    for (let attempt = 0; attempt < MAX_DIRECTOR_LOOPS; attempt++) {
      loopCount = attempt + 1;
      directorResult = await runDirector({
        userStory: input.userStory,
        templateBlocks: input.templateBlocks,
        selectedArc,
        preferredArc: input.preferredArc ?? null,
        customArc: input.customArc ?? null,
        arcPatternCatalog,
        visualStyleCatalog,
        preferredVisualStyle: input.preferredVisualStyle ?? null,
        customVisualPrompt: input.customVisualPrompt ?? null,
        engagementFeedback,
        engagementScore,
        directorLoopCount: loopCount,
        researchContext,
        language,
        apiKey: input.apiKey,
        model: input.model
      });
      const evalResult = await evaluateEngagement({
        userStory: input.userStory,
        narrativePlan: directorResult.narrativePlan,
        directorLoopCount: loopCount,
        language,
        apiKey: input.apiKey,
        model: input.model
      });
      engagementScore = evalResult.engagementScore;
      engagementFeedback = evalResult.engagementFeedback;
      const ctx = getRunContext();
      ctx?.write("narrative.md", [
        `# Narrative Plan (Attempt ${loopCount})`,
        ...(directorResult.narrativePlan ?? []).map(
          (b, i) => `## Block ${i + 1} [${b.narrativeRole}]
Key message: ${b.keyMessage}
Script: ${b.spokenScript}`
        )
      ].join("\n\n"));
      ctx?.append("iteration-log.md", [
        `## Attempt ${loopCount}`,
        `Score: ${engagementScore}/10`,
        `Pass: ${engagementScore >= ENGAGEMENT_THRESHOLD ? "YES \u2713" : "NO"}`,
        engagementFeedback ? `Feedback: ${engagementFeedback}` : ""
      ].filter(Boolean).join("\n"));
      if (engagementScore >= ENGAGEMENT_THRESHOLD) break;
    }
    return {
      ...data,
      directorResult,
      engagementScore
    };
  }
});
const fillBlocksStep = createStep({
  id: "fill-blocks",
  inputSchema: z.object({}).passthrough(),
  outputSchema: z.object({}).passthrough(),
  execute: async ({ inputData }) => {
    const data = inputData;
    const { input, videoMeta, directorResult, mediaStrategy, researchContext, language, errors: prevErrors } = data;
    const errors = [...prevErrors || []];
    const filledBlocks = await Promise.all(
      input.templateBlocks.map(async (block, i) => {
        const narrativeBrief = directorResult.narrativePlan[i] ?? null;
        try {
          if (block.type === "custom-plugin") {
            return fillCustomPluginBlock(block);
          }
          const { rawContent, error: contentError } = await generateContent({
            blockType: block.type,
            blockIndex: i,
            userStory: input.userStory,
            originalBlock: block,
            narrativeBrief,
            storyBible: directorResult.storyBible,
            selectedLenses: directorResult.selectedLenses,
            researchContext,
            mediaStrategy,
            aspectRatio: videoMeta.aspectRatio ?? "9:16",
            language,
            apiKey: input.apiKey,
            model: input.model
          });
          if (contentError) {
            errors.push(`Block ${i + 1} (${block.type}): ${contentError}`);
            return block;
          }
          const { imageFields, audioFields, videoFields, rawContent: updatedRawContent } = await classifyMediaFields({
            rawContent,
            blockType: block.type,
            originalBlock: block,
            narrativeBrief,
            mediaStrategy,
            blockIndex: i
          });
          const effectiveRawContent = updatedRawContent ?? rawContent;
          const [imgResult, audioResult, videoResult] = await Promise.all([
            resolveImages({ imageFields, blockIndex: i, mediaStrategy, visualStyleGuide: directorResult.visualStyleGuide}),
            resolveAudio({ audioFields, preferredVoice: input.preferredVoice ?? null}),
            resolveVideo({ videoFields})
          ]);
          const resolvedUrls = { ...imgResult.resolvedUrls, ...videoResult.resolvedUrls };
          const { finalBlock } = await mergeBlock({
            rawContent: effectiveRawContent,
            resolvedUrls,
            resolvedAudio: audioResult.resolvedAudio,
            originalBlock: block,
            blockType: block.type,
            blockIndex: i,
            narrativeBrief
          });
          return mergeParallaxLayers(finalBlock, block);
        } catch (e) {
          errors.push(`Block ${i + 1} (${block.type}): ${e.message}`);
          return block;
        }
      })
    );
    return {
      ...data,
      filledBlocks,
      errors
    };
  }
});
const assembleStep = createStep({
  id: "assemble",
  inputSchema: z.object({}).passthrough(),
  outputSchema: videoGenOutputSchema,
  execute: async ({ inputData }) => {
    const data = inputData;
    const { input, videoMeta, directorResult, filledBlocks, errors } = data;
    const contentBlocks = await applyBlockPostProcessors(filledBlocks, input.templateBlocks, videoMeta);
    const payload = { videoMeta, contentBlocks };
    return {
      success: true,
      selectedArc: directorResult.selectedArc.name,
      payload,
      errors: errors || [],
      tokensUsed: getTokenTotal()
    };
  }
});
const videoGenWorkflow = createWorkflow({
  id: "video-gen",
  inputSchema: videoGenInputSchema,
  outputSchema: videoGenOutputSchema
}).then(enrichVideoMetaStep).then(selectArcStep).then(directorEvaluateStep).then(fillBlocksStep).then(assembleStep).commit();

async function createJob(threadId, userId) {
  await db$1.query(
    `INSERT INTO wizard_jobs (thread_id, user_id, status)
     VALUES ($1, $2, 'running')
     ON CONFLICT (thread_id) DO NOTHING`,
    [threadId, userId]
  );
}
async function getJob(threadId) {
  const result = await db$1.query(
    `SELECT * FROM wizard_jobs WHERE thread_id = $1`,
    [threadId]
  );
  return result.rows[0] ?? null;
}
async function updateJob(threadId, update) {
  await db$1.query(
    `UPDATE wizard_jobs
     SET status = $2, interrupt = $3, payload = $4, error = $5, state = COALESCE($6, state), updated_at = NOW()
     WHERE thread_id = $1`,
    [
      threadId,
      update.status,
      update.interrupt ? JSON.stringify(update.interrupt) : null,
      update.payload ? JSON.stringify(update.payload) : null,
      update.error ?? null,
      update.state ? JSON.stringify(update.state) : null
    ]
  );
}
async function patchJobState(threadId, updater) {
  const job = await getJob(threadId);
  if (!job) return;
  const current = job.state ?? {};
  const updated = updater(current);
  await db$1.query(
    `UPDATE wizard_jobs SET state = $2, updated_at = NOW() WHERE thread_id = $1`,
    [threadId, JSON.stringify(updated)]
  );
}
async function patchJobStateBlock(threadId, index, block) {
  await db$1.query(
    `UPDATE wizard_jobs 
     SET state = jsonb_set(
       COALESCE(state, '{}'::jsonb), 
       ARRAY['filledBlocks', $2::text], 
       $3::jsonb,
       true
     ), 
     updated_at = NOW() 
     WHERE thread_id = $1`,
    [threadId, index.toString(), JSON.stringify(block)]
  );
}
async function patchJobStateImageItem(threadId, item) {
  const job = await getJob(threadId);
  if (!job) return;
  const state = job.state ?? {};
  const imageItems = state.imageItems ?? [];
  const idx = imageItems.findIndex((i) => i.blockIdx === item.blockIdx && i.field_path === item.field_path);
  if (idx >= 0) {
    await db$1.query(
      `UPDATE wizard_jobs 
       SET state = jsonb_set(state, ARRAY['imageItems', $2::text], $3::jsonb),
       updated_at = NOW()
       WHERE thread_id = $1`,
      [threadId, idx.toString(), JSON.stringify(item)]
    );
  } else {
    await db$1.query(
      `UPDATE wizard_jobs 
       SET state = jsonb_set(
         COALESCE(state, '{}'::jsonb), 
         ARRAY['imageItems'], 
         COALESCE(state->'imageItems', '[]'::jsonb) || $2::jsonb
       ),
       updated_at = NOW()
       WHERE thread_id = $1`,
      [threadId, JSON.stringify(item)]
    );
  }
}

async function saveWizardState(threadId, state) {
  const job = await getJob(threadId);
  if (job) {
    await patchJobState(threadId, () => state);
  } else {
    await db$1.query(
      `INSERT INTO wizard_jobs (thread_id, user_id, status, state, updated_at) VALUES ($1, '', 'running', $2, NOW())
       ON CONFLICT (thread_id) DO UPDATE SET state = $2, updated_at = NOW()`,
      [threadId, JSON.stringify(state)]
    );
  }
}
async function loadWizardState(threadId) {
  const job = await getJob(threadId);
  if (!job) return null;
  return job.state ?? null;
}
const wizardInputSchema = z.object({
  threadId: z.string(),
  userStory: z.string(),
  templateBlocks: z.array(z.object({ type: z.string() }).passthrough()),
  partialVideoMeta: z.record(z.string(), z.any()),
  preferredArc: z.string().nullable(),
  preferredVoice: z.string().nullable(),
  preferredVisualStyle: z.string().nullable(),
  customVisualPrompt: z.string().nullable(),
  customArc: z.object({ roles: z.array(z.string()), defaultTone: z.string() }).nullable(),
  language: z.string(),
  apiKey: z.string(),
  model: z.string(),
  /** Inline preview mode: chat stays open, previews appear inline.
   *  Paged mode (default): legacy separate review pages. */
  inlineMode: z.boolean().optional().default(false)
}).passthrough();
const wizardOutputSchema = z.object({
  status: z.enum(["interrupted", "complete"]),
  interrupt: z.record(z.string(), z.any()).optional(),
  payload: z.record(z.string(), z.any()).optional(),
  stateSnapshot: z.record(z.string(), z.any()).optional(),
  tokensUsed: z.number(),
  /** In inline mode, the preview data is attached here for immediate display */
  preview: z.record(z.string(), z.any()).optional()
}).passthrough();
function isFilledUrl(value) {
  if (typeof value !== "string") return false;
  return value.startsWith("http://") || value.startsWith("https://") || value.startsWith("data:");
}
async function fillAllBlocks(params) {
  const { threadId, templateBlocks, narrativePlan, userStory, visualStyleGuide, storyBible, selectedLenses, mediaStrategy, researchContext, videoMeta, preferredVoice, language, apiKey, model } = params;
  const allImageItems = [];
  const allVideoItems = [];
  const classifiedByBlock = /* @__PURE__ */ new Map();
  if (threadId) {
    try {
      await patchJobState(threadId, (current) => ({
        ...current,
        filledBlocks: templateBlocks.map((b, i) => ({ ...b, blockIndex: i })),
        imageItems: [],
        audioItems: []
      }));
    } catch (e) {
      console.warn(`[wizard-workflow] Initial state patch failed: ${e.message}`);
    }
  }
  const blocksWithContent = await Promise.all(
    templateBlocks.map(async (block, i) => {
      const brief = narrativePlan[i] ?? null;
      try {
        let schemaDescriptions;
        if (block.type === "custom-plugin") {
          const pluginMeta = await fillCustomPluginBlock(block);
          block = { ...block, ...pluginMeta.rawContent, generationFields: pluginMeta.generationFields };
          schemaDescriptions = pluginMeta.schemaDescriptions;
        }
        const { rawContent, error } = await generateContent({
          blockType: block.type,
          blockIndex: i,
          userStory,
          originalBlock: block,
          narrativeBrief: brief,
          storyBible,
          selectedLenses,
          researchContext,
          mediaStrategy,
          aspectRatio: videoMeta.aspectRatio ?? "9:16",
          language,
          apiKey,
          model,
          schemaDescriptions
        });
        if (error) return block;
        const { imageFields, audioFields, videoFields, rawContent: updatedRawContent } = await classifyMediaFields({
          rawContent,
          blockType: block.type,
          originalBlock: block,
          narrativeBrief: brief,
          mediaStrategy,
          blockIndex: i
        });
        const effectiveRawContent = updatedRawContent ?? rawContent;
        const classified = [
          ...imageFields.map((f) => ({ kind: "image", path: f.path, description: f.description })),
          ...audioFields.map((f) => ({ kind: "audio", path: f.path, description: f.text })),
          ...videoFields.map((f) => ({ kind: "video", path: f.path, description: f.prompt }))
        ];
        classifiedByBlock.set(i, classified);
        const [imgResult, videoResult] = await Promise.all([
          resolveImages({ imageFields, blockIndex: i, mediaStrategy, visualStyleGuide}),
          resolveVideo({ videoFields})
        ]);
        const combinedUrls = { ...imgResult.resolvedUrls, ...videoResult.resolvedUrls };
        for (const [path, url] of Object.entries(imgResult.resolvedUrls)) {
          const desc = imageFields.find((f) => f.path === path)?.description ?? "";
          const match = path.match(/^layers\[(\d+)]/);
          const playerImgMatch = path.match(/^players\[(\d+)]\.image$/);
          const removeBg = match ? !!effectiveRawContent?.layers?.[parseInt(match[1], 10)]?.removeBackground : !!playerImgMatch;
          allImageItems.push({ blockIdx: i, fieldPath: path, url, description: desc, removeBackground: removeBg });
        }
        for (const { path, prompt } of videoFields) {
          allVideoItems.push({ blockIdx: i, fieldPath: path, url: "", description: prompt });
        }
        const { finalBlock } = await mergeBlock({
          rawContent: effectiveRawContent,
          resolvedUrls: combinedUrls,
          resolvedAudio: {},
          originalBlock: block,
          blockType: block.type,
          blockIndex: i,
          narrativeBrief: brief
        });
        const mergedBlock = mergeParallaxLayers(finalBlock, block);
        if (threadId) {
          try {
            await patchJobStateBlock(threadId, i, mergedBlock);
            for (const [path, url] of Object.entries(imgResult.resolvedUrls)) {
              const desc = imageFields.find((f) => f.path === path)?.description ?? "";
              const match = path.match(/^layers\[(\d+)]/);
              const playerImgMatch = path.match(/^players\[(\d+)]\.image$/);
              const removeBg = match ? !!effectiveRawContent?.layers?.[parseInt(match[1], 10)]?.removeBackground : !!playerImgMatch;
              await patchJobStateImageItem(threadId, {
                blockIdx: i,
                fieldPath: path,
                url,
                description: desc,
                removeBackground: removeBg
              });
            }
          } catch (e) {
            console.warn(`[wizard-workflow] Image state patch failed for block ${i}: ${e.message}`);
          }
        }
        return mergedBlock;
      } catch (e) {
        return block;
      }
    })
  );
  const filledBlocks = await Promise.all(
    blocksWithContent.map(async (block, i) => {
      try {
        const audioFields = extractAudioFields(block);
        if (audioFields.length === 0) return block;
        let updated = { ...block };
        for (const { path, text } of audioFields) {
          if (text && !text.startsWith("data:") && !text.startsWith("http")) {
            try {
              const audioResult = await resolveAudio({
                audioFields: [{ path, text }],
                preferredVoice});
              if (audioResult.resolvedAudio[path]) {
                updated = setBlockNestedValue(updated, path, audioResult.resolvedAudio[path]);
                if (threadId) {
                  try {
                    await patchJobStateBlock(threadId, i, updated);
                  } catch (e) {
                    console.warn(`[wizard-workflow] Audio state patch failed for block ${i}: ${e.message}`);
                  }
                }
              }
            } catch (e) {
              console.warn(`[wizard-workflow] Audio failed for block ${i} path ${path}: ${e.message}`);
            }
          }
        }
        return updated;
      } catch (e) {
        return block;
      }
    })
  );
  const unresolvable = [];
  for (let i = 0; i < filledBlocks.length; i++) {
    const block = filledBlocks[i];
    const classified = classifiedByBlock.get(i) ?? [];
    if (classified.length === 0) continue;
    for (const field of classified) {
      const current = getBlockNestedValue(block, field.path);
      if (isFilledUrl(current)) continue;
      try {
        if (field.kind === "image") {
          const r = await resolveImages({
            imageFields: [{ path: field.path, description: field.description }],
            blockIndex: i,
            mediaStrategy,
            visualStyleGuide});
          const url = r.resolvedUrls[field.path];
          if (isFilledUrl(url)) {
            const updated = setBlockNestedValue(block, field.path, url);
            filledBlocks[i] = updated;
            if (threadId) {
              try {
                await patchJobStateBlock(threadId, i, updated);
              } catch {
              }
            }
            continue;
          }
        } else if (field.kind === "video") {
          const r = await resolveVideo({
            videoFields: [{ path: field.path, prompt: field.description }]});
          const url = r.resolvedUrls[field.path];
          if (isFilledUrl(url)) {
            const updated = setBlockNestedValue(block, field.path, url);
            filledBlocks[i] = updated;
            if (threadId) {
              try {
                await patchJobStateBlock(threadId, i, updated);
              } catch {
              }
            }
            continue;
          }
        } else if (field.kind === "audio") {
          const text = field.description;
          if (text && !text.startsWith("http") && !text.startsWith("data:")) {
            const r = await resolveAudio({
              audioFields: [{ path: field.path, text }],
              preferredVoice});
            const url = r.resolvedAudio[field.path];
            if (isFilledUrl(url)) {
              const updated = setBlockNestedValue(block, field.path, url);
              filledBlocks[i] = updated;
              if (threadId) {
                try {
                  await patchJobStateBlock(threadId, i, updated);
                } catch {
                }
              }
              continue;
            }
          }
        }
      } catch (e) {
        console.warn(`[wizard-workflow] Retry failed for block ${i} path ${field.path}: ${e?.message ?? e}`);
      }
      unresolvable.push({
        blockIndex: i,
        path: field.path,
        kind: field.kind,
        reason: "still empty after one retry"
      });
    }
  }
  const audioItems = filledBlocks.map((block, idx) => {
    const audioSrc = block.audioSrc ?? "";
    const hasAudio = audioSrc.startsWith("data:") || audioSrc.startsWith("http");
    return {
      blockIdx: idx,
      narrativeRole: block.narrativeRole ?? block.role ?? `block_${idx}`,
      hasAudio,
      audioUrl: hasAudio ? audioSrc : "",
      script: block.spokenScript ?? (!hasAudio ? audioSrc : "") ?? ""
    };
  });
  return { blocksWithContent, allImageItems, allVideoItems, filledBlocks, audioItems, unresolvable };
}
const initStep = createStep({
  id: "init",
  inputSchema: wizardInputSchema,
  outputSchema: z.object({}).passthrough(),
  suspendSchema: z.object({
    type: z.string(),
    narrativePlan: z.array(z.any()),
    videoMeta: z.record(z.string(), z.any()),
    selectedArc: z.string(),
    engagementScore: z.number(),
    visualStyleGuide: z.string(),
    storyBible: z.string()
  }).passthrough(),
  execute: async ({ inputData, suspend }) => {
    const input = inputData;
    const threadId = input.threadId;
    const inlineMode = input.inlineMode ?? false;
    let arcPatternCatalog = {};
    let visualStyleCatalog = {};
    try {
      const [arcRows, styleRows] = await Promise.all([
        db$1.query("SELECT id, label, description, arc_pattern FROM story_arcs WHERE is_active = true"),
        db$1.query("SELECT id, label, prompt_prefix FROM visual_styles WHERE is_active = true")
      ]);
      for (const row of arcRows.rows) {
        if (row.arc_pattern?.roles && row.arc_pattern?.defaultTone) {
          arcPatternCatalog[row.id] = { name: row.id, description: row.description, roles: row.arc_pattern.roles, defaultTone: row.arc_pattern.defaultTone };
        }
      }
      for (const row of styleRows.rows) {
        if (row.prompt_prefix) visualStyleCatalog[row.id] = { name: row.label, promptPrefix: row.prompt_prefix };
      }
    } catch {
    }
    const videoMeta = await enrichVideoMeta({
      userStory: input.userStory,
      partialVideoMeta: input.partialVideoMeta,
      language: input.language,
      apiKey: input.apiKey,
      model: input.model
    });
    getRunContext()?.write("plan.md", [
      `# Run Plan`,
      `Story: ${input.userStory}`,
      `Language: ${input.language ?? "en"}`,
      `Blocks (${input.templateBlocks.length}): ${input.templateBlocks.map((b) => b.type).join(", ")}`
    ].join("\n"));
    const { mediaStrategy, researchContext } = await planMediaStrategyViaAgent({
      userStory: input.userStory,
      selectedArc: null,
      preferredArc: input.preferredArc,
      templateBlocks: input.templateBlocks,
      apiKey: input.apiKey,
      model: input.model
    });
    const selectedArc = await selectArc({
      userStory: input.userStory,
      templateBlocks: input.templateBlocks,
      preferredArc: input.preferredArc,
      arcPatternCatalog,
      apiKey: input.apiKey,
      model: input.model
    });
    let directorResult;
    let engagementScore = 0;
    let engagementFeedback = "";
    let loopCount = 0;
    for (let attempt = 0; attempt < MAX_DIRECTOR_LOOPS; attempt++) {
      loopCount = attempt + 1;
      directorResult = await runDirector({
        userStory: input.userStory,
        templateBlocks: input.templateBlocks,
        selectedArc,
        preferredArc: input.preferredArc,
        customArc: input.customArc,
        arcPatternCatalog,
        visualStyleCatalog,
        preferredVisualStyle: input.preferredVisualStyle,
        customVisualPrompt: input.customVisualPrompt,
        engagementFeedback,
        engagementScore,
        directorLoopCount: loopCount,
        researchContext,
        language: input.language,
        apiKey: input.apiKey,
        model: input.model
      });
      const evalResult = await evaluateEngagement({
        userStory: input.userStory,
        narrativePlan: directorResult.narrativePlan,
        directorLoopCount: loopCount,
        language: input.language,
        apiKey: input.apiKey,
        model: input.model
      });
      engagementScore = evalResult.engagementScore;
      engagementFeedback = evalResult.engagementFeedback;
      const ctx = getRunContext();
      ctx?.write("narrative.md", [
        `# Narrative Plan (Attempt ${loopCount})`,
        ...(directorResult.narrativePlan ?? []).map(
          (b, i) => `## Block ${i + 1} [${b.narrativeRole}]
Key message: ${b.keyMessage}
Script: ${b.spokenScript}`
        )
      ].join("\n\n"));
      ctx?.append("iteration-log.md", [
        `## Attempt ${loopCount}`,
        `Score: ${engagementScore}/10`,
        `Pass: ${engagementScore >= ENGAGEMENT_THRESHOLD ? "YES \u2713" : "NO"}`,
        engagementFeedback ? `Feedback: ${engagementFeedback}` : ""
      ].filter(Boolean).join("\n"));
      if (engagementScore >= ENGAGEMENT_THRESHOLD) break;
    }
    if (inlineMode) {
      const fillResult = await fillAllBlocks({
        threadId,
        templateBlocks: input.templateBlocks,
        narrativePlan: directorResult.narrativePlan,
        userStory: input.userStory,
        visualStyleGuide: directorResult.visualStyleGuide ?? "",
        storyBible: directorResult.storyBible ?? "",
        selectedLenses: directorResult.selectedLenses,
        mediaStrategy,
        researchContext,
        videoMeta,
        preferredVoice: input.preferredVoice,
        language: input.language,
        apiKey: input.apiKey,
        model: input.model
      });
      const postProcessedBlocks = await applyBlockPostProcessors(
        fillResult.filledBlocks,
        input.templateBlocks,
        videoMeta
      );
      const wizardState2 = {
        input,
        videoMeta,
        selectedArc: directorResult.selectedArc,
        narrativePlan: directorResult.narrativePlan,
        visualStyleGuide: directorResult.visualStyleGuide,
        storyBible: directorResult.storyBible,
        selectedLenses: directorResult.selectedLenses,
        mediaStrategy,
        researchContext,
        blocksWithImages: fillResult.blocksWithContent,
        imageItems: fillResult.allImageItems,
        videoItems: fillResult.allVideoItems,
        filledBlocks: postProcessedBlocks,
        audioItems: fillResult.audioItems,
        unresolvable: fillResult.unresolvable,
        phase: "preview",
        // New phase: preview is ready, waiting for user feedback
        inlineMode: true
      };
      await saveWizardState(threadId, wizardState2);
      if (threadId) {
        try {
          for (let i = 0; i < postProcessedBlocks.length; i++) {
            await patchJobStateBlock(threadId, i, postProcessedBlocks[i]);
          }
        } catch (e) {
          console.warn(`[wizard-workflow] Post-processor state patch failed: ${e.message}`);
        }
      }
      return {
        input,
        videoMeta,
        directorResult,
        mediaStrategy,
        researchContext,
        fillResult: { ...fillResult, filledBlocks: postProcessedBlocks },
        phase: "preview",
        inlineMode: true
      };
    }
    const storyInterrupt = {
      type: "review_story",
      narrativePlan: directorResult.narrativePlan,
      videoMeta,
      selectedArc: directorResult.selectedArc?.name ?? "documentary",
      engagementScore,
      visualStyleGuide: directorResult.visualStyleGuide ?? "",
      storyBible: directorResult.storyBible ?? ""
    };
    const wizardState = {
      input,
      videoMeta,
      selectedArc: directorResult.selectedArc,
      narrativePlan: directorResult.narrativePlan,
      visualStyleGuide: directorResult.visualStyleGuide,
      storyBible: directorResult.storyBible,
      selectedLenses: directorResult.selectedLenses,
      mediaStrategy,
      researchContext,
      phase: "review_story",
      inlineMode: false
    };
    await saveWizardState(threadId, wizardState);
    await suspend(storyInterrupt);
    return { input, videoMeta, directorResult, mediaStrategy, researchContext, phase: "review_story_done" };
  }
});
const reviewStoryStep = createStep({
  id: "review-story",
  inputSchema: z.object({}).passthrough(),
  outputSchema: z.object({}).passthrough(),
  resumeSchema: z.object({
    editedScripts: z.record(z.string(), z.string()).optional()
  }).passthrough(),
  suspendSchema: z.object({
    type: z.string(),
    imageItems: z.array(z.any()),
    videoItems: z.array(z.any()),
    blocksWithImages: z.array(z.any())
  }).passthrough(),
  execute: async ({ inputData, resumeData, suspend }) => {
    const data = inputData;
    if (resumeData) {
      const threadId = data.input?.threadId ?? data.threadId;
      const state = await loadWizardState(threadId);
      if (!state) throw new Error("No wizard state found for thread: " + threadId);
      const { input, videoMeta, narrativePlan, visualStyleGuide, storyBible, selectedLenses, mediaStrategy, researchContext } = state;
      const editedScripts = resumeData.editedScripts ?? {};
      const updatedPlan = narrativePlan.map(
        (brief, i) => editedScripts[i] !== void 0 ? { ...brief, spokenScript: editedScripts[i] } : brief
      );
      const fillResult = await fillAllBlocks({
        threadId,
        templateBlocks: input.templateBlocks,
        narrativePlan: updatedPlan,
        userStory: input.userStory,
        visualStyleGuide,
        storyBible,
        selectedLenses,
        mediaStrategy,
        researchContext,
        videoMeta,
        preferredVoice: input.preferredVoice,
        language: input.language,
        apiKey: input.apiKey,
        model: input.model
      });
      const imageInterrupt = {
        type: "review_images",
        imageItems: fillResult.allImageItems,
        videoItems: fillResult.allVideoItems,
        blocksWithImages: fillResult.blocksWithContent
      };
      const wizardState = {
        ...state,
        narrativePlan: updatedPlan,
        blocksWithImages: fillResult.blocksWithContent,
        imageItems: fillResult.allImageItems,
        videoItems: fillResult.allVideoItems,
        filledBlocks: fillResult.filledBlocks,
        audioItems: fillResult.audioItems,
        phase: "review_audio"
        // Skip review_images page in paged mode — go straight to audio review
      };
      await saveWizardState(threadId, wizardState);
      await suspend(imageInterrupt);
      return { phase: "review_images_done" };
    }
    return { ...data, phase: "init_done" };
  }
});
const generateAudioStep = createStep({
  id: "generate-audio",
  inputSchema: z.object({}).passthrough(),
  outputSchema: z.object({}).passthrough(),
  resumeSchema: z.object({
    imageOverrides: z.record(z.string(), z.any()).optional()
  }).passthrough(),
  suspendSchema: z.object({
    type: z.string(),
    audioItems: z.array(z.any()),
    filledBlocks: z.array(z.any())
  }).passthrough(),
  execute: async ({ inputData, resumeData, suspend }) => {
    const data = inputData;
    const threadId = data.input?.threadId ?? data.threadId;
    const state = await loadWizardState(threadId);
    if (!state) throw new Error("No wizard state found for thread: " + threadId);
    const { narrativePlan, filledBlocks } = state;
    const editedScripts = resumeData?.editedScripts ?? {};
    const updatedPlan = narrativePlan.map(
      (brief, i) => editedScripts[i] !== void 0 ? { ...brief, spokenScript: editedScripts[i] } : brief
    );
    let blocks = [...filledBlocks || []];
    const imageOverrides = resumeData?.imageOverrides ?? {};
    for (const [idx, override] of Object.entries(imageOverrides)) {
      const blockIdx = parseInt(idx, 10);
      if (blockIdx >= 0 && blockIdx < blocks.length && override) {
        const o = override;
        if (o.imageSrc) blocks[blockIdx] = { ...blocks[blockIdx], imageSrc: o.imageSrc };
        if (o.src) blocks[blockIdx] = { ...blocks[blockIdx], src: o.src };
      }
    }
    const audioItems = blocks.map((block, idx) => {
      const audioSrc = block.audioSrc ?? "";
      const hasAudio = audioSrc.startsWith("data:") || audioSrc.startsWith("http");
      return {
        blockIdx: idx,
        narrativeRole: block.narrativeRole ?? block.role ?? `block_${idx}`,
        hasAudio,
        audioUrl: hasAudio ? audioSrc : "",
        script: block.spokenScript ?? (!hasAudio ? audioSrc : "") ?? ""
      };
    });
    const audioInterrupt = {
      type: "review_audio",
      audioItems,
      filledBlocks: blocks
    };
    const wizardState = {
      ...state,
      narrativePlan: updatedPlan,
      filledBlocks: blocks,
      phase: "review_audio"
    };
    await saveWizardState(threadId, wizardState);
    await suspend(audioInterrupt);
    return { phase: "review_audio_done" };
  }
});
const finalizeStep = createStep({
  id: "finalize",
  inputSchema: z.object({}).passthrough(),
  outputSchema: wizardOutputSchema,
  resumeSchema: z.object({
    audioOverrides: z.record(z.string(), z.any()).optional(),
    editedScripts: z.record(z.string(), z.string()).optional()
  }).passthrough(),
  execute: async ({ inputData, resumeData }) => {
    const data = inputData;
    const threadId = data.input?.threadId ?? data.threadId;
    const state = await loadWizardState(threadId);
    if (!state) throw new Error("No wizard state found for thread: " + threadId);
    const { input, videoMeta, narrativePlan } = state;
    const editedScripts = resumeData?.editedScripts ?? {};
    const updatedPlan = narrativePlan.map(
      (brief, i) => editedScripts[i] !== void 0 ? { ...brief, spokenScript: editedScripts[i] } : brief
    );
    let blocks = [...state.filledBlocks];
    const audioOverrides = resumeData?.audioOverrides ?? {};
    for (const [idx, override] of Object.entries(audioOverrides)) {
      const blockIdx = parseInt(idx, 10);
      if (blockIdx >= 0 && blockIdx < blocks.length && override) {
        const o = override;
        if (o.audioSrc) blocks[blockIdx] = { ...blocks[blockIdx], audioSrc: o.audioSrc };
        if (o.spokenScript) blocks[blockIdx] = { ...blocks[blockIdx], spokenScript: o.spokenScript };
      }
    }
    const contentBlocks = await applyBlockPostProcessors(blocks, input.templateBlocks, videoMeta);
    const payload = { videoMeta, contentBlocks };
    try {
      await updateJob(threadId, { status: "complete", payload });
    } catch {
    }
    return {
      status: "complete",
      payload,
      stateSnapshot: { ...state, narrativePlan: updatedPlan },
      tokensUsed: getTokenTotal()
    };
  }
});
const wizardWorkflow = createWorkflow({
  id: "wizard",
  inputSchema: wizardInputSchema,
  outputSchema: wizardOutputSchema
}).then(initStep).then(reviewStoryStep).then(generateAudioStep).then(finalizeStep).commit();
async function runWizardWorkflow(threadId, input, options) {
  const inlineMode = options?.inlineMode ?? false;
  console.log(`[Mastra wizard-workflow] Starting... (inlineMode=${inlineMode})`);
  try {
    if (inlineMode) {
      await runContextStorage.run(
        new RunContext(),
        () => withTokenTracking(async () => {
          const run = await wizardWorkflow.createRun();
          const workflowResult = await run.start({
            inputData: { ...input, threadId, inlineMode: true }
          });
          if (workflowResult.status === "success") {
            return workflowResult.result;
          }
          return null;
        })
      );
      const state2 = await loadWizardState(threadId);
      if (!state2) throw new Error("No wizard state found after inline init");
      const preview = {
        narrativePlan: state2.narrativePlan,
        selectedArc: state2.selectedArc?.name ?? "documentary",
        visualStyleGuide: state2.visualStyleGuide ?? "",
        storyBible: state2.storyBible ?? "",
        blocksWithImages: state2.blocksWithImages,
        imageItems: state2.imageItems,
        videoItems: state2.videoItems,
        filledBlocks: state2.filledBlocks,
        audioItems: state2.audioItems,
        videoMeta: state2.videoMeta,
        unresolvable: state2.unresolvable ?? []
      };
      return {
        status: "interrupted",
        interrupt: {
          type: "preview_ready",
          message: "Your video preview is ready! You can request changes in the chat.",
          selectedArc: state2.selectedArc?.name ?? "documentary",
          engagementScore: state2.engagementScore
        },
        payload: preview,
        stateSnapshot: state2,
        tokensUsed: getTokenTotal(),
        preview
      };
    }
    await runContextStorage.run(
      new RunContext(),
      () => withTokenTracking(async () => {
        const run = await wizardWorkflow.createRun();
        try {
          const result = await run.start({ inputData: { ...input, threadId, inlineMode: false } });
          if (result.status === "success") return result.result;
          return null;
        } catch (e) {
          console.log("[Mastra wizard-workflow] Workflow suspended, loading state...");
        }
        return null;
      })
    );
    const state = await loadWizardState(threadId);
    if (!state) throw new Error("No wizard state found after init");
    const interruptData = {
      type: "review_story",
      narrativePlan: state.narrativePlan,
      videoMeta: state.videoMeta,
      selectedArc: state.selectedArc?.name ?? "documentary",
      engagementScore: state.engagementScore,
      visualStyleGuide: state.visualStyleGuide ?? "",
      storyBible: state.storyBible ?? ""
    };
    return {
      status: "interrupted",
      interrupt: interruptData,
      stateSnapshot: state,
      tokensUsed: getTokenTotal()
    };
  } catch (e) {
    console.error("[Mastra wizard-workflow] Failed:", e.message);
    return {
      status: "complete",
      payload: { videoMeta: input.partialVideoMeta, contentBlocks: [] },
      stateSnapshot: {},
      tokensUsed: getTokenTotal()
    };
  }
}

var wizard_workflow = /*#__PURE__*/Object.freeze({
  __proto__: null,
  runWizardWorkflow: runWizardWorkflow,
  wizardWorkflow: wizardWorkflow
});

const RESERVED_DATA_FIELDS = /* @__PURE__ */ new Set(["animation", "theme", "motionProfile"]);
function lineNumberForIndex(source, index) {
  return source.slice(0, Math.max(0, index)).split(/\r\n|\r|\n/).length;
}
function addRegexIssues(issues, file, source, pattern, message) {
  for (const match of source.matchAll(pattern)) {
    issues.push({
      file,
      line: lineNumberForIndex(source, match.index ?? 0),
      message
    });
  }
}
function validatePluginSource(files) {
  const issues = [];
  for (const [file, source] of Object.entries(files)) {
    addRegexIssues(
      issues,
      file,
      source,
      /\bdata\s*\.\s*animation\s*(?:[?.]\s*)?\.\s*(?:enter|hold|exit)\b/g,
      "Do not read animation timing from data.animation. The Scene receives animation as its own prop; use animation.enter, animation.hold, or animation.exit."
    );
    addRegexIssues(
      issues,
      file,
      source,
      /\bdata\s*\.\s*animation\b(?!\s*(?:[?.]\s*)?\.)/g,
      "Do not read animation from plugin data. animation is a reserved Scene prop, not a schema/data field."
    );
    addRegexIssues(
      issues,
      file,
      source,
      /\b(?:const|let|var)\s*\{[^}]*\banimation\b[^}]*\}\s*=\s*data\b/g,
      "Do not destructure animation from data. Destructure animation from Scene props instead."
    );
    addRegexIssues(
      issues,
      file,
      source,
      /\b(?:const|let|var)\s+animation\s*=\s*data\b/g,
      "Do not assign animation from data. animation is passed separately to Scene."
    );
  }
  return { ok: issues.length === 0, issues };
}
function validatePluginSchemaReservedFields(schemaJson) {
  const issues = [];
  let schema;
  try {
    schema = typeof schemaJson === "string" ? JSON.parse(schemaJson) : schemaJson;
  } catch {
    return { ok: true, issues };
  }
  const properties = schema?.properties;
  if (!properties || typeof properties !== "object" || Array.isArray(properties)) {
    return { ok: true, issues };
  }
  for (const fieldName of Object.keys(properties)) {
    if (RESERVED_DATA_FIELDS.has(fieldName)) {
      issues.push({
        file: "schema.json",
        line: 1,
        message: `"${fieldName}" is reserved by the host Scene props and cannot be a plugin data field.`
      });
    }
  }
  return { ok: issues.length === 0, issues };
}
function formatPluginSourceIssues(issues) {
  return issues.map((issue) => `${issue.file}:${issue.line} ${issue.message}`).join("\n");
}

const FORBIDDEN_PATTERNS = [
  { pattern: /\beval\s*\(/, reason: "eval() is not allowed in plugins" },
  { pattern: /process\.exit\s*\(/, reason: "process.exit() is not allowed in plugins" },
  { pattern: /require\s*\(\s*['"]fs['"]/, reason: "Direct filesystem access (fs) is not allowed" },
  { pattern: /require\s*\(\s*['"]child_process['"]/, reason: "child_process is not allowed in plugins" },
  { pattern: /\bexecSync\b|\bspawnSync\b|\bexec\b\s*\(/, reason: "Shell execution is not allowed in plugins" }
];
function checkPluginCompatibility(pluginDir, options = {}) {
  const errors = [];
  const warnings = [];
  const requiredFiles = ["plugin.json", "schema.json", "src/Scene.tsx"];
  for (const file of requiredFiles) {
    if (!fs.existsSync(path.join(pluginDir, file))) {
      errors.push(`Missing required file: ${file}`);
    }
  }
  const bundlePath = path.join(pluginDir, "dist", "index.esm.js");
  if (!options.skipDistCheck && !fs.existsSync(bundlePath)) {
    errors.push(
      "dist/index.esm.js is missing \u2014 run 'npm run build' in your plugin folder before creating the ZIP"
    );
  } else if (!options.skipDistCheck) {
    const bundleContent = fs.readFileSync(bundlePath, "utf-8").trim();
    if (bundleContent.length < 50) {
      errors.push("dist/index.esm.js is empty \u2014 run 'npm run build' to generate a valid bundle");
    }
  }
  if (errors.length > 0) {
    return { compatible: false, errors, warnings };
  }
  let manifest;
  try {
    const raw = fs.readFileSync(path.join(pluginDir, "plugin.json"), "utf-8");
    manifest = JSON.parse(raw);
  } catch {
    errors.push("plugin.json is not valid JSON");
    return { compatible: false, errors, warnings };
  }
  const requiredManifestFields = ["id", "name", "version", "category"];
  for (const field of requiredManifestFields) {
    if (!manifest[field]) {
      errors.push(`plugin.json missing required field: "${field}"`);
    }
  }
  if (manifest.id && !/^[a-z0-9-]+$/.test(String(manifest.id))) {
    errors.push('plugin.json "id" must only contain lowercase letters, numbers, and hyphens');
  }
  if (manifest.version && !/^\d+\.\d+\.\d+/.test(String(manifest.version))) {
    warnings.push('plugin.json "version" should follow semver (e.g. "1.0.0")');
  }
  let schema;
  try {
    const raw = fs.readFileSync(path.join(pluginDir, "schema.json"), "utf-8");
    schema = JSON.parse(raw);
  } catch {
    errors.push("schema.json is not valid JSON");
    return { compatible: false, errors, warnings };
  }
  if (!schema.properties || typeof schema.properties !== "object") {
    errors.push('schema.json must have a "properties" object');
  }
  const schemaReservedCheck = validatePluginSchemaReservedFields(schema);
  if (!schemaReservedCheck.ok) {
    errors.push(...schemaReservedCheck.issues.map((issue) => issue.message));
  }
  const sourceFiles = ["src/Scene.tsx", "src/index.ts", "src/Editor.tsx"];
  for (const file of sourceFiles) {
    const filePath = path.join(pluginDir, file);
    if (!fs.existsSync(filePath)) continue;
    const code = fs.readFileSync(filePath, "utf-8");
    for (const { pattern, reason } of FORBIDDEN_PATTERNS) {
      if (pattern.test(code)) {
        errors.push(`${file}: ${reason}`);
      }
    }
    const sourceCheck = validatePluginSource({ [file]: code });
    if (!sourceCheck.ok) {
      errors.push(...formatPluginSourceIssues(sourceCheck.issues).split("\n"));
    }
  }
  const pkgPath = path.join(pluginDir, "package.json");
  if (fs.existsSync(pkgPath)) {
    try {
      const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf-8"));
      const deps = Object.keys({ ...pkg.dependencies ?? {}, ...pkg.devDependencies ?? {} });
      const conflicting = ["react", "react-dom", "remotion"].filter((d) => deps.includes(d));
      if (conflicting.length > 0) {
        warnings.push(
          `plugin/package.json declares ${conflicting.join(", ")} as dependencies \u2014 these are provided by the host app and will be ignored during bundling`
        );
      }
      if (deps.length > 0) {
        warnings.push(`Plugin declares ${deps.length} extra dependency/dependencies. Make sure they are compiled into dist/index.esm.js via 'npm run build'.`);
      }
    } catch {
      warnings.push("package.json could not be parsed \u2014 extra dependencies will not be installed");
    }
  }
  return {
    compatible: errors.length === 0,
    errors,
    warnings
  };
}

const PACKAGE_NAME_RE = /^(@[a-z0-9][\w.-]*\/)?[a-z0-9][\w.-]*$/i;
const HOST_PROVIDED_PLUGIN_DEPS = /* @__PURE__ */ new Set([
  "react",
  "react-dom",
  "remotion",
  "@remotion/player",
  "@remotion/renderer",
  "framer-motion"
]);
const HOST_VERSIONED_PLUGIN_DEPS = /* @__PURE__ */ new Set([
  "three",
  "@react-three/fiber",
  "@react-three/drei",
  "@react-three/postprocessing",
  "postprocessing"
]);
function normalizePluginDependencies(deps) {
  const dependencies = {};
  const installDependencies = {};
  const hostDependencies = {};
  const stripped = [];
  const normalized = [];
  for (const [name, range] of Object.entries(deps ?? {})) {
    if (typeof name !== "string" || typeof range !== "string" || !PACKAGE_NAME_RE.test(name)) {
      stripped.push(name);
      continue;
    }
    if (HOST_PROVIDED_PLUGIN_DEPS.has(name) || name.startsWith("@remotion/")) {
      stripped.push(name);
      continue;
    }
    if (HOST_VERSIONED_PLUGIN_DEPS.has(name)) {
      const hostVersion = readHostDependencyVersion(name);
      dependencies[name] = hostVersion;
      hostDependencies[name] = hostVersion;
      if (range !== hostVersion) {
        normalized.push({ name, from: range, to: hostVersion });
      }
      continue;
    }
    dependencies[name] = range;
    installDependencies[name] = range;
  }
  return { dependencies, installDependencies, hostDependencies, stripped, normalized };
}
function readHostDependencyVersion(name) {
  const candidates = [];
  if (process.env.HOST_PACKAGE_JSON) {
    candidates.push(path.resolve(process.env.HOST_PACKAGE_JSON));
  }
  let dir = process.cwd();
  for (let i = 0; i < 8 && dir !== path.dirname(dir); i++) {
    candidates.push(path.join(dir, "package.json"));
    dir = path.dirname(dir);
  }
  for (const pkgPath of candidates) {
    try {
      const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf-8"));
      const version = pkg.dependencies?.[name] ?? pkg.devDependencies?.[name];
      if (typeof version === "string" && version.trim()) {
        return version;
      }
    } catch {
    }
  }
  return "*";
}
function formatDependencyPolicyChanges(result) {
  const messages = [];
  if (result.stripped.length > 0) {
    messages.push(`app-provided/invalid deps kept out of plugin manifest: ${result.stripped.join(", ")}`);
  }
  return messages;
}

const HOST_PEER_PACKAGES = /* @__PURE__ */ new Set([
  "react",
  "react-dom",
  "react-reconciler",
  "remotion",
  "@types/react",
  "@types/react-dom"
]);
let _hostVersionsCache = null;
function readHostVersions() {
  if (_hostVersionsCache) return _hostVersionsCache;
  const candidates = [];
  if (process.env.HOST_PACKAGE_JSON) {
    candidates.push(path.resolve(process.env.HOST_PACKAGE_JSON));
  }
  let dir = process.cwd();
  for (let i = 0; i < 6 && dir !== path.dirname(dir); i++) {
    candidates.push(path.join(dir, "package.json"));
    dir = path.dirname(dir);
  }
  let lastError = null;
  for (const rootPkgPath of candidates) {
    let pkg = {};
    try {
      pkg = JSON.parse(fs.readFileSync(rootPkgPath, "utf-8"));
    } catch (e) {
      lastError = `${rootPkgPath}: ${e?.message ?? "unreadable"}`;
      continue;
    }
    const deps = pkg.dependencies ?? {};
    const react = deps["react"];
    const reactDom = deps["react-dom"];
    const remotion = deps["remotion"];
    if (react && reactDom && remotion) {
      _hostVersionsCache = { react, reactDom, remotion };
      return _hostVersionsCache;
    }
    lastError = `${rootPkgPath}: missing react/react-dom/remotion in dependencies`;
  }
  throw new Error(
    `sandbox-builder: could not find a host package.json with react/react-dom/remotion versions (checked: ${candidates.join(", ")}). Last error: ${lastError ?? "unknown"}. Set HOST_PACKAGE_JSON to the absolute path of the Next.js app package.json.`
  );
}
const EXTERNALS = [
  "react",
  "react-dom",
  "react-dom/client",
  "react/jsx-runtime",
  "react/jsx-dev-runtime",
  "remotion",
  "@remotion/player",
  "@remotion/renderer",
  "three",
  "@react-three/fiber",
  "@react-three/drei",
  "@react-three/postprocessing",
  "postprocessing"
];
const BUFFER_SHIM = `
const encoder = new TextEncoder();
function from(value, encoding) {
  if (typeof value === 'string') {
    if (encoding === 'base64') {
      const binary = atob(value);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
      return bytes;
    }
    return encoder.encode(value);
  }
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  if (ArrayBuffer.isView(value)) return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
  if (Array.isArray(value)) return new Uint8Array(value);
  return new Uint8Array();
}
globalThis.Buffer = globalThis.Buffer ?? {
  from,
  alloc(size) { return new Uint8Array(size); },
  isBuffer(value) { return value instanceof Uint8Array; },
};
`;
const MAX_BUNDLE_BYTES = 5 * 1024 * 1024;
const SOURCE_EXT_RE = /\.(tsx?|jsx?)$/;
function normalizeModulePath(filePath) {
  if (typeof filePath !== "string") return null;
  const normalized = filePath.replace(/\\/g, "/").replace(/^src\//, "");
  if (!normalized || normalized.startsWith("/") || normalized.includes("\0") || normalized.split("/").some((part) => part === ".." || part === "")) {
    return null;
  }
  if (!SOURCE_EXT_RE.test(normalized)) return null;
  return normalized;
}
function normalizePluginModules(sceneCode, modules) {
  const normalized = {};
  for (const [filePath, source] of Object.entries(modules ?? {})) {
    const safePath = normalizeModulePath(filePath);
    if (!safePath || typeof source !== "string") continue;
    normalized[safePath] = source;
  }
  if (!normalized["Scene.tsx"]) {
    normalized["Scene.tsx"] = sceneCode;
  }
  return normalized;
}
function shouldAllowLocalBuild$1() {
  return process.env.ALLOW_LOCAL_PLUGIN_BUILD === "true" || process.env.USE_SANDBOX_BUILDER === "false";
}
function hasSandboxCredentials$1() {
  return Boolean(process.env.E2B_API_KEY || "e2b_4d4e8b7ef35bd3a37a3d77bf839b38a98e6b3b71");
}
function formatSandboxErrors$1(errors) {
  if (errors.length === 0) return "No sandbox provider was attempted.";
  return errors.map((error, index) => `${index + 1}. ${error}`).join("\n");
}
async function buildPluginInSandbox(params) {
  const { pluginId, sceneCode, schemaJson } = params;
  const modules = normalizePluginModules(sceneCode, params.modules);
  const useSandbox = process.env.USE_SANDBOX_BUILDER !== "false";
  const depPolicy = normalizePluginDependencies(params.dependencies);
  const safeDeps = depPolicy.installDependencies;
  for (const message of formatDependencyPolicyChanges(depPolicy)) {
    console.warn(`[sandbox-builder] ${message}`);
  }
  const allModuleNames = [...EXTERNALS, ...Object.keys(safeDeps)];
  const stubsContent = allModuleNames.map((m) => `declare module '${m}' { const m: any; export default m; export = m; }`).join("\n");
  const tsconfigContent = JSON.stringify({
    compilerOptions: {
      target: "ES2020",
      module: "ESNext",
      moduleResolution: "bundler",
      jsx: "react",
      strict: false,
      noImplicitAny: false,
      skipLibCheck: true,
      noEmit: true
    },
    include: ["src/**/*", "src/stubs.d.ts"]
  }, null, 2);
  const hostVersions = readHostVersions();
  const sandboxAvailable = useSandbox && hasSandboxCredentials$1();
  if (sandboxAvailable) {
    const errors = [];
    try {
      const result = await buildWithE2BSandbox(pluginId, sceneCode, schemaJson, {
        ...params,
        modules,
        dependencies: safeDeps,
        stubsContent,
        tsconfigContent,
        hostVersions
      });
      enforceBundleSize(result);
      return { bundleContent: result, builtInSandbox: true };
    } catch (e) {
      const details = e?.details;
      const message = `sandbox: ${e?.message ?? e}${details ? `
${JSON.stringify(details)}` : ""}`;
      errors.push(message);
      console.warn(`[sandbox-builder] E2B sandbox failed: ${e?.message ?? e}`, details ? { details } : "");
    }
    if (!shouldAllowLocalBuild$1()) {
      throw new Error(
        `Sandbox builder failed. Local fallback is disabled for safety.
${formatSandboxErrors$1(errors)}
Configure E2B sandbox credentials on the Mastra server.`
      );
    }
  } else if (useSandbox && !hasSandboxCredentials$1()) {
    console.warn(
      "[sandbox-builder] E2B Sandbox credentials not configured (E2B_API_KEY) \u2014 falling through to local esbuild. Set ALLOW_LOCAL_PLUGIN_BUILD=false to hard-fail instead."
    );
  }
  console.warn("[sandbox-builder] \u26A0\uFE0F Building plugin LOCALLY \u2014 AI-generated code is untrusted!");
  if (Object.keys(safeDeps).length > 0) {
    console.warn(
      `[sandbox-builder] local fallback does not npm-install declared deps (${Object.keys(safeDeps).join(", ")}). esbuild will fail to resolve them unless they're already in the host node_modules. Set USE_SANDBOX_BUILDER=true to use the real build path.`
    );
  }
  const bundleContent = await buildWithLocalEsbuild(pluginId, sceneCode, { ...params, modules });
  enforceBundleSize(bundleContent);
  return { bundleContent, builtInSandbox: false };
}
function enforceBundleSize(bundleContent) {
  const size = Buffer.byteLength(bundleContent, "utf-8");
  if (size > MAX_BUNDLE_BYTES) {
    throw new Error(
      `Plugin bundle exceeded ${MAX_BUNDLE_BYTES} bytes (got ${size}). Drop heavy libraries (three.js and @react-three/drei are the usual culprits) or simplify the scene.`
    );
  }
}
async function buildWithE2BSandbox(pluginId, sceneCode, schemaJson, params) {
  const { Sandbox } = await import('@e2b/code-interpreter');
  const ROOT = process.cwd();
  const sharedUtils = params.sharedUtilsPath || path.join(ROOT, "shared", "plugin-utils", "index.ts");
  const sharedTypes = params.sharedTypesPath || path.join(ROOT, "shared", "plugin-types", "index.ts");
  let sharedUtilsContent = "";
  let sharedTypesContent = "";
  try {
    sharedUtilsContent = fs.readFileSync(sharedUtils, "utf-8");
  } catch {
  }
  try {
    sharedTypesContent = fs.readFileSync(sharedTypes, "utf-8");
  } catch {
  }
  const CWD = "/home/user";
  const packageJson = JSON.stringify({
    name: `plugin-build-${pluginId}`,
    version: "0.0.0",
    private: true,
    type: "module",
    dependencies: { esbuild: "^0.25.0", typescript: "^5.0.0", buffer: "^6.0.3", ...params.dependencies ?? {} }
  }, null, 2);
  const hostVersionsJson = JSON.stringify(params.hostVersions ?? readHostVersions());
  const hostPeerPackagesJson = JSON.stringify([...HOST_PEER_PACKAGES]);
  const buildScript = `
import esbuild from 'esbuild';
import { execFileSync } from 'child_process';
import fs from 'fs';
import path from 'path';

const srcDir = '${CWD}/src';
const distDir = '${CWD}/dist';
fs.mkdirSync(distDir, { recursive: true });

// TypeScript type check \u2014 catches undefined identifiers (e.g. TS2304) before
// bundling, so the agent gets an actionable error instead of a browser crash.
try {
  execFileSync(
    path.join('${CWD}', 'node_modules', '.bin', 'tsc'),
    ['--noEmit'],
    { cwd: '${CWD}', stdio: 'pipe' },
  );
} catch (e) {
  const out = (e.stdout?.toString() ?? '') + (e.stderr?.toString() ?? '');
  const lines = out.split('\\n');
  // Only TS2304 ("Cannot find name") = truly undefined identifier in plugin code.
  // All other codes (TS2307 module-not-found, TS2614/TS2694 named-import/namespace
  // issues from stubs, etc.) are artefacts of the ambient stub declarations.
  const realErrors = lines.filter(l => l.includes('TS2304') || l.includes('TS2552'));
  if (realErrors.length > 0) {
    process.stdout.write(JSON.stringify({ success: false, typeErrors: realErrors.join('\\n') }));
    process.exit(0);
  }
}

// \u2500\u2500 Host peer-dependency compatibility scan \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
// Walks node_modules and verifies every installed package's peerDependencies
// against the host's react/react-dom/remotion versions. A plugin dep built for
// React 18 will crash at runtime when rendered by a React 19 host \u2014 catch it
// here with an actionable message instead.
const HOST_VERSIONS = ${hostVersionsJson};
const HOST_PEER_PACKAGES = new Set(${hostPeerPackagesJson});

function satisfiesSingle(major, minor, patch, range) {
  if (range === '' || range === '*') return true;
  return range.split(/\\s+/).filter(Boolean).every((comp) => satisfiesComparator(major, minor, patch, comp));
}
function satisfiesComparator(major, minor, patch, comp) {
  let op = '';
  let verPart = comp;
  const m = comp.match(/^(>=|<=|>|<|\\^|~|=)?\\s*(.+)$/);
  if (m) { op = m[1] ?? ''; verPart = m[2]; }
  if (verPart === '*' || verPart === 'x' || verPart === 'X') return true;
  const [rM, rMn = '0', rP = '0'] = verPart.split('.');
  if (rM === '*' || rM === 'x' || rM === 'X') return true;
  const cM = parseInt(rM, 10), cMn = parseInt(rMn, 10), cP = parseInt(rP, 10);
  if (Number.isNaN(cM)) return true;
  const minorWild = rMn === '*' || rMn === 'x' || rMn === 'X';
  const patchWild = rP === '*' || rP === 'x' || rP === 'X';
  switch (op) {
    case '^':
      if (cM > 0) return major === cM && (minor > cMn || (minor === cMn && patch >= cP));
      if (cMn > 0) return major === 0 && minor === cMn && patch >= cP;
      return major === 0 && minor === 0 && patch >= cP;
    case '~':
      return major === cM && minor === cMn && (patchWild || patch >= cP);
    case '>=':
      return [major, minor, patch] >= [cM, cMn, cP]
        ? true
        : (major > cM || (major === cM && (minor > cMn || (minor === cMn && patch >= cP))));
    case '<=':
      return major < cM || (major === cM && (minor < cMn || (minor === cMn && patch <= cP)));
    case '>':
      return major > cM || (major === cM && (minor > cMn || (minor === cMn && patch > cP)));
    case '<':
      return major < cM || (major === cM && (minor < cMn || (minor === cMn && patch < cP)));
    case '=':
    case '':
      if (minorWild) return major === cM;
      if (patchWild) return major === cM && minor === cMn;
      return major === cM && minor === cMn && patch === cP;
    default:
      return true;
  }
}
function satisfies(version, range) {
  const clean = version.replace(/^[^0-9]+/, '');
  const [major, minor = 0, patch = 0] = clean.split('.').map((n) => parseInt(n, 10));
  if (Number.isNaN(major)) return true;
  return range.split('||').some((alt) => satisfiesSingle(major, minor, patch, alt.trim()));
}

function hostVersionFor(peerName) {
  if (peerName === 'react' || peerName === '@types/react') return HOST_VERSIONS.react;
  if (peerName === 'react-dom' || peerName === '@types/react-dom' || peerName === 'react-reconciler') return HOST_VERSIONS.reactDom;
  if (peerName === 'remotion' || peerName.startsWith('@remotion/')) return HOST_VERSIONS.remotion;
  return null;
}

const peerErrors = [];
const nmRoot = path.join('${CWD}', 'node_modules');
function walkNodeModules(dir, seen) {
  if (!fs.existsSync(dir)) return;
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    let pkgPath;
    if (entry.name.startsWith('@')) {
      const scopedDir = path.join(dir, entry.name);
      let scopedEntries;
      try { scopedEntries = fs.readdirSync(scopedDir, { withFileTypes: true }); } catch { continue; }
      for (const sub of scopedEntries) {
        if (!sub.isDirectory()) continue;
        pkgPath = path.join(scopedDir, sub.name, 'package.json');
        inspectPkg(pkgPath, seen);
      }
      continue;
    }
    pkgPath = path.join(dir, entry.name, 'package.json');
    inspectPkg(pkgPath, seen);
  }
}
function inspectPkg(pkgPath, seen) {
  if (seen.has(pkgPath)) return;
  seen.add(pkgPath);
  let pkg;
  try { pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf-8')); } catch { return; }
  const peers = pkg.peerDependencies ?? {};
  const pkgId = (pkg.name ?? '?') + '@' + (pkg.version ?? '?');
  for (const [peerName, peerRange] of Object.entries(peers)) {
    if (!HOST_PEER_PACKAGES.has(peerName) && !(peerName === '@types/react') && !(peerName.startsWith('@remotion/'))) continue;
    const hostVersion = hostVersionFor(peerName);
    if (!hostVersion) continue;
    if (!satisfies(hostVersion, peerRange)) {
      peerErrors.push(
        'Plugin dep "' + pkgId + '" requires peer ' + peerName + '@' + peerRange +
        ' but host runs ' + peerName + '@' + hostVersion + '. ' +
        'Pick a version of ' + pkg.name + ' compatible with ' + peerName + '@' + hostVersion +
        ', or remove this dependency.'
      );
    }
  }
  // Recurse into nested node_modules (transitive deps with their own peers)
  const nested = path.join(path.dirname(pkgPath), 'node_modules');
  if (fs.existsSync(nested)) walkNodeModules(nested, seen);
}
const seen = new Set();
walkNodeModules(nmRoot, seen);
// Also walk top-level @types scope for @types/react compat
walkNodeModules(path.join(nmRoot, '@types'), seen);

if (peerErrors.length > 0) {
  process.stdout.write(JSON.stringify({ success: false, peerDepErrors: peerErrors }));
  process.exit(0);
}


const aliasPlugin = {
  name: 'shared-alias',
  setup(build) {
    build.onResolve({ filter: /shared\\/plugin-utils/ }, () => ({ path: path.join(srcDir, 'plugin-utils.ts') }));
    build.onResolve({ filter: /shared\\/plugin-types/ }, () => ({ path: path.join(srcDir, 'plugin-types.ts') }));
  },
};

const outfile = path.join(distDir, 'index.esm.js');

await esbuild.build({
  entryPoints: [path.join(srcDir, 'Scene.tsx')],
  outfile,
  format: 'cjs',
  bundle: true,
  external: ${JSON.stringify(EXTERNALS)},
  target: ['chrome90'],
  platform: 'browser',
  // Polyfill Buffer for dependencies that reference it (e.g. three, uuid)
  inject: [path.join(srcDir, 'buffer-shim.js')],
  define: { global: 'globalThis' },
  plugins: [aliasPlugin],
  sourcemap: false,
  minify: false,
});

const bundleContent = fs.readFileSync(outfile, 'utf-8');
process.stdout.write(JSON.stringify({ success: true, bundleContent }));
`;
  const sandbox = await Sandbox.create({
    apiKey: process.env.E2B_API_KEY || "e2b_4d4e8b7ef35bd3a37a3d77bf839b38a98e6b3b71",
    timeoutMs: 12e4
  });
  try {
    const moduleFiles = Object.entries(normalizePluginModules(sceneCode, params.modules)).map(([filePath, content]) => ({
      path: `${CWD}/src/${filePath}`,
      content
    }));
    await Promise.all([
      sandbox.files.write(`${CWD}/package.json`, packageJson),
      sandbox.files.write(`${CWD}/build.mjs`, buildScript),
      sandbox.files.write(`${CWD}/tsconfig.json`, params.tsconfigContent ?? "{}"),
      ...moduleFiles.map((f) => sandbox.files.write(f.path, f.content)),
      sandbox.files.write(`${CWD}/src/stubs.d.ts`, params.stubsContent ?? ""),
      sandbox.files.write(`${CWD}/src/plugin-utils.ts`, sharedUtilsContent),
      sandbox.files.write(`${CWD}/src/plugin-types.ts`, sharedTypesContent),
      // Polyfill Buffer so deps like three/uuid don't crash in the browser
      sandbox.files.write(`${CWD}/src/buffer-shim.js`, BUFFER_SHIM)
    ]);
    const install = await sandbox.commands.run("npm install --legacy-peer-deps --no-audit --no-fund --loglevel=error", { cwd: CWD });
    if (install.error || install.exitCode !== 0) {
      throw new Error(
        `Sandbox npm install failed (exit ${install.exitCode})
stdout: ${install.stdout}
stderr: ${install.stderr}`
      );
    }
    const build = await sandbox.commands.run("node build.mjs", { cwd: CWD });
    const stdout = build.stdout;
    const stderr = build.stderr;
    if (build.error || build.exitCode !== 0) {
      throw new Error(
        `Sandbox build failed (exit ${build.exitCode})
stdout: ${stdout}
stderr: ${stderr}`
      );
    }
    const output = JSON.parse(stdout);
    if (!output.success) {
      let errMsg;
      if (output.peerDepErrors && output.peerDepErrors.length > 0) {
        errMsg = "Plugin dependency is incompatible with host runtime:\n" + output.peerDepErrors.map((e) => "  - " + e).join("\n");
      } else if (output.typeErrors) {
        errMsg = `TypeScript errors in plugin Scene.tsx:
${output.typeErrors}`;
      } else {
        errMsg = `Sandbox build reported failure: ${stderr}`;
      }
      throw new Error(errMsg);
    }
    return output.bundleContent;
  } finally {
    await sandbox.kill();
  }
}
async function buildWithLocalEsbuild(pluginId, sceneCode, params) {
  const ROOT = process.cwd();
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), `plugin-local-${pluginId}-`));
  try {
    const srcDir = path.join(tmpDir, "src");
    const distDir = path.join(tmpDir, "dist");
    fs.mkdirSync(srcDir, { recursive: true });
    fs.mkdirSync(distDir, { recursive: true });
    for (const [filePath, content] of Object.entries(normalizePluginModules(sceneCode, params.modules))) {
      const targetPath = path.join(srcDir, filePath);
      fs.mkdirSync(path.dirname(targetPath), { recursive: true });
      fs.writeFileSync(targetPath, content, "utf-8");
    }
    fs.writeFileSync(path.join(srcDir, "buffer-shim.js"), BUFFER_SHIM, "utf-8");
    const sharedUtils = params.sharedUtilsPath || path.join(ROOT, "shared", "plugin-utils", "index.ts");
    const sharedTypes = params.sharedTypesPath || path.join(ROOT, "shared", "plugin-types", "index.ts");
    const esbuild = require("esbuild");
    const aliasPlugin = {
      name: "shared-alias",
      setup(build) {
        build.onResolve({ filter: /shared\/plugin-utils/ }, () => ({ path: sharedUtils }));
        build.onResolve({ filter: /shared\/plugin-types/ }, () => ({ path: sharedTypes }));
      }
    };
    const outfile = path.join(distDir, "index.esm.js");
    await esbuild.build({
      entryPoints: [path.join(srcDir, "Scene.tsx")],
      outfile,
      format: "cjs",
      bundle: true,
      external: EXTERNALS,
      target: ["chrome90"],
      platform: "browser",
      // Polyfill Buffer for dependencies that reference it (e.g. three, uuid)
      inject: [path.join(srcDir, "buffer-shim.js")],
      define: { global: "globalThis" },
      plugins: [aliasPlugin],
      sourcemap: false,
      minify: false
    });
    if (!fs.existsSync(outfile)) {
      throw new Error("Build succeeded but bundle not found");
    }
    return fs.readFileSync(outfile, "utf-8");
  } finally {
    try {
      fs.rmSync(tmpDir, { recursive: true });
    } catch {
    }
  }
}

const REGION = process.env.LAMBDA_REGION || "us-east-1";
function getBucketName() {
  const siteUrl = process.env.LAMBDA_SITE_URL || "";
  const match = siteUrl.match(/https:\/\/([^.]+)\.s3\./);
  return match?.[1] || process.env.S3_BUCKET || "remotionlambda-useast1-l722vmwfn0";
}
const s3 = new S3Client({
  region: REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID || "",
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || ""
  }
});
async function uploadToS3(key, body, contentType) {
  await s3.send(new PutObjectCommand({
    Bucket: getBucketName(),
    Key: key,
    Body: body,
    ContentType: contentType
  }));
}
async function getSignedS3Url(key, expiresIn = 3600) {
  return getSignedUrl(
    s3,
    new GetObjectCommand({ Bucket: getBucketName(), Key: key }),
    { expiresIn }
  );
}

function normalizePluginId(input) {
  return input.toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "").substring(0, 64);
}

const STOP_WORDS$1 = /* @__PURE__ */ new Set([
  "and",
  "for",
  "from",
  "into",
  "the",
  "this",
  "that",
  "with",
  "your",
  "block",
  "plugin",
  "video",
  "slide",
  "scene",
  "animation",
  "animated"
]);
const SYNONYM_TAGS = {
  graph: ["chart", "data"],
  graphs: ["chart", "data"],
  leaderboard: ["ranking", "competition"],
  leaders: ["ranking"],
  player: ["sports", "person"],
  players: ["sports", "people"],
  athlete: ["sports", "person"],
  athletes: ["sports", "people"],
  versus: ["comparison", "competition"],
  vs: ["comparison", "competition"],
  battle: ["comparison", "competition"],
  brand: ["business"],
  brands: ["business"],
  product: ["business"],
  products: ["business"],
  code: ["developer", "technical"],
  tutorial: ["education", "how-to"],
  explainer: ["education"],
  timeline: ["sequence", "history"]
};
function normalizeTag(value) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40);
}
function normalizeTags(values) {
  const tags = /* @__PURE__ */ new Set();
  for (const value of values) {
    if (!value) continue;
    const normalized = normalizeTag(value);
    if (!normalized || normalized.length < 2 || STOP_WORDS$1.has(normalized)) continue;
    tags.add(normalized);
    for (const synonym of SYNONYM_TAGS[normalized] ?? []) {
      tags.add(synonym);
    }
  }
  return [...tags].slice(0, 16);
}
function wordsFromText(value) {
  return value.split(/[^a-zA-Z0-9]+/).map(normalizeTag).filter((word) => word.length >= 2 && !STOP_WORDS$1.has(word));
}
function derivePluginTags(input) {
  const words = [
    ...input.category ? [input.category] : [],
    ...wordsFromText(input.id ?? ""),
    ...wordsFromText(input.name ?? ""),
    ...wordsFromText(input.description ?? "")
  ];
  let schemaObj = input.schemaJson;
  if (typeof schemaObj === "string") {
    try {
      schemaObj = JSON.parse(schemaObj);
    } catch {
      schemaObj = null;
    }
  }
  if (schemaObj?.properties && typeof schemaObj.properties === "object") {
    for (const [key, property] of Object.entries(schemaObj.properties)) {
      words.push(...wordsFromText(key));
      words.push(...wordsFromText(property?.title ?? ""));
      words.push(...wordsFromText(property?.editor ?? ""));
    }
  }
  return normalizeTags(words);
}
function parseTags(value) {
  if (Array.isArray(value)) return normalizeTags(value.map((item) => String(item)));
  if (typeof value === "string") {
    if (!value.trim()) return [];
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed)) return normalizeTags(parsed.map((item) => String(item)));
    } catch {
      return normalizeTags(value.split(","));
    }
  }
  return [];
}

const CORE_PLUGIN_IDS = ["counter-block", "stat-block", "cta-block"];
async function createPluginFromSource(input) {
  const {
    id,
    name,
    description = "",
    category = "content",
    sceneCode,
    modules,
    schemaJson,
    dependencies,
    userId
  } = input;
  const normalizedId = normalizePluginId(id);
  const sourceModules = normalizePluginModules(sceneCode, modules);
  const effectiveSceneCode = sourceModules["Scene.tsx"] ?? sceneCode;
  if (!normalizedId || !name || !effectiveSceneCode || !schemaJson) {
    return { ok: false, status: 400, error: "Missing required fields: id, name, sceneCode, schemaJson" };
  }
  if (normalizedId.length < 3) {
    return { ok: false, status: 400, error: "Plugin id (normalized) must be at least 3 characters" };
  }
  if (CORE_PLUGIN_IDS.includes(normalizedId)) {
    return { ok: false, status: 409, error: `Plugin id "${normalizedId}" conflicts with a core plugin` };
  }
  let schemaObj;
  try {
    schemaObj = typeof schemaJson === "string" ? JSON.parse(schemaJson) : schemaJson;
  } catch {
    return { ok: false, status: 400, error: "schemaJson is not valid JSON" };
  }
  if (!schemaObj.properties || typeof schemaObj.properties !== "object") {
    return { ok: false, status: 400, error: 'schemaJson must have a "properties" object' };
  }
  const schemaReservedCheck = validatePluginSchemaReservedFields(schemaObj);
  if (!schemaReservedCheck.ok) {
    return {
      ok: false,
      status: 422,
      error: "Plugin schema failed validation",
      errors: schemaReservedCheck.issues.map((issue) => issue.message)
    };
  }
  const sourceCheck = validatePluginSource(
    Object.fromEntries(Object.entries(sourceModules).map(([filePath, source]) => [`src/${filePath}`, source]))
  );
  if (!sourceCheck.ok) {
    return {
      ok: false,
      status: 422,
      error: "Plugin source failed validation",
      errors: formatPluginSourceIssues(sourceCheck.issues).split("\n")
    };
  }
  const schemaString = typeof schemaJson === "string" ? schemaJson : JSON.stringify(schemaJson);
  const depPolicy = normalizePluginDependencies(dependencies);
  const depPolicyWarnings = formatDependencyPolicyChanges(depPolicy);
  for (const message of depPolicyWarnings) {
    console.warn(`[create-plugin] ${message}`);
  }
  let tmpDir;
  try {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), `plugin-create-${normalizedId}-`));
    fs.writeFileSync(path.join(tmpDir, "plugin.json"), JSON.stringify({
      id: normalizedId,
      name,
      description,
      version: "1.0.0",
      category
    }), "utf-8");
    fs.writeFileSync(path.join(tmpDir, "schema.json"), schemaString, "utf-8");
    const srcDir = path.join(tmpDir, "src");
    fs.mkdirSync(srcDir, { recursive: true });
    for (const [filePath, source] of Object.entries(sourceModules)) {
      const targetPath = path.join(srcDir, filePath);
      fs.mkdirSync(path.dirname(targetPath), { recursive: true });
      fs.writeFileSync(targetPath, source, "utf-8");
    }
    const check = checkPluginCompatibility(tmpDir, { skipDistCheck: true });
    if (!check.compatible) {
      return { ok: false, status: 422, error: "Plugin source failed validation", errors: check.errors };
    }
    const { bundleContent, builtInSandbox } = await buildPluginInSandbox({
      pluginId: normalizedId,
      sceneCode: effectiveSceneCode,
      modules: sourceModules,
      schemaJson: schemaString,
      dependencies: depPolicy.installDependencies
    });
    const s3Key = `plugins/${normalizedId}/bundle.cjs.js`;
    await uploadToS3(s3Key, bundleContent, "application/javascript");
    const sourceJson = JSON.stringify({
      sceneCode: effectiveSceneCode,
      modules: sourceModules,
      dependencies
    });
    const sourceS3Key = `plugins/${normalizedId}/source.json`;
    await uploadToS3(sourceS3Key, sourceJson, "application/json");
    const generationFields = extractNormalizedFields(schemaObj, effectiveSceneCode);
    const tags = derivePluginTags({
      id: normalizedId,
      name,
      description,
      category,
      schemaJson: schemaObj
    });
    await db$1.query(
      `INSERT INTO plugins (id, name, description, version, category, icon, color, status, s3_key, schema_json, generation_fields, user_id, tags, likes_count)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, 0)
       ON CONFLICT (id) DO UPDATE SET
         name = $2, description = $3, version = $4, category = $5,
         icon = $6, color = $7, status = $8, s3_key = $9, schema_json = $10,
         generation_fields = $11, tags = $13, updated_at = NOW()`,
      [
        normalizedId,
        name,
        description,
        "1.0.0",
        category,
        "puzzle",
        "#7C3AED",
        "stable",
        s3Key,
        schemaString,
        JSON.stringify(generationFields),
        userId ?? null,
        tags
      ]
    );
    console.log(`[create-plugin] Successfully saved plugin "${normalizedId}" to database. S3 Key: ${s3Key}`);
    return { ok: true, pluginId: normalizedId, name, s3Key, builtInSandbox, warnings: [...depPolicyWarnings, ...check.warnings] };
  } catch (e) {
    const diagnostics = Array.isArray(e?.errors) ? e.errors.map((err) => ({
      text: err?.text ?? "Unknown error",
      file: err?.location?.file ?? "Scene.tsx",
      line: err?.location?.line ?? 0,
      column: err?.location?.column ?? 0,
      lineText: err?.location?.lineText
    })) : void 0;
    const error = e?.message ?? "Plugin creation failed";
    return {
      ok: false,
      status: 500,
      error,
      errors: diagnostics ? diagnostics.map(
        (d) => `${d.text} at ${d.file}:${d.line}:${d.column}${d.lineText ? `
  > ${d.lineText}` : ""}`
      ) : void 0
    };
  } finally {
    if (tmpDir) {
      try {
        fs.rmSync(tmpDir, { recursive: true });
      } catch {
      }
    }
  }
}

const CORE_BRIDGE_PACKAGES = {
  "react": ["__pv_react", [
    "Children",
    "Component",
    "Fragment",
    "Profiler",
    "PureComponent",
    "StrictMode",
    "Suspense",
    "cloneElement",
    "createContext",
    "createElement",
    "createFactory",
    "createRef",
    "forwardRef",
    "isValidElement",
    "lazy",
    "memo",
    "startTransition",
    "use",
    "useCallback",
    "useContext",
    "useDebugValue",
    "useDeferredValue",
    "useEffect",
    "useId",
    "useImperativeHandle",
    "useInsertionEffect",
    "useLayoutEffect",
    "useMemo",
    "useReducer",
    "useRef",
    "useState",
    "useSyncExternalStore",
    "useTransition",
    "version"
  ]],
  "react/jsx-runtime": ["__pv_react_jsx_runtime", [
    "Fragment",
    "jsx",
    "jsxs"
  ]],
  "react/jsx-dev-runtime": ["__pv_react_jsx_dev_runtime", [
    "Fragment",
    "jsxDEV"
  ]],
  "react-dom": ["__pv_react_dom", [
    "createPortal",
    "findDOMNode",
    "flushSync",
    "hydrate",
    "render",
    "unmountComponentAtNode",
    "unstable_batchedUpdates",
    "version"
  ]],
  "react-dom/client": ["__pv_react_dom_client", [
    "createRoot",
    "hydrateRoot"
  ]],
  "remotion": ["__pv_remotion", [
    "AbsoluteFill",
    "Audio",
    "Composition",
    "cancelRender",
    "continueRender",
    "delayRender",
    "Easing",
    "Freeze",
    "getInputProps",
    "getRemotionEnvironment",
    "Img",
    "interpolate",
    "interpolateColors",
    "Loop",
    "measureSpring",
    "OffthreadVideo",
    "prefetch",
    "random",
    "registerRoot",
    "Sequence",
    "Series",
    "spring",
    "staticFile",
    "Still",
    "useCurrentFrame",
    "useCurrentScale",
    "useVideoConfig",
    "Video",
    "VideoTexture",
    "watchStaticFile"
  ]],
  "@remotion/player": ["__pv_remotion_player", [
    "CallbackListener",
    "Player",
    "PlayerRef",
    "RenderPoster",
    "ThumbnailProps"
  ]],
  "@remotion/renderer": ["__pv_remotion_renderer", []],
  "@remotion/media-utils": ["__pv_remotion_media_utils", [
    "getVideoMetadata",
    "getAudioMetadata",
    "visualizeAudio",
    "useAudioData",
    "useWindowedAudioData",
    "getWaveformPortion"
  ]],
  "three": ["__pv_three", [
    "ACESFilmicToneMapping",
    "AddEquation",
    "AddOperation",
    "AdditiveAnimationBlendMode",
    "AdditiveBlending",
    "AgXToneMapping",
    "AlphaFormat",
    "AlwaysCompare",
    "AlwaysDepth",
    "AlwaysStencilFunc",
    "AmbientLight",
    "AnimationAction",
    "AnimationClip",
    "AnimationLoader",
    "AnimationMixer",
    "AnimationObjectGroup",
    "AnimationUtils",
    "ArcCurve",
    "ArrayCamera",
    "ArrowHelper",
    "AttachedBindMode",
    "Audio",
    "AudioAnalyser",
    "AudioContext",
    "AudioListener",
    "AudioLoader",
    "AxesHelper",
    "BackSide",
    "BasicDepthPacking",
    "BasicShadowMap",
    "BatchedMesh",
    "BezierInterpolant",
    "Bone",
    "BooleanKeyframeTrack",
    "Box2",
    "Box3",
    "Box3Helper",
    "BoxGeometry",
    "BoxHelper",
    "BufferAttribute",
    "BufferGeometry",
    "BufferGeometryLoader",
    "ByteType",
    "Cache",
    "Camera",
    "CameraHelper",
    "CanvasTexture",
    "CapsuleGeometry",
    "CatmullRomCurve3",
    "CineonToneMapping",
    "CircleGeometry",
    "ClampToEdgeWrapping",
    "Clock",
    "Color",
    "ColorKeyframeTrack",
    "ColorManagement",
    "Compatibility",
    "CompressedArrayTexture",
    "CompressedCubeTexture",
    "CompressedTexture",
    "CompressedTextureLoader",
    "ConeGeometry",
    "ConstantAlphaFactor",
    "ConstantColorFactor",
    "Controls",
    "CubeCamera",
    "CubeDepthTexture",
    "CubeReflectionMapping",
    "CubeRefractionMapping",
    "CubeTexture",
    "CubeTextureLoader",
    "CubeUVReflectionMapping",
    "CubicBezierCurve",
    "CubicBezierCurve3",
    "CubicInterpolant",
    "CullFaceBack",
    "CullFaceFront",
    "CullFaceFrontBack",
    "CullFaceNone",
    "Curve",
    "CurvePath",
    "CustomBlending",
    "CustomToneMapping",
    "CylinderGeometry",
    "Cylindrical",
    "Data3DTexture",
    "DataArrayTexture",
    "DataTexture",
    "DataTextureLoader",
    "DataUtils",
    "DecrementStencilOp",
    "DecrementWrapStencilOp",
    "DefaultLoadingManager",
    "DepthFormat",
    "DepthStencilFormat",
    "DepthTexture",
    "DetachedBindMode",
    "DirectionalLight",
    "DirectionalLightHelper",
    "DiscreteInterpolant",
    "DodecahedronGeometry",
    "DoubleSide",
    "DstAlphaFactor",
    "DstColorFactor",
    "DynamicCopyUsage",
    "DynamicDrawUsage",
    "DynamicReadUsage",
    "EdgesGeometry",
    "EllipseCurve",
    "EqualCompare",
    "EqualDepth",
    "EqualStencilFunc",
    "EquirectangularReflectionMapping",
    "EquirectangularRefractionMapping",
    "Euler",
    "EventDispatcher",
    "ExternalTexture",
    "ExtrudeGeometry",
    "FileLoader",
    "Float16BufferAttribute",
    "Float32BufferAttribute",
    "FloatType",
    "Fog",
    "FogExp2",
    "FramebufferTexture",
    "FrontSide",
    "Frustum",
    "FrustumArray",
    "GLBufferAttribute",
    "GLSL1",
    "GLSL3",
    "GreaterCompare",
    "GreaterDepth",
    "GreaterEqualCompare",
    "GreaterEqualDepth",
    "GreaterEqualStencilFunc",
    "GreaterStencilFunc",
    "GridHelper",
    "Group",
    "HalfFloatType",
    "HemisphereLight",
    "HemisphereLightHelper",
    "IcosahedronGeometry",
    "ImageBitmapLoader",
    "ImageLoader",
    "ImageUtils",
    "IncrementStencilOp",
    "IncrementWrapStencilOp",
    "InstancedBufferAttribute",
    "InstancedBufferGeometry",
    "InstancedInterleavedBuffer",
    "InstancedMesh",
    "Int16BufferAttribute",
    "Int32BufferAttribute",
    "Int8BufferAttribute",
    "IntType",
    "InterleavedBuffer",
    "InterleavedBufferAttribute",
    "Interpolant",
    "InterpolateBezier",
    "InterpolateDiscrete",
    "InterpolateLinear",
    "InterpolateSmooth",
    "InterpolationSamplingMode",
    "InterpolationSamplingType",
    "InvertStencilOp",
    "KeepStencilOp",
    "KeyframeTrack",
    "LOD",
    "LatheGeometry",
    "Layers",
    "LessCompare",
    "LessDepth",
    "LessEqualCompare",
    "LessEqualDepth",
    "LessEqualStencilFunc",
    "LessStencilFunc",
    "Light",
    "LightProbe",
    "Line",
    "Line3",
    "LineBasicMaterial",
    "LineCurve",
    "LineCurve3",
    "LineDashedMaterial",
    "LineLoop",
    "LineSegments",
    "LinearFilter",
    "LinearInterpolant",
    "LinearMipMapLinearFilter",
    "LinearMipMapNearestFilter",
    "LinearMipmapLinearFilter",
    "LinearMipmapNearestFilter",
    "LinearSRGBColorSpace",
    "LinearToneMapping",
    "LinearTransfer",
    "Loader",
    "LoaderUtils",
    "LoadingManager",
    "LoopOnce",
    "LoopPingPong",
    "LoopRepeat",
    "MOUSE",
    "Material",
    "MaterialBlending",
    "MaterialLoader",
    "MathUtils",
    "Matrix2",
    "Matrix3",
    "Matrix4",
    "MaxEquation",
    "Mesh",
    "MeshBasicMaterial",
    "MeshDepthMaterial",
    "MeshDistanceMaterial",
    "MeshLambertMaterial",
    "MeshMatcapMaterial",
    "MeshNormalMaterial",
    "MeshPhongMaterial",
    "MeshPhysicalMaterial",
    "MeshStandardMaterial",
    "MeshToonMaterial",
    "MinEquation",
    "MirroredRepeatWrapping",
    "MixOperation",
    "MultiplyBlending",
    "MultiplyOperation",
    "NearestFilter",
    "NearestMipMapLinearFilter",
    "NearestMipMapNearestFilter",
    "NearestMipmapLinearFilter",
    "NearestMipmapNearestFilter",
    "NeutralToneMapping",
    "NeverCompare",
    "NeverDepth",
    "NeverStencilFunc",
    "NoBlending",
    "NoColorSpace",
    "NoNormalPacking",
    "NoToneMapping",
    "NormalAnimationBlendMode",
    "NormalBlending",
    "NormalGAPacking",
    "NormalRGPacking",
    "NotEqualCompare",
    "NotEqualDepth",
    "NotEqualStencilFunc",
    "NumberKeyframeTrack",
    "Object3D",
    "ObjectLoader",
    "ObjectSpaceNormalMap",
    "OctahedronGeometry",
    "OneFactor",
    "OneMinusConstantAlphaFactor",
    "OneMinusConstantColorFactor",
    "OneMinusDstAlphaFactor",
    "OneMinusDstColorFactor",
    "OneMinusSrcAlphaFactor",
    "OneMinusSrcColorFactor",
    "OrthographicCamera",
    "PCFShadowMap",
    "PCFSoftShadowMap",
    "PMREMGenerator",
    "Path",
    "PerspectiveCamera",
    "Plane",
    "PlaneGeometry",
    "PlaneHelper",
    "PointLight",
    "PointLightHelper",
    "Points",
    "PointsMaterial",
    "PolarGridHelper",
    "PolyhedronGeometry",
    "PositionalAudio",
    "PropertyBinding",
    "PropertyMixer",
    "QuadraticBezierCurve",
    "QuadraticBezierCurve3",
    "Quaternion",
    "QuaternionKeyframeTrack",
    "QuaternionLinearInterpolant",
    "R11_EAC_Format",
    "RED_GREEN_RGTC2_Format",
    "RED_RGTC1_Format",
    "REVISION",
    "RG11_EAC_Format",
    "RGBADepthPacking",
    "RGBAFormat",
    "RGBAIntegerFormat",
    "RGBA_ASTC_10x10_Format",
    "RGBA_ASTC_10x5_Format",
    "RGBA_ASTC_10x6_Format",
    "RGBA_ASTC_10x8_Format",
    "RGBA_ASTC_12x10_Format",
    "RGBA_ASTC_12x12_Format",
    "RGBA_ASTC_4x4_Format",
    "RGBA_ASTC_5x4_Format",
    "RGBA_ASTC_5x5_Format",
    "RGBA_ASTC_6x5_Format",
    "RGBA_ASTC_6x6_Format",
    "RGBA_ASTC_8x5_Format",
    "RGBA_ASTC_8x6_Format",
    "RGBA_ASTC_8x8_Format",
    "RGBA_BPTC_Format",
    "RGBA_ETC2_EAC_Format",
    "RGBA_PVRTC_2BPPV1_Format",
    "RGBA_PVRTC_4BPPV1_Format",
    "RGBA_S3TC_DXT1_Format",
    "RGBA_S3TC_DXT3_Format",
    "RGBA_S3TC_DXT5_Format",
    "RGBDepthPacking",
    "RGBFormat",
    "RGBIntegerFormat",
    "RGB_BPTC_SIGNED_Format",
    "RGB_BPTC_UNSIGNED_Format",
    "RGB_ETC1_Format",
    "RGB_ETC2_Format",
    "RGB_PVRTC_2BPPV1_Format",
    "RGB_PVRTC_4BPPV1_Format",
    "RGB_S3TC_DXT1_Format",
    "RGDepthPacking",
    "RGFormat",
    "RGIntegerFormat",
    "RawShaderMaterial",
    "Ray",
    "Raycaster",
    "RectAreaLight",
    "RedFormat",
    "RedIntegerFormat",
    "ReinhardToneMapping",
    "RenderTarget",
    "RenderTarget3D",
    "RepeatWrapping",
    "ReplaceStencilOp",
    "ReverseSubtractEquation",
    "RingGeometry",
    "SIGNED_R11_EAC_Format",
    "SIGNED_RED_GREEN_RGTC2_Format",
    "SIGNED_RED_RGTC1_Format",
    "SIGNED_RG11_EAC_Format",
    "SRGBColorSpace",
    "SRGBTransfer",
    "Scene",
    "ShaderChunk",
    "ShaderLib",
    "ShaderMaterial",
    "ShadowMaterial",
    "Shape",
    "ShapeGeometry",
    "ShapePath",
    "ShapeUtils",
    "ShortType",
    "Skeleton",
    "SkeletonHelper",
    "SkinnedMesh",
    "Source",
    "Sphere",
    "SphereGeometry",
    "Spherical",
    "SphericalHarmonics3",
    "SplineCurve",
    "SpotLight",
    "SpotLightHelper",
    "Sprite",
    "SpriteMaterial",
    "SrcAlphaFactor",
    "SrcAlphaSaturateFactor",
    "SrcColorFactor",
    "StaticCopyUsage",
    "StaticDrawUsage",
    "StaticReadUsage",
    "StereoCamera",
    "StreamCopyUsage",
    "StreamDrawUsage",
    "StreamReadUsage",
    "StringKeyframeTrack",
    "SubtractEquation",
    "SubtractiveBlending",
    "TOUCH",
    "TangentSpaceNormalMap",
    "TetrahedronGeometry",
    "Texture",
    "TextureLoader",
    "TextureUtils",
    "Timer",
    "TimestampQuery",
    "TorusGeometry",
    "TorusKnotGeometry",
    "Triangle",
    "TriangleFanDrawMode",
    "TriangleStripDrawMode",
    "TrianglesDrawMode",
    "TubeGeometry",
    "UVMapping",
    "Uint16BufferAttribute",
    "Uint32BufferAttribute",
    "Uint8BufferAttribute",
    "Uint8ClampedBufferAttribute",
    "Uniform",
    "UniformsGroup",
    "UniformsLib",
    "UniformsUtils",
    "UnsignedByteType",
    "UnsignedInt101111Type",
    "UnsignedInt248Type",
    "UnsignedInt5999Type",
    "UnsignedIntType",
    "UnsignedShort4444Type",
    "UnsignedShort5551Type",
    "UnsignedShortType",
    "VSMShadowMap",
    "Vector2",
    "Vector3",
    "Vector4",
    "VectorKeyframeTrack",
    "VideoFrameTexture",
    "VideoTexture",
    "WebGL3DRenderTarget",
    "WebGLArrayRenderTarget",
    "WebGLCoordinateSystem",
    "WebGLCubeRenderTarget",
    "WebGLRenderTarget",
    "WebGLRenderer",
    "WebGLUtils",
    "WebGPUCoordinateSystem",
    "WebXRController",
    "WireframeGeometry",
    "WrapAroundEnding",
    "ZeroCurvatureEnding",
    "ZeroFactor",
    "ZeroSlopeEnding",
    "ZeroStencilOp",
    "createCanvasElement",
    "error",
    "getConsoleFunction",
    "log",
    "setConsoleFunction",
    "warn",
    "warnOnce"
  ]],
  "@react-three/fiber": ["__pv_react_three_fiber", [
    "Canvas",
    "ReactThreeFiber",
    "__esModule",
    "_roots",
    "act",
    "addAfterEffect",
    "addEffect",
    "addTail",
    "advance",
    "applyProps",
    "buildGraph",
    "context",
    "createEvents",
    "createPortal",
    "createRoot",
    "dispose",
    "events",
    "extend",
    "flushGlobalEffects",
    "flushSync",
    "getRootState",
    "invalidate",
    "reconciler",
    "unmountComponentAtNode",
    "useFrame",
    "useGraph",
    "useInstanceHandle",
    "useLoader",
    "useStore",
    "useThree"
  ]],
  "@react-three/drei": ["__pv_react_three_drei", [
    "AccumulativeShadows",
    "AdaptiveDpr",
    "AdaptiveEvents",
    "ArcballControls",
    "AsciiRenderer",
    "BBAnchor",
    "Backdrop",
    "BakeShadows",
    "Billboard",
    "Bounds",
    "Box",
    "Bvh",
    "CameraControls",
    "CameraShake",
    "Capsule",
    "CatmullRomLine",
    "Caustics",
    "Center",
    "Circle",
    "Clone",
    "Cloud",
    "CloudInstance",
    "Clouds",
    "ComputedAttribute",
    "Cone",
    "ContactShadows",
    "CubeCamera",
    "CubeTexture",
    "CubicBezierLine",
    "CurveModifier",
    "CycleRaycast",
    "Cylinder",
    "Decal",
    "Detailed",
    "DetectGPU",
    "DeviceOrientationControls",
    "Dodecahedron",
    "DragControls",
    "Edges",
    "Effects",
    "Environment",
    "EnvironmentCube",
    "EnvironmentMap",
    "EnvironmentPortal",
    "Example",
    "Extrude",
    "FaceControls",
    "FaceLandmarker",
    "FaceLandmarkerDefaults",
    "Facemesh",
    "FacemeshDatas",
    "FacemeshEye",
    "FacemeshEyeDefaults",
    "Fbo",
    "Fbx",
    "FirstPersonControls",
    "Fisheye",
    "Float",
    "FlyControls",
    "GizmoHelper",
    "GizmoViewcube",
    "GizmoViewport",
    "Gltf",
    "GradientTexture",
    "GradientType",
    "Grid",
    "Helper",
    "Html",
    "Hud",
    "Icosahedron",
    "Image",
    "Instance",
    "InstancedAttribute",
    "Instances",
    "IsObject",
    "KeyboardControls",
    "Ktx2",
    "Lathe",
    "Lightformer",
    "Line",
    "Loader",
    "MapControls",
    "MarchingCube",
    "MarchingCubes",
    "MarchingPlane",
    "Mask",
    "MatcapTexture",
    "Merged",
    "MeshDiscardMaterial",
    "MeshDistortMaterial",
    "MeshPortalMaterial",
    "MeshReflectorMaterial",
    "MeshRefractionMaterial",
    "MeshTransmissionMaterial",
    "MeshWobbleMaterial",
    "MotionPathControls",
    "MultiMaterial",
    "NormalTexture",
    "Octahedron",
    "OrbitControls",
    "OrthographicCamera",
    "Outlines",
    "PerformanceMonitor",
    "PerspectiveCamera",
    "PivotControls",
    "Plane",
    "Point",
    "PointMaterial",
    "PointMaterialImpl",
    "PointerLockControls",
    "Points",
    "PointsBuffer",
    "Polyhedron",
    "PositionMesh",
    "PositionPoint",
    "PositionalAudio",
    "Preload",
    "PresentationControls",
    "Progress",
    "QuadraticBezierLine",
    "RandomizedLight",
    "RenderCubeTexture",
    "RenderTexture",
    "Resize",
    "Ring",
    "RoundedBox",
    "RoundedBoxGeometry",
    "Sampler",
    "ScreenQuad",
    "ScreenSizer",
    "ScreenSpace",
    "ScreenVideoTexture",
    "Scroll",
    "ScrollControls",
    "Segment",
    "SegmentObject",
    "Segments",
    "Select",
    "Shadow",
    "ShadowAlpha",
    "Shape",
    "Sky",
    "SoftShadows",
    "Sparkles",
    "Sphere",
    "Splat",
    "SpotLight",
    "SpotLightShadow",
    "SpriteAnimator",
    "Stage",
    "Stars",
    "Stats",
    "StatsGl",
    "Svg",
    "Tetrahedron",
    "Text",
    "Text3D",
    "Texture",
    "Torus",
    "TorusKnot",
    "TrackballControls",
    "Trail",
    "TrailTexture",
    "TransformControls",
    "Tube",
    "VideoTexture",
    "View",
    "WebcamVideoTexture",
    "Wireframe",
    "__esModule",
    "accumulativeContext",
    "calcPosFromAngles",
    "calculateScaleFactor",
    "checkIfFrameIsEmpty",
    "createInstances",
    "getFirstFrame",
    "isWebGL2Available",
    "meshBounds",
    "shaderMaterial",
    "useAnimations",
    "useAspect",
    "useBVH",
    "useBounds",
    "useBoxProjectedEnv",
    "useCamera",
    "useContextBridge",
    "useCubeCamera",
    "useCubeTexture",
    "useCursor",
    "useDepthBuffer",
    "useDetectGPU",
    "useEnvironment",
    "useFBO",
    "useFBX",
    "useFaceControls",
    "useFaceLandmarker",
    "useFont",
    "useGLTF",
    "useGizmoContext",
    "useHelper",
    "useIntersect",
    "useKTX2",
    "useKeyboardControls",
    "useMask",
    "useMatcapTexture",
    "useMotion",
    "useNormalTexture",
    "usePerformanceMonitor",
    "useProgress",
    "useScroll",
    "useSelect",
    "useSpriteAnimator",
    "useSpriteLoader",
    "useSurfaceSampler",
    "useTexture",
    "useTrail",
    "useTrailTexture",
    "useVideoTexture"
  ]],
  "@react-three/postprocessing": ["__pv_react_three_postprocessing", [
    "ASCII",
    "Autofocus",
    "Bloom",
    "BrightnessContrast",
    "ChromaticAberration",
    "ColorAverage",
    "ColorDepth",
    "Depth",
    "DepthOfField",
    "DotScreen",
    "EffectComposer",
    "EffectComposerContext",
    "FXAA",
    "Glitch",
    "GodRays",
    "Grid",
    "HueSaturation",
    "LUT",
    "LensFlare",
    "LensFlareEffect",
    "N8AO",
    "Noise",
    "Outline",
    "Pixelation",
    "Ramp",
    "RampEffect",
    "RampType",
    "SMAA",
    "SSAO",
    "Scanline",
    "Select",
    "Selection",
    "SelectiveBloom",
    "Sepia",
    "ShockWave",
    "Texture",
    "TiltShift",
    "TiltShift2",
    "TiltShiftEffect",
    "ToneMapping",
    "Vignette",
    "WaterEffect",
    "WaterEffectImpl",
    "resolveRef",
    "selectionContext",
    "useVector2",
    "wrapEffect"
  ]],
  "postprocessing": ["__pv_postprocessing", [
    "ASCIIEffect",
    "ASCIITexture",
    "AdaptiveLuminanceMaterial",
    "AdaptiveLuminancePass",
    "BlendFunction",
    "BlendMode",
    "BloomEffect",
    "BlurPass",
    "BokehEffect",
    "BokehMaterial",
    "BoxBlurMaterial",
    "BoxBlurPass",
    "BrightnessContrastEffect",
    "ChromaticAberrationEffect",
    "CircleOfConfusionMaterial",
    "ClearMaskPass",
    "ClearPass",
    "ColorAverageEffect",
    "ColorChannel",
    "ColorDepthEffect",
    "ColorEdgesMaterial",
    "ConvolutionMaterial",
    "CopyMaterial",
    "CopyPass",
    "DepthComparisonMaterial",
    "DepthCopyMaterial",
    "DepthCopyMode",
    "DepthCopyPass",
    "DepthDownsamplingMaterial",
    "DepthDownsamplingPass",
    "DepthEffect",
    "DepthMaskMaterial",
    "DepthOfFieldEffect",
    "DepthPass",
    "DepthPickingPass",
    "DepthSavePass",
    "DepthTestStrategy",
    "Disposable",
    "DotScreenEffect",
    "DownsamplingMaterial",
    "EdgeDetectionMaterial",
    "EdgeDetectionMode",
    "Effect",
    "EffectAttribute",
    "EffectComposer",
    "EffectMaterial",
    "EffectPass",
    "EffectShaderData",
    "EffectShaderSection",
    "FXAAEffect",
    "GammaCorrectionEffect",
    "GaussKernel",
    "GaussianBlurMaterial",
    "GaussianBlurPass",
    "GlitchEffect",
    "GlitchMode",
    "GodRaysEffect",
    "GodRaysMaterial",
    "GridEffect",
    "HueSaturationEffect",
    "ImmutableTimer",
    "Initializable",
    "KawaseBlurMaterial",
    "KawaseBlurPass",
    "KernelSize",
    "LUT1DEffect",
    "LUT3DEffect",
    "LUT3dlLoader",
    "LUTCubeLoader",
    "LUTEffect",
    "LUTOperation",
    "LambdaPass",
    "LensDistortionEffect",
    "LookupTexture",
    "LookupTexture3D",
    "LuminanceMaterial",
    "LuminancePass",
    "MaskFunction",
    "MaskMaterial",
    "MaskPass",
    "MipmapBlurPass",
    "NoiseEffect",
    "NoiseTexture",
    "NormalPass",
    "OutlineEdgesMaterial",
    "OutlineEffect",
    "OutlineMaterial",
    "OverrideMaterialManager",
    "Pass",
    "PixelationEffect",
    "PredicationMode",
    "RawImageData",
    "RealisticBokehEffect",
    "RenderPass",
    "Resizable",
    "Resizer",
    "Resolution",
    "SMAAAreaImageData",
    "SMAAEffect",
    "SMAAImageGenerator",
    "SMAAImageLoader",
    "SMAAPreset",
    "SMAASearchImageData",
    "SMAAWeightsMaterial",
    "SSAOEffect",
    "SSAOMaterial",
    "SavePass",
    "ScanlineEffect",
    "Section",
    "Selection",
    "SelectiveBloomEffect",
    "SepiaEffect",
    "ShaderPass",
    "ShockWaveEffect",
    "TetrahedralUpscaler",
    "TextureEffect",
    "TiltShiftBlurMaterial",
    "TiltShiftBlurPass",
    "TiltShiftEffect",
    "Timer",
    "ToneMappingEffect",
    "ToneMappingMode",
    "UpsamplingMaterial",
    "VignetteEffect",
    "VignetteTechnique",
    "WebGLExtension",
    "version"
  ]],
  "@remotion/three": ["__pv_remotion_three", [
    "ThreeCanvas",
    "useOffthreadVideoTexture",
    "useVideoTexture"
  ]]
};
const DYNAMIC_BRIDGE_PACKAGES = {};
function getPreviewModules(sceneCode, modules) {
  if (modules && Object.keys(modules).length > 0) {
    return modules;
  }
  return { "Scene.tsx": sceneCode };
}
function assertSafeModulePath(filePath) {
  const normalized = filePath.replace(/\\/g, "/");
  if (path.isAbsolute(filePath) || normalized.startsWith("../") || normalized.includes("/../") || normalized === ".." || normalized.includes("\0")) {
    throw new Error(`Unsafe plugin module path: ${filePath}`);
  }
}
function writePreviewModules(srcDir, modules) {
  for (const [filePath, source] of Object.entries(modules)) {
    assertSafeModulePath(filePath);
    const targetPath = path.join(srcDir, filePath);
    fs.mkdirSync(path.dirname(targetPath), { recursive: true });
    fs.writeFileSync(targetPath, source, "utf-8");
  }
}
function isValidExportName(name) {
  return /^[A-Za-z_$][\w$]*$/.test(name) && name !== "default";
}
async function collectPackageExportNames(pkg) {
  try {
    const mod = await import(pkg);
    return Object.keys(mod).filter(isValidExportName).sort();
  } catch {
    return [];
  }
}
async function createBridgePackages() {
  const bridgePackages = { ...CORE_BRIDGE_PACKAGES };
  for (const [pkg, globalKey] of Object.entries(DYNAMIC_BRIDGE_PACKAGES)) {
    bridgePackages[pkg] = [globalKey, await collectPackageExportNames(pkg)];
  }
  return bridgePackages;
}
function shouldAllowLocalBuild() {
  return process.env.ALLOW_LOCAL_PLUGIN_BUILD === "true" || process.env.USE_SANDBOX_BUILDER === "false";
}
function hasSandboxCredentials() {
  return Boolean(process.env.E2B_API_KEY || "e2b_4d4e8b7ef35bd3a37a3d77bf839b38a98e6b3b71");
}
function formatSandboxErrors(errors) {
  if (errors.length === 0) return "No sandbox provider was attempted.";
  return errors.map((error, index) => `${index + 1}. ${error}`).join("\n");
}
async function bundlePreview(sceneCode, pluginId, options = {}) {
  const ROOT = process.cwd();
  const modules = getPreviewModules(sceneCode, options.modules);
  const sourceCheck = validatePluginSource(modules);
  if (!sourceCheck.ok) {
    return {
      ok: false,
      error: `Plugin source failed validation:
${formatPluginSourceIssues(sourceCheck.issues)}`,
      diagnostics: sourceCheck.issues.map((issue) => ({
        text: issue.message,
        file: issue.file,
        line: issue.line,
        column: 0
      }))
    };
  }
  const depPolicy = normalizePluginDependencies(options.dependencies);
  const safeDeps = depPolicy.dependencies;
  for (const message of formatDependencyPolicyChanges(depPolicy)) {
    console.warn(`[preview-bundler] ${message}`);
  }
  if (Object.keys(safeDeps).length > 0 && process.env.USE_SANDBOX_BUILDER !== "false" && hasSandboxCredentials()) {
    const errors = [];
    try {
      const bundleJs = await bundlePreviewInSandbox(pluginId, safeDeps, modules);
      return { ok: true, bundleJs };
    } catch (e) {
      const message = `sandbox: ${e?.message ?? e}`;
      errors.push(message);
      console.warn(`[preview-bundler] E2B sandbox preview failed: ${e?.message ?? e}`);
    }
    if (!shouldAllowLocalBuild()) {
      return {
        ok: false,
        error: `Plugin preview sandbox build failed. Local fallback is disabled for safety.
${formatSandboxErrors(errors)}
Configure E2B sandbox credentials.`
      };
    }
  } else if (Object.keys(safeDeps).length > 0 && !hasSandboxCredentials()) {
    console.warn(
      "[preview-bundler] E2B Sandbox credentials not configured \u2014 using local esbuild. Set ALLOW_LOCAL_PLUGIN_BUILD=false to hard-fail instead."
    );
  }
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), `plugin-preview-${pluginId}-`));
  try {
    const srcDir = path.join(tmpDir, "src");
    const distDir = path.join(tmpDir, "dist");
    fs.mkdirSync(srcDir, { recursive: true });
    fs.mkdirSync(distDir, { recursive: true });
    writePreviewModules(srcDir, modules);
    const sharedUtils = path.join(ROOT, "shared", "plugin-utils", "index.ts");
    const sharedTypes = path.join(ROOT, "shared", "plugin-types", "index.ts");
    const esbuild = require("esbuild");
    const aliasPlugin = {
      name: "shared-alias",
      setup(build) {
        if (fs.existsSync(sharedUtils)) {
          build.onResolve({ filter: /shared\/plugin-utils/ }, () => ({ path: sharedUtils }));
        }
        if (fs.existsSync(sharedTypes)) {
          build.onResolve({ filter: /shared\/plugin-types/ }, () => ({ path: sharedTypes }));
        }
      }
    };
    const outfile = path.join(distDir, "index.cjs");
    const bridgePackages = await createBridgePackages();
    await esbuild.build({
      entryPoints: [path.join(srcDir, "Scene.tsx")],
      outfile,
      format: "cjs",
      bundle: true,
      external: Object.keys(bridgePackages),
      target: ["chrome90"],
      platform: "browser",
      nodePaths: [path.join(ROOT, "node_modules")],
      absWorkingDir: ROOT,
      inject: [path.join(ROOT, "src/lib/plugins/buffer-shim.js")],
      define: { global: "globalThis" },
      plugins: [aliasPlugin],
      sourcemap: "inline",
      minify: false
    });
    if (!fs.existsSync(outfile)) {
      return { ok: false, error: "Build succeeded but bundle not found" };
    }
    const bundleJs = fs.readFileSync(outfile, "utf-8");
    return { ok: true, bundleJs };
  } catch (e) {
    let summary = e?.message ?? "esbuild failed";
    let diagnostics;
    if (Array.isArray(e?.errors) && e.errors.length > 0) {
      diagnostics = e.errors.map((err) => ({
        text: err.text ?? "Unknown error",
        file: err.location?.file ?? "Scene.tsx",
        line: err.location?.line ?? 0,
        column: err.location?.column ?? 0,
        lineText: err.location?.lineText
      }));
      summary = diagnostics.map((d) => `${d.text} at ${d.file}:${d.line}:${d.column}`).join("\n");
    }
    return { ok: false, error: summary, diagnostics };
  } finally {
    try {
      fs.rmSync(tmpDir, { recursive: true });
    } catch {
    }
  }
}
async function bundlePreviewInSandbox(pluginId, dependencies, modules) {
  const { Sandbox } = await import('@e2b/code-interpreter');
  const ROOT = process.cwd();
  const CWD = "/home/user";
  const sharedUtils = path.join(ROOT, "shared", "plugin-utils", "index.ts");
  const sharedTypes = path.join(ROOT, "shared", "plugin-types", "index.ts");
  let sharedUtilsContent = "";
  let sharedTypesContent = "";
  try {
    sharedUtilsContent = fs.readFileSync(sharedUtils, "utf-8");
  } catch {
  }
  try {
    sharedTypesContent = fs.readFileSync(sharedTypes, "utf-8");
  } catch {
  }
  const packageJson = JSON.stringify({
    name: `plugin-preview-${pluginId}`,
    version: "0.0.0",
    private: true,
    type: "module",
    dependencies: {
      esbuild: "^0.25.0",
      buffer: "^6.0.3",
      ...dependencies
    }
  }, null, 2);
  const buildScript = `
import esbuild from 'esbuild';
import fs from 'fs';
import path from 'path';

const srcDir = '${CWD}/src';
const distDir = '${CWD}/dist';
fs.mkdirSync(distDir, { recursive: true });

const coreBridgePackages = ${JSON.stringify(CORE_BRIDGE_PACKAGES)};
const dynamicBridgePackages = ${JSON.stringify(DYNAMIC_BRIDGE_PACKAGES)};

function isValidExportName(name) {
  return /^[A-Za-z_$][\\w$]*$/.test(name) && name !== 'default';
}

async function collectPackageExportNames(pkg) {
  try {
    const mod = await import(pkg);
    return Object.keys(mod).filter(isValidExportName).sort();
  } catch {
    return [];
  }
}

const bridgePackages = { ...coreBridgePackages };
for (const [pkg, globalKey] of Object.entries(dynamicBridgePackages)) {
  bridgePackages[pkg] = [globalKey, await collectPackageExportNames(pkg)];
}

const globalsBridgePlugin = {
  name: 'globals-bridge',
  setup(build) {
    for (const pkg of Object.keys(bridgePackages)) {
      const escaped = pkg.replace(/[.*+?^$\\{\\}()|[\\]\\\\]/g, '\\\\$&');
      build.onResolve({ filter: new RegExp('^' + escaped + '$') }, () => ({
        path: pkg,
        namespace: 'globals-bridge',
      }));
    }
    build.onLoad({ filter: /.*/, namespace: 'globals-bridge' }, (args) => {
      const [globalKey, namedExports] = bridgePackages[args.path] ?? ['__pv_unknown', []];
      const lines = ['const __ns = globalThis[' + JSON.stringify(globalKey) + '] ?? {};'];
      for (const name of namedExports) {
        lines.push('export const ' + name + ' = __ns[' + JSON.stringify(name) + '];');
      }
      lines.push('export default __ns;');
      return { contents: lines.join('\\n'), loader: 'js' };
    });
  },
};

const aliasPlugin = {
  name: 'shared-alias',
  setup(build) {
    build.onResolve({ filter: /shared\\/plugin-utils/ }, () => ({ path: path.join(srcDir, 'plugin-utils.ts') }));
    build.onResolve({ filter: /shared\\/plugin-types/ }, () => ({ path: path.join(srcDir, 'plugin-types.ts') }));
  },
};

const outfile = path.join(distDir, 'index.js');

await esbuild.build({
  entryPoints: [path.join(srcDir, 'Scene.tsx')],
  outfile,
  format: 'cjs',
  bundle: true,
  external: Object.keys(bridgePackages),
  target: ['chrome90'],
  platform: 'browser',
  nodePaths: [path.join('${CWD}', 'node_modules')],
  absWorkingDir: '${CWD}',
  inject: [path.join(srcDir, 'buffer-shim.js')],
  define: { global: 'globalThis' },
  plugins: [aliasPlugin],
  sourcemap: 'inline',
  minify: false,
});

const bundleJs = fs.readFileSync(outfile, 'utf-8');
process.stdout.write(JSON.stringify({ success: true, bundleJs }));
`;
  const sandbox = await Sandbox.create({
    apiKey: process.env.E2B_API_KEY || "e2b_4d4e8b7ef35bd3a37a3d77bf839b38a98e6b3b71",
    timeoutMs: 12e4
  });
  try {
    const fileWrites = [
      sandbox.files.write(`${CWD}/package.json`, packageJson),
      sandbox.files.write(`${CWD}/build.mjs`, buildScript),
      sandbox.files.write(`${CWD}/src/plugin-utils.ts`, sharedUtilsContent),
      sandbox.files.write(`${CWD}/src/plugin-types.ts`, sharedTypesContent),
      sandbox.files.write(`${CWD}/src/buffer-shim.js`, fs.readFileSync(path.join(ROOT, "src/lib/plugins/buffer-shim.js"), "utf-8"))
    ];
    for (const [filePath, content] of Object.entries(modules)) {
      assertSafeModulePath(filePath);
      fileWrites.push(sandbox.files.write(`${CWD}/src/${filePath.replace(/\\/g, "/")}`, content));
    }
    await Promise.all(fileWrites);
    const install = await sandbox.commands.run("npm install --legacy-peer-deps --no-audit --no-fund --loglevel=error", { cwd: CWD });
    if (install.error || install.exitCode !== 0) {
      throw new Error(
        `Sandbox npm install failed (exit ${install.exitCode})
stdout: ${install.stdout}
stderr: ${install.stderr}`
      );
    }
    const build = await sandbox.commands.run("node build.mjs", { cwd: CWD });
    const stdout = build.stdout;
    const stderr = build.stderr;
    if (build.error || build.exitCode !== 0) {
      throw new Error(`Sandbox preview build failed (exit ${build.exitCode})
stdout: ${stdout}
stderr: ${stderr}`);
    }
    const parsed = JSON.parse(stdout);
    if (!parsed.success || typeof parsed.bundleJs !== "string") {
      throw new Error(`Sandbox preview build returned invalid output: ${stdout || stderr}`);
    }
    return parsed.bundleJs;
  } finally {
    await sandbox.kill();
  }
}

function extractExports(code) {
  const lines = code.split("\n");
  const exports = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    let m = line.match(/^export\s+default\s+function\s+(\w+)/);
    if (m) {
      const end = findFunctionEnd$1(lines, i);
      exports.push({ name: m[1], type: "default", lines: [i + 1, end + 1] });
      continue;
    }
    m = line.match(/^export\s+function\s+(\w+)/);
    if (m) {
      const end = findFunctionEnd$1(lines, i);
      exports.push({ name: m[1], type: "function", lines: [i + 1, end + 1] });
      continue;
    }
    m = line.match(/^export\s+default\s+/);
    if (m && !line.includes("function")) {
      exports.push({ name: "default", type: "default", lines: [i + 1, i + 1] });
      continue;
    }
    m = line.match(/^export\s+(?:const|let|var)\s+(\w+)/);
    if (m) {
      const end = findConstEnd$1(lines, i);
      exports.push({ name: m[1], type: "const", lines: [i + 1, end + 1] });
      continue;
    }
    m = line.match(/^export\s+(?:type|interface)\s+(\w+)/);
    if (m) {
      const end = findBlockEnd$1(lines, i);
      exports.push({ name: m[1], type: line.includes("interface") ? "interface" : "type", lines: [i + 1, end + 1] });
      continue;
    }
  }
  return exports;
}
function extractSections(code) {
  const lines = code.split("\n");
  const markers = [];
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(/\/\/\s*={3,}\s*(.+?)\s*={3,}/);
    if (m) {
      markers.push({ name: m[1].trim(), lineIndex: i });
    }
  }
  const sections = [];
  for (let i = 0; i < markers.length; i++) {
    const start = markers[i].lineIndex;
    const end = i + 1 < markers.length ? markers[i + 1].lineIndex - 1 : lines.length - 1;
    sections.push({ name: markers[i].name, lines: [start + 1, end + 1] });
  }
  return sections;
}
function extractImportsRange(code) {
  const lines = code.split("\n");
  let firstImport = -1;
  let lastImport = -1;
  for (let i = 0; i < lines.length; i++) {
    if (/^import\s/.test(lines[i].trim())) {
      if (firstImport === -1) firstImport = i;
      lastImport = i;
    }
  }
  if (firstImport === -1) return null;
  return { lines: [firstImport + 1, lastImport + 1] };
}
function findFunctionEnd$1(lines, startLine) {
  let depth = 0;
  let foundOpen = false;
  for (let i = startLine; i < lines.length; i++) {
    for (const ch of lines[i]) {
      if (ch === "{") {
        depth++;
        foundOpen = true;
      }
      if (ch === "}") depth--;
    }
    if (foundOpen && depth === 0) return i;
  }
  return lines.length - 1;
}
function findConstEnd$1(lines, startLine) {
  const line = lines[startLine];
  if (line.includes("=>") && line.includes("{")) {
    return findFunctionEnd$1(lines, startLine);
  }
  for (let i = startLine; i < lines.length; i++) {
    if (lines[i].trimEnd().endsWith(";")) return i;
  }
  return startLine;
}
function findBlockEnd$1(lines, startLine) {
  let depth = 0;
  let foundOpen = false;
  for (let i = startLine; i < lines.length; i++) {
    for (const ch of lines[i]) {
      if (ch === "{") {
        depth++;
        foundOpen = true;
      }
      if (ch === "}") depth--;
    }
    if (foundOpen && depth === 0) return i;
  }
  for (let i = startLine; i < lines.length; i++) {
    if (lines[i].includes(";")) return i;
  }
  return lines.length - 1;
}
function deriveAST(modules) {
  const ast = { files: {} };
  for (const [path, code] of Object.entries(modules)) {
    const lines = code.split("\n");
    ast.files[path] = {
      totalLines: lines.length,
      imports: extractImportsRange(code),
      exports: extractExports(code),
      sections: extractSections(code)
    };
  }
  return ast;
}

function isMultiFile(modules) {
  return Object.keys(modules).length > 1;
}

const KNOWN_REQUIREMENTS = [
  {
    id: "maplibre",
    aliases: ["maplibre", "maplibre-gl", "MapLibre"],
    reason: "The request mentioned MapLibre, so the plugin must not silently degrade to SVG-only."
  },
  {
    id: "generation-fields",
    aliases: ["generationfields", "generation fields", "removebackground", "removeBackground", 'editor": "image', 'editor":"image'],
    reason: "The request mentioned generated media fields, so image field metadata must stay present."
  },
  {
    id: "plugin-data",
    aliases: ["plugindata", "pluginData"],
    reason: "The request mentioned pluginData, so the plugin data contract must stay explicit."
  },
  {
    id: "tail-tracer",
    aliases: ["tail-light", "taillight", "lightning", "strokeDasharray", "pathLength", "dashoffset"],
    reason: "The request mentioned a moving tracer, so the border trace implementation must remain present."
  },
  {
    id: "geojson",
    aliases: ["geojson", "GeoJSON", "centerLngLat", "screenPath"],
    reason: "The request mentioned map geometry/projection, so geometry fields must stay present."
  }
];
const HOST_EXTERNALS = /* @__PURE__ */ new Set([
  "react",
  "react-dom",
  "remotion",
  "@remotion/player",
  "@remotion/renderer",
  "@remotion/lambda",
  "@remotion/media",
  "@remotion/webcodecs",
  "three",
  "@react-three/fiber",
  "@react-three/drei",
  "@react-three/postprocessing",
  "postprocessing",
  "shared"
]);
const FILE_EXTENSIONS = ["", ".ts", ".tsx", ".js", ".jsx"];
function normalizeSlash(value) {
  return value.replace(/\\/g, "/").replace(/^.\//, "");
}
function dirname(filePath) {
  const normalized = normalizeSlash(filePath);
  const index = normalized.lastIndexOf("/");
  return index === -1 ? "" : normalized.slice(0, index);
}
function joinLocal(baseDir, specifier) {
  const raw = `${baseDir ? `${baseDir}/` : ""}${specifier}`;
  const parts = [];
  for (const part of normalizeSlash(raw).split("/")) {
    if (!part || part === ".") continue;
    if (part === "..") {
      parts.pop();
      continue;
    }
    parts.push(part);
  }
  return parts.join("/");
}
function getModules$1(pending) {
  if (pending.modules && Object.keys(pending.modules).length > 0) {
    return pending.modules;
  }
  return { "Scene.tsx": pending.sceneCode ?? "" };
}
function getPackageName(specifier) {
  if (specifier.startsWith("@")) {
    const [scope, name] = specifier.split("/");
    return name ? `${scope}/${name}` : specifier;
  }
  return specifier.split("/")[0] ?? specifier;
}
function resolveLocalImport(filePath, specifier, modules) {
  const base = joinLocal(dirname(filePath), specifier);
  for (const ext of FILE_EXTENSIONS) {
    const candidate = `${base}${ext}`;
    if (modules[candidate] !== void 0) return candidate;
  }
  for (const ext of FILE_EXTENSIONS.filter(Boolean)) {
    const candidate = `${base}/index${ext}`;
    if (modules[candidate] !== void 0) return candidate;
  }
  return void 0;
}
function collectImportSpecifiers(code) {
  const specs = /* @__PURE__ */ new Set();
  const patterns = [
    /\bimport\s+(?:type\s+)?(?:[\s\S]*?\s+from\s+)?['"]([^'"]+)['"]/g,
    /\bexport\s+(?:type\s+)?[\s\S]*?\s+from\s+['"]([^'"]+)['"]/g,
    /\bimport\s*\(\s*['"]([^'"]+)['"]\s*\)/g,
    /\brequire\s*\(\s*['"]([^'"]+)['"]\s*\)/g
  ];
  for (const pattern of patterns) {
    for (const match of code.matchAll(pattern)) {
      if (match[1]) specs.add(match[1]);
    }
  }
  return [...specs];
}
function analyzePluginImports(modules, dependencies = {}) {
  const imports = [];
  const issues = [];
  const warnings = [];
  for (const [file, code] of Object.entries(modules)) {
    for (const specifier of collectImportSpecifiers(code)) {
      if (specifier.startsWith(".") || specifier.startsWith("/")) {
        const resolved = resolveLocalImport(file, specifier, modules);
        imports.push({ file, specifier, kind: "local", resolved });
        if (!resolved) {
          issues.push({
            file,
            specifier,
            message: `Local import "${specifier}" does not resolve from ${file}. Create the file or fix the import.`
          });
        }
        continue;
      }
      const packageName = getPackageName(specifier);
      imports.push({ file, specifier, kind: "external", packageName });
      if (HOST_EXTERNALS.has(packageName) || packageName.startsWith("@remotion/")) continue;
      if (dependencies[packageName] === void 0) {
        issues.push({
          file,
          specifier,
          message: `External package "${packageName}" is imported by ${file} but not declared in dependencies. Add dependencies: { "${packageName}": "<semver>" } with updateDependencies or setInitialScene before compiling. Do not switch to CDN/dynamic script loading unless sandbox package install is truly impossible.`
        });
      }
    }
  }
  return { imports, issues, warnings };
}
function promptMentions(prompt, term) {
  const compact = prompt.toLowerCase().replace(/[\s_-]+/g, "");
  const normal = prompt.toLowerCase();
  return term.aliases.some((alias) => {
    const lower = alias.toLowerCase();
    return normal.includes(lower) || compact.includes(lower.replace(/[\s_-]+/g, ""));
  });
}
function buildSearchText(pending) {
  const modules = getModules$1(pending);
  return [
    pending.description ?? "",
    pending.schemaJson ?? "",
    Object.keys(pending.dependencies ?? {}).join(" "),
    Object.values(modules).join("\n")
  ].join("\n");
}
function parseSchema(schemaJson) {
  if (!schemaJson) return null;
  try {
    const parsed = JSON.parse(schemaJson);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : null;
  } catch {
    return null;
  }
}
function schemaHasPreviewValue(schema, field) {
  if (!schema) return false;
  const rootDefaults = schema.defaults && typeof schema.defaults === "object" ? schema.defaults : {};
  const property = schema.properties?.[field];
  const value = rootDefaults[field] ?? property?.default;
  return value !== void 0 && value !== null && String(value).trim() !== "";
}
function codeHasFallbackForDataField(source, field) {
  const escaped = field.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`data\\.${escaped}[^\\n;,)\\]}]*(?:\\?\\?|\\|\\|)\\s*['"\`]`, "m").test(source);
}
function detectVisualIssues(pending) {
  const modules = getModules$1(pending);
  const schema = parseSchema(pending.schemaJson);
  const issues = [];
  for (const [file, source] of Object.entries(modules)) {
    if (/\breturn\s+null\b/.test(source)) {
      issues.push({ file, message: "Scene/component returns null, so preview can be blank." });
    }
    if (/<AbsoluteFill\s*\/>/.test(source)) {
      issues.push({ file, message: "Scene renders an empty <AbsoluteFill /> with no visible children." });
    }
  }
  const combined = Object.entries(modules).map(([file, source]) => `/* ${file} */
${source}`).join("\n");
  const hasVisiblePrimitive = /<(?:AbsoluteFill|div|section|main|svg|canvas|Img|img|video|span|p|h1|h2|h3|[A-Z][A-Za-z0-9_]*)\b/.test(combined);
  const hasPaintSignal = /(?:background|color|fill|stroke|boxShadow|textShadow|gradient|linearGradient|radialGradient|fontSize|border|opacity|transform)/.test(combined);
  if (!hasVisiblePrimitive || !hasPaintSignal) {
    issues.push({
      file: "Scene.tsx",
      message: "No clear visible painted element was detected. Add a full-frame background and at least one visible text/shape/image layer."
    });
  }
  const dataFields = /* @__PURE__ */ new Set();
  for (const match of combined.matchAll(/\bdata\.(\w+)/g)) {
    dataFields.add(match[1]);
  }
  for (const field of dataFields) {
    if (schemaHasPreviewValue(schema, field) || codeHasFallbackForDataField(combined, field)) continue;
    issues.push({
      file: "schema.json",
      message: `data.${field} is used by the scene but has no non-empty schema default and no inline fallback. Preview may render empty.`
    });
  }
  return issues;
}
function containsRequirement(searchText, term) {
  const compact = searchText.toLowerCase().replace(/[\s_-]+/g, "");
  const normal = searchText.toLowerCase();
  if (term.id === "generation-fields") {
    return normal.includes("generationfields") || normal.includes("generation fields") || normal.includes("removebackground") || normal.includes("removebackground") || normal.includes('"editor": "image"') || normal.includes('"editor":"image"') || normal.includes("'editor': 'image'");
  }
  return term.aliases.some((alias) => {
    const lower = alias.toLowerCase();
    return normal.includes(lower) || compact.includes(lower.replace(/[\s_-]+/g, ""));
  });
}
function deriveHardRequirements(sourcePrompt) {
  return KNOWN_REQUIREMENTS.filter((term) => promptMentions(sourcePrompt, term));
}
function createSnapshot(pending) {
  const modules = getModules$1(pending);
  const dependencies = pending.dependencies ?? {};
  const { imports } = analyzePluginImports(modules, dependencies);
  return {
    files: Object.keys(modules).sort(),
    dependencies: Object.keys(dependencies).sort(),
    imports
  };
}
function createPluginRunLedger(pending, sourcePrompt) {
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const ledger = {
    version: 1,
    sourcePrompt,
    hardRequirements: deriveHardRequirements(sourcePrompt),
    baseline: createSnapshot(pending),
    events: [],
    createdAt: now,
    updatedAt: now
  };
  ledger.events.push({
    type: "init",
    summary: `Initialized plugin run ledger with ${ledger.hardRequirements.length} hard requirement(s).`,
    at: now
  });
  return ledger;
}
function createPluginExecutionState(params) {
  const now = (/* @__PURE__ */ new Date()).toISOString();
  return {
    version: 1,
    pluginId: params.pluginId,
    mode: params.mode ?? "create",
    frozenContracts: {
      schemaPaths: params.frozenContracts?.schemaPaths ?? [],
      files: params.frozenContracts?.files ?? [],
      dependencies: params.frozenContracts?.dependencies ?? {},
      generationFields: params.frozenContracts?.generationFields ?? [],
      notes: params.frozenContracts?.notes ?? []
    },
    steps: params.steps.map((step) => ({
      id: step.id,
      title: step.title,
      category: step.category,
      owner: step.owner,
      goal: step.goal,
      files: step.files ?? [],
      status: "pending",
      attempts: 0,
      issues: [],
      hypothesis: step.hypothesis,
      evidence: step.evidence,
      failureMode: step.failureMode,
      dependsOn: step.dependsOn
    })),
    deviations: [],
    lastReconAt: params.lastReconAt ?? null,
    lastReconOverallHash: params.lastReconOverallHash ?? null,
    createdAt: now,
    updatedAt: now
  };
}
function attachPluginExecutionState(pending, execution) {
  if (!execution || !pending.runLedger) return pending;
  const now = (/* @__PURE__ */ new Date()).toISOString();
  return {
    ...pending,
    runLedger: {
      ...pending.runLedger,
      execution,
      events: [
        ...pending.runLedger.events.slice(-24),
        {
          type: "plan",
          summary: `Registered ${execution.steps.length} execution step(s). Core logic: ${execution.steps.filter((s) => s.category === "core_remotion_logic").length}; glue: ${execution.steps.filter((s) => s.category === "glue_code").length}.`,
          at: now
        }
      ],
      updatedAt: now
    }
  };
}
function updatePluginExecutionStep(execution, params) {
  const now = (/* @__PURE__ */ new Date()).toISOString();
  return {
    ...execution,
    currentStepId: params.status === "in_progress" ? params.stepId : execution.currentStepId,
    steps: execution.steps.map((step) => {
      if (step.id !== params.stepId) return step;
      return {
        ...step,
        status: params.status ?? step.status,
        attempts: params.status === "in_progress" ? step.attempts + 1 : step.attempts,
        summary: params.summary ?? step.summary,
        issues: params.issues ?? step.issues
      };
    }),
    updatedAt: now
  };
}
function summarizePluginExecution(execution) {
  if (!execution) return "No execution plan registered yet.";
  const lines = execution.steps.map((step) => {
    const issueSummary = step.issues?.length ? ` Issues: ${step.issues.map((issue) => `${issue.type}${issue.fixed ? " fixed" : ""}`).join(", ")}.` : "";
    const hypothesisTag = step.hypothesis ? ` [hypothesis: ${step.hypothesis.slice(0, 80)}${step.hypothesis.length > 80 ? "\u2026" : ""}]` : "";
    return `- ${step.id} [${step.status}, ${step.category}, ${step.owner}]${hypothesisTag}: ${step.summary ?? step.goal}.${issueSummary}`;
  });
  const deviations = execution.deviations ?? [];
  if (deviations.length > 0) {
    lines.push(`Deviations (${deviations.length}):`);
    for (const d of deviations.slice(-5)) {
      lines.push(`  \u2022 ${d.stepId} \u2192 ${d.resolution}: ${d.reason}`);
    }
  }
  return lines.join("\n");
}
function validatePluginRunState(pending) {
  const modules = getModules$1(pending);
  const dependencies = pending.dependencies ?? {};
  const ledger = pending.runLedger;
  const hardRequirements = ledger?.hardRequirements ?? [];
  const searchText = buildSearchText(pending);
  const { imports, issues, warnings } = analyzePluginImports(modules, dependencies);
  const visualIssues = detectVisualIssues(pending);
  const missingRequirements = hardRequirements.filter((term) => !containsRequirement(searchText, term)).map((term) => `${term.id}: ${term.reason}`);
  return {
    ok: missingRequirements.length === 0 && issues.length === 0 && visualIssues.length === 0,
    hardRequirements,
    missingRequirements,
    importIssues: issues,
    visualIssues,
    warnings,
    snapshot: {
      files: Object.keys(modules).sort(),
      dependencies: Object.keys(dependencies).sort(),
      imports
    }
  };
}
function appendPluginLedgerEvent(pending, event) {
  const ledger = pending.runLedger;
  if (!ledger) return pending;
  const now = (/* @__PURE__ */ new Date()).toISOString();
  return {
    ...pending,
    runLedger: {
      ...ledger,
      events: [...ledger.events.slice(-24), { ...event, at: now }],
      updatedAt: now
    }
  };
}

const FILENAME_ROLE_HINTS = [
  { pattern: /^Scene\.tsx$/, role: "composition root" },
  { pattern: /theme\./i, role: "theme tokens (colors, fonts, spacing)" },
  { pattern: /animations?\./i, role: "animation timeline helpers" },
  { pattern: /components?\./i, role: "shared sub-components" },
  { pattern: /layout\./i, role: "positioning / AbsoluteFill structure" },
  { pattern: /utils?\./i, role: "utility helpers" },
  { pattern: /map/i, role: "map / geographic layer" },
  { pattern: /chart/i, role: "chart / data visualization" },
  { pattern: /camera/i, role: "camera controller" },
  { pattern: /particle/i, role: "particle system" }
];
function extractRoleFromJSDoc(code) {
  const m = code.match(/(?:\/\*\*?|\/\/)\s*@role\s*[:\s]\s*([^\n*]+)/);
  return m ? m[1].trim() : null;
}
function extractRoleFromFirstSection(fileAst) {
  if (fileAst.sections.length === 0) return null;
  return fileAst.sections[0].name;
}
function deriveRoleFromFilename(filePath) {
  for (const hint of FILENAME_ROLE_HINTS) {
    if (hint.pattern.test(filePath)) return hint.role;
  }
  const base = filePath.split("/").pop() ?? filePath;
  return `module (${base})`;
}
function deriveFileRole(filePath, code, fileAst) {
  const jsdoc = extractRoleFromJSDoc(code);
  if (jsdoc) return { role: jsdoc, roleSource: "jsdoc" };
  const section = extractRoleFromFirstSection(fileAst);
  if (section) return { role: section, roleSource: "section" };
  return { role: deriveRoleFromFilename(filePath), roleSource: "filename" };
}
function hashFile(content) {
  return createHash("sha256").update(content).digest("hex").slice(0, 16);
}
function hashOverall(entries) {
  const stable = entries.slice().sort((a, b) => a.path.localeCompare(b.path)).map((e) => `${e.path}:${e.hash}`).join("|");
  return createHash("sha256").update(stable).digest("hex").slice(0, 16);
}
function classifyImport(specifier) {
  return specifier.startsWith(".") || specifier.startsWith("/") ? "local" : "external";
}
const IMPORT_LINE_REGEX = /^\s*import\s+(?:type\s+)?(?:[\s\S]*?\s+from\s+)?['"]([^'"]+)['"]/;
function extractImportsWithLines(code) {
  const out = [];
  const lines = code.split("\n");
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(IMPORT_LINE_REGEX);
    if (m && m[1]) out.push({ specifier: m[1], line: i + 1 });
  }
  return out;
}
function resolveLocalPath(fromFile, specifier, modulePaths) {
  const baseDir = fromFile.includes("/") ? fromFile.slice(0, fromFile.lastIndexOf("/")) : "";
  const join = (a, b) => a ? `${a}/${b}` : b;
  const candidates = [];
  const parts = (baseDir ? join(baseDir, specifier) : specifier).split("/");
  const cleaned = [];
  for (const p of parts) {
    if (!p || p === ".") continue;
    if (p === "..") {
      cleaned.pop();
      continue;
    }
    cleaned.push(p);
  }
  const base = cleaned.join("/");
  for (const ext of ["", ".ts", ".tsx", ".js", ".jsx"]) {
    candidates.push(`${base}${ext}`);
  }
  for (const ext of [".ts", ".tsx", ".js", ".jsx"]) {
    candidates.push(`${base}/index${ext}`);
  }
  return candidates.find((c) => modulePaths.has(c));
}
function extractDataFieldUsages(modules) {
  const usages = [];
  const pattern = /\bdata\.([A-Za-z_$][A-Za-z0-9_$]*)/g;
  for (const [file, code] of Object.entries(modules)) {
    const lines = code.split("\n");
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      let m;
      pattern.lastIndex = 0;
      while ((m = pattern.exec(line)) !== null) {
        const field = m[1];
        const after = line.slice(m.index);
        const pathMatch = after.match(/^data\.[A-Za-z_$][A-Za-z0-9_$]*(?:\[[^\]]*\]|\.[A-Za-z_$][A-Za-z0-9_$]*)*/);
        usages.push({
          field,
          path: pathMatch ? pathMatch[0] : `data.${field}`,
          file,
          line: i + 1,
          lineText: line.trim()
        });
      }
    }
  }
  return usages;
}
const KEYWORDS = /* @__PURE__ */ new Set([
  "if",
  "else",
  "for",
  "while",
  "do",
  "switch",
  "case",
  "break",
  "continue",
  "return",
  "function",
  "class",
  "interface",
  "type",
  "enum",
  "namespace",
  "import",
  "export",
  "from",
  "default",
  "try",
  "catch",
  "finally",
  "throw",
  "new",
  "delete",
  "typeof",
  "instanceof",
  "in",
  "of",
  "this",
  "super",
  "extends",
  "implements",
  "static",
  "public",
  "private",
  "protected",
  "readonly",
  "async",
  "await",
  "yield",
  "void",
  "null",
  "undefined",
  "true",
  "false",
  "const",
  "let",
  "var"
]);
function extractInternalSymbols(code, exportedNames) {
  const lines = code.split("\n");
  const out = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();
    if (/^[<(]/.test(trimmed) || /=>\s*[<(]/.test(trimmed)) continue;
    if (/^[A-Za-z_$][\w$]*\./.test(trimmed) && trimmed.includes("=")) continue;
    if (/^\s*(\/\/|\/\*|\*)/.test(line)) continue;
    let m = line.match(/^(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*[\(<]/);
    if (m && !exportedNames.has(m[1]) && !KEYWORDS.has(m[1])) {
      const end = findFunctionEnd(lines, i);
      out.push({ name: m[1], kind: "internal-function", lines: [i + 1, end + 1] });
      continue;
    }
    m = line.match(/^(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=/);
    if (m && !exportedNames.has(m[1]) && !KEYWORDS.has(m[1])) {
      if (line.match(/^(?:export\s+)?(?:const|let|var)\s*\{/)) continue;
      if (line.match(/^(?:export\s+)?(?:const|let|var)\s*\[/)) continue;
      const end = findConstEnd(lines, i);
      out.push({ name: m[1], kind: "internal-const", lines: [i + 1, end + 1] });
      continue;
    }
    m = line.match(/^class\s+([A-Za-z_$][\w$]*)/);
    if (m && !exportedNames.has(m[1]) && !KEYWORDS.has(m[1])) {
      const end = findBlockEnd(lines, i);
      out.push({ name: m[1], kind: "internal-class", lines: [i + 1, end + 1] });
      continue;
    }
  }
  return out;
}
function findFunctionEnd(lines, startLine) {
  let depth = 0;
  let foundOpen = false;
  for (let i = startLine; i < lines.length; i++) {
    for (const ch of lines[i]) {
      if (ch === "{") {
        depth++;
        foundOpen = true;
      }
      if (ch === "}") depth--;
    }
    if (foundOpen && depth === 0) return i;
  }
  return lines.length - 1;
}
function findConstEnd(lines, startLine) {
  const line = lines[startLine];
  if (line.includes("=>") && line.includes("{")) {
    return findFunctionEnd(lines, startLine);
  }
  for (let i = startLine; i < lines.length; i++) {
    if (lines[i].trimEnd().endsWith(";")) return i;
  }
  return startLine;
}
function findBlockEnd(lines, startLine) {
  let depth = 0;
  let foundOpen = false;
  for (let i = startLine; i < lines.length; i++) {
    for (const ch of lines[i]) {
      if (ch === "{") {
        depth++;
        foundOpen = true;
      }
      if (ch === "}") depth--;
    }
    if (foundOpen && depth === 0) return i;
  }
  for (let i = startLine; i < lines.length; i++) {
    if (lines[i].includes(";")) return i;
  }
  return lines.length - 1;
}
const REMOTION_APIS = [
  "useCurrentFrame",
  "useVideoConfig",
  "interpolate",
  "spring",
  "Easing",
  "AbsoluteFill",
  "Sequence",
  "Audio",
  "Img",
  "Video",
  "Composition",
  "delayRender",
  "continueRender",
  "prefetch",
  "random",
  "staticFile"
];
const REACT_APIS = [
  "useState",
  "useEffect",
  "useRef",
  "useMemo",
  "useCallback",
  "useReducer",
  "useContext",
  "useLayoutEffect"
];
const JS_BUILTINS = /* @__PURE__ */ new Set([
  "Math",
  "Date",
  "JSON",
  "Object",
  "Array",
  "String",
  "Number",
  "Boolean",
  "Promise",
  "Map",
  "Set",
  "Symbol",
  "Reflect",
  "Proxy",
  "console",
  "parseInt",
  "parseFloat",
  "isNaN",
  "isFinite",
  "setTimeout",
  "setInterval",
  "clearTimeout",
  "clearInterval",
  "encodeURI",
  "decodeURI",
  "encodeURIComponent",
  "decodeURIComponent"
]);
function deriveSymbolSummary(name, kind, sourceText) {
  const reads = [];
  const readPattern = /\bdata\.([A-Za-z_$][A-Za-z0-9_$]*)/g;
  let m;
  while ((m = readPattern.exec(sourceText)) !== null) {
    if (!reads.includes(m[1])) reads.push(m[1]);
  }
  const frameworkCalls = [];
  for (const api of [...REMOTION_APIS, ...REACT_APIS]) {
    const pattern = new RegExp(`\\b${api}\\b`);
    if (pattern.test(sourceText) && !frameworkCalls.includes(api)) {
      frameworkCalls.push(api);
    }
  }
  const otherCalls = [];
  const callPattern = /\b([A-Za-z_$][A-Za-z0-9_$]*)\s*\(/g;
  while ((m = callPattern.exec(sourceText)) !== null) {
    const callee = m[1];
    if (KEYWORDS.has(callee)) continue;
    if (JS_BUILTINS.has(callee)) continue;
    if (frameworkCalls.includes(callee)) continue;
    if (callee === name) continue;
    if (!otherCalls.includes(callee)) otherCalls.push(callee);
  }
  const parts = [`${kind} ${name}`];
  if (reads.length > 0) parts.push(`reads [${reads.join(", ")}]`);
  if (frameworkCalls.length > 0) parts.push(`remotion/react [${frameworkCalls.join(", ")}]`);
  if (otherCalls.length > 0) parts.push(`calls [${otherCalls.slice(0, 5).join(", ")}${otherCalls.length > 5 ? ", \u2026" : ""}]`);
  return {
    summary: parts.join("; "),
    reads,
    calls: [...frameworkCalls, ...otherCalls]
  };
}
const STOP_WORDS = /* @__PURE__ */ new Set([
  "the",
  "a",
  "an",
  "for",
  "of",
  "to",
  "is",
  "are",
  "was",
  "were",
  "where",
  "what",
  "which",
  "who",
  "whom",
  "find",
  "show",
  "get",
  "give",
  "me",
  "my",
  "i",
  "want",
  "need",
  "this",
  "that",
  "these",
  "those",
  "and",
  "or",
  "but",
  "in",
  "on",
  "at",
  "by",
  "with",
  "from",
  "as",
  "into",
  "about",
  "how",
  "why",
  "when",
  "it",
  "its",
  "be",
  "been",
  "being",
  "have",
  "has",
  "had",
  "do",
  "does",
  "did",
  "will",
  "would",
  "should",
  "could",
  "can",
  "may",
  "might",
  "must",
  "use",
  "using",
  "used",
  // "use" appears in hook names but is noise in intent
  "go",
  "going",
  "gone"
]);
function tokenize(text) {
  const tokens = text.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/[_\-]/g, " ").split(/[^a-zA-Z0-9]+/).map((t) => t.toLowerCase()).map((t) => {
    if (t.length > 4 && t.endsWith("ed")) return t.slice(0, -2);
    if (t.length > 3 && t.endsWith("s") && !t.endsWith("ss")) return t.slice(0, -1);
    return t;
  }).filter((t) => t.length > 1 && !STOP_WORDS.has(t));
  return [...new Set(tokens)];
}
function scoreIntentMatch(intentTokens, symbol) {
  if (intentTokens.length === 0) return 0;
  if (symbol.tokens.length === 0) return 0;
  const symbolTokenSet = new Set(symbol.tokens);
  let matched = 0;
  for (const t of intentTokens) {
    if (symbolTokenSet.has(t)) matched++;
  }
  if (matched === 0) return 0;
  const recall = matched / intentTokens.length;
  const precision = matched / symbolTokenSet.size;
  return recall * 0.7 + precision * 0.3;
}
function buildSymbolTokens(symbol, fileRole) {
  const raw = [
    symbol.name,
    symbol.summary,
    symbol.reads.join(" "),
    symbol.calls.join(" "),
    fileRole
  ].join(" ");
  return tokenize(raw);
}
function deriveSourceMap(modules, options = {}) {
  const ast = deriveAST(modules);
  const modulePaths = new Set(Object.keys(modules));
  const files = [];
  const symbols = [];
  const perFileHashes = {};
  for (const [path, code] of Object.entries(modules)) {
    const fileAst = ast.files[path];
    if (!fileAst) continue;
    const roleOverride = options.roleOverrides?.[path];
    const roleInfo = roleOverride ? { role: roleOverride, roleSource: "agent" } : deriveFileRole(path, code, fileAst);
    const imports = extractImportsWithLines(code).map(({ specifier, line }) => {
      const kind = classifyImport(specifier);
      const resolved = kind === "local" ? resolveLocalPath(path, specifier, modulePaths) : void 0;
      return { specifier, kind, resolved, line };
    });
    const hash = hashFile(code);
    perFileHashes[path] = hash;
    files.push({
      path,
      totalLines: fileAst.totalLines,
      role: roleInfo.role,
      roleSource: roleInfo.roleSource,
      exports: fileAst.exports,
      sections: fileAst.sections,
      imports,
      hash
    });
    const lines = code.split("\n");
    const exportedNames = new Set(fileAst.exports.map((e) => e.name));
    for (const exp of fileAst.exports) {
      const sourceText = lines.slice(exp.lines[0] - 1, exp.lines[1]).join("\n");
      const derived = deriveSymbolSummary(exp.name, exp.type, sourceText);
      const sourceHash = hashFile(sourceText);
      const tokens = buildSymbolTokens(
        { name: exp.name, summary: derived.summary, reads: derived.reads, calls: derived.calls },
        roleInfo.role
      );
      symbols.push({
        name: exp.name,
        kind: exp.type,
        file: path,
        lines: exp.lines,
        exported: true,
        summary: derived.summary,
        sourceHash,
        reads: derived.reads,
        calls: derived.calls,
        tokens
      });
    }
    const internalSymbols = extractInternalSymbols(code, exportedNames);
    for (const internal of internalSymbols) {
      const sourceText = lines.slice(internal.lines[0] - 1, internal.lines[1]).join("\n");
      const derived = deriveSymbolSummary(internal.name, internal.kind, sourceText);
      const sourceHash = hashFile(sourceText);
      const tokens = buildSymbolTokens(
        { name: internal.name, summary: derived.summary, reads: derived.reads, calls: derived.calls },
        roleInfo.role
      );
      symbols.push({
        name: internal.name,
        kind: internal.kind,
        file: path,
        lines: internal.lines,
        exported: false,
        summary: derived.summary,
        sourceHash,
        reads: derived.reads,
        calls: derived.calls,
        tokens
      });
    }
  }
  const overallHash = hashOverall(files.map((f) => ({ path: f.path, hash: f.hash })));
  const dataFieldUsages = extractDataFieldUsages(modules);
  return {
    version: 1,
    pluginId: options.pluginId ?? "unknown",
    generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    files,
    symbols,
    dataFieldUsages,
    perFileHashes,
    overallHash
  };
}
function diffSourceMaps(before, after) {
  if (!before) {
    return {
      added: after.files.map((f) => f.path),
      removed: [],
      changed: [],
      unchanged: []
    };
  }
  const beforeHashes = before.perFileHashes;
  const afterHashes = after.perFileHashes;
  const beforePaths = new Set(Object.keys(beforeHashes));
  const afterPaths = new Set(Object.keys(afterHashes));
  const added = [];
  const removed = [];
  const changed = [];
  const unchanged = [];
  for (const p of afterPaths) {
    if (!beforePaths.has(p)) added.push(p);
    else if (beforeHashes[p] !== afterHashes[p]) changed.push(p);
    else unchanged.push(p);
  }
  for (const p of beforePaths) {
    if (!afterPaths.has(p)) removed.push(p);
  }
  return { added, removed, changed, unchanged };
}
function summarizeSourceMap(sm) {
  const lines = [];
  lines.push(`SOURCE MAP (overall ${sm.overallHash}, ${sm.files.length} file(s), ${sm.symbols.length} symbol(s), ${sm.dataFieldUsages.length} data-field usage(s))`);
  for (const f of sm.files) {
    const exportNames = f.exports.map((e) => `${e.name}${e.kind === "default" ? "(default)" : ""}`).join(", ") || "\u2014";
    const unresolved = f.imports.filter((i) => i.kind === "local" && !i.resolved);
    lines.push(`  \u2022 ${f.path} [${f.hash}] (${f.totalLines} lines) \u2014 ${f.role}`);
    lines.push(`    exports: ${exportNames}`);
    if (unresolved.length > 0) {
      lines.push(`    \u26A0 unresolved local imports: ${unresolved.map((u) => u.specifier).join(", ")}`);
    }
    const fileSymbols = sm.symbols.filter((s) => s.file === f.path);
    if (fileSymbols.length > 0) {
      const shown = fileSymbols.slice(0, 8);
      for (const s of shown) {
        const expTag = s.exported ? "" : " (internal)";
        lines.push(`    \u2013 ${s.name}${expTag} [${s.kind}] L${s.lines[0]}-${s.lines[1]}: ${s.summary}`);
      }
      if (fileSymbols.length > 8) {
        lines.push(`    \u2026 and ${fileSymbols.length - 8} more symbol(s)`);
      }
    }
  }
  if (sm.dataFieldUsages.length > 0) {
    const byField = /* @__PURE__ */ new Map();
    for (const u of sm.dataFieldUsages) {
      byField.set(u.field, (byField.get(u.field) ?? 0) + 1);
    }
    const fieldSummary = [...byField.entries()].map(([f, c]) => `${f}(${c})`).join(", ");
    lines.push(`  data fields read: ${fieldSummary}`);
  }
  return lines.join("\n");
}

function getModules(pending) {
  if (pending.modules && Object.keys(pending.modules).length > 0) {
    return pending.modules;
  }
  return { "Scene.tsx": pending.sceneCode ?? "" };
}
function withCurrentSourceHash$1(pending) {
  function stableStringify(value) {
    if (value === null || typeof value !== "object") return JSON.stringify(value);
    if (Array.isArray(value)) return `[${value.map((item) => stableStringify(item)).join(",")}]`;
    const entries = Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => `${JSON.stringify(key)}:${stableStringify(item)}`);
    return `{${entries.join(",")}}`;
  }
  const payload = {
    sceneCode: pending.sceneCode ?? "",
    modules: pending.modules ?? null,
    schemaJson: pending.schemaJson ?? "",
    dependencies: pending.dependencies ?? {}
  };
  return {
    ...pending,
    sourceHash: createHash("sha256").update(stableStringify(payload)).digest("hex").slice(0, 16)
  };
}
function refreshSourceMap(pending) {
  const previousMap = pending.sourceMap ?? null;
  const modules = getModules(pending);
  const sourceMap = deriveSourceMap(modules, {
    roleOverrides: pending.roleOverrides,
    pluginId: pending.pluginId
  });
  const diff = diffSourceMaps(previousMap, sourceMap);
  return { pending: { ...pending, sourceMap }, sourceMap, diff };
}
function formatGuardFailure$1(guard) {
  const parts = [];
  if (guard.missingRequirements?.length > 0) parts.push(`Missing hard requirement(s): ${guard.missingRequirements.join("; ")}`);
  if (guard.importIssues?.length > 0) parts.push(`Import issue(s): ${guard.importIssues.map((i) => `${i.file} imports ${i.specifier}: ${i.message}`).join("; ")}`);
  if (guard.visualIssues?.length > 0) parts.push(`Visual issue(s): ${guard.visualIssues.map((i) => `${i.file}: ${i.message}`).join("; ")}`);
  return parts.join("\n");
}
const getSourceMapTool = createTool({
  id: "get-source-map",
  description: "RECON step. Produce a semantic source map of the current pending plugin: per-file role + exports + sections + imports + per-file hash, plus a symbol index and reverse data-field usage index. Call this BEFORE recordPluginPlan in modify mode (it is mandatory \u2014 the guard rejects plans without a recent recon event). In create mode, call this once after setInitialScene so subsequent edits can reference real files/symbols/line numbers. Returns the full source map plus a human-readable summary. The map is cached on pendingPlugin.sourceMap and refreshed automatically after every edit.",
  inputSchema: z.object({
    threadId: z.string(),
    refresh: z.boolean().optional().default(false).describe("Force re-derivation even if cached. Defaults to false (use cache).")
  }),
  execute: async (inputData) => {
    const { threadId, refresh } = inputData;
    const job = await getJob(threadId);
    const pending = job?.state?.pendingPlugin;
    if (!pending) {
      return { ok: false, error: "No pending plugin found. Call setInitialScene first." };
    }
    let sourceMap;
    let diff = null;
    if (refresh || !pending.sourceMap) {
      const refreshed = refreshSourceMap(pending);
      sourceMap = refreshed.sourceMap;
      diff = refreshed.diff;
      const nextPending = appendPluginLedgerEvent(
        { ...refreshed.pending, lastReconAt: (/* @__PURE__ */ new Date()).toISOString() },
        {
          type: "validation",
          summary: `Recon: ${sourceMap.files.length} files, ${sourceMap.symbols.length} symbols, ${sourceMap.dataFieldUsages.length} data-field usages. Overall hash ${sourceMap.overallHash}.`,
          warnings: diff ? `Added ${diff.added.length}, removed ${diff.removed.length}, changed ${diff.changed.length}` : void 0
        }
      );
      await patchJobState(threadId, (s) => ({ ...s, pendingPlugin: nextPending }));
    } else {
      sourceMap = pending.sourceMap;
    }
    console.log(`[get-source-map] \u2705 ${sourceMap.files.length} files, hash ${sourceMap.overallHash} for thread ${threadId.slice(0, 8)}`);
    return {
      ok: true,
      sourceMap,
      summary: summarizeSourceMap(sourceMap),
      diff: diff ?? null
    };
  }
});
const setFileRoleTool = createTool({
  id: "set-file-role",
  description: 'Override the semantic role tag of a file in the source map (e.g. "hero reveal animation"). Use this when the agent-created file has a non-obvious purpose that filename/section heuristics got wrong. The role travels with the source map and helps future recon calls understand the file without re-reading it.',
  inputSchema: z.object({
    threadId: z.string(),
    filePath: z.string(),
    role: z.string().describe('Short semantic role, e.g. "MapLibre camera controller"')
  }),
  execute: async (inputData) => {
    const { threadId, filePath, role } = inputData;
    const job = await getJob(threadId);
    const pending = job?.state?.pendingPlugin;
    if (!pending) {
      return { ok: false, error: "No pending plugin found." };
    }
    const roleOverrides = { ...pending.roleOverrides ?? {}, [filePath]: role };
    const modules = getModules(pending);
    if (!modules[filePath]) {
      return { ok: false, error: `File "${filePath}" not found in plugin modules.` };
    }
    const sourceMap = deriveSourceMap(modules, { roleOverrides, pluginId: pending.pluginId });
    const nextPending = appendPluginLedgerEvent(
      { ...pending, roleOverrides, sourceMap },
      { type: "edit", filePath, summary: `Set role for ${filePath}: "${role}".` }
    );
    await patchJobState(threadId, (s) => ({ ...s, pendingPlugin: nextPending }));
    return { ok: true, filePath, role };
  }
});
const findSymbolTool = createTool({
  id: "find-symbol",
  description: "Find a symbol (function, const, type, interface, default export) by name across all plugin files. Returns file + line range + kind. Use this instead of readModule when you know the symbol name and just need to locate it.",
  inputSchema: z.object({
    threadId: z.string(),
    name: z.string().describe("Symbol name (exact match). Use listSymbols for discovery."),
    kind: z.enum(["function", "const", "type", "interface", "default"]).optional()
  }),
  execute: async (inputData) => {
    const { threadId, name, kind } = inputData;
    const job = await getJob(threadId);
    const pending = job?.state?.pendingPlugin;
    if (!pending?.sourceMap) {
      return { ok: false, error: "No source map available. Call getSourceMap first." };
    }
    const matches = pending.sourceMap.symbols.filter((s) => {
      if (s.name !== name) return false;
      if (kind && s.kind !== kind) return false;
      return true;
    });
    return {
      ok: true,
      matches,
      count: matches.length
    };
  }
});
const listSymbolsTool = createTool({
  id: "list-symbols",
  description: "List all symbols across all plugin files. Returns name + file + line range + kind. Use this for discovery before findSymbol when you only have a partial idea of the name.",
  inputSchema: z.object({
    threadId: z.string(),
    file: z.string().optional().describe("Restrict to one file"),
    kind: z.enum(["function", "const", "type", "interface", "default"]).optional()
  }),
  execute: async (inputData) => {
    const { threadId, file, kind } = inputData;
    const job = await getJob(threadId);
    const pending = job?.state?.pendingPlugin;
    if (!pending?.sourceMap) {
      return { ok: false, error: "No source map available. Call getSourceMap first." };
    }
    const matches = pending.sourceMap.symbols.filter((s) => {
      if (file && s.file !== file) return false;
      if (kind && s.kind !== kind) return false;
      return true;
    });
    return { ok: true, symbols: matches, count: matches.length };
  }
});
const readLinesTool = createTool({
  id: "read-lines",
  description: "Read a range of lines from a plugin file, with optional context padding. Use this when getSourceMap or findSymbol told you the line range and you only need that range \u2014 do NOT pull the whole file with readModule. Lines are 1-indexed and inclusive on both ends. Context adds N lines before startLine and after endLine.",
  inputSchema: z.object({
    threadId: z.string(),
    file: z.string(),
    startLine: z.number().int().min(1),
    endLine: z.number().int().min(1),
    context: z.number().int().min(0).max(20).optional().default(0).describe("Extra lines of padding before and after the range")
  }),
  execute: async (inputData) => {
    const { threadId, file, startLine, endLine, context } = inputData;
    if (endLine < startLine) {
      return { ok: false, error: "endLine must be >= startLine" };
    }
    const job = await getJob(threadId);
    const pending = job?.state?.pendingPlugin;
    if (!pending) {
      return { ok: false, error: "No pending plugin found." };
    }
    const modules = getModules(pending);
    const code = modules[file];
    if (!code) {
      return { ok: false, error: `File "${file}" not found. Available: ${Object.keys(modules).join(", ")}` };
    }
    const lines = code.split("\n");
    const totalLines = lines.length;
    const padStart = Math.max(1, startLine - context);
    const padEnd = Math.min(totalLines, endLine + context);
    const selected = lines.slice(padStart - 1, padEnd).map((line, i) => ({
      line: padStart + i,
      text: line
    }));
    return {
      ok: true,
      file,
      startLine: padStart,
      endLine: padEnd,
      totalLines,
      lines: selected
    };
  }
});
const searchInFileTool = createTool({
  id: "search-in-file",
  description: "Search for a pattern inside ONE file. Pattern is a regex string. Returns matching lines with N lines of context before/after. Use this when you need to find every place a particular identifier or pattern appears in one file.",
  inputSchema: z.object({
    threadId: z.string(),
    file: z.string(),
    pattern: z.string().describe('JavaScript regex pattern (e.g. "useEffect\\(", "data\\.players")'),
    contextLines: z.number().int().min(0).max(10).optional().default(2)
  }),
  execute: async (inputData) => {
    const { threadId, file, pattern, contextLines } = inputData;
    const job = await getJob(threadId);
    const pending = job?.state?.pendingPlugin;
    if (!pending) {
      return { ok: false, error: "No pending plugin found." };
    }
    const modules = getModules(pending);
    const code = modules[file];
    if (!code) {
      return { ok: false, error: `File "${file}" not found. Available: ${Object.keys(modules).join(", ")}` };
    }
    let regex;
    try {
      regex = new RegExp(pattern);
    } catch (e) {
      return { ok: false, error: `Invalid regex pattern: ${e?.message}` };
    }
    const lines = code.split("\n");
    const matches = [];
    for (let i = 0; i < lines.length; i++) {
      if (regex.test(lines[i])) {
        const before = lines.slice(Math.max(0, i - contextLines), i);
        const after = lines.slice(i + 1, Math.min(lines.length, i + 1 + contextLines));
        matches.push({ line: i + 1, lineText: lines[i], before, after });
      }
      regex.lastIndex = 0;
    }
    return { ok: true, file, pattern, matches, count: matches.length };
  }
});
const grepPluginTool = createTool({
  id: "grep-plugin",
  description: 'Cross-file search across the entire plugin. Pattern is a regex string. filePattern (optional) restricts to file paths matching a glob (e.g. "features/**"). Use this when you need every file:line that reads data.players, calls useEffect, or references a specific identifier.',
  inputSchema: z.object({
    threadId: z.string(),
    pattern: z.string(),
    filePattern: z.string().optional().describe('Glob filter for file paths, e.g. "features/**" or "*.tsx"'),
    contextLines: z.number().int().min(0).max(5).optional().default(0)
  }),
  execute: async (inputData) => {
    const { threadId, pattern, filePattern, contextLines } = inputData;
    const job = await getJob(threadId);
    const pending = job?.state?.pendingPlugin;
    if (!pending) {
      return { ok: false, error: "No pending plugin found." };
    }
    let regex;
    try {
      regex = new RegExp(pattern);
    } catch (e) {
      return { ok: false, error: `Invalid regex pattern: ${e?.message}` };
    }
    let globRegex = null;
    if (filePattern) {
      const re = filePattern.replace(/\./g, "\\.").replace(/\*\*/g, "{{DOUBLE_STAR}}").replace(/\*/g, "[^/]*").replace(/\{\{DOUBLE_STAR\}\}/g, ".*");
      globRegex = new RegExp(`^${re}$`);
    }
    const modules = getModules(pending);
    const matches = [];
    for (const [file, code] of Object.entries(modules)) {
      if (globRegex && !globRegex.test(file)) continue;
      const lines = code.split("\n");
      for (let i = 0; i < lines.length; i++) {
        if (regex.test(lines[i])) {
          const before = lines.slice(Math.max(0, i - contextLines), i);
          const after = lines.slice(i + 1, Math.min(lines.length, i + 1 + contextLines));
          matches.push({ file, line: i + 1, lineText: lines[i], before, after });
        }
        regex.lastIndex = 0;
      }
    }
    return { ok: true, pattern, matches, count: matches.length };
  }
});
const findDataFieldUsagesTool = createTool({
  id: "find-data-field-usages",
  description: "Find every file:line that reads data.<field> for a given schema field name. CRITICAL for safe schema edits \u2014 call this BEFORE editing or renaming a schema field, so you know which code sites need to change in lockstep.",
  inputSchema: z.object({
    threadId: z.string(),
    field: z.string().describe('Schema field name (without data. prefix), e.g. "players" or "title"')
  }),
  execute: async (inputData) => {
    const { threadId, field } = inputData;
    const job = await getJob(threadId);
    const pending = job?.state?.pendingPlugin;
    if (!pending?.sourceMap) {
      return { ok: false, error: "No source map available. Call getSourceMap first." };
    }
    const usages = pending.sourceMap.dataFieldUsages.filter((u) => u.field === field);
    const byFile = {};
    for (const u of usages) {
      if (!byFile[u.file]) byFile[u.file] = [];
      byFile[u.file].push({ line: u.line, path: u.path, lineText: u.lineText });
    }
    return {
      ok: true,
      field,
      usages,
      byFile,
      count: usages.length,
      hint: usages.length === 0 ? `No code reads data.${field}. Safe to remove from schema.` : `data.${field} is read at ${usages.length} site(s). Update them in lockstep if you rename/remove the field.`
    };
  }
});
const findAnchorTool = createTool({
  id: "find-anchor",
  description: 'Find the symbol + line range that best matches a natural-language intent. Use this as the PRIMARY anchor-finding tool when you know WHAT you want to edit (semantically) but not WHERE it is or what it is named. Examples: intent="the spring config for the hero enter animation" \u2192 returns the symbol + line range. intent="where the score gets flashed" \u2192 returns the symbol + line range. Backed by AST extraction (covers both exported AND internal/non-exported symbols) + per-symbol semantic summaries (reads, calls, Remotion APIs) + tokenized keyword matching. No embeddings. Returns top-K matches with scores; pick the best one, call readLines to verify, then editLines to make the change. If no matches, call listSymbols to see every available symbol and refine your intent.',
  inputSchema: z.object({
    threadId: z.string(),
    intent: z.string().describe('Natural-language description of what you want to find, e.g. "where the score gets flashed" or "the MapLibre camera setup"'),
    file: z.string().optional().describe("Restrict search to one file path"),
    topK: z.number().int().min(1).max(10).optional().default(3).describe("How many top matches to return"),
    minScore: z.number().min(0).max(1).optional().default(0.15).describe("Minimum match score (0..1). Below this, matches are filtered out.")
  }),
  execute: async (inputData) => {
    const { threadId, intent, file, topK, minScore } = inputData;
    const job = await getJob(threadId);
    const pending = job?.state?.pendingPlugin;
    if (!pending?.sourceMap) {
      return { ok: false, error: "No source map available. Call getSourceMap first." };
    }
    const intentTokens = tokenize(intent);
    if (intentTokens.length === 0) {
      return {
        ok: false,
        error: "Intent produced no searchable tokens (all stop words or too short). Be more specific \u2014 include the symbol's purpose, what data it reads, or what Remotion APIs it uses.",
        intent
      };
    }
    const candidates = [];
    for (const symbol of pending.sourceMap.symbols) {
      if (file && symbol.file !== file) continue;
      const score = scoreIntentMatch(intentTokens, symbol);
      if (score >= minScore) {
        candidates.push({ symbol, score });
      }
    }
    candidates.sort((a, b) => b.score - a.score);
    const top = candidates.slice(0, topK);
    if (top.length === 0) {
      return {
        ok: true,
        intent,
        intentTokens,
        matches: [],
        count: 0,
        hint: "No symbols matched. Try different keywords, or call listSymbols to see all available symbols."
      };
    }
    return {
      ok: true,
      intent,
      intentTokens,
      matches: top.map((c) => ({
        name: c.symbol.name,
        kind: c.symbol.kind,
        exported: c.symbol.exported,
        file: c.symbol.file,
        lines: c.symbol.lines,
        summary: c.symbol.summary,
        reads: c.symbol.reads,
        calls: c.symbol.calls,
        score: Number(c.score.toFixed(3))
      })),
      count: top.length,
      hint: `Call readLines({ file: "${top[0].symbol.file}", startLine: ${top[0].symbol.lines[0]}, endLine: ${top[0].symbol.lines[1]} }) to verify, then editLines to make the change.`
    };
  }
});
async function applyLineEdit(args) {
  const { threadId, file, startLine, endLine, newLines, description } = args;
  if (startLine < 1 || endLine < startLine) {
    return { ok: false, error: `Invalid line range: startLine=${startLine}, endLine=${endLine}` };
  }
  const job = await getJob(threadId);
  const pending = job?.state?.pendingPlugin;
  if (!pending) {
    return { ok: false, error: "No pending plugin found." };
  }
  const isMulti = pending.modules && Object.keys(pending.modules).length > 1;
  const modules = getModules(pending);
  const code = modules[file];
  if (!code) {
    return {
      ok: false,
      error: `File "${file}" not found. Available: ${isMulti ? Object.keys(modules).join(", ") : "Scene.tsx (single-file mode)"}`
    };
  }
  const lines = code.split("\n");
  const totalLines = lines.length;
  if (endLine > totalLines) {
    return { ok: false, error: `endLine ${endLine} exceeds file length ${totalLines}.` };
  }
  const before = lines.slice(0, startLine - 1);
  const after = lines.slice(endLine);
  const updatedLines = [...before, ...newLines, ...after];
  const updatedCode = updatedLines.join("\n");
  const candidateModules = isMulti ? { ...modules, [file]: updatedCode } : { "Scene.tsx": updatedCode };
  const sourceCheck = validatePluginSource(candidateModules);
  if (!sourceCheck.ok) {
    const formatted = formatPluginSourceIssues(sourceCheck.issues);
    return {
      ok: false,
      error: `Edit would leave invalid plugin source:
${formatted}`,
      hint: "Use the Scene animation prop directly. Do not read animation from data or schema fields."
    };
  }
  const candidatePending = isMulti && pending.modules?.[file] ? { ...pending, modules: candidateModules, sceneCode: candidateModules["Scene.tsx"] ?? pending.sceneCode, ast: deriveAST(candidateModules) } : { ...pending, sceneCode: updatedCode, ast: deriveAST({ "Scene.tsx": updatedCode }) };
  const refreshed = refreshSourceMap(candidatePending);
  const guard = validatePluginRunState(refreshed.pending);
  const hasCriticalErrors = guard.missingRequirements.length > 0 || guard.importIssues.length > 0;
  if (hasCriticalErrors) {
    return {
      ok: false,
      error: `Edit blocked by plugin guard:
${formatGuardFailure$1(guard)}`,
      missingRequirements: guard.missingRequirements,
      importIssues: guard.importIssues,
      warnings: guard.warnings,
      hint: "Make a smaller patch that preserves hard requirements and resolves every local import."
    };
  }
  const nextPending = appendPluginLedgerEvent(withCurrentSourceHash$1(refreshed.pending), {
    type: "edit",
    filePath: file,
    summary: `${description} (lines ${startLine}-${endLine} \u2192 ${newLines.length} line(s))`,
    changedChars: updatedCode.length - code.length,
    warnings: guard.warnings
  });
  await patchJobState(threadId, (s) => ({ ...s, pendingPlugin: nextPending }));
  const linesDelta = newLines.length - (endLine - startLine + 1);
  console.log(`[line-edit] \u2705 ${file} ${startLine}-${endLine} \u2192 ${newLines.length} line(s) (\u0394${linesDelta >= 0 ? "+" : ""}${linesDelta}) for thread ${threadId.slice(0, 8)}`);
  return {
    ok: true,
    result: {
      file,
      replacedRange: { startLine, endLine },
      newRange: { startLine, endLine: startLine + newLines.length - 1 },
      linesDelta,
      warnings: guard.warnings,
      sourceMapDiff: refreshed.diff,
      message: `${file} updated.`
    }
  };
}
const editLinesTool = createTool({
  id: "edit-lines",
  description: "Replace a range of lines in a plugin file with new content. Deterministic \u2014 no string matching, no uniqueness requirement. Use this as the DEFAULT edit tool. Always call getSourceMap/readLines first to know the exact line range. Lines are 1-indexed and inclusive on both ends. newLines replaces lines startLine..endLine verbatim.",
  inputSchema: z.object({
    threadId: z.string(),
    file: z.string(),
    startLine: z.number().int().min(1),
    endLine: z.number().int().min(1),
    newLines: z.array(z.string()).describe("New content (array of lines, no trailing newline). Pass [] to delete the range.")
  }),
  execute: async (inputData) => {
    const result = await applyLineEdit({
      threadId: inputData.threadId,
      file: inputData.file,
      startLine: inputData.startLine,
      endLine: inputData.endLine,
      newLines: inputData.newLines,
      description: "editLines"
    });
    if (!result.ok) return result;
    return { ok: true, ...result.result };
  }
});
const insertAtTool = createTool({
  id: "insert-at",
  description: "Insert new content AFTER a given line in a plugin file. Use this to add a new function, a new export, a new import, etc. \u2014 without needing to anchor on existing text. Pass afterLine=0 to insert at the top of the file.",
  inputSchema: z.object({
    threadId: z.string(),
    file: z.string(),
    afterLine: z.number().int().min(0).describe("Insert AFTER this line. Use 0 to insert at the top of the file."),
    content: z.string().describe("Content to insert (may be multi-line \u2014 use \\n)")
  }),
  execute: async (inputData) => {
    const { threadId, file, afterLine, content } = inputData;
    const newLines = content.split("\n");
    const result = await applyLineEdit({
      threadId,
      file,
      startLine: afterLine + 1,
      endLine: afterLine,
      newLines,
      description: `insertAt(afterLine=${afterLine})`
    });
    if (!result.ok) return result;
    return { ok: true, ...result.result };
  }
});
const deleteLinesTool = createTool({
  id: "delete-lines",
  description: "Delete a range of lines from a plugin file. Equivalent to editLines with newLines=[]. Use this for removing dead code, unused imports, or stale helpers.",
  inputSchema: z.object({
    threadId: z.string(),
    file: z.string(),
    startLine: z.number().int().min(1),
    endLine: z.number().int().min(1)
  }),
  execute: async (inputData) => {
    const result = await applyLineEdit({
      threadId: inputData.threadId,
      file: inputData.file,
      startLine: inputData.startLine,
      endLine: inputData.endLine,
      newLines: [],
      description: "deleteLines"
    });
    if (!result.ok) return result;
    return { ok: true, ...result.result };
  }
});
const previewEditTool = createTool({
  id: "preview-edit",
  description: "Preview what an editLines / insertAt / deleteLines call WOULD do, without committing it. Returns a unified diff plus a validation flag (would the resulting code pass source validation + guard?). Use this for risky changes \u2014 verify intent before mutating state.",
  inputSchema: z.object({
    threadId: z.string(),
    file: z.string(),
    startLine: z.number().int().min(1),
    endLine: z.number().int().min(1),
    newLines: z.array(z.string())
  }),
  execute: async (inputData) => {
    const { threadId, file, startLine, endLine, newLines } = inputData;
    const job = await getJob(threadId);
    const pending = job?.state?.pendingPlugin;
    if (!pending) {
      return { ok: false, error: "No pending plugin found." };
    }
    const modules = getModules(pending);
    const code = modules[file];
    if (!code) {
      return { ok: false, error: `File "${file}" not found.` };
    }
    const lines = code.split("\n");
    if (endLine > lines.length) {
      return { ok: false, error: `endLine ${endLine} exceeds file length ${lines.length}.` };
    }
    const before = lines.slice(0, startLine - 1);
    const after = lines.slice(endLine);
    const updatedLines = [...before, ...newLines, ...after];
    const updatedCode = updatedLines.join("\n");
    const diff = [];
    diff.push(`--- a/${file}`);
    diff.push(`+++ b/${file}`);
    const oldRange = lines.slice(startLine - 1, endLine);
    diff.push(`@@ -${startLine},${oldRange.length} +${startLine},${newLines.length} @@`);
    for (const line of oldRange) diff.push(`-${line}`);
    for (const line of newLines) diff.push(`+${line}`);
    const isMulti = pending.modules && Object.keys(pending.modules).length > 1;
    const candidateModules = isMulti ? { ...modules, [file]: updatedCode } : { "Scene.tsx": updatedCode };
    const sourceCheck = validatePluginSource(candidateModules);
    const candidatePending = isMulti && pending.modules?.[file] ? { ...pending, modules: candidateModules, sceneCode: candidateModules["Scene.tsx"] ?? pending.sceneCode } : { ...pending, sceneCode: updatedCode };
    const refreshed = refreshSourceMap(candidatePending);
    const guard = validatePluginRunState(refreshed.pending);
    return {
      ok: true,
      diff: diff.join("\n"),
      wouldPassValidation: sourceCheck.ok && guard.ok,
      sourceValidation: sourceCheck.ok ? { ok: true } : { ok: false, issues: sourceCheck.issues.map((i) => `${i.file}:${i.line} ${i.message}`) },
      guard: {
        ok: guard.ok,
        missingRequirements: guard.missingRequirements,
        importIssues: guard.importIssues,
        visualIssues: guard.visualIssues,
        warnings: guard.warnings
      },
      hint: sourceCheck.ok && guard.ok ? "Safe to apply. Call editLines with the same args to commit." : "Edit would fail validation. Adjust the new content or fix the underlying issue first."
    };
  }
});
const sourceMapTools = {
  getSourceMap: getSourceMapTool,
  setFileRole: setFileRoleTool,
  findAnchor: findAnchorTool,
  // ← NEW: semantic grep by intent
  findSymbol: findSymbolTool,
  listSymbols: listSymbolsTool,
  readLines: readLinesTool,
  searchInFile: searchInFileTool,
  grepPlugin: grepPluginTool,
  findDataFieldUsages: findDataFieldUsagesTool,
  editLines: editLinesTool,
  insertAt: insertAtTool,
  deleteLines: deleteLinesTool,
  previewEdit: previewEditTool
};

const recordPlanDeviationTool = createTool({
  id: "record-plan-deviation",
  description: "Record that a step's hypothesis did NOT hold, and how the plan is adapting. Call this BEFORE routing a repair step or replanning. The deviation ledger is the system's audit trail \u2014 repeated deviations on the same step signal that a global replan is needed instead of another local repair. Do NOT skip this even if the fix is obvious \u2014 the audit trail matters more than the saved token.",
  inputSchema: z.object({
    threadId: z.string(),
    stepId: z.string(),
    expected: z.string().describe('What you expected to happen, e.g. "compilePreview would pass because the only change was a color value"'),
    actual: z.string().describe('What actually happened, e.g. "compilePreview failed: data.animation is reserved at Scene.tsx:42"'),
    reason: z.string().describe('Why the hypothesis was wrong, e.g. "I assumed the coder would use props.animation, but it read data.animation instead"'),
    resolution: z.enum(["local_repair", "global_replan", "abort", "continue"]).describe("How the plan adapts"),
    nextStepId: z.string().nullable().optional().describe("Next step id the orchestrator will route to. Null if aborting.")
  }),
  execute: async (inputData) => {
    const { threadId, stepId, expected, actual, reason, resolution, nextStepId } = inputData;
    const deviation = {
      stepId,
      expected,
      actual,
      reason,
      resolution,
      nextStepId: nextStepId ?? null,
      recordedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    let deviationCount = 0;
    let updatedExecution = null;
    await patchJobState(threadId, (state) => {
      const existingExecution = state.pluginExecution ?? state.pendingPlugin?.runLedger?.execution;
      if (!existingExecution) return state;
      const deviations = [...existingExecution.deviations ?? [], deviation];
      deviationCount = deviations.filter((d) => d.stepId === stepId).length;
      updatedExecution = { ...existingExecution, deviations, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
      let pendingPlugin = state.pendingPlugin;
      if (pendingPlugin?.runLedger) {
        const now = (/* @__PURE__ */ new Date()).toISOString();
        pendingPlugin = {
          ...pendingPlugin,
          runLedger: {
            ...pendingPlugin.runLedger,
            execution: updatedExecution,
            events: [
              ...pendingPlugin.runLedger.events.slice(-24),
              {
                type: "feedback",
                summary: `Deviation on ${stepId} (#${deviationCount} for this step): ${reason}. Resolution: ${resolution}${nextStepId ? ` \u2192 ${nextStepId}` : ""}.`,
                errors: [actual],
                at: now
              }
            ],
            updatedAt: now
          }
        };
      }
      return { ...state, pluginExecution: updatedExecution, pendingPlugin };
    });
    return {
      ok: true,
      deviation,
      deviationCountForStep: deviationCount,
      hint: deviationCount >= 3 ? `Step ${stepId} has deviated ${deviationCount} times. Consider global replan instead of another local repair.` : void 0
    };
  }
});

const loadForkedPluginSourceTool = createTool({
  id: "load-forked-plugin-source",
  description: 'Load the source code of an existing plugin into the current pendingPlugin state so you can modify it instead of creating from scratch. Use this when you are in mode "create" but a forkPluginId is provided.',
  inputSchema: z.object({
    threadId: z.string(),
    pluginId: z.string(),
    forkPluginId: z.string()
  }),
  execute: async ({ context }) => {
    const { threadId, pluginId, forkPluginId } = context;
    const sourceS3Key = `plugins/${forkPluginId}/source.json`;
    let sourceJson;
    try {
      const url = await getSignedS3Url(sourceS3Key, 60);
      const res = await fetch(url);
      if (!res.ok) {
        throw new Error(`Failed to fetch source: ${res.statusText}`);
      }
      sourceJson = await res.json();
    } catch (e) {
      console.error(`[load-forked-plugin-source] Failed to fetch source for ${forkPluginId}:`, e.message);
      return {
        ok: false,
        error: "Source code not available for this plugin. Only plugins created after the source code update can be remixed."
      };
    }
    const result = await db$1.query("SELECT name, schema_json FROM plugins WHERE id = $1", [forkPluginId]);
    const pluginName = result.rows[0]?.name || forkPluginId;
    const schemaJson = result.rows[0]?.schema_json || "{}";
    const { sceneCode, modules, dependencies } = sourceJson;
    const pendingPlugin = {
      pluginId,
      pluginName: pluginName.startsWith("Copy of ") ? pluginName : `Copy of ${pluginName}`,
      sceneCode: sceneCode || "",
      modules: modules || null,
      schemaJson: schemaJson,
      dependencies: dependencies || {},
      runLedger: createPluginRunLedger()
    };
    const ast = modules ? deriveAST(modules) : deriveAST({ "Scene.tsx": sceneCode });
    await patchJobState(threadId, (s) => ({
      ...s,
      pendingPlugin: { ...pendingPlugin, ast }
    }));
    return {
      ok: true,
      message: "Successfully loaded forked plugin source into pendingPlugin state. You can now use getSourceMap and proceed as if in modify mode."
    };
  }
});

function formatGuardFailure(guard) {
  const parts = [];
  if (guard.missingRequirements.length > 0) {
    parts.push(`Missing hard requirement(s): ${guard.missingRequirements.join("; ")}`);
  }
  if (guard.importIssues.length > 0) {
    parts.push(`Import issue(s): ${guard.importIssues.map((issue) => `${issue.file} imports ${issue.specifier}: ${issue.message}`).join("; ")}`);
  }
  if (guard.visualIssues.length > 0) {
    parts.push(`Visual issue(s): ${guard.visualIssues.map((issue) => `${issue.file}: ${issue.message}`).join("; ")}`);
  }
  return parts.join("\n");
}
function stableStringify$1(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map((item) => stableStringify$1(item)).join(",")}]`;
  const entries = Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => `${JSON.stringify(key)}:${stableStringify$1(item)}`);
  return `{${entries.join(",")}}`;
}
function currentPluginSourcePayload(pending) {
  return {
    sceneCode: pending.sceneCode ?? "",
    modules: pending.modules ?? null,
    schemaJson: pending.schemaJson ?? "",
    dependencies: pending.dependencies ?? {}
  };
}
function computePluginSourceHash(pending) {
  return createHash("sha256").update(stableStringify$1(currentPluginSourcePayload(pending))).digest("hex").slice(0, 16);
}
function withCurrentSourceHash(pending) {
  return {
    ...pending,
    sourceHash: computePluginSourceHash(pending)
  };
}
function validateSchemaShape(schemaJson) {
  let parsed;
  try {
    parsed = JSON.parse(schemaJson);
  } catch (e) {
    return { ok: false, issues: [`Schema is not valid JSON: ${e?.message}`], warnings: [] };
  }
  const issues = [];
  const warnings = [];
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    issues.push("Schema root must be an object.");
    return { ok: false, issues, warnings };
  }
  if (!parsed.properties || typeof parsed.properties !== "object") {
    issues.push('Schema must have a "properties" object at the root.');
    return { ok: false, issues, warnings };
  }
  const fieldNames = Object.keys(parsed.properties);
  if (fieldNames.length === 0) {
    issues.push('Schema "properties" is empty \u2014 at least one field is required.');
  }
  const reservedFieldCheck = validatePluginSchemaReservedFields(parsed);
  if (!reservedFieldCheck.ok) {
    issues.push(...reservedFieldCheck.issues.map((issue) => issue.message));
  }
  for (const [name, def] of Object.entries(parsed.properties)) {
    if (def?.editor === "image" && !/(?:Url|Image|image)$/.test(name)) {
      warnings.push(`Image field "${name}" should end in "Url", "Image", or follow the imageUrl/bgImageUrl naming convention.`);
    }
  }
  if (issues.length > 0) return { ok: false, issues, warnings };
  return { ok: true, fieldNames, warnings };
}
const workCategorySchema = z.enum(["core_remotion_logic", "glue_code", "validation"]);
const stepStatusSchema = z.enum(["pending", "in_progress", "done", "blocked"]);
const recordPluginPlanTool = createTool({
  id: "record-plugin-plan",
  description: "Register the sequential execution plan and frozen contracts for a plugin run. Call this BEFORE code generation. Use core_remotion_logic for hard Remotion/motion work and glue_code for schema/import/data wiring. RECON GATE: in modify mode, this tool REJECTS if no getSourceMap call has been recorded recently. Always call getSourceMap first in modify mode. REASON+ACT: each step should include hypothesis (what you expect to happen and why), evidence (source-map symbols / line ranges / ledger events supporting the hypothesis), and failureMode (what it probably means if the hypothesis is wrong). This makes the audit trail useful.",
  inputSchema: z.object({
    threadId: z.string(),
    pluginId: z.string(),
    mode: z.enum(["create", "modify"]).default("create"),
    frozenContracts: z.object({
      schemaPaths: z.array(z.string()).default([]),
      files: z.array(z.string()).default([]),
      dependencies: z.record(z.string(), z.string()).default({}),
      generationFields: z.array(z.string()).default([]),
      notes: z.array(z.string()).optional()
    }),
    steps: z.array(z.object({
      id: z.string(),
      title: z.string(),
      category: workCategorySchema,
      owner: z.enum(["orchestrator", "schema_agent", "remotion_coder", "dependency_agent", "validator"]),
      goal: z.string(),
      files: z.array(z.string()).default([]),
      hypothesis: z.string().optional().describe('What you expect to happen and why, e.g. "editing useSpringIn will fix the blank enter phase because the spring config currently produces NaN"'),
      evidence: z.array(z.string()).optional().describe("Source-map symbols / line ranges / ledger events supporting the hypothesis"),
      failureMode: z.string().optional().describe("If this does not fix it, the real cause is probably..."),
      dependsOn: z.array(z.string()).optional().describe("Step ids this step depends on (for future parallel execution)")
    })).min(1)
  }),
  execute: async (inputData) => {
    const job = await getJob(inputData.threadId);
    const state = job?.state;
    const hasExistingPlugin = inputData.mode === "modify" || !!state?.pendingPlugin;
    if (hasExistingPlugin) {
      const lastReconAt = state?.pendingPlugin?.lastReconAt ?? state?.pluginExecution?.lastReconAt ?? null;
      const reconStale = !lastReconAt || Date.now() - new Date(lastReconAt).getTime() > 5 * 60 * 1e3;
      if (reconStale) {
        return {
          ok: false,
          error: "Recon gate: modifying an existing plugin requires a recent getSourceMap call. Call getSourceMap({ threadId }) first, then re-issue recordPluginPlan.",
          lastReconAt,
          requiredAction: "getSourceMap"
        };
      }
      const overallHash = state?.pendingPlugin?.sourceMap?.overallHash ?? null;
      inputData.frozenContracts.notes = [...inputData.frozenContracts.notes ?? [], `reconOverallHash=${overallHash ?? "unknown"}`];
    }
    const execution = createPluginExecutionState({
      pluginId: inputData.pluginId,
      mode: inputData.mode,
      frozenContracts: inputData.frozenContracts,
      steps: inputData.steps,
      lastReconAt: hasExistingPlugin ? state?.pendingPlugin?.lastReconAt ?? null : null,
      lastReconOverallHash: hasExistingPlugin ? state?.pendingPlugin?.sourceMap?.overallHash ?? null : null
    });
    await patchJobState(inputData.threadId, (state2) => {
      const pendingPlugin = state2.pendingPlugin ? attachPluginExecutionState(state2.pendingPlugin, execution) : state2.pendingPlugin;
      return { ...state2, pluginExecution: execution, pendingPlugin };
    });
    return {
      ok: true,
      execution,
      summary: summarizePluginExecution(execution),
      message: `Registered ${execution.steps.length} sequential plugin step(s) with hypothesis/evidence/failureMode.`
    };
  }
});
const updatePluginStepTool = createTool({
  id: "update-plugin-step",
  description: "Update one execution-plan step in the plugin ledger. Call this before starting a step and after completing/blocking it. Use issues to distinguish core_remotion_logic failures from glue_code failures.",
  inputSchema: z.object({
    threadId: z.string(),
    stepId: z.string(),
    status: stepStatusSchema,
    summary: z.string().optional(),
    issues: z.array(z.object({
      type: z.string(),
      area: workCategorySchema,
      detail: z.string(),
      fixed: z.boolean().optional()
    })).optional()
  }),
  execute: async (inputData) => {
    let updatedExecution = null;
    await patchJobState(inputData.threadId, (state) => {
      const existingExecution = state.pluginExecution ?? state.pendingPlugin?.runLedger?.execution;
      if (!existingExecution) return state;
      updatedExecution = updatePluginExecutionStep(existingExecution, {
        stepId: inputData.stepId,
        status: inputData.status,
        summary: inputData.summary,
        issues: inputData.issues
      });
      let pendingPlugin = state.pendingPlugin;
      if (pendingPlugin?.runLedger) {
        const now = (/* @__PURE__ */ new Date()).toISOString();
        pendingPlugin = {
          ...pendingPlugin,
          runLedger: {
            ...pendingPlugin.runLedger,
            execution: updatedExecution,
            events: [
              ...pendingPlugin.runLedger.events.slice(-24),
              {
                type: "step",
                summary: `${inputData.stepId} -> ${inputData.status}${inputData.summary ? `: ${inputData.summary}` : ""}`,
                errors: inputData.issues?.filter((issue) => !issue.fixed).map((issue) => issue.detail),
                at: now
              }
            ],
            updatedAt: now
          }
        };
      }
      return { ...state, pluginExecution: updatedExecution, pendingPlugin };
    });
    if (!updatedExecution) {
      return { ok: false, error: "No plugin execution plan found. Call recordPluginPlan first." };
    }
    return {
      ok: true,
      execution: updatedExecution,
      summary: summarizePluginExecution(updatedExecution)
    };
  }
});
const setInitialSceneTool = createTool({
  id: "set-initial-scene",
  description: "Emit the initial schema and Scene.tsx for a new plugin. Call this exactly ONCE at the start of a CREATE flow. For single-file mode, pass sceneCode. For multi-file mode, pass modules (Record<string, string> mapping file paths to code, must include Scene.tsx). Returns { ok, fieldNames } or { ok: false, issues } if the schema is malformed. After this succeeds, call compilePreview to verify the code bundles.",
  inputSchema: z.object({
    threadId: z.string(),
    pluginId: z.string(),
    pluginName: z.string(),
    description: z.string(),
    schemaJson: z.string().describe('Full JSON Schema (draft-07) \u2014 must have root "properties" and root "defaults". Skygen editor seeds pluginData from schema.defaults. Do not rely only on properties.<field>.default.'),
    sceneCode: z.string().optional().describe("Full Scene.tsx source code (single-file mode)"),
    modules: z.record(z.string(), z.string()).optional().describe('Multi-file mode: map of file paths to code. Must include "Scene.tsx". E.g. { "Scene.tsx": "...", "animations.ts": "...", "theme.ts": "..." }'),
    dependencies: z.record(z.string(), z.string()).optional().describe('npm packages the scene imports (e.g. { "recharts": "^2.15.4" })'),
    userId: z.string().nullable().optional()
  }),
  execute: async (inputData) => {
    const { threadId, pluginId, pluginName, description, schemaJson, sceneCode, modules, dependencies, userId } = inputData;
    const hasModules = modules && Object.keys(modules).length > 0;
    const hasSceneCode = !!sceneCode;
    if (!hasModules && !hasSceneCode) {
      return { ok: false, issues: ["Must provide either sceneCode or modules."], error: "No code provided." };
    }
    const schemaCheck = validateSchemaShape(schemaJson);
    if (!schemaCheck.ok) {
      console.log(`[set-initial-scene] \u274C schema invalid for thread ${threadId.slice(0, 8)}: ${schemaCheck.issues[0]}`);
      return {
        ok: false,
        issues: schemaCheck.issues,
        error: `Schema invalid: ${schemaCheck.issues.join("; ")}`
      };
    }
    const depPolicy = normalizePluginDependencies(dependencies);
    const cleanDeps = depPolicy.dependencies;
    const depPolicyWarnings = formatDependencyPolicyChanges(depPolicy);
    for (const message of depPolicyWarnings) {
      console.warn(`[set-initial-scene] ${message}`);
    }
    let effectiveModules;
    if (hasModules) {
      effectiveModules = modules;
    } else {
      effectiveModules = { "Scene.tsx": sceneCode };
    }
    const sourceCheck = validatePluginSource(effectiveModules);
    if (!sourceCheck.ok) {
      const formatted = formatPluginSourceIssues(sourceCheck.issues);
      console.log(`[set-initial-scene] source invalid for thread ${threadId.slice(0, 8)}: ${formatted.split("\n")[0]}`);
      return {
        ok: false,
        issues: sourceCheck.issues.map((issue) => `${issue.file}:${issue.line} ${issue.message}`),
        error: `Plugin source failed validation:
${formatted}`,
        hint: "Fix the Scene props/data boundary. animation, theme, and motionProfile are host props, not data fields."
      };
    }
    const ast = deriveAST(effectiveModules);
    let pendingPlugin = {
      pluginId,
      pluginName,
      description,
      sceneCode: effectiveModules["Scene.tsx"] ?? sceneCode ?? "",
      modules: isMultiFile(effectiveModules) ? effectiveModules : void 0,
      schemaJson,
      dependencies: cleanDeps,
      userId,
      ast
    };
    const existingJob = await getJob(threadId);
    const existingExecution = existingJob?.state?.pluginExecution ?? null;
    pendingPlugin.runLedger = createPluginRunLedger(pendingPlugin, `${pluginName}
${description}`);
    pendingPlugin = attachPluginExecutionState(pendingPlugin, existingExecution);
    const guard = validatePluginRunState(pendingPlugin);
    const hasCriticalErrors = guard.missingRequirements.length > 0 || guard.importIssues.length > 0;
    if (hasCriticalErrors) {
      return {
        ok: false,
        error: `Plugin guard failed before storing:
${formatGuardFailure(guard)}`,
        missingRequirements: guard.missingRequirements,
        importIssues: guard.importIssues,
        warnings: guard.warnings,
        hint: "If the user required a concept like MapLibre, implement it or report the dependency/build blocker. Do not silently replace it with a fallback."
      };
    }
    pendingPlugin = appendPluginLedgerEvent(withCurrentSourceHash(pendingPlugin), {
      type: "init",
      summary: `Stored ${Object.keys(effectiveModules).length} file(s), ${schemaCheck.fieldNames.length} schema field(s).`,
      warnings: [...depPolicyWarnings, ...guard.warnings]
    });
    await patchJobState(threadId, (current) => ({ ...current, pendingPlugin }));
    const fileCount = Object.keys(effectiveModules).length;
    console.log(`[set-initial-scene] \u2705 stored ${fileCount} files, ${schemaCheck.fieldNames.length} fields for thread ${threadId.slice(0, 8)}`);
    return {
      ok: true,
      fieldNames: schemaCheck.fieldNames,
      warnings: [...depPolicyWarnings, ...guard.warnings],
      dependencies: cleanDeps,
      guard: {
        hardRequirements: guard.hardRequirements.map((term) => term.id),
        files: guard.snapshot.files,
        dependencies: guard.snapshot.dependencies
      },
      message: `Stored. ${schemaCheck.fieldNames.length} schema fields, ${fileCount} file(s). Now call compilePreview to verify.`
    };
  }
});
const readSceneCodeTool = createTool({
  id: "read-scene-code",
  description: "Read the current Scene.tsx from job state. Returns the full source code as a string. Call this before editSceneCode so you know the exact text to match. For multi-file plugins, this returns the Scene.tsx entry file only \u2014 use readModule for other files.",
  inputSchema: z.object({
    threadId: z.string()
  }),
  execute: async (inputData) => {
    const job = await getJob(inputData.threadId);
    const pending = job?.state?.pendingPlugin;
    if (!pending?.sceneCode) {
      console.log(`[read-scene-code] \u274C no pendingPlugin for thread ${inputData.threadId.slice(0, 8)}`);
      return { ok: false, error: "No pending plugin found. Call setInitialScene first to create one." };
    }
    const sceneCode = pending.modules?.["Scene.tsx"] ?? pending.sceneCode;
    console.log(`[read-scene-code] \u2705 returned ${sceneCode.length} chars for thread ${inputData.threadId.slice(0, 8)}`);
    return { ok: true, sceneCode };
  }
});
const editSceneCodeTool = createTool({
  id: "edit-scene-code",
  description: "Surgically replace a block of code in Scene.tsx (or a specific file in multi-file mode via filePath). oldString must appear EXACTLY ONCE in the target file. Use the smallest unique block that contains your change. Call multiple times for multiple separate edits. Always call readSceneCode or readModule first to get the exact current text.",
  inputSchema: z.object({
    threadId: z.string(),
    oldString: z.string().describe("Exact code block to replace \u2014 must appear exactly once"),
    newString: z.string().describe("Replacement code"),
    filePath: z.string().optional().describe('For multi-file mode: which file to edit (e.g. "animations.ts", "theme.ts"). Defaults to "Scene.tsx".')
  }),
  execute: async (inputData) => {
    const { threadId, oldString, newString, filePath } = inputData;
    const targetFile = filePath ?? "Scene.tsx";
    const job = await getJob(threadId);
    const current = job?.state?.pendingPlugin;
    if (!current) {
      console.log(`[edit-scene-code] \u274C no pendingPlugin in job state for thread ${threadId.slice(0, 8)}`);
      return { ok: false, error: "No pending plugin found." };
    }
    let targetCode;
    const isMulti = current.modules && Object.keys(current.modules).length > 1;
    if (isMulti && current.modules?.[targetFile]) {
      targetCode = current.modules[targetFile];
    } else if (targetFile === "Scene.tsx") {
      targetCode = current.sceneCode;
    } else {
      return { ok: false, error: `File "${targetFile}" not found. Available files: ${isMulti ? Object.keys(current.modules).join(", ") : "Scene.tsx (single-file mode)"}` };
    }
    const occurrences = targetCode.split(oldString).length - 1;
    if (occurrences === 0) {
      console.log(`[edit-scene-code] \u274C oldString not found in ${targetFile} (${oldString.length} chars) for thread ${threadId.slice(0, 8)}`);
      return {
        ok: false,
        error: `oldString not found in ${targetFile}. Call readModule or readSceneCode and use an exact verbatim match (including whitespace).`
      };
    }
    if (occurrences > 1) {
      console.log(`[edit-scene-code] \u274C oldString appears ${occurrences} times in ${targetFile} for thread ${threadId.slice(0, 8)}`);
      return {
        ok: false,
        error: `oldString appears ${occurrences} times in ${targetFile} \u2014 it must be unique. Add more surrounding context to make it unique.`
      };
    }
    const updatedCode = targetCode.replace(oldString, newString);
    const candidateModules = isMulti ? { ...current.modules, [targetFile]: updatedCode } : { "Scene.tsx": updatedCode };
    const sourceCheck = validatePluginSource(candidateModules);
    if (!sourceCheck.ok) {
      const formatted = formatPluginSourceIssues(sourceCheck.issues);
      return {
        ok: false,
        error: `Edit would leave invalid plugin source:
${formatted}`,
        hint: "Use the Scene animation prop directly. Do not read animation from data or schema fields."
      };
    }
    const candidatePending = isMulti && current.modules?.[targetFile] ? { ...current, modules: candidateModules, sceneCode: candidateModules["Scene.tsx"] ?? current.sceneCode, ast: deriveAST(candidateModules) } : { ...current, sceneCode: updatedCode, ast: deriveAST({ "Scene.tsx": updatedCode }) };
    const guard = validatePluginRunState(candidatePending);
    const hasCriticalErrors = guard.missingRequirements.length > 0 || guard.importIssues.length > 0;
    if (hasCriticalErrors) {
      return {
        ok: false,
        error: `Edit blocked by plugin guard:
${formatGuardFailure(guard)}`,
        missingRequirements: guard.missingRequirements,
        importIssues: guard.importIssues,
        warnings: guard.warnings,
        hint: "Make a smaller patch that preserves hard requirements and resolves every local import."
      };
    }
    const nextPending = appendPluginLedgerEvent(withCurrentSourceHash(candidatePending), {
      type: "edit",
      filePath: targetFile,
      summary: `Replaced ${oldString.length} chars with ${newString.length} chars.`,
      changedChars: updatedCode.length - targetCode.length,
      warnings: guard.warnings
    });
    if (isMulti && current.modules?.[targetFile]) {
      await patchJobState(threadId, (s) => ({
        ...s,
        pendingPlugin: nextPending
      }));
    } else {
      await patchJobState(threadId, (s) => ({
        ...s,
        pendingPlugin: nextPending
      }));
    }
    const sizeDelta = updatedCode.length - targetCode.length;
    console.log(`[edit-scene-code] \u2705 replaced ${oldString.length}\u2192${newString.length} chars in ${targetFile} (\u0394${sizeDelta >= 0 ? "+" : ""}${sizeDelta}) for thread ${threadId.slice(0, 8)}`);
    return {
      ok: true,
      warnings: guard.warnings,
      guard: {
        hardRequirements: guard.hardRequirements.map((term) => term.id),
        files: guard.snapshot.files
      },
      message: `${targetFile} updated.`
    };
  }
});
const readSchemaTool = createTool({
  id: "read-schema",
  description: "Read the current schema JSON from job state. Use this when you need to add, rename, or remove fields.",
  inputSchema: z.object({
    threadId: z.string()
  }),
  execute: async (inputData) => {
    const job = await getJob(inputData.threadId);
    const schemaJson = job?.state?.pendingPlugin?.schemaJson ?? null;
    if (!schemaJson) {
      console.log(`[read-schema] \u274C no pendingPlugin for thread ${inputData.threadId.slice(0, 8)}`);
      return { ok: false, error: "No pending plugin found." };
    }
    console.log(`[read-schema] \u2705 returned ${schemaJson.length} chars for thread ${inputData.threadId.slice(0, 8)}`);
    return { ok: true, schemaJson };
  }
});
const editSchemaTool = createTool({
  id: "edit-schema",
  description: "Surgically replace a block in the schema JSON. Same uniqueness rules as editSceneCode. Use this when adding/renaming/removing fields. After editing the schema, you usually need to editSceneCode too so the scene reads the new field.",
  inputSchema: z.object({
    threadId: z.string(),
    oldString: z.string().describe("Exact text to replace \u2014 must appear exactly once"),
    newString: z.string().describe("Replacement text")
  }),
  execute: async (inputData) => {
    const { threadId, oldString, newString } = inputData;
    const job = await getJob(threadId);
    const current = job?.state?.pendingPlugin;
    if (!current?.schemaJson) {
      return { ok: false, error: "No pending plugin found." };
    }
    const occurrences = current.schemaJson.split(oldString).length - 1;
    if (occurrences === 0) {
      console.log(`[edit-schema] \u274C oldString not found in thread ${threadId.slice(0, 8)}`);
      return {
        ok: false,
        error: "oldString not found in schema. Call readSchema and use an exact match."
      };
    }
    if (occurrences > 1) {
      console.log(`[edit-schema] \u274C oldString appears ${occurrences} times in thread ${threadId.slice(0, 8)}`);
      return {
        ok: false,
        error: `oldString appears ${occurrences} times \u2014 must be unique.`
      };
    }
    const updatedSchema = current.schemaJson.replace(oldString, newString);
    const check = validateSchemaShape(updatedSchema);
    if (!check.ok) {
      return {
        ok: false,
        error: `Edit would produce invalid schema: ${check.issues.join("; ")}`
      };
    }
    const candidatePending = { ...current, schemaJson: updatedSchema };
    const guard = validatePluginRunState(candidatePending);
    const hasCriticalErrors = guard.missingRequirements.length > 0 || guard.importIssues.length > 0;
    if (hasCriticalErrors) {
      return {
        ok: false,
        error: `Schema edit blocked by plugin guard:
${formatGuardFailure(guard)}`,
        missingRequirements: guard.missingRequirements,
        importIssues: guard.importIssues,
        warnings: guard.warnings
      };
    }
    const nextPending = appendPluginLedgerEvent(withCurrentSourceHash(candidatePending), {
      type: "schema-edit",
      summary: `Schema text changed by ${updatedSchema.length - current.schemaJson.length} chars.`,
      changedChars: updatedSchema.length - current.schemaJson.length,
      warnings: guard.warnings
    });
    await patchJobState(threadId, (s) => ({
      ...s,
      pendingPlugin: nextPending
    }));
    console.log(`[edit-schema] \u2705 updated for thread ${threadId.slice(0, 8)}, ${check.fieldNames.length} fields`);
    return { ok: true, fieldNames: check.fieldNames, warnings: guard.warnings, message: "Schema updated." };
  }
});
const compilePreviewTool = createTool({
  id: "compile-preview",
  description: "Compile the current Scene.tsx with the real esbuild config (same one the browser uses). For multi-file plugins, compiles the actual module files. Returns structured errors with line numbers on failure. On success, returns { ok: true }.",
  inputSchema: z.object({
    threadId: z.string()
  }),
  execute: async (inputData) => {
    const { threadId } = inputData;
    const job = await getJob(threadId);
    const current = job?.state?.pendingPlugin;
    if (!current?.sceneCode) {
      return { ok: false, error: "No pending plugin found. Call setInitialScene first." };
    }
    const depPolicy = normalizePluginDependencies(current.dependencies);
    const depPolicyWarnings = formatDependencyPolicyChanges(depPolicy);
    for (const message of depPolicyWarnings) {
      console.warn(`[compile-preview] ${message}`);
    }
    const currentWithNormalizedDeps = { ...current, dependencies: depPolicy.dependencies };
    const sourceHash = computePluginSourceHash(currentWithNormalizedDeps);
    const currentWithHash = { ...currentWithNormalizedDeps, sourceHash };
    const filesToValidate = currentWithHash.modules && isMultiFile(currentWithHash.modules) ? currentWithHash.modules : { "Scene.tsx": currentWithHash.sceneCode };
    const sourceCheck = validatePluginSource(filesToValidate);
    if (!sourceCheck.ok) {
      const formatted = formatPluginSourceIssues(sourceCheck.issues);
      return {
        ok: false,
        error: `Plugin source failed validation:
${formatted}`,
        locations: sourceCheck.issues.map((issue) => ({
          text: issue.message,
          file: issue.file,
          line: issue.line,
          column: 0
        })),
        hint: "Call readSceneCode/readModule, then editSceneCode to remove data.animation usage. animation is its own Scene prop."
      };
    }
    console.log(`[compile-preview] \u25B6 compiling ${Object.keys(filesToValidate).length} file(s) for thread ${threadId.slice(0, 8)}`);
    const guard = validatePluginRunState(currentWithHash);
    if (!guard.ok) {
      return {
        ok: false,
        error: `Plugin guard failed before compile:
${formatGuardFailure(guard)}`,
        locations: [],
        missingRequirements: guard.missingRequirements,
        importIssues: guard.importIssues,
        warnings: [...depPolicyWarnings, ...guard.warnings],
        hint: "Fix the missing requirement/import first. Do not compile a plugin that dropped hard requirements."
      };
    }
    const result = await bundlePreview(currentWithHash.sceneCode, currentWithHash.pluginId ?? "preview", {
      dependencies: currentWithHash.dependencies,
      modules: currentWithHash.modules
    });
    if (!result.ok) {
      console.log(`[compile-preview] \u274C ${result.error.slice(0, 200)}`);
      const locations = (result.diagnostics ?? []).filter((d) => d.line > 0).map((d) => ({
        text: d.text,
        file: d.file,
        line: d.line,
        column: d.column
      }));
      return {
        ok: false,
        error: result.error,
        locations,
        warnings: [...depPolicyWarnings, ...guard.warnings],
        hint: "Call readSceneCode to see the actual code around the error line, then use editSceneCode to fix it. After editing, call compilePreview again."
      };
    }
    console.log(`[compile-preview] \u2705 ${result.bundleJs.length} bytes`);
    const nextPending = appendPluginLedgerEvent({
      ...currentWithHash,
      lastCompiledSourceHash: sourceHash,
      lastCompileOk: true,
      lastBundleBytes: result.bundleJs.length,
      lastCompiledAt: (/* @__PURE__ */ new Date()).toISOString()
    }, {
      type: "compile",
      summary: `Preview compilation successful (${result.bundleJs.length} bytes, sourceHash ${sourceHash}).`,
      warnings: [...depPolicyWarnings, ...guard.warnings]
    });
    await patchJobState(threadId, (s) => ({ ...s, pendingPlugin: nextPending }));
    return {
      ok: true,
      sourceHash,
      lastCompiledSourceHash: sourceHash,
      bundleBytes: result.bundleJs.length,
      warnings: [...depPolicyWarnings, ...guard.warnings],
      guard: {
        hardRequirements: guard.hardRequirements.map((term) => term.id),
        files: guard.snapshot.files,
        dependencies: guard.snapshot.dependencies
      },
      message: "Compilation successful. Call savePendingPlugin to trigger the real browser preview."
    };
  }
});
const savePendingPluginTool = createTool({
  id: "save-pending-plugin",
  description: "Save the current pendingPlugin and trigger a browser preview. Call this after compilePreview returns ok. Returns { ok: true, pluginId, name }.",
  inputSchema: z.object({
    threadId: z.string()
  }),
  execute: async (inputData, ctx) => {
    const { threadId } = inputData;
    const job = await getJob(threadId);
    const pendingPlugin = job?.state?.pendingPlugin;
    if (!pendingPlugin) {
      return { ok: false, error: "No pending plugin found." };
    }
    const sourceHash = computePluginSourceHash(pendingPlugin);
    const pendingWithHash = { ...pendingPlugin, sourceHash };
    if (pendingWithHash.lastCompiledSourceHash !== sourceHash || !pendingWithHash.lastCompileOk) {
      return {
        ok: false,
        error: `Cannot save plugin preview because source changed after the last compile. current sourceHash=${sourceHash}, lastCompiledSourceHash=${pendingWithHash.lastCompiledSourceHash ?? "none"}. Call compilePreview again, then savePendingPlugin.`,
        sourceHash,
        lastCompiledSourceHash: pendingWithHash.lastCompiledSourceHash ?? null
      };
    }
    const filesToValidate = pendingWithHash.modules && isMultiFile(pendingWithHash.modules) ? pendingWithHash.modules : { "Scene.tsx": pendingWithHash.sceneCode };
    const sourceCheck = validatePluginSource(filesToValidate);
    if (!sourceCheck.ok) {
      const formatted = formatPluginSourceIssues(sourceCheck.issues);
      return {
        ok: false,
        error: `Cannot save plugin preview because source failed validation:
${formatted}`,
        hint: "Fix reserved Scene prop usage first. Use animation.enter/hold/exit from props, not data.animation."
      };
    }
    const guard = validatePluginRunState(pendingWithHash);
    if (!guard.ok) {
      return {
        ok: false,
        error: `Cannot save plugin preview because the plugin guard failed:
${formatGuardFailure(guard)}`,
        missingRequirements: guard.missingRequirements,
        importIssues: guard.importIssues,
        warnings: guard.warnings
      };
    }
    const previewBuildId = `${sourceHash}-${Date.now().toString(36)}`;
    const guardedPendingPlugin = appendPluginLedgerEvent({
      ...pendingWithHash,
      previewBuildId,
      previewSourceHash: sourceHash,
      previewSavedAt: (/* @__PURE__ */ new Date()).toISOString()
    }, {
      type: "compile",
      summary: `Saved pending plugin preview for sourceHash ${sourceHash}.`,
      warnings: guard.warnings
    });
    await patchJobState(threadId, (current) => ({ ...current, pendingPlugin: guardedPendingPlugin }));
    try {
      await ctx?.writer?.custom?.({
        type: "data-wizard-progress",
        data: {
          phase: "create-plugin",
          status: "preview-ready",
          toolCallId: `save-pending-${Date.now()}`,
          pluginId: pendingWithHash.pluginId,
          pluginName: pendingWithHash.pluginName,
          sourceHash,
          previewSourceHash: sourceHash,
          previewBuildId,
          pendingPlugin: guardedPendingPlugin
        },
        transient: false
      });
    } catch {
    }
    console.log(`[save-pending-plugin] \u2705 ${pendingWithHash.pluginId} (${sourceHash})`);
    return {
      ok: true,
      pluginId: pendingWithHash.pluginId,
      name: pendingWithHash.pluginName,
      sourceHash,
      previewBuildId,
      warnings: guard.warnings
    };
  }
});
function classifyError(error) {
  const lower = error.toLowerCase();
  if (lower.includes("schemajson") || lower.includes('"properties"')) return "schema";
  if (lower.includes("plugin source failed validation")) return "scene";
  if (lower.includes("sandbox build failed") || lower.includes("error ts") || lower.includes("syntaxerror") || lower.includes("expected") || lower.includes("transform failed") || lower.includes("build.mjs")) return "scene";
  return "build";
}
createTool({
  id: "validate-and-build",
  description: "Final build: compatibility check \u2192 sandbox build \u2192 S3 upload \u2192 DB insert. Use after user approves the preview. Returns { ok: true, pluginId, ... } or { ok: false, error, step }.",
  inputSchema: z.object({
    pluginId: z.string(),
    pluginName: z.string(),
    description: z.string(),
    sceneCode: z.string(),
    modules: z.record(z.string(), z.string()).optional(),
    schemaJson: z.string(),
    dependencies: z.record(z.string(), z.string()).optional(),
    userId: z.string().nullable().optional()
  }),
  execute: async (inputData) => {
    const { pluginId, pluginName, description, sceneCode, modules, schemaJson, dependencies, userId } = inputData;
    const result = await createPluginFromSource({
      id: pluginId,
      name: pluginName,
      description,
      category: "custom",
      sceneCode,
      modules,
      schemaJson,
      dependencies,
      userId: userId ?? null
    });
    if (!result.ok) {
      return {
        ok: false,
        error: result.error,
        errors: result.errors,
        step: classifyError(result.error)
      };
    }
    return {
      ok: true,
      pluginId: result.pluginId,
      name: result.name,
      builtInSandbox: result.builtInSandbox,
      warnings: result.warnings
    };
  }
});
const readModuleTool = createTool({
  id: "read-module",
  description: "Read a specific module file from the pending plugin. Returns the code and its AST section (exports, line ranges). For Scene.tsx, defaults to readSceneCode behavior but includes AST.",
  inputSchema: z.object({
    threadId: z.string(),
    filePath: z.string().describe('File to read (e.g. "animations.ts", "theme.ts", "Scene.tsx")')
  }),
  execute: async (inputData) => {
    const { threadId, filePath } = inputData;
    const job = await getJob(threadId);
    const pending = job?.state?.pendingPlugin;
    if (!pending) {
      return { ok: false, error: "No pending plugin found." };
    }
    const isMulti = pending.modules && Object.keys(pending.modules).length > 1;
    let code;
    let fileAst = null;
    if (isMulti && pending.modules?.[filePath]) {
      code = pending.modules[filePath];
    } else if (filePath === "Scene.tsx") {
      code = pending.sceneCode;
    } else {
      return {
        ok: false,
        error: `File "${filePath}" not found. Available: ${isMulti ? Object.keys(pending.modules).join(", ") : "Scene.tsx (single-file mode)"}`
      };
    }
    const fullAst = pending.ast ?? null;
    if (fullAst?.files?.[filePath]) {
      fileAst = fullAst.files[filePath];
    } else {
      fileAst = deriveAST({ [filePath]: code }).files[filePath] ?? null;
    }
    console.log(`[read-module] \u2705 ${filePath} (${code.length} chars) for thread ${threadId.slice(0, 8)}`);
    return { ok: true, filePath, code, ast: fileAst };
  }
});
const readASTTool = createTool({
  id: "read-ast",
  description: "Return the full AST (structural map) of all plugin files. Shows exports, sections, and line ranges for each file. Use this to understand code layout before making surgical edits.",
  inputSchema: z.object({
    threadId: z.string()
  }),
  execute: async (inputData) => {
    const { threadId } = inputData;
    const job = await getJob(threadId);
    const pending = job?.state?.pendingPlugin;
    if (!pending) {
      return { ok: false, error: "No pending plugin found." };
    }
    let ast;
    if (pending.modules && isMultiFile(pending.modules)) {
      ast = deriveAST(pending.modules);
    } else {
      ast = deriveAST({ "Scene.tsx": pending.sceneCode });
    }
    await patchJobState(threadId, (s) => ({
      ...s,
      pendingPlugin: { ...pending, ast }
    }));
    const fileNames = Object.keys(ast.files);
    console.log(`[read-ast] \u2705 ${fileNames.length} files: ${fileNames.join(", ")} for thread ${threadId.slice(0, 8)}`);
    return { ok: true, ast, files: fileNames };
  }
});
const inspectPluginStateTool = createTool({
  id: "inspect-plugin-state",
  description: "Inspect the current pending plugin without reading full source. Returns files, dependencies, import graph, hard requirements, missing requirements, warnings, and recent ledger events. Call this before complex edits or when a fix unexpectedly changes architecture.",
  inputSchema: z.object({
    threadId: z.string()
  }),
  execute: async (inputData) => {
    const { threadId } = inputData;
    const job = await getJob(threadId);
    const pending = job?.state?.pendingPlugin;
    if (!pending) {
      return { ok: false, error: "No pending plugin found." };
    }
    const guard = validatePluginRunState(pending);
    const ledger = pending.runLedger ?? null;
    const execution = ledger?.execution ?? job?.state?.pluginExecution ?? null;
    const sourceHash = computePluginSourceHash(pending);
    const lastCompiledSourceHash = pending.lastCompiledSourceHash ?? null;
    const previewSourceHash = pending.previewSourceHash ?? null;
    const compileState = lastCompiledSourceHash === sourceHash && pending.lastCompileOk ? "compiled-current" : "source-changed-after-compile";
    const previewState = previewSourceHash === sourceHash ? "preview-current" : "preview-stale-or-not-saved";
    return {
      ok: guard.ok,
      pluginId: pending.pluginId,
      pluginName: pending.pluginName,
      sourceVersion: {
        sourceHash,
        lastCompiledSourceHash,
        previewSourceHash,
        previewBuildId: pending.previewBuildId ?? null,
        lastBundleBytes: pending.lastBundleBytes ?? null,
        lastCompiledAt: pending.lastCompiledAt ?? null,
        previewSavedAt: pending.previewSavedAt ?? null,
        compileState,
        previewState
      },
      files: guard.snapshot.files,
      dependencies: guard.snapshot.dependencies,
      imports: guard.snapshot.imports,
      hardRequirements: guard.hardRequirements.map((term) => ({
        id: term.id,
        aliases: term.aliases,
        reason: term.reason
      })),
      missingRequirements: guard.missingRequirements,
      importIssues: guard.importIssues,
      warnings: guard.warnings,
      execution,
      executionSummary: summarizePluginExecution(execution),
      recentEvents: ledger?.events?.slice(-8) ?? [],
      hint: guard.ok ? "State is consistent. Use readAST/readModule for targeted edits." : "Fix missing requirements/import issues before compilePreview or savePendingPlugin."
    };
  }
});
const updateDependenciesTool = createTool({
  id: "update-dependencies",
  description: "Surgically edit the pendingPlugin's npm dependency manifest WITHOUT touching Scene.tsx or schema. Use this when a peer-dep / resolution error blocks compilePreview or buildAndSavePlugin and the source code is already correct. Pass { add, remove } \u2014 add merges into the manifest (overwriting existing entries by name), remove deletes the listed names. The app already provides React/Remotion and Skygen-supported Three/R3F/Drei packages, so dependency policy keeps those out of the plugin manifest. Use dependencies for additional packages only. After this, call compilePreview then savePendingPlugin to refresh the preview. To REPLACE a dep with a compatible version, add the new version under the same name (overwrites).",
  inputSchema: z.object({
    threadId: z.string(),
    add: z.record(z.string(), z.string()).optional().describe('Map of { packageName: semver-range } to add or overwrite, e.g. { "@react-three/fiber": "^9.0.0" }'),
    remove: z.array(z.string()).optional().describe('Package names to remove from the manifest, e.g. ["@react-spring/three", "@react-three/drei"]')
  }),
  execute: async ({ context }) => {
    const { threadId, add, remove } = context;
    const job = await getJob(threadId);
    const pendingPlugin = job?.state?.pendingPlugin;
    if (!pendingPlugin) {
      return { ok: false, error: "No pending plugin found." };
    }
    const current = { ...pendingPlugin.dependencies ?? {} };
    let added = 0;
    let removed = 0;
    if (add) {
      for (const [name, range] of Object.entries(add)) {
        if (typeof name !== "string" || typeof range !== "string") continue;
        current[name] = range;
        added += 1;
      }
    }
    if (Array.isArray(remove)) {
      for (const name of remove) {
        if (typeof name !== "string") continue;
        if (current[name] !== void 0) {
          delete current[name];
          removed += 1;
        }
      }
    }
    const depPolicy = normalizePluginDependencies(current);
    const normalizedDeps = depPolicy.dependencies;
    const depPolicyWarnings = formatDependencyPolicyChanges(depPolicy);
    const candidatePending = { ...pendingPlugin, dependencies: normalizedDeps };
    const guard = validatePluginRunState(candidatePending);
    const nextPending = appendPluginLedgerEvent(withCurrentSourceHash(candidatePending), {
      type: "dependency-edit",
      summary: `Dependencies changed: added ${added}, removed ${removed}; dependency policy kept ${depPolicy.stripped.length} app-provided/invalid package(s) out of the plugin manifest.`,
      warnings: [...depPolicyWarnings, ...guard.warnings],
      errors: guard.ok ? [] : [...guard.missingRequirements, ...guard.importIssues.map((issue) => issue.message)]
    });
    await patchJobState(threadId, (state) => ({
      ...state,
      pendingPlugin: nextPending
    }));
    return {
      ok: true,
      dependencies: normalizedDeps,
      added,
      removed,
      normalized: depPolicy.normalized,
      stripped: depPolicy.stripped,
      guard: {
        ok: guard.ok,
        missingRequirements: guard.missingRequirements,
        importIssues: guard.importIssues,
        warnings: guard.warnings
      },
      hint: "Dependencies updated. Call compilePreview to verify the sandbox build passes, then savePendingPlugin to refresh the browser preview."
    };
  }
});
const listDependenciesTool = createTool({
  id: "list-dependencies",
  description: "Read the current pendingPlugin dependency manifest. Call this when you see a peer-dep or resolution error to see exactly what is declared before deciding what to add or remove.",
  inputSchema: z.object({
    threadId: z.string()
  }),
  execute: async ({ context }) => {
    const { threadId } = context;
    const job = await getJob(threadId);
    const pendingPlugin = job?.state?.pendingPlugin;
    if (!pendingPlugin) {
      return { ok: false, error: "No pending plugin found." };
    }
    return {
      ok: true,
      dependencies: pendingPlugin.dependencies ?? {},
      pluginId: pendingPlugin.pluginId
    };
  }
});
const pluginCreatorTools = {
  recordPluginPlan: recordPluginPlanTool,
  updatePluginStep: updatePluginStepTool,
  setInitialScene: setInitialSceneTool,
  readSceneCode: readSceneCodeTool,
  editSceneCode: editSceneCodeTool,
  readModule: readModuleTool,
  readAST: readASTTool,
  inspectPluginState: inspectPluginStateTool,
  readSchema: readSchemaTool,
  editSchema: editSchemaTool,
  compilePreview: compilePreviewTool,
  savePendingPlugin: savePendingPluginTool,
  updateDependencies: updateDependenciesTool,
  listDependencies: listDependenciesTool,
  loadForkedPluginSource: loadForkedPluginSourceTool
};
const pluginCreatorToolsV2 = {
  ...pluginCreatorTools,
  // ─── Recon (mandatory before recordPluginPlan in modify mode) ──────────
  getSourceMap: sourceMapTools.getSourceMap,
  setFileRole: sourceMapTools.setFileRole,
  // ─── Semantic grep + symbol / line search ───────────────────────────────
  findAnchor: sourceMapTools.findAnchor,
  // ← NEW: natural-language intent → symbol + line range
  findSymbol: sourceMapTools.findSymbol,
  listSymbols: sourceMapTools.listSymbols,
  readLines: sourceMapTools.readLines,
  searchInFile: sourceMapTools.searchInFile,
  grepPlugin: sourceMapTools.grepPlugin,
  findDataFieldUsages: sourceMapTools.findDataFieldUsages,
  // ─── Line-based edits (deterministic, no string matching) ───────────────
  editLines: sourceMapTools.editLines,
  insertAt: sourceMapTools.insertAt,
  deleteLines: sourceMapTools.deleteLines,
  previewEdit: sourceMapTools.previewEdit,
  // ─── Reason+Act audit trail ──────────────────────────────────────────────
  recordPlanDeviation: recordPlanDeviationTool
};

const pluginPlannerAgent = new Agent({
  id: "plugin-planner",
  name: "Plugin Planner Agent",
  instructions: `You are a plugin planning architect. Your job is to analyze a plugin creation request and produce a structured design plan. You do NOT write code \u2014 you design.

## INPUT
JSON: \`{ pluginId, pluginName, description, userStory, userId, threadId, mode? }\`

If the conversation contains an image attachment (multimodal message with an image_url), analyze the visual to understand what the plugin should look like before planning.

\`mode\` is "create" (default) for new plugins, or "modify" for changes. For modify mode, the plan should focus on what needs to change, not a full redesign.

## DOMAIN CLASSIFICATION

Read \`description\` and \`userStory\`. Pick ONE domain:

- **"animation"** (DEFAULT) \u2014 Stat overlays, counters, tickers, text reveals, lower thirds, leaderboards, scoreboards, image overlays, progress bars, any general animation. Keywords: stat, counter, ticker, text reveal, lower third, leaderboard, overlay, progress bar, social stats.
  When in doubt, choose "animation".

- **"chart"** \u2014 Primary rendering is a chart or graph. Keywords: chart, graph, bar chart, pie chart, line chart, area chart, data visualization, recharts, histogram, scatter plot, donut chart, radar chart.

- **"lottie"** \u2014 Primary rendering uses a Lottie JSON animation. Keywords: lottie, JSON animation, motion file, animated icon, lottie-react.

- **"three"** \u2014 Primary rendering is a 3D scene. Keywords: 3D, three.js, sphere, cube, cylinder, particle, depth, 3D bar, 3D chart, three-dimensional, WebGL, rotating, orbit.

## SCHEMA DESIGN RULES

- Top-level: \`{ "properties": {...}, "defaults": {...} }\`
- Field names: camelCase
- Media fields follow naming convention: images \u2192 \`imageUrl\`, \`backgroundImage\` + \`"editor": "image"\`; audio \u2192 \`audioSrc\` + \`"editor": "audio"\`; video \u2192 \`videoSrc\` + \`"editor": "video"\`
- Foreground characters/objects: add \`"removeBackground": true\`
- Always include a root \`defaults\` block with example values for every editable field. Skygen uses this to seed \`pluginData\` in the editor when the plugin is added; \`properties.<field>.default\` alone is not enough.
- Keep \`defaults\` flat: field names directly under \`defaults\`, never nested under \`pluginData\`.

## FILE LAYOUT \u2014 feature-based, not kind-based

For moderate/complex plugins, organize by FEATURE (one directory per visual concept) instead of by KIND (one file per type). This keeps each feature self-contained and lets the orchestrator's frozen-contract system enforce clean boundaries.

\`\`\`
Scene.tsx                              \u2190 composition root only (~50 lines)
shared/
  theme.ts                             \u2190 cross-feature theme tokens
  utils.ts                             \u2190 cross-feature utilities
features/
  <feature-name>/                      \u2190 e.g. hero-reveal, stat-ticker, background-drift
    index.tsx                          \u2190 feature entry (default export)
    animations.ts                      \u2190 feature-local timeline helpers
\`\`\`

Rules:
- A new feature = a new directory. No merge conflicts with existing features.
- Cross-feature code lives in \`shared/\`.
- Each \`codeStructure: "multi-file"\` plugin should describe its feature split in \`moduleSplit\`.
- For simple plugins, single-file mode (just \`Scene.tsx\`) is still fine.

## SCENE.TSX CONTRACT

\`\`\`tsx
interface SceneProps {
  data: Record<string, unknown>;
  theme: string;
  animation: { enter: number; hold: number; exit: number };  // SECONDS \u2014 HOST LENGTH ONLY
  motionProfile?: 'subtle' | 'dynamic' | 'energetic';
}
export default function Scene({ data, theme, animation }: SceneProps): React.ReactElement
\`\`\`

REQUIRED IMPORTS \u2014 when you list Scene.tsx dependencies, these imports MUST appear at the top of EVERY file that uses React/Remotion APIs (copy verbatim, including into component/animation modules). Without them, the preview crashes with "X is not defined":
\`\`\`ts
import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useCurrentFrame, useVideoConfig, interpolate, spring, Easing, AbsoluteFill, Sequence, Audio, Img, Video } from 'remotion';
\`\`\`

## TIMING / MOTION GRAPHICS PLAN (HARD)

enter/hold/exit are **NOT** the creative model. They only set total length for the host timeline/preview.

You MUST plan a **Creativly-style frame score**:
1. Pick \`durationSec\` (total graphic length). Defaults:
   - simple overlay/stat: 8\u201312
   - standard motion graphic: **12\u201320**
   - full short MG film (user asks for video/film/30s): **20\u201330**
2. Put \`durationSec\` in schema \`defaults\` so the browser preview uses it (not a 5s stub).
3. Output structured \`animationTimeline\` with **named beats** and **approx frame ranges at 30fps**, plus **layer start delays**.
4. Require **always-on sustain motion** (drift/pulse/slow camera) for the full duration.
5. **Forbidden plan:** "fade in during enter, hold static, fade out during exit".

Host animation mapping (for reference only):
- enter \u2248 8\u201312% of durationSec
- exit \u2248 8\u201312% of durationSec
- hold \u2248 remainder
- total = enter + hold + exit \u2248 durationSec

## OUTPUT

Your final message must be ONLY a raw JSON object \u2014 no prose, no markdown.

\`\`\`json
{
  "domain": "animation" | "chart" | "lottie" | "three",
  "domainReason": "one sentence explaining why this domain was chosen",
  "durationSec": 15,
  "schemaOutline": {
    "fields": [
      { "name": "string", "type": "string|number|boolean|array|object", "description": "what this field holds" }
    ],
    "mediaFields": ["list of fields that are images/audio/video"],
    "generationFields": ["list of fields that need AI-generated media"]
  },
  "sceneArchitecture": "2-4 sentences: visual structure, z-order, layout, continuous motion strategy (NOT widget+fade)",
  "dependencies": { "packageName": "^version" },
  "estimatedComplexity": "simple" | "moderate" | "complex",
  "animationTimeline": {
    "fps": 30,
    "durationSec": 15,
    "beats": [
      { "id": "open", "fromSec": 0, "toSec": 2, "what": "bg/ambient + first setup" },
      { "id": "hook", "fromSec": 2, "toSec": 5, "what": "primary title/logo impact" },
      { "id": "build", "fromSec": 5, "toSec": 9, "what": "cascade secondary elements" },
      { "id": "climax", "fromSec": 9, "toSec": 12, "what": "accent / densest motion" },
      { "id": "resolve", "fromSec": 12, "toSec": 15, "what": "end pose + micro-motion" }
    ],
    "layers": [
      { "name": "bg", "startSec": 0, "motion": "continuous-drift" },
      { "name": "title", "startSec": 2, "motion": "spring-impact" },
      { "name": "cards", "startSec": 5, "staggerSec": 0.25, "motion": "cascade" }
    ],
    "sustain": "what stays alive full duration (noise/pulse/scale breath/camera)",
    "forbidden": "no single global enter/hold/exit fade for all elements"
  },
  "hostAnimation": { "enter": 1.5, "hold": 12, "exit": 1.5 },
  "potentialPitfalls": ["list of things that could go wrong"],
  "codeStructure": "single-file" | "multi-file",
  "moduleSplit": {
    "Scene.tsx": "entry point \u2014 imports from modules and renders layout",
    "theme.ts": "optional \u2014 describe if needed",
    "animations.ts": "optional \u2014 beat helpers + layer clocks",
    "components.tsx": "optional \u2014 describe if needed"
  }
}

For simple plugins, set \`codeStructure: "single-file"\` and omit \`moduleSplit\`.
For moderate/complex plugins, set \`codeStructure: "multi-file"\` and describe what each module should contain.
Always include \`durationSec\` and structured \`animationTimeline.beats\`. Always include \`durationSec\` in schema defaults.
\`\`\`

## RULES
- Motion plan = frame/beat score. Never plan as static enter/hold/exit phases.
- Schema defaults MUST include \`durationSec\` matching the plan so plugin preview length is correct.
- Be specific about schema fields \u2014 name, type, and purpose of each
- Be specific about which layer starts at which second
- List real dependencies with version ranges (e.g. \`{ "recharts": "^2.15.4" }\`)
- Empty dependencies = \`{}\`
- For modify mode: only include fields that need to change, mark the rest as "keep existing"`,
  model: createOpenRouterModel(),
  defaultGenerateOptionsLegacy: { maxSteps: 3 }
});

const REMOTION_SKILLS = `
## REMOTION REFERENCE (Official Skills)

### Core: Motion-graphics timing model (Skygen)

Host props \`animation.enter/hold/exit\` only define **total duration**. Creative timing is a **frame score**:
- totalFrames = (enter+hold+exit)*fps  (or schema defaults.durationSec * fps)
- Named beats: open \u2192 hook \u2192 build \u2192 climax \u2192 resolve
- Per-layer delays: \`spring({ frame: Math.max(0, frame - startFrame), fps, config })\`
- Multi-keyframe moves: \`interpolate(frame, [0, a, b, total], [...])\`
- Sustain ALWAYS ON: breath / drift / pulse for the full duration
- FORBIDDEN: single global fade for enter/hold/exit (widget quality)

### Core: Timing & Interpolation

\`interpolate(frame, inputRange, outputRange, options)\` maps a frame number to a value.
- Always clamp: \`{ extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }\`
- Use \`Easing.out\` for impact landings (starts fast, decelerates into place)
- Use \`Easing.in\` for resolve-outs
- B\xE9zier easing: \`Easing.bezier(x1, y1, x2, y2)\` \u2014 matches CSS cubic-bezier syntax
  - Crisp UI entrance: \`Easing.bezier(0.22, 1, 0.36, 1)\`
  - Editorial fade: \`Easing.bezier(0.45, 0, 0.55, 1)\`
  - Playful overshoot: \`Easing.bezier(0.34, 1.56, 0.64, 1)\`
- Named presets: \`Easing.quad\`, \`Easing.cubic\`, \`Easing.sin\`, \`Easing.exp\`, \`Easing.circle\`
  combined with \`.in\`, \`.out\`, \`.inOut\`
- Derive multiple animated properties from a SINGLE normalized progress (0\u21921):
  \`\`\`ts
  const progress = interpolate(frame, [start, start + dur], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const opacity = progress;
  const scale = interpolate(progress, [0, 1], [0.8, 1]);
  \`\`\`
- **Multi-Stage Keyframing**: You can pass more than two waypoints to create complex continuous movement without nesting Sequences.
  \`\`\`ts
  // Pans a camera across a large canvas across multiple beats
  const camX = interpolate(frame, [0, 30, 60, 90, 120], [0, -100, -100, -250, -250], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic) });
  \`\`\`

### Core: Organic Motion (@remotion/noise)

\`noise2D(seed, x, y)\` and \`noise3D(seed, x, y, z)\` from \`@remotion/noise\` generate smooth, deterministic random values (-1 to 1).
- **Subtle Camera Shake**: \`const shakeX = noise2D("cam-x", frame * 0.008, 0) * 3;\`
- **Floating Particles**: \`const driftY = noise2D("drift", i * 8, frame * 0.012) * 15;\`
- ALWAYS prefer \`noise2D\` over \`Math.sin()\` for organic drift, as it feels more natural and less mechanical.

\`spring({ frame, fps, config })\` \u2014 bouncy physics animation.
- Returns 0\u21921 (approximately). Config: \`{ stiffness: 80\u2013200, damping: 15\u201325 }\`
- Higher stiffness = faster/snappier. Higher damping = less bounce.
- Use for enter animations that need a natural overshoot feel.

### Core: Sequencing

\`<Sequence from={N} durationInFrames={N}>\` \u2014 delays and limits child visibility.
- Inside a Sequence, \`useCurrentFrame()\` counts from 0 (local time, not global).
- \`layout="none"\` to avoid wrapping in AbsoluteFill.
- \`premountFor={N}\` \u2014 preloads component N frames before it appears.
- Nesting: inner Sequence trims start, outer Sequence adds delay.
  \`\`\`tsx
  <Sequence from={30}> // delay 30 frames
    <Sequence from={-15}> // trim first 15 frames of animation
      <MyComponent />
    </Sequence>
  </Sequence>
  \`\`\`

\`<Series>\` \u2014 arranges children sequentially without overlap.
- Children use \`<Series.Sequence durationInFrames={N}>\`
- Negative \`offset\` creates overlaps between sequences.

Stagger multi-element entries:
\`\`\`ts
const opacity = interpolate(frame, [i * 5, enterFrames + i * 5], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
\`\`\`

### Images

\`<Img src={url} style={...} />\` \u2014 Remotion's image component (use instead of <img>).
- Blocks rendering until loaded (important for Lambda render accuracy).
- \`objectFit: 'cover' | 'contain' | 'fill'\`
- For frame-by-frame sequences: \`<Img src={staticFile(\`frames/frame\${frame}.png\`)}\` />\`
- Get dimensions: \`getImageDimensions(url)\` returns \`{ width, height }\`

### Videos

\`<Video src={url} style={...} />\` \u2014 frame-accurate video (use instead of <video>).
- \`trimBefore={N}\` / \`trimAfter={N}\` \u2014 trim frames from start/end.
- \`playbackRate={2}\` \u2014 speed (no reverse).
- \`loop\` \u2014 infinite loop.
- \`muted\` \u2014 silence.
- \`volume={0.5}\` or volume callback: \`volume={(f) => interpolate(f, [0, 30], [0, 1])}\`
- Wrap in \`<Sequence from={30}>\` to delay start.

### Audio

\`<Audio src={url} />\` \u2014 synced audio.
- Same \`trimBefore\`, \`trimAfter\`, \`playbackRate\`, \`loop\`, \`muted\`, \`volume\` as Video.
- Wrap in \`<Sequence>\` to delay.

### Transitions (TransitionSeries)

\`<TransitionSeries>\` from \`@remotion/transitions\` \u2014 manages scene transitions.
- Built-in presentations: \`fade()\`, \`slide()\`, \`wipe()\`, \`flip()\`, \`clockWipe()\`
- Timing: \`linearTiming({ durationInFrames })\` (smooth cinematic) or \`springTiming({ config: { damping: 200 } })\` (snappy physical entrances)
- Transitions OVERLAP adjacent scenes \u2192 total duration is SHORTER than sum of parts.
  Example: two 60-frame scenes + 15-frame transition = 105 total frames.
- **Cinematic Overlays**: Use \`<TransitionSeries.Overlay durationInFrames={30}>\` with \`<LightLeak seed={3} hueShift={50} />\` from \`@remotion/light-leaks\` to create premium, high-end studio transitions between scenes.
\`\`\`tsx
import { LightLeak } from "@remotion/light-leaks";
<TransitionSeries>
  <TransitionSeries.Sequence durationInFrames={60}><SceneA /></TransitionSeries.Sequence>
  <TransitionSeries.Overlay durationInFrames={30}><LightLeak seed={3} hueShift={50} /></TransitionSeries.Overlay>
  <TransitionSeries.Transition presentation={fade()} timing={linearTiming({ durationInFrames: 15 })} />
  <TransitionSeries.Sequence durationInFrames={60}><SceneB /></TransitionSeries.Sequence>
</TransitionSeries>
\`\`\`

### Text Animations

Typewriter effect \u2014 always use string slicing, NEVER per-character opacity:
\`\`\`ts
const charsToShow = Math.floor(interpolate(frame, [0, enterFrames], [0, text.length], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }));
const visible = text.slice(0, charsToShow);
\`\`\`

Word highlight \u2014 interpolate background-color or opacity per word based on frame position.

### Fonts

Google Fonts (recommended \u2014 type-safe, auto-blocks render):
\`\`\`ts
import { loadFont } from '@remotion/google-fonts/Inter';
const { fontFamily } = loadFont();
// use fontFamily in style={{ fontFamily }}
\`\`\`
Call \`loadFont()\` at module level (top of file), not inside component.
Specify weights/subsets for smaller bundles: \`loadFont('normal', { subsets: ['latin'], weights: ['400', '700'] })\`

Local fonts (from public/ folder):
\`\`\`ts
import { loadFont } from '@remotion/fonts';
await loadFont({ family: 'MyFont', url: staticFile('MyFont.woff2'), weight: '400' });
\`\`\`

### Measuring Text

\`measureText({ text, fontFamily, fontSize, fontWeight })\` from \`@remotion/layout-utils\`
- Results are cached \u2014 safe to call repeatedly.
- Load font BEFORE measuring.
- Use \`validateFontIsLoaded: true\` to catch font loading issues.
- Use \`outline\` instead of \`border\` to avoid layout differences.

\`fitText({ text, withinWidth, fontFamily, fontWeight })\` \u2014 find optimal font size for a container.

### Measuring DOM Nodes

Remotion applies a \`scale()\` transform \u2014 \`getBoundingClientRect()\` values are scaled.
Fix:
\`\`\`ts
import { useCurrentScale } from 'remotion';
const scale = useCurrentScale();
const rect = ref.current.getBoundingClientRect();
const realWidth = rect.width / scale;
const realHeight = rect.height / scale;
\`\`\`

### GIFs / Animated Images

\`<AnimatedImage src={url} width={N} height={N} />\` from \`@remotion/gif\`
- \`fit\`: 'fill' | 'contain' | 'cover'
- \`playbackRate\`: speed multiplier
- \`loop\`: 'loop' | 'pause-after-finish' | 'clear-after-finish'
- Get duration: \`getGifDurationInSeconds(url)\`

### Audio Visualization

\`useWindowedAudioData({ src, frame, fps, windowDurationInSeconds })\` from \`@remotion/media-utils\`

Spectrum bars:
\`\`\`ts
const data = useWindowedAudioData({ src: staticFile('audio.mp3'), frame, fps, windowDurationInSeconds: 1 });
const bars = visualizeAudio({ fps, frame, audioData: data, numberOfSamples: 64 }); // powers of 2: 32-1024
// bars[i] is 0-1, lower indices = bass frequencies
\`\`\`

Waveform: \`visualizeAudioWaveform()\` + \`createSmoothSvgPath()\`

Bass reactivity:
\`\`\`ts
const bassValues = bars.slice(0, 4);
const bassIntensity = bassValues.reduce((a, b) => a + b, 0) / bassValues.length;
\`\`\`

Pass \`frame\` as a prop to child components \u2014 don't call \`useCurrentFrame()\` separately inside them.
Sample counts MUST be powers of 2. Apply logarithmic scaling to low frequencies for balanced visuals.

### Lottie

\`\`\`ts
import Lottie from 'lottie-react'; // declare in deps
const lottieRef = useRef(null);
useEffect(() => { lottieRef.current?.goToAndStop(frame, true); }, [frame]);
<Lottie lottieRef={lottieRef} animationData={lottieJson} loop autoplay={false} />
\`\`\`
- \`animationData\` MUST be a JS object (never a URL string). Embed minimal inline JSON if no file provided.
- Sync to Remotion frame via \`goToAndStop(frame, true)\` inside useEffect.

### 3D (React Three Fiber)

\`\`\`ts
import { Canvas, useFrame } from '@react-three/fiber'; // declare in deps
import { Text, Box, Sphere, Cylinder, OrbitControls } from '@react-three/drei'; // declare in deps
\`\`\`
- MUST wrap in \`<ThreeCanvas width={width} height={height}>\` from \`@remotion/three\` OR plain \`<Canvas>\` at 100%\xD7100%.
- Animations MUST be driven by \`useCurrentFrame()\`. Using \`useFrame\` alone causes flicker during rendering.
- Pass frame as prop into Canvas children, read inside useFrame:
  \`\`\`tsx
  function Mesh({ syncFrame }: { syncFrame: number }) {
    const ref = useRef<THREE.Mesh>(null);
    useFrame(() => { if (ref.current) ref.current.rotation.y = syncFrame * 0.02; });
    return <mesh ref={ref}><boxGeometry /><meshStandardMaterial /></mesh>;
  }
  // Inside Scene:
  const frame = useCurrentFrame();
  <Canvas><ambientLight /><directionalLight position={[10,10,5]} /><Mesh syncFrame={frame} /></Canvas>
  \`\`\`
- \`<Sequence layout="none">\` inside ThreeCanvas.
- Primitives only: Box, Sphere, Cylinder, Torus, Text. No GLTF/GLB.

### Maps (MapLibre GL JS + Turf)

Use MapLibre for deterministic map animations: route reveals, flight paths, markers, labels, and camera movement.

\`\`\`ts
import maplibregl, { type GeoJSONSource, type Map } from 'maplibre-gl'; // declare in deps
import * as turf from '@turf/turf'; // declare in deps
import 'maplibre-gl/dist/maplibre-gl.css';
\`\`\`

- Dependencies: \`maplibre-gl\` and \`@turf/turf\`. Do NOT install \`@types/maplibre-gl\`; MapLibre ships types.
- Coordinates are always \`[longitude, latitude]\`.
- **SCHEMA CUSTOMIZATION**: Ensure the map is highly customizable via \`schema.json\`. Users MUST be able to define the region (e.g., center \`latitude\`, \`longitude\`) and borders/routes (e.g., arrays of points) through plugin properties. Do NOT hardcode regions.
- Use GeoJSON sources + MapLibre layers for lines, markers, and labels. Avoid DOM Marker elements unless explicitly requested.
- For geodesic flight routes, use Turf \`greatCircle()\`, \`length()\`, \`along()\`, and \`lineSliceAlong()\`; keep slices non-empty with \`Math.max(0.001, distance * progress)\`.
- For visually straight map lines, use a simple GeoJSON \`LineString\` between points instead of \`greatCircle()\`.
- For camera motion, prefer \`map.calculateCameraOptionsFromTo(cameraLngLat, cameraAltitudeMeters, targetLngLat)\`.
- Separate \`targetRoute\` from \`cameraRoute\`; animate travel progress separately from camera altitude for zoom-out / travel / zoom-in motion.
- Per frame: update the GeoJSON source with \`source.setData(...)\`, call \`map.jumpTo(...)\`, wait for \`idle\`, then \`continueRender(handle)\`; call \`map.triggerRepaint()\` if camera values may be unchanged.
- Marker dots and labels should be map-native layers; make label sizes large enough for video resolution.
- Rendering WebGL maps should use single concurrency and ANGLE: \`remotion render --gl=angle --concurrency=1\`.

### Transparent Video Export

ProRes (for video editing software):
- imageFormat: png, pixelFormat: yuva444p10le, codec: prores, profile: 4444

WebM/VP9 (for browser):
- imageFormat: png, pixelFormat: yuva420p, codec: vp9

### calculateMetadata (dynamic composition config)

\`\`\`ts
export const calculateMetadata: CalculateMetadataFunction<Props> = async ({ props, abortSignal }) => {
  const duration = await getVideoDuration(props.videoSrc);
  return { durationInFrames: Math.round(duration * props.fps), props };
};
\`\`\`
Returns any of: durationInFrames, width, height, fps, props, defaultOutName, defaultCodec.

### Advanced Cinematic Patterns (CRITICAL FOR PREMIUM PLUGINS)

When building plugins, you MUST use these premium patterns instead of basic implementations:

1. **High-End Procedural Backgrounds**:
   - FORBIDDEN: Plain solid color backgrounds.
   - REQUIRED: Use CSS \`radial-gradient\` mapped to \`Math.sin/cos\` driven by \`useCurrentFrame()\` to create floating "Aurora" color blobs. Or use lightweight absolute-positioned elements drifting with \`noise2D\` to create particle fields.

2. **Kinetic Typography (Staggered Reveals)**:
   - FORBIDDEN: Fading in whole text blocks at once.
   - REQUIRED: Split text into characters or words (using \`map\`). Use \`spring()\` with a stagger delay: \`frame: Math.max(0, frame - i * stagger)\`.
   - Interpolate \`translateY\`, \`scale\`, and \`filter: blur()\` simultaneously on each word for premium, Apple-style text reveals.

3. **Infinite Canvas / Camera Pan (Creativly FlowDemo pattern \u2014 REQUIRED for multi-node / explainer scenes)**:
   - Create a massive canvas \`div\` (e.g. **2400\xD71400**) inside \`AbsoluteFill\`, centered with \`left/top: 50%\` and \`transformOrigin: "center center"\`.
   - Place all nodes/UI absolutely on that canvas (not on the viewport).
   - Drive camera with multi-keyframe \`interpolate\` + \`Easing.inOut(Easing.cubic)\` on **camScale, camX, camY** together (same frame stops for all three).
   - **Creativly pull-back recipe** (tight on first element \u2192 reveal full board):
     - frames: \`[0, 20, 55, 90, 125, 165]\`
     - camScale: \`[1.45, 1.25, 1.0, 0.88, 0.78, 0.75]\` (start zoomed-in, dolly out)
     - camX / camY: multi-stage pans that track the narrative (e.g. start offset on first node, end centered on full pipeline)
   - Apply: \`transform: \\\`translate(calc(-50% + \${camX + shakeX}px), calc(-50% + \${camY + shakeY}px)) scale(\${camScale})\\\`\`
   - **Handheld**: \`shakeX = noise2D("cam-sx", frame * 0.008, 0) * 3\`, \`shakeY = noise2D("cam-sy", 0, frame * 0.008) * 2\` (subtle \u2014 never > ~4px unless intentional chaos)
   - Optional **mini-map viewport** (#41): rect size inversely tracks camScale so zoom context is readable.

4. **2.5D Browser Mockups**:
   - For UI showcases, wrap images in a macOS-style browser frame (top bar with 3 dots).
   - Apply 3D CSS transforms: \`perspective: 1000px\`, \`rotateX\`, and \`rotateY\` to make them float in 3D space.

5. **Node/Workflow Diagrams**:
   - Draw data flows using SVG cubic bezier paths (\`<path d="M... C...">\`) to connect nodes.
   - Animate data flowing between them using \`strokeDasharray\` and animating \`strokeDashoffset\` with \`useCurrentFrame()\`.

6. **Animated Data Counters & Progress**:
   - FORBIDDEN: Static numbers for stats or data.
   - REQUIRED: Use \`Math.floor(interpolate(progress, [0, 1], [0, targetValue]))\` to animate numbers ticking up.
   - REQUIRED: Animate SVG lines/charts using \`evolvePath\` from \`@remotion/paths\` over time.

7. **Staggered 3D Cards Grid**:
   - When showing a grid of elements (like templates, photos, or features), use \`perspective(800px) rotateX(\${tiltX}deg) rotateY(\${tiltY}deg)\`.
   - Stagger the entrance of each card with \`delay = i * 5\` and calculate tilt directions based on their row/column position to give the grid depth.

8. **Audio / Data Waveforms**:
   - For audio or data plugins, create an array of bars \`<divs>\` where height is driven by \`Math.sin()\` and \`noise2D()\`.
   - Apply a floor reflection by duplicating the bars upside down with \`transform: scaleY(-1)\` and fading them out using \`maskImage: "linear-gradient(to bottom, rgba(0,0,0,0.15), transparent)"\`.

9. **3D Exploding UI Layers**:
   - When showcasing a dashboard or editor UI, wrap the layers in a container with \`transformStyle: "preserve-3d"\` and \`rotateX("15deg")\`.
   - Place different pieces of the UI in separate child layers, and animate their \`translateZ\` values to "explode" them apart along the Z-axis, creating a cinematic depth effect.

10. **Multiplayer / Collaboration Cursors**:
   - When showing real-time collaboration, draw SVG cursors and animate their x/y positions using \`spring\`.
   - REQUIRED: Add organic wobble to the cursor paths using \`noise2D\`.
   - REQUIRED: Draw curved SVG connecting paths between cursors using \`evolvePath\` to show team connectivity.

11. **Before / After Scanlines (AI Processing)**:
   - When showing an AI feature (like inpainting, upscaling, or editing), use a sweeping scanline \`<div>\`.
   - REQUIRED: Use \`clipPath: "polygon(...)"\` to separate the "before" state (e.g. with \`backdropFilter: "grayscale(100%) blur(10px)"\`) from the "after" state.
   - Attach small \`@remotion/shapes\` stars that follow the scanline and drift dynamically using \`noise2D\`.

12. **Node-Based Workflows (Pipelines & Graphs)**:
   - When showing a pipeline or workflow, render distinct Node components and connect them using curved SVG \`<path>\` edges (animating with \`evolvePath\`).
   - REQUIRED: Animate a cinematic camera panning and zooming across the nodes using \`interpolate\` on a parent container's \`scale\` and \`translate\`.

13. **Typewriter Text with Evolving Indicator**:
   - When showing AI generating text, use a \`<Typewriter>\` component.
   - REQUIRED: Alongside the text, animate a vertical line drawing down using \`evolvePath\`, accompanied by a blurred gradient glow block that acts as a highlighted cursor.

14. **Floating Camera / Recorder Overlays**:
   - When showing screen recording, presentations, or video calls, place a floating "Camera Overlay" box in the bottom right (with heavy rounded borders, \`overflow: hidden\`, and colored shadows).
   - Add a blinking "REC" indicator animated via \`Math.sin()\` and wrap it in a circular \`evolvePath\` ring.

15. **Card Shimmer Sweep**:
   - On cards and panels, animate a diagonal light sweep: \`background: "linear-gradient(105deg, transparent 30%, rgba(255,255,255,0.2) 50%, transparent 70%)"\`.
   - Animate \`transform: translateX(\${shimmerX}%)\` from -120% to 220% over ~35 frames to make cards feel premium and tactile.

16. **Dual Ghost Watermark Depth**:
   - For background depth, render two copies of a large italic watermark word stacked on top of each other.
   - First copy is at normal opacity (e.g. 0.06), second copy is offset slightly (e.g. \`top: "48%", left: "51%"\`) at 40% of the first copy's opacity, creating a parallax depth effect.

17. **Matrix Rain Background**:
   - When showing a "code", "open source", or "developer" scene, use a \`<MatrixRain>\` component with a dot grid (\`backgroundImage: "radial-gradient(#color 1px, transparent 1px)"\`) overlay.
   - Set the Matrix Rain to a very low opacity (e.g. 0.12) so it's a subtle, atmospheric background effect.

18. **Aurora Background with Breathing Glow**:
   - For outro or hero scenes, use an \`<AuroraBackground>\` component behind everything, then layer a \`radial-gradient\` centered glow on top of it.
   - Animate the glow's \`scale\` property using \`noise2D\` to make it "breathe" organically: \`scale(\${0.6 + 0.15 * noise2D("breathe", frame * 0.02, 0)})\`.

19. **Interactive Before/After Comparison Slider**:
   - For image editing, enhancement, or preset comparisons, overlay the "Before" state using \`clipPath: polygon(0 0, \${sliderPos}% 0, \${sliderPos}% 100%, 0 100%)\` over the "After" state.
   - Draw a physical white vertical divider line at \`left: \${sliderPos}%\` with a custom floating drag handle container containing grip dots.

20. **Horizontal Speed Line Warp**:
   - To show high speed or performance, render an array of horizontal lines that move across the screen.
   - Calculate their position using frame-based modulo: \`left: ((frame * speed + offset) % (width + margin)) - margin\`. Blend their widths dynamically using \`noise2D\`.

21. **Decaying Screen Shake**:
   - During high-impact transitions or speed bursts, add camera shake to the parent container using \`noise2D("shake", frame * frequency, 0) * intensity\`.
   - REQUIRED: Multiply the shake by a decaying factor (e.g., \`1 - progress\`) so it starts intense and organically settles to zero.

22. **Connection Handles with State Glow**:
   - For node-based workflows, render precise circular connection handles at the left and right edges: \`position: absolute, left/right: -6, top: "50%", transform: "translateY(-50%)", width: 12, height: 12, borderRadius: "50%"\`.
   - Modulate their border glow colors based on active signals using \`handleGlow\` props: \`boxShadow: handleGlow > 0 ? 0 0 \${12 * handleGlow}px \${color} : none\`.

23. **Scanning Progress Tints**:
   - During a progress sweep, render a semi-transparent colored tint behind the sweep line covering only the completed portion: \`position: absolute, top: 0, left: 0, width: \${scanLinePos}%, background: \${color}08, zIndex: 4\`.

24. **Contextual Slide-Out Action Docks**:
   - When elements are selected or focused, slide out a contextual glass action toolbar from behind the element: \`position: absolute, right: -52, top: "50%", transform: translateY(-50%) translateX(\${10 * (1 - actionDockOpacity)}px)\`.
   - Coordinate the dock's opacity and position to animate in perfect sync using spring values.

25. **Transition Series Sequence Orchestration**:
   - For multi-scene layouts, coordinate scenes using \`<TransitionSeries>\` from \`@remotion/transitions\` with standard transitions (\`wipe\`, \`slide\`, \`fade\`, \`flip\`).
   - Use spring timings like \`springTiming({ config: { damping: 200 } })\` for smooth, satisfying cuts.

26. **Organic Light Leak Transitions**:
   - When moving between major sections, layer a \`<TransitionSeries.Overlay>\` containing a \`<LightLeak>\` from \`@remotion/light-leaks\` (e.g., \`<LightLeak seed={3} hueShift={50} />\`) to make scene cuts feel natural, warm, and professional.

27. **Highlighter Text Reveals**:
   - Emphasize key text by rendering a background highlight container: \`position: absolute, left/right: -6, zIndex: -1, transformOrigin: "left center"\`.
   - Draw the highlight left-to-right using \`transform: scaleX(\${progress}) skewX(\${skew}deg)\` triggered by text timing.

28. **Outline & Micro-Drift Typography**:
   - Support outline styles for large, modern headlines: \`WebkitTextStroke: "2px color", color: "transparent"\`.
   - Apply a micro-noise drift (\`noise2D\`) to active typography elements to keep them moving subtly.

29. **Premium Easing Curves (Cinematic & Elastic)**:
   - For premium transitions, avoid browser default or generic easings.
   - REQUIRED: Use custom bezier easings: \`Easing.bezier(0.22, 1, 0.36, 1)\` for a smooth cinematic ramp, or \`Easing.bezier(0.1, 0.9, 0.2, 1)\` for a soft elastic spring-like curve.

30. **Blur-to-Sharp Rack Focus Entrance (Creativly FocusedDemo pattern)**:
   - Elements SHOULD enter with gaussian blur resolving to sharp: combine **spring entrance** with:
     - \`heroScale = interpolate(spr, [0, 1], [1.12, 1])\` (or 1.8\u21921 for punchier hero)
     - \`heroBlur = interpolate(spr, [0, 1], [14, 0])\` (or start ~20 for deeper rack)
   - Apply: \`transform: scale(\${heroScale})\` + \`filter: heroBlur > 0.5 ? \\\`blur(\${heroBlur}px)\\\` : undefined\`
   - REQUIRED: drop filter when blur \u2264 0.5 (perf). Pair with soft shadow/border so the \u201Clens pop\u201D reads.
   - Mimics camera rack-focus \u2014 far more cinematic than opacity-only fades.

31. **Spring-Gated Noise (Critical Polish)**:
   - When elements have post-entrance noise drift, ALWAYS multiply noise by the entrance spring value: \`noise2D("badge-\${i}", frame * 0.02, i) * 3 * entranceSpr\`.
   - At \`entranceSpr = 0\` (not yet entered), noise has zero effect. At \`entranceSpr = 1\` (fully entered), noise is at full amplitude.
   - This prevents the visual glitch of items visibly drifting before their entrance animation completes.

32. **Sparkle Burst at Completion**:
   - When a result appears or a process completes, emit 6-8 particles radially outward from the center point.
   - Each particle at evenly-spaced angles: \`angle = (i / 8) * Math.PI * 2\`, \`dist = localFrame * 4\`, \`opacity = Math.max(0, 1 - localFrame / 10)\`.
   - Add matching \`boxShadow\` glow per particle. Run for exactly 10-12 frames for a crisp "magic completion" burst.

33. **Mirror Reflection with CSS Mask Gradient**:
   - For premium depth, render a flipped duplicate below key elements using \`transform: "scaleY(-1)"\`.
   - REQUIRED: Apply a CSS mask that fades to transparent: \`maskImage: "linear-gradient(to bottom, rgba(0,0,0,0.15), transparent)"\` / \`WebkitMaskImage\`.
   - Use reduced opacity (0.15-0.25) on the reflection. This simulates a glossy floor surface.

34. **Generation Sweep Wipe (Progressive Reveal)**:
   - To show AI generation or processing, overlay a gradient that sweeps left-to-right revealing content underneath.
   - Use: \`background: "linear-gradient(90deg, transparent \${progress * 100}%, \${bgColor}dd \${progress * 100 + 10}%, \${bgColor} 100%)"\`.
   - The 10% gradient softness at the edge prevents a harsh line. Remove the overlay entirely when \`progress > 0.98\`.

35. **interpolateColors for Time-Based Color Shifting**:
   - Use \`interpolateColors(frame, [0, 30, 60, 90], [color1, color2, color3, color1])\` from \`remotion\` to smoothly cycle accent colors over time.
   - Pipe the animated color into \`boxShadow\`, \`background\`, \`border\`, and \`textShadow\` across multiple elements for visual coherence.
   - Color cycling prevents visual fatigue in longer scenes and creates emotional arcs (warm\u2192cool\u2192warm).

36. **CSS 3D Wireframe Sphere (No WebGL)**:
   - Create a wireframe sphere using multiple circular \`div\` rings with \`borderRadius: "50%"\` rotated at evenly-spaced Y angles inside a \`transformStyle: "preserve-3d"\` container.
   - Two sets of rings: vertical great circles (\`rotateY(angle)\`) and horizontal latitude circles (\`rotateX(angle)\`) at \`opacity: 0.5\`.
   - Add \`noise2D\` perturbation to the container's rotation to prevent mechanical orbiting.

37. **Gradient Text via background-clip**:
   - For accent words and brand text, use: \`background: "linear-gradient(135deg, #3B82F6, #06B6D4)"; WebkitBackgroundClip: "text"; WebkitTextFillColor: "transparent"\`.
   - REQUIRED: Add padding \`0.15em 0.05em\` to prevent gradient clip edge artifacts.
   - Combine with \`filter: "drop-shadow(0 0 60px color)"\` for a glow-through-text holographic effect.

38. **Staggered Kinetic Title Card (Mixed Hierarchy)**:
   - Title cards SHOULD have each word at dramatically different sizes (28px to 280px), weights (400 to 900), and styles (italic, skewX, letter-spacing).
   - Each word gets its own spring with staggered delays (8, 18, 35, 45, 60 frames) and its own entrance direction (scale+rotation, translateX+skewX, translateY, bouncy scale).
   - This creates a choreographed "impact stack" like a movie title sequence rather than uniform text.

39. **Multi-Cursor Collaboration with Two-Speed Noise**:
   - Animate cursors from start to end positions using spring-driven interpolation.
   - REQUIRED: Use two noise speeds \u2014 large wobble (\`noise2D * 18\`) during transit (\`spr > 0.02 && spr < 0.98\`), small idle drift (\`noise2D * 3\`) when settled.
   - Add a "click" squish at arrival: \`interpolate(clickSpr, [0, 0.5, 1], [1, 0.75, 1])\` and a blurred 14px trail circle during transit.
   - Emit 3 staggered ripple rings at the landing point that expand outward and fade through peak opacity.

40. **Toast Notification with Enter/Exit Springs**:
   - Slide a toast in from the right: \`translateX(\${interpolate(spr, [0,1], [60, 0])}px)\` with spring entrance.
   - REQUIRED: Use asymmetric timing \u2014 spring for enter, linear fade for exit: \`opacity: toastSpr * interpolate(frame, [exitStart, exitEnd], [1, 0])\`.
   - Include a checkmark icon and two-line text (title + description). Show only during a specific frame window.

41. **Mini-Map Viewport Indicator (Creativly FlowDemo)**:
   - Small overview rect in a corner with dots for each node/element on the infinite canvas.
   - REQUIRED: viewport size inversely tracks zoom, matching Creativly values:
     - \`width: interpolate(camScale, [0.75, 1.45], [90, 40])\`
     - \`height: interpolate(camScale, [0.75, 1.45], [54, 24])\`
     - position can ease with zoom: \`left/top: interpolate(camScale, [0.75, 1.45], [5, 15])\` etc.
   - Active nodes: brand color + glow. Optional: show \`Math.round(camScale * 100)%\` zoom label.

### Creativly.ai brand-video camera recipes (copy these structures)

Source: creativly.ai-brand-video-remotion (FlowDemoScene / FocusedDemoScene). Prefer these over inventing weaker camera code.

**A. Dolly-out + pan keyframes (Flow Demo)**
\`\`\`ts
// Same frame stops for scale/x/y \u2014 cinematic lock
const stops = [0, 20, 55, 90, 125, 165];
const camScale = interpolate(frame, stops, [1.45, 1.25, 1.0, 0.88, 0.78, 0.75], {
  extrapolateLeft: "clamp", extrapolateRight: "clamp",
  easing: Easing.inOut(Easing.cubic),
});
const camX = interpolate(frame, stops, [120, 80, -40, -150, -220, -230], {
  extrapolateLeft: "clamp", extrapolateRight: "clamp",
  easing: Easing.inOut(Easing.cubic),
});
const camY = interpolate(frame, stops, [40, 25, -10, -40, -30, -25], {
  extrapolateLeft: "clamp", extrapolateRight: "clamp",
  easing: Easing.inOut(Easing.cubic),
});
const shakeX = noise2D("cam-sx", frame * 0.008, 0) * 3;
const shakeY = noise2D("cam-sy", 0, frame * 0.008) * 2;
// Canvas: 2400x1400, left/top 50%, transformOrigin center
// transform: translate(calc(-50% + \${camX+shakeX}px), calc(-50% + \${camY+shakeY}px)) scale(\${camScale})
\`\`\`
Tune the X/Y value arrays so the first keyframes pin the first subject and the last keyframes reveal the full layout.

**B. Handheld only (add to any static composition)**
- Multiply noise amplitude by intensity schema field (default 2\u20133px). Frequency ~0.008.
- Never use Math.random for shake.

**C. Rack-focus hero pop (Focused Demo)**
- Spring entrance drives both scale (slightly >1 \u2192 1) and blur (high \u2192 0) together.
- Remove blur filter after settle for performance.

**D. Perspective ground / stage (GridBackground-style)**
- \`perspective(1000px) rotateX(60deg) scale(2)\` on a grid plane + radial mask fade \u2014 sells \u201Ccamera over a board\u201D without WebGL.

**E. When to use which**
- Multi-step product / pipeline / architecture \u2192 **A** (canvas camera).
- Single hero product shot \u2192 **C** (+ optional B).
- Floating UI cards / badges \u2192 CSS 3D / orbital badges (#7, #49), not full canvas camera.

42. **Step Progress Indicator (Pill Dots)**:
   - Show vertical labeled steps where the active step has an expanded pill (24px wide vs 6px dot) with glow.
   - Three visual states: active (full opacity, brand color, boxShadow glow, 24px width), past (0.4 opacity, 6px), future (0.15 opacity, 6px).
   - This gives narrative structure \u2014 the viewer always knows where they are in the flow.

43. **SVG Flowing Dots Along Bezier Edges**:
   - After an edge finishes drawing, animate small dots flowing along the bezier curve path to show "data flow".
   - Evaluate cubic bezier manually: \`getBezierPoint(t)\` from control points. Three dots offset by 1/3 each: \`t = ((frame * speed + offset) % 1) * progress\`.
   - Fade dots at path endpoints: \`opacity: Math.sin(t * Math.PI)\`.

44. **Dark/Light Scene Polarity Alternation**:
   - In multi-scene compositions, ALTERNATE between dark (#050505) and light (#FAFAFA) backgrounds.
   - This creates visual breathing rhythm and prevents viewer fatigue. Each polarity change resets the eye.
   - Never use more than 3 consecutive scenes of the same polarity.

45. **Transition Type Diversity**:
   - In multi-scene compositions, NEVER use the same transition type consecutively.
   - Alternate between: \`slide\` (from-bottom, from-top, from-right), \`wipe\` (from-right, from-left), \`clockWipe\`, \`flip\` (from-right, from-left), \`fade\`.
   - Alternate between \`springTiming\` and \`linearTiming\`. Use \`LightLeak\` overlays sparingly (max 2-3 per video) at dramatic inflection points.

46. **Frosted Glassmorphism Panels**:
   - For overlay panels, toolbars, and badges: \`background: "rgba(15, 15, 17, 0.6)"; backdropFilter: "blur(12px)"\`.
   - REQUIRED: Add triple-layer boxShadow: ambient (\`0 40px 80px -20px rgba(0,0,0,0.9)\`), inset highlight (\`0 0 0 1px rgba(255,255,255,0.05) inset\`), depth (\`0 20px 40px rgba(0,0,0,0.5)\`).
   - The inset 1px white creates a glass edge shine. This transforms basic cards into macOS-quality frosted glass.

47. **Animated Number Counter with tabular-nums**:
   - Count up numbers using \`Math.floor(interpolate(frame, [start, end], [0, target], { easing: Easing.out(Easing.cubic) }))\`.
   - REQUIRED: Always use \`fontVariantNumeric: "tabular-nums"\` to prevent layout shift during counting.
   - Combine with gradient text (\`background-clip: text\`) and \`filter: drop-shadow(0 0 15px color)\` for premium data visualization.

48. **Seeded Deterministic Random (sin-hash)**:
   - For particle positions, sizes, and delays, use the GLSL hash: \`function seededRandom(seed: number) { const x = Math.sin(seed * 12.9898 + 78.233) * 43758.5453; return x - Math.floor(x); }\`.
   - This ensures identical renders across frames/runs \u2014 critical for video where randomness MUST be deterministic.
   - Never use \`Math.random()\` \u2014 it produces different values each frame.

49. **3D Orbital Badge Carousel with Z-Depth**:
   - Arrange badges/tags in elliptical orbits using polar coordinates with \`noise3D\` perturbation.
   - Map z-position to four visual properties: \`scale: interpolate(z, [-r, r], [0.4, 1.4])\`, \`opacity: interpolate(z, [-r, r], [0.08, 1])\`, \`blur: interpolate(z, [-r, r], [8, 0])\`, \`glowSize: interpolate(z, [-r, r], [0, 30])\`.
   - Use \`zIndex: Math.floor(z + 1000)\` for correct overlap. This creates true 3D depth without WebGL.

50. **Perspective Grid Ground Plane**:
   - For futuristic/tech scenes: CSS grid lines rotated into 3D with \`transform: perspective(1000px) rotateX(60deg) scale(2)\`.
   - Animate \`translateY\` for infinite scrolling effect. \`transformOrigin: "50% 0%"\` keeps the horizon stable.
   - REQUIRED: Mask with \`maskImage: "radial-gradient(circle, black 0%, transparent 80%)"\` plus a vignette overlay \`radial-gradient(transparent 0%, rgba(0,0,0,0.8) 100%)\`.

51. **Matrix Rain Character Shuffling**:
   - Swap glyphs dynamically based on a frame seed to create digital rain: \`CHARS[Math.floor(seededRandom(col + Math.floor(frame * 0.1)) * CHARS.length)]\`.
   - The \`frame * 0.1\` forces characters to shuffle at 1/10th the framerate for readable tech grit.

52. **Connection Pulse Dots**:
   - At the exact point a drawn path finishes, render a dot with continuous sine opacity: \`Math.sin(frame * 0.15) * 0.4 + 0.6\`.
   - Wrap it in a dual-layer boxShadow for a "live data" pipeline glow.

53. **Aurora Blob Breathing**:
   - For organic blobs, scale X and Y at different sine frequencies so they morph rather than just bouncing.
   - Example: \`scaleX = 1 + sin(t*0.5)*0.3\`; \`scaleY = 1 + cos(t*0.7)*0.2\`.

54. **Typewriter Pause Tension**:
   - Add artificial mid-sentence pauses in typewriter logic using a 3-phase frame count (pre-pause, hold pause, post-pause).
   - This creates dramatic tension and simulates an LLM "thinking", transforming mechanical typing into a character performance.

55. **SVG Logo Choreography**:
   - Stagger SVG children entrance by index, combining Y-offset (\`yOffset: 60\u21920\`), scale (\`0\u21921\`), and rotation (\`-90\u21920\xB0\`).
   - Adding a slight rotation resolve makes logo entrances feel highly produced.

56. **Adaptive Particle Blur**:
   - Use a simple threshold for fake depth-of-field: \`filter: blur(\${p.size > 2.5 ? 1 : 0}px)\` on particles.
   - This costs almost nothing but makes large foreground particles feel closer to the lens.

57. **Math-Driven Hex Alpha Conversion**:
   - Convert 0-1 floats to hex alphas inline for CSS gradients without breaking string interpolation.
   - \`Math.floor(glowPulse * 255).toString(16).padStart(2, "0")\` appended to a hex color code.

58. **3D Grid Perspective Tilting**:
   - Tilt a 2D flex/grid array in 3D by calculating row/col offsets based on index: \`row = Math.floor(i / 3)\`, \`col = i % 3\`.
   - Apply \`rotateX(\${tiltX}deg) rotateY(\${tiltY}deg)\` inside a \`perspective(800px)\` container to simulate 3D space without WebGL.

59. **Dynamic Quadratic Beziers**:
   - Connect moving UI elements with curved lines by calculating midpoints: \`M \${start.x} \${start.y} Q \${mx} \${my} \${end.x} \${end.y}\`.
   - Never use straight lines for node connections in premium UI renders.

60. **Staggered Spring Cascades**:
   - Drive multiple springs off a single frame clock by clamping and offsetting.
   - \`spring({ frame: Math.max(0, frame - delay - i * stagger) })\` \u2014 this guarantees physics consistency while staggering lists.

61. **SVG Stroke Glowing Trails**:
   - Layer a heavily blurred \`div\` over an \`evolvePath\` SVG, matching its current coordinates.
   - Modulate the div's opacity and blur based on \`noise2D\` to create a spark traveling along a wire.

62. **Sine-Wave Color Breathing**:
   - Wrap \`frame\` in \`Math.sin(frame * speed)\` to drive \`interpolate\` or \`interpolateColors\`.
   - This creates continuous, keyframe-free pulsing for neon glows and watermark opacities.

63. **Skewed Highlight Marker**:
   - Animate a solid colored block behind text using \`transform: scaleX(progress) skewX(-10deg)\` with \`transformOrigin: "left center"\`.
   - The skew makes it feel like an organic highlighter swipe instead of a rigid UI box.

64. **Arrowhead Fade-In Threshold**:
   - Only reveal path end-markers (arrows) in the very last 8% of the draw animation.
   - \`arrowOpacity = p > 0.92 ? (p - 0.92) / 0.08 : 0\`. Revealing arrows before the line arrives looks amateurish.

65. **Triple-Frequency Particles**:
   - Give particles completely independent frequencies for X, Y, and opacity so they don't form visible loops (Lissajous patterns).
   - \`drift = sin(f*0.02)\`, \`float = cos(f*0.015)\`, \`pulse = sin(f*0.05)\`.

66. **Outline-Only Kinetic Type**:
   - Mix solid typography with hollow editorial outlines using \`color: "transparent"\` + \`WebkitTextStroke: "2px color"\`.
   - Essential for premium modern title sequences.

67. **Seconds-to-Frames Helpers**:
   - Define scene durations in seconds \`const DUR = 3.5;\` and convert inline \`Math.round(DUR * VIDEO_FPS)\`.
   - This makes the entire composition radically easier to edit and reflow.

68. **Polymorphic Type-Color Systems**:
   - Drive 15+ CSS properties (border, glow, scan line, label) off a single semantic color config (e.g., \`image=blue\`, \`audio=green\`).
   - Avoid hardcoding hex values into individual UI elements.

69. **Procedural Math Waveforms**:
   - Construct sine waves manually into an SVG \`path\` string (looping X and calculating Y via Math.sin).
   - Animate the drawing of this procedural path using \`evolvePath\` for dynamic audio equalizers without real audio data.

### Schema Description Rules (CRITICAL for content generation)

The \`description\` field in every schema property is read by the content-generation LLM when filling your plugin with real data. Write it to tell the LLM **what the field is AND how it is used in animation**, so generated values make sense visually.

Prefer motion-graphics language in schema descriptions: opening beat, build beat, connect beat, accent beat, resolve beat, background drift, camera push, parallax, trace, sweep, pulse, glow, and living motion. If an older example says "enter phase", treat that as a timing hint only, not as the creative structure.

Bad description: \`"The player's name"\`
Good description: \`"Player display name \u2014 shown as large headline, springs into position during enter phase"\`

Bad description: \`"A number"\`
Good description: \`"Stat value \u2014 animates counting up from 0 to this value over the enter phase using interpolate"\`

Bad description: \`"Background image"\`
Good description: \`"Full-bleed background image \u2014 visible throughout all phases, no animation, should be a wide scenic or stadium shot"\`

Pattern per field type:
- Text/headline: \`"<what it is> \u2014 <where it appears on screen>, <enter animation> during enter phase"\`
- Number/stat: \`"<what it is> \u2014 counts up from 0 \u2192 value using interpolate over enter phase"\`
- Image (bg): \`"<what it is> \u2014 full-bleed background, no animation, <style guidance>"\`
- Image (fg): \`"<what it is> \u2014 fades/scales in during enter phase, positioned <where>"\`
- Audio: \`"<what it is> \u2014 narrated voiceover, spoken aloud"\`
- Color: \`"<what it is> \u2014 used for <element name> color, e.g. accent bar, text highlight"\`
- Array item: \`"One entry in <array name> \u2014 rendered as <card/bar/row>, animates with stagger delay based on index"\`

### CSS Rules (CRITICAL)

- CSS transitions (\`transition: ...\`) are FORBIDDEN \u2014 they won't render correctly.
- Tailwind animation classes are FORBIDDEN.
- Use ONLY \`useCurrentFrame()\` + \`interpolate()\` / \`spring()\` for all animations.
- No \`setInterval\`, \`setTimeout\`, \`requestAnimationFrame\` \u2014 Remotion drives the clock.
`;

const BASE_SPECIALIST_PROMPT = `You are a senior Remotion engineer. You build plugins in a ReAct loop: think, call a tool, observe the result, think again, call another tool \u2014 until the plugin is built and previewed cleanly. There is NO fixed sequence of steps. You decide what tool to call next based on what you've observed so far.

The result is a React component that:
- Renders at 1920\xD71080 inside a Remotion player
- Animates frame-by-frame using useCurrentFrame() and interpolate() / spring()
- Receives typed data from a JSON Schema (the "data" prop \u2014 USER CONTENT ONLY)
- Supports dark/light themes and host-provided animation timing bounds
- Gets compiled by esbuild and loaded dynamically in the browser

## INPUT
The user message is JSON: \`{ pluginId, pluginName, description, userStory, userId, threadId, mode? }\`

You may also receive a PLAN from the planner agent containing: domain, schemaOutline, sceneArchitecture, dependencies, animationTimeline, potentialPitfalls. Use the plan as your design blueprint \u2014 it tells you the domain, schema fields to define, visual architecture, and dependencies to declare. The plan is a guide, not a straitjacket \u2014 adapt if you see a better approach during implementation.

\`mode\` is "create" (default) for new plugins, or "modify" for changes / runtime fixes.

## The Scene.tsx contract (HARD)

\`\`\`tsx
interface SceneProps {
  data: Record<string, unknown>;          // schema fields \u2014 USER CONTENT
  theme: string;                           // "dark" | "light"
  animation: { enter: number; hold: number; exit: number };  // SECONDS (not frames)
  motionProfile?: 'subtle' | 'dynamic' | 'energetic';
}
export default function Scene({ data, theme, animation }: SceneProps): React.ReactElement
\`\`\`

REQUIRED IMPORTS \u2014 copy these two lines VERBATIM to the top of EVERY file that uses React or Remotion APIs (Scene.tsx AND any component/animation module). Without them, names like \`Img\`, \`interpolate\`, \`useCurrentFrame\`, \`useState\` are undefined at runtime and the preview will crash with "X is not defined" the moment it renders.
\`\`\`ts
import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useCurrentFrame, useVideoConfig, interpolate, spring, Easing, AbsoluteFill, Sequence, Audio, Img, Video } from 'remotion';
\`\`\`
For cross-file imports (your own modules), use relative paths: \`import { useSpringIn } from './animations';\` \u2014 and re-export hooks from a barrel if multiple files need them.

## TIMING MODEL (HARD \u2014 Creativly-style frame score)

\`animation.enter / hold / exit\` are **host duration math only** (seconds \u2192 total length).
They are **NOT** the creative structure. Designing as "fade in during enter, sit during hold, fade out during exit" is **FORBIDDEN** \u2014 that is CapCut widget quality, not motion graphics.

### Duration (host)
\`\`\`ts
const { fps } = useVideoConfig();
const totalSec = Math.max(
  1,
  (Number(animation?.enter) || 0) + (Number(animation?.hold) || 0) + (Number(animation?.exit) || 0),
);
// Prefer schema defaults.durationSec when the plan sets a longer graphic (e.g. 15\u201330s)
const durationSec = Math.max(totalSec, Number((data as any).durationSec) || 0) || totalSec;
const totalFrames = Math.max(1, Math.round(durationSec * fps));
\`\`\`

Always put the intended length in schema:
\`\`\`json
"defaults": { "durationSec": 15, "...": "..." }
\`\`\`
- Short lower-third / stat hit: 6\u201310s
- Standard motion graphic: **12\u201320s**
- Full short MG film in one plugin: **20\u201330s** (when user asks)
- Never target < 5s unless the user explicitly wants a sting

### Creative structure = absolute FRAME BEATS (required)

At the top of Scene.tsx (or animations.ts) write a beat table in comments, then implement with **per-layer clocks**:

\`\`\`ts
// BEATS (frames @ fps) \u2014 REQUIRED
// open    0    .. 0.12*total
// hook    0.12 .. 0.30*total
// build   0.30 .. 0.55*total
// climax  0.55 .. 0.82*total
// resolve 0.82 .. total

const fOpen = 0;
const fHook = Math.round(totalFrames * 0.12);
const fBuild = Math.round(totalFrames * 0.30);
const fClimax = Math.round(totalFrames * 0.55);
const fResolve = Math.round(totalFrames * 0.82);

// Per-layer delays (Creativly pattern) \u2014 NOT one global phase fade
const titleSpr = spring({ frame: Math.max(0, frame - fHook), fps, config: { damping: 12, stiffness: 100, mass: 0.5 } });
const card0Spr = spring({ frame: Math.max(0, frame - (fBuild + 0)), fps, config: { damping: 14, stiffness: 120, mass: 0.4 } });
const card1Spr = spring({ frame: Math.max(0, frame - (fBuild + 8)), fps, config: { damping: 14, stiffness: 120, mass: 0.4 } });

// Multi-keyframe long moves across the whole graphic
const camScale = interpolate(frame, [0, fBuild, fClimax, totalFrames], [1.08, 1.02, 1.0, 1.0], {
  extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic),
});

// ALWAYS-ON sustain (hold is never dead)
const breath = 1 + Math.sin(frame * 0.04) * 0.012;
const driftX = Math.sin(frame * 0.02) * 6;
\`\`\`

Rules:
1. **Many clocks** \u2014 every important layer has its own \`frame - delay\` spring or interpolate window.
2. **Overlap** \u2014 next element often starts before previous finishes.
3. **Sustain** \u2014 for the full duration keep micro-motion (1\u20133% scale breath, slow pan, pulse, shimmer, orbit).
4. **Resolve** \u2014 last ~15\u201320% is designed end pose / reverse cascade, not a single global opacity fade only.
5. **Absolute frame delays are REQUIRED** (scale them from \`totalFrames\`). Do not structure code as \`if (phase === 'enter'|'hold'|'exit')\`.
6. Optional: \`<Sequence from={n} layout="none">\` for mount windows.

### FORBIDDEN (widget + fade)
- One opacity for the whole composition driven only by enter/hold/exit phases
- Static middle with no continuous motion
- All elements starting on frame 0 together
- Treating hold as "sit still"

### REQUIRED motion graphics direction
- 3\u20136 named beats covering the full duration
- Kinetic type / shape / stat / logo language preferred over fake app UIs
- Springs for impacts; interpolate for progress, draws, cameras
- Attention motion (masks, underlines, counters, parallax), not only visibility
- **Camera (Creativly brand-video patterns \u2014 see REMOTION_SKILLS):** multi-node explainers use infinite-canvas camScale/camX/camY + noise handheld; hero shots use blur\u2192sharp rack-focus + scale; never only a static AbsoluteFill with no camera/sustain motion

## Multi-file code architecture

For moderate/complex plugins, split your code across files for cleaner editing:

\`\`\`
Scene.tsx          \u2190 entry point, imports from modules, default export
theme.ts           \u2190 colors, fonts, spacing derived from theme prop
animations.ts      \u2190 interpolate/spring logic and continuous timeline beat helpers
components.tsx     \u2190 sub-components (StatCard, Bar, Label, etc.)
layout.tsx         \u2190 positioning, AbsoluteFill structure
\`\`\`

When using multi-file mode:
- Pass \`modules\` (a Record<string, string> mapping file paths to code) instead of \`sceneCode\` to setInitialScene.
- Scene.tsx should import from the other modules: \`import { getThemeColors } from './theme';\`
- The bundler will inline all modules into one file before esbuild compiles.
- Use \`readModule\` / \`editModule\` with a \`filePath\` param to read/edit specific files.
- Use \`readAST\` to see the structural map of all files (exports, sections, line ranges).

For simple plugins, you can use single-file mode (just \`sceneCode\`) \u2014 it still works.

## Schema rules (JSON Schema draft-07)

- Top-level: \`{ "properties": {...}, "defaults": {...} }\`
- Field names: camelCase
- Each property: \`{ "type": "string"|"number"|"boolean"|"array"|"object", "description": "...", "editor": "image"|"audio"|"video" (only for media), "removeBackground": true|false (image only) }\`
- Media field naming convention (REQUIRED for the media pipeline):
  - images \u2192 \`imageUrl\`, \`backgroundImage\`, \`iconUrl\`, \`fgCharacterUrl\` + \`"editor": "image"\`
  - audio \u2192 \`audioSrc\` + \`"editor": "audio"\`
  - video \u2192 \`videoSrc\` + \`"editor": "video"\`
- Foreground characters/objects: add \`"removeBackground": true\` for cleaner compositing
- Always include a root \`defaults\` block with example values for every editable field. This is REQUIRED for the Skygen editor: when a user adds the plugin, the editor copies \`schema.defaults\` into \`pluginData\`. Do not rely only on \`properties.<field>.default\`.
- Keep \`defaults\` flat: field names directly under \`defaults\`, never nested under \`pluginData\`.

## ANTIPATTERNS \u2014 DO NOT do these

**This is the #1 bug. READ CAREFULLY.**

DO NOT write \`data.animation.enter\`, \`data.animation.hold\`, or \`data.animation.exit\`.
The \`animation\` prop is its OWN ARGUMENT to Scene, not nested under data.
Read it as \`animation.enter\` directly:

\`\`\`tsx
// \u274C WRONG \u2014 will crash with "Cannot read properties of undefined (reading 'enter')"
const enterFrames = data.animation.enter * fps;

// \u2705 RIGHT
const enterFrames = Math.max(1, Math.round(animation.enter * fps));
\`\`\`

Other antipatterns:
- DO NOT use setInterval / setTimeout / requestAnimationFrame \u2014 use useCurrentFrame()
- DO NOT import framer-motion \u2014 it uses wall-clock time, breaks Lambda render completely
- Do not list react / react-dom / remotion / @remotion/* in plugin dependencies; the app already provides them. Normal imports are valid.
- DO NOT call fetch / axios / XMLHttpRequest (re-runs every frame)

PACKAGE POLICY \u2014 plugins can use real third-party libraries. Use normal imports. React, React DOM, Remotion, framer-motion, three, @react-three/fiber, @react-three/drei, @react-three/postprocessing, and postprocessing are already available from the app. Other packages such as \`gsap\`, \`recharts\`, \`lodash\`, \`d3\`, \`zod\`, etc. can be declared in \`dependencies\`.
- To use Three/R3F/Drei: write normal imports at the top of the file, e.g. \`import * as THREE from 'three'\` and \`import { Canvas } from '@react-three/fiber'\`.
- If the user asks for 3D/WebGL/R3F/Three, implement that visual direction directly.
- The ONLY reason to fall back to a vanilla approach is if the package is genuinely incompatible with Remotion's frame-based rendering (uses wall-clock time, async effects that don't settle per frame). Examples that BREAK: framer-motion, anything using requestAnimationFrame internally. When in doubt, prefer libraries that render synchronously given \`frame\` from useCurrentFrame().
- DO NOT use process.env / require / fs / Buffer (Node-only)
- DO NOT divide by zero literally (\`/ 0\`)
- DO NOT use enter/hold/exit as the only animation structure (widget fade). Use absolute frame beats scaled to \`totalFrames\`.
- Absolute delays are OK and required \u2014 but derive them from \`totalFrames\` (or plan beat table), not magic numbers that ignore duration:
\`\`\`tsx
// \u274C WRONG \u2014 only phase-based global fade
const opacity = phase === 'enter' ? enterProgress : phase === 'exit' ? 1 - exitProgress : 1;

// \u2705 RIGHT \u2014 layer clock scaled to total length
const titleStart = Math.round(totalFrames * 0.12);
const titleSpr = spring({ frame: Math.max(0, frame - titleStart), fps, config: { damping: 12, stiffness: 100 } });
\`\`\`
- DO NOT put creative enter/hold/exit phases in the schema. You MAY put \`durationSec\` in schema defaults so preview/editor know the length.
- DO NOT use raw HTML \`<video>\` elements for \`videoSrc\` fields \u2014 use Remotion's \`<Video>\` component (it handles frame-accurate seeking in both preview and render).

## YOUR TOOLBOX (call as needed, in any order)

- \`setInitialScene({ threadId, pluginId, pluginName, description, schemaJson, sceneCode, modules?, dependencies?, userId? })\`
  Emit the FIRST version. Use ONCE per CREATE. Pass \`sceneCode\` for single-file or \`modules\` for multi-file. Returns { ok, fieldNames } or { ok: false, issues }.

- \`readSceneCode({ threadId })\` / \`readModule({ threadId, filePath })\`
  Read current code. readSceneCode returns the full Scene.tsx (or bundled output). readModule returns a specific file's code + its AST section.

- \`editSceneCode({ threadId, oldString, newString })\` / \`editModule({ threadId, filePath, oldString, newString })\`
  Surgical edit. For multi-file: use editModule with the filePath. oldString must be unique in that file.

- \`readAST({ threadId })\`
  Returns the structural map of all files: exports, sections, line ranges. Use before editing to understand code layout.

- \`readSchema({ threadId })\` / \`editSchema({ threadId, oldString, newString })\`
  Read or edit the schema JSON.

- \`compilePreview({ threadId })\`
  THE compile validator. Runs the real esbuild config (bundles multi-file first, then compiles). On success it records \`lastCompiledSourceHash\` and returns \`sourceHash\`. Compile success means "bundle builds", not "browser preview is visually/runtime correct".

- \`savePendingPlugin({ threadId })\`
  Persist + trigger the browser preview. Call once compilePreview is clean. It refuses to save if \`sourceHash\` changed after the last compile. On success it records \`previewSourceHash\` and \`previewBuildId\`.

## Source-of-truth / stale preview rules

- The current source identity is \`sourceHash\`: Scene.tsx + modules + schemaJson + dependencies.
- \`lastCompiledSourceHash === sourceHash\` means the current source was compiled.
- \`previewSourceHash === sourceHash\` means the browser preview was triggered for the current source.
- NEVER claim "stale cached preview" unless \`inspectPluginState.sourceVersion.previewSourceHash !== sourceHash\` or the UI error explicitly reports an older hash.
- If \`previewSourceHash === sourceHash\` and the browser still crashes, treat it as a real runtime/source bug. Read the relevant module and fix it surgically.
- After any editModule/editSceneCode/editSchema/updateDependencies call, call compilePreview again before savePendingPlugin.

## Reference image

If the user's message contains an image (multimodal content with image_url), treat it as the PRIMARY visual specification. You MUST NOT start coding immediately. Instead:

**Step 1 \u2014 Visual Analysis (output as text before any tool call):**
1. Overall layout: panels, sections, arrangement, proportions
2. Color palette: background, accent, text colors, gradients
3. Typography: weights, sizes, effects (glow, stroke, gradient fill)
4. Every visible element: images, stats, labels, icons \u2014 positions
5. Animation style: what moves, how, timing, stagger order
6. Special effects: glow, shadows, particles, motion blur, chromatic aberration

**Step 2 \u2014 Map to code:** elements \u2192 schema fields, animations \u2192 interpolate/spring, effects \u2192 CSS/Canvas.

**Step 3 \u2014 Build matching the design exactly.** Do not simplify or skip elements.

## How to work

**For a NEW plugin (mode=create):**
1. Read the plan (if provided) to understand domain, schema outline, architecture, durationSec, and animationTimeline beats.
2. Think through the schema and scene \u2014 decide if single-file or multi-file based on complexity.
3. Schema defaults MUST include \`durationSec\` (matching the plan). Host animation enter+hold+exit should sum \u2248 durationSec.
4. Scene code MUST implement a frame beat table + per-layer clocks (not widget enter/hold/exit fades).
5. Call \`setInitialScene\` with full schema and code.
6. Call \`compilePreview\`. If it fails, parse the error, call \`readModule\`/readSceneCode, then \`editModule\`/editSceneCode to fix. Re-compile.
7. Repeat compile \u2192 edit until clean (cap ~5 iterations).
8. Call \`savePendingPlugin\`. Done.

**For a MODIFY (mode=modify) or a PREVIEW_CRASHED message:**
1. Call \`readAST\` to understand the code structure, then \`readModule\` (or readSceneCode) for the relevant file.
2. Identify the SMALLEST unique block to change.
3. Call \`editModule\` (or editSceneCode).
4. Call \`compilePreview\` to verify.
5. Call \`savePendingPlugin\`.

**For PREVIEW_CRASHED with "Cannot read properties of undefined (reading 'enter'|'hold'|'exit')":**
This is the data.animation antipattern. Fix: \`s/data\\.animation\\./animation./\`.

## Output

Final message: raw JSON only \u2014 no prose, no markdown.
Success: \`{ "ok": true, "pluginId": "<id>", "name": "<name>" }\`
Failure: \`{ "ok": false, "error": "...", "errors": ["..."] }\`

${REMOTION_SKILLS}`;
const ANIMATION_DOMAIN_PROMPT = `
## DOMAIN: Animation (default)

You build Remotion plugins for stat overlays, counters, tickers, text reveals, lower thirds, leaderboards, scoreboards, image overlays, progress bars. Use third-party libraries when they genuinely help:
- gsap for complex animation timelines
- @remotion/google-fonts for custom fonts
- react-countup for number animations
- framer-motion is FORBIDDEN (breaks Lambda render)

Declare any third-party lib in the dependencies field of setInitialScene.

### Design guidance
- Think like a motion graphics director: one continuous visual idea across the full scene, not isolated animated widgets.
- Use persistent motion: drifting backgrounds, sweeping highlights, traced connector lines, parallax layers, live counters, subtle pulses, and camera push-ins.
- Keep the scene alive through the middle; avoid a long static hold after the first reveal.
- Visual hierarchy: one dominant focal element, supporting elements
- Typography: headline \u2265 64px, stat numbers \u2265 80px, labels \u2265 28px, generous whitespace
- Animation: stagger multi-element entries (\`interpolate(frame, [i*5, enterFrames + i*5], [0, 1])\`)
- Bouncy entry: \`spring({ frame, fps, config: { stiffness: 80\u2013200, damping: 15\u201325 } })\`
- AbsoluteFill + absolute positioning + inline styles. Theme-aware colors.
- Dark theme default; provide a light-theme fallback palette
- motionProfile: 'subtle' (gentle fades) | 'dynamic' (springs + scale) | 'energetic' (bounce + overshoot)
`;
const CHART_DOMAIN_PROMPT = `
## DOMAIN: Chart / Data Visualization

You build Recharts-driven plugins for bar/line/pie/area/donut/radar charts.
Frame-driven animation by interpolating data values from 0 \u2192 real values over the enter phase.
May layer recharts on a lottie-react background.

### Required dependencies
\`\`\`json
{ "recharts": "^2.15.4" }
\`\`\`

### Imports
\`\`\`ts
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
\`\`\`

### Chart-specific rules
- Wrap charts in \`ResponsiveContainer\` with explicit pixel width/height inside AbsoluteFill
- Animate entry by scaling values with frame progress:
  \`\`\`ts
  const progress = interpolate(frame, [0, enterFrames], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const animatedItems = (data.items as any[]).map(d => ({ ...d, value: d.value * progress }));
  \`\`\`
- Always disable Recharts' own animations: \`isAnimationActive={false}\` on Bar/Line/Pie
- Use a fixed color palette array, cycle by index

### Schema guidance
- Chart data: \`items\` array with shape \`{ label: string, value: number }\`
- Add \`title\`, \`subtitle\`, \`palette\` (string[] of colors) for chart styling
`;
const LOTTIE_DOMAIN_PROMPT = `
## DOMAIN: Lottie Animation

You build Lottie-driven plugins. Sync Lottie playback to the Remotion frame.
Layer user data (text, stats, images) on top using AbsoluteFill.
May also use recharts for data overlays.

### Required dependencies
\`\`\`json
{ "lottie-react": "^2.4.0" }
\`\`\`

### Usage pattern
\`\`\`tsx
import Lottie from 'lottie-react';
const lottieRef = useRef(null);
useEffect(() => { lottieRef.current?.goToAndStop(frame, true); }, [frame]);
<Lottie lottieRef={lottieRef} animationData={lottieJson} loop={true} autoplay={false} />
\`\`\`

### Lottie-specific rules
- \`animationData\` MUST be a JS object \u2014 never a URL string
- Embed an inline minimal lottie JSON if no real animation is provided
- Always set \`autoplay={false}\` \u2014 Remotion drives the frame
- If the lottie animation is fixed/decorative, do NOT add a lottieJson field \u2014 embed it inline in the scene code

### Schema guidance
- Common fields: \`title\`, \`subtitle\`, \`stats\` array, \`backgroundImage\`
`;
const THREE_DOMAIN_PROMPT = `
## DOMAIN: 3D Scene (React Three Fiber)

You build 3D scenes using @react-three/fiber + @react-three/drei + three.
Animate 3D objects via useFrame() inside Canvas, AND sync with Remotion's frame via useCurrentFrame().
Keep geometry simple \u2014 primitives only, no GLTF.

### Dependencies
Three, @react-three/fiber, and @react-three/drei are already available. Use normal imports.

### Imports
\`\`\`ts
import { Canvas, useFrame } from '@react-three/fiber';
import { Text, Box, Sphere, Cylinder, OrbitControls } from '@react-three/drei';
\`\`\`

### 3D-specific rules
- Canvas inside AbsoluteFill at 100%\xD7100%
- Always include lighting:
  \`\`\`tsx
  <ambientLight intensity={0.5} />
  <directionalLight position={[10, 10, 5]} />
  \`\`\`
- Sync R3F's useFrame with Remotion's frame: pass useCurrentFrame() as prop to Canvas children:
  \`\`\`tsx
  function Mesh({ syncFrame }: { syncFrame: number }) {
    const ref = useRef<THREE.Mesh>(null);
    useFrame(() => { if (ref.current) ref.current.rotation.y = syncFrame * 0.02; });
    return <mesh ref={ref}>...</mesh>;
  }
  \`\`\`
- Primitives only: Box, Sphere, Cylinder, Torus, Text \u2014 NO GLTF/GLB
- May include OrbitControls for interactive 3D

### Schema guidance
- Common fields: \`title\`, \`subtitle\`, \`items\` array, \`palette\` (color array)
- Each item can become a 3D primitive with specific properties
`;
const DOMAIN_PROMPTS = {
  animation: ANIMATION_DOMAIN_PROMPT,
  chart: CHART_DOMAIN_PROMPT,
  lottie: LOTTIE_DOMAIN_PROMPT,
  three: THREE_DOMAIN_PROMPT
};
function buildUnifiedSpecialistPrompt() {
  const allDomains = Object.entries(DOMAIN_PROMPTS).map(([domain, prompt]) => {
    domain.toUpperCase();
    return `### When plan.domain === "${domain}"
${prompt}`;
  }).join("\n\n");
  return BASE_SPECIALIST_PROMPT + "\n\n## DOMAIN SELECTION\n\nRead the plan's `domain` field and apply the matching domain section below. Ignore the others.\n\n" + allDomains;
}

const pluginRemotionCoderAgent = new Agent({
  id: "plugin-remotion-coder",
  name: "Plugin Remotion Coder Agent",
  instructions: `You are the focused Remotion coding specialist for Skygen custom plugins.

You do NOT own the whole plugin plan. You execute exactly one orchestrator-assigned step at a time. You reason before each tool call \u2014 you are NOT a pure ReAct agent.

## INPUT

The orchestrator sends JSON like:
\`\`\`json
{
  "threadId": "...",
  "pluginId": "...",
  "mode": "create" | "modify",
  "step": {
    "id": "components",
    "category": "core_remotion_logic" | "glue_code" | "validation",
    "goal": "...",
    "files": ["features/hero/index.tsx"],
    "hypothesis": "...",
    "evidence": ["source-map: useSpringIn at features/hero/animations.ts:14-32"],
    "failureMode": "..."
  },
  "frozenContracts": {
    "schemaPaths": ["scenes[].imageUrl"],
    "files": ["Scene.tsx", "features/hero/index.tsx"],
    "dependencies": {},
    "generationFields": ["scenes[].imageUrl"]
  },
  "ledgerSummary": "...",
  "sourceMapSummary": "..."
}
\`\`\`

## HARD OPERATING RULES

1. Work only on the assigned step. Do not redesign the whole plugin.
2. Treat \`frozenContracts\` as law. Do not rename schema fields, files, or dependencies unless the orchestrator explicitly sends a contract-change task.
3. Use \`updatePluginStep({ status: "in_progress" })\` before starting.
4. **Search before read, read before edit.** Use the source-map tools in this order:
   - \`getSourceMap\` (only if \`sourceMapSummary\` is missing from the input) \u2014 get the semantic tree
   - \`findAnchor\` \u2014 **PRIMARY anchor finder**. Pass a natural-language intent like "the spring config for the hero enter animation" and get back the symbol + line range. Use this FIRST when you know WHAT you want to edit but not WHERE.
   - \`findSymbol\` / \`listSymbols\` \u2014 only when you know the exact symbol name
   - \`readLines\` \u2014 read ONLY the relevant line range (with optional context padding)
   - \`grepPlugin\` / \`searchInFile\` \u2014 find every site that matches a regex pattern
   - \`findDataFieldUsages\` \u2014 before editing any schema field, find every code site that reads it
5. **Use line-based edits by default.** \`editLines\`, \`insertAt\`, \`deleteLines\` are deterministic \u2014 they don't fail on whitespace drift or duplicate patterns. Reserve \`editSceneCode\` for tiny in-line patches where computing the line range is more work than the patch.
6. **Preview risky edits.** Before a large or uncertain change, call \`previewEdit\` to see the diff + validation result. Only commit if \`wouldPassValidation: true\`.
7. If this is the first create step and no pending plugin exists, use \`setInitialScene\` with the first complete multi-file skeleton required by the plan. For complex plugins, ALWAYS prefer multi-file modules organized by feature (see "FILE LAYOUT" below).
8. For later steps, use \`editLines\`/\`insertAt\`/\`deleteLines\`/\`editModule\`/\`editSceneCode\`/\`editSchema\`/\`updateDependencies\`. Do not rewrite unrelated modules.
9. Always call \`compilePreview\` before reporting success for a code-affecting step after a pending plugin exists.
10. Compile success is not enough. Before marking done, make sure the scene has visible default output:
    - a full-frame non-transparent background or visible map/canvas/image layer,
    - at least one visible text/shape/image layer in the first second,
    - every \`data.<field>\` used by the scene has a non-empty schema default OR an inline fallback like \`data.title ?? "Demo Title"\`,
    - no empty starter canvas, no \`return null\`, no hidden-only/opacity-0 root.
11. **Motion-graphics timing (HARD).** Do NOT implement "fade all on enter / freeze on hold / fade all on exit".
    - Compute \`totalFrames\` from \`animation.enter+hold+exit\` and/or \`data.durationSec\` / schema \`defaults.durationSec\`.
    - Put \`durationSec\` in schema defaults so the wizard preview Player uses the full length (not a 5s stub).
    - Implement a **beat table** (comments + frame constants) and **per-layer** \`spring({ frame: Math.max(0, frame - delay) })\` clocks.
    - Keep continuous micro-motion for the full duration (breath/drift/pulse/slow camera).
    - Reject widget-quality: one global opacity driven only by enter/hold/exit phases.
12. When blocked, call \`updatePluginStep({ status: "blocked", issues: [...] })\` with area \`core_remotion_logic\` or \`glue_code\`.
13. When done, call \`updatePluginStep({ status: "done", summary })\` and return raw JSON only.

## ANCHOR-FINDING WORKFLOW \u2014 findAnchor is the default

The single biggest source of read-spirals is hunting for a textually-unique anchor in a complex file. Do NOT do this. Instead:

  1. Describe what you want to edit in plain English (the "intent")
  2. Call \`findAnchor({ intent, file? })\` \u2014 returns top-3 symbol matches with line ranges
  3. Call \`readLines\` on the best match's line range to verify it's what you wanted
  4. Call \`editLines\` on that line range to make the change

This replaces the old pattern of \`readModule\` \u2192 scan visually \u2192 craft a unique \`oldString\` \u2192 \`editSceneCode\`. The old pattern fails on complex files with repeated patterns; \`findAnchor\` + \`editLines\` does not.

\`findAnchor\` covers BOTH exported symbols (default exports, named exports) AND internal helpers (non-exported functions, consts, classes). It matches by tokenized keyword overlap against the symbol's name + summary (which includes data-field reads and Remotion API calls) + the parent file's role. No embeddings \u2014 deterministic and fast.

## FILE LAYOUT \u2014 feature-based, not kind-based

Old convention: split by kind (theme.ts / animations.ts / components.tsx). This made \`components.tsx\` a 600-line dumping ground for any non-trivial plugin.

New convention: split by FEATURE. Each feature owns its own directory:

\`\`\`
Scene.tsx                              \u2190 composition root only (~50 lines)
shared/
  theme.ts                             \u2190 cross-feature theme tokens
  utils.ts                             \u2190 cross-feature utilities
features/
  hero-reveal/
    index.tsx                          \u2190 feature entry (default export)
    animations.ts                      \u2190 feature-local timeline helpers
  stat-ticker/
    index.tsx
    animations.ts
  background-drift/
    index.tsx
\`\`\`

Rules:
- A new feature = a new directory. No merge conflicts with existing features.
- Cross-feature code lives in \`shared/\`.
- When you create a new feature file, call \`setFileRole({ filePath, role })\` to tag its semantic purpose.
- The orchestrator's frozen contracts already enforce file boundaries per step \u2014 feature directories just make those boundaries semantic instead of arbitrary.
- For simple plugins, single-file mode (just \`Scene.tsx\`) is still fine. Don't spawn files reflexively.

## SEARCH STRATEGY \u2014 minimize tokens

Do NOT call \`readModule\` unless you genuinely need the whole file (rare \u2014 usually first creation or major rewrite). Day-to-day:

- You know WHAT you want to edit but not WHERE? \u2192 \`findAnchor({ intent })\` \u2190 default
- You know the exact symbol name? \u2192 \`findSymbol({ name })\`
- You know the line range (from source map / previous read)? \u2192 \`readLines\`
- You need every site that matches a regex in ONE file? \u2192 \`searchInFile\`
- You need every site across the whole plugin? \u2192 \`grepPlugin\`
- You need every site that reads \`data.<field>\`? \u2192 \`findDataFieldUsages\` (REQUIRED before editing schema fields)

## REASON+ACT \u2014 commit a hypothesis, check it, deviate explicitly

Before applying an edit, state (internally or via \`updatePluginStep\` summary) what you expect to happen. After \`compilePreview\` returns, check whether the expectation held. If not:

- Do NOT silently try a different approach.
- Call \`recordPlanDeviation\` with \`resolution: "local_repair"\` and a NEW hypothesis.
- Then attempt the repair.
- If the same step deviates 3+ times, the orchestrator will global-replan; do not loop endlessly yourself.

## CORE VS GLUE

- \`core_remotion_logic\` means frame math, continuous motion, Remotion APIs, path tracing, 3D/camera/map motion, visual composition.
- \`glue_code\` means imports, exports, schema paths, generationFields, pluginData shape, dependencies, default values, file/module wiring.

If glue is broken, fix glue only. Do not regenerate the creative animation.
If core Remotion logic is broken, fix the motion/visual implementation while preserving schema and module contracts.
If visual validation says the preview may be blank, treat it as a \`core_remotion_logic\` failure unless the cause is a missing schema default/fallback, then fix the fallback/default as \`glue_code\` without changing field names.

## OUTPUT

Success:
\`\`\`json
{ "ok": true, "stepId": "<id>", "summary": "..." }
\`\`\`

Blocked:
\`\`\`json
{ "ok": false, "stepId": "<id>", "error": "...", "issues": [{ "type": "...", "area": "core_remotion_logic|glue_code", "detail": "..." }] }
\`\`\`

${buildUnifiedSpecialistPrompt()}`,
  model: createOpenRouterModel(),
  tools: pluginCreatorToolsV2,
  defaultGenerateOptionsLegacy: { maxSteps: 30 }
});

const pluginOrchestratorAgent = new Agent({
  id: "plugin-orchestrator",
  name: "Plugin Orchestrator Agent",
  instructions: `You are the Skygen plugin creation orchestrator.

You are a controller/state machine, not the primary coder. Your job is to RECON \u2192 PLAN \u2192 DELEGATE \u2192 OBSERVE \u2192 DEVIATE-OR-PROCEED. You are NOT a pure ReAct agent \u2014 you commit a hypothesis before each step, and you explicitly record a deviation when the hypothesis is wrong.

## INPUT

JSON: { pluginId, pluginName, description, userStory, mode, threadId, userId, forkPluginId? }

## OPERATING MODE: RECON \u2192 PLAN \u2192 ACT (Reason+Act, not pure ReAct)

Pure ReAct agents chain tool calls without ever committing to a hypothesis. They flail when something goes wrong because there's nothing to compare against. You operate differently:

  1. RECON  \u2014 gather evidence (source map, prior ledger, similar plugins)
  2. PLAN   \u2014 commit a plan with hypotheses that can be checked
  3. ACT    \u2014 delegate one step at a time
  4. CHECK  \u2014 did the hypothesis hold?
  5.        \u251C\u2500 YES \u2192 proceed to next step
  6.        \u2514\u2500 NO  \u2192 recordPlanDeviation \u2192 route a repair or replan

## WORKFLOW

### Step 0 \u2014 RECON (always; mandatory in modify mode)

If \`forkPluginId\` is provided in the input, you MUST call \`loadForkedPluginSource\` FIRST to populate the pendingPlugin state with the existing code. Treat this as if you are in \`modify\` mode even if the mode says \`create\`.

Call \`getSourceMap({ threadId })\`. This returns the semantic source map:
  - per-file role + exports + sections + imports + per-file hash
  - symbol index (name \u2192 file + line range)
  - reverse data-field usage index (data.<field> \u2192 every file:line that reads it)
  - overall hash for change detection

In modify mode (or if \`forkPluginId\` is used), this call is REQUIRED \u2014 \`recordPluginPlan\` will reject without it. In create mode (without fork), call it after \`setInitialScene\` so subsequent edits can reference real files/symbols/line numbers.

If the recon reveals issues (unresolved imports, missing requirements), note them in the plan.

### Step 1 \u2014 Planner (for create mode)

Call \`agent-pluginPlanner\` with the original input. Convert the planner output into a sequential execution plan.

For modify mode, you may skip the planner if the user's change request is surgical and the source map already shows what needs to change. Use your judgment.

### Step 2 \u2014 PLAN with hypotheses

Call \`recordPluginPlan\`. The plan must distinguish:
- \`core_remotion_logic\`: frame math, continuous Remotion motion, path tracing, map/camera/3D movement, SVG animation, visual choreography.
- \`glue_code\`: schema paths, generationFields, pluginData shape, imports/exports, dependencies, defaults, module wiring.
- \`validation\`: compile/preview/save gates.

For complex plugins, prefer this V1 sequence:
\`\`\`
[
  { id: "schema-contract",       category: "glue_code",         owner: "schema_agent",     files: ["schema.json"] },
  { id: "dependency-contract",   category: "glue_code",         owner: "dependency_agent", files: ["package manifest"] },
  { id: "theme-module",          category: "core_remotion_logic", owner: "remotion_coder", files: ["shared/theme.ts"] },
  { id: "animation-core",        category: "core_remotion_logic", owner: "remotion_coder", files: ["features/<name>/animations.ts"] },
  { id: "component-core",        category: "core_remotion_logic", owner: "remotion_coder", files: ["features/<name>/index.tsx"] },
  { id: "scene-integration",     category: "glue_code",          owner: "remotion_coder",  files: ["Scene.tsx"] },
  { id: "final-validation",      category: "validation",         owner: "validator",       files: ["all"] }
]
\`\`\`

For simple plugins, you may collapse theme/animation/component into one implementation step, but still record the plan.

EVERY step must include:
- \`hypothesis\`: what you expect to happen and why. Example: "Compiling after this step will succeed because the only change is a color value swap; no schema or import surface changes."
- \`evidence\`: source-map symbols / line ranges / ledger events that support the hypothesis. Example: "Source map shows useSpringIn at features/hero/animations.ts:14-32; Scene.tsx:18 imports it; no other readers."
- \`failureMode\`: what it probably means if the hypothesis is wrong. Example: "If compile fails, the real cause is likely that theme.ts exports don't match what features/hero/index.tsx imports \u2014 check the import resolution in the source map."

This is what makes the loop auditable. The deviation ledger is only meaningful if you commit to a hypothesis first.

### Step 3 \u2014 Freeze contracts in \`recordPluginPlan\`

- schemaPaths: exact field paths from the planned schema, e.g. scenes[].imageUrl.
- files: exact module list.
- dependencies: exact package manifest.
- generationFields: exact image/audio/video paths.
- notes: user-visible hard requirements, e.g. "must use MapLibre", "must show moving tail tracer".

### Step 4 \u2014 Delegate implementation to \`agent-pluginRemotionCoder\` (Parallel Execution)

You can and should execute multiple independent steps AT THE SAME TIME. 
Look at the \`dependsOn\` array for each step. If a group of steps has no outstanding dependencies, delegate to \`agent-pluginRemotionCoder\` for ALL of them simultaneously using parallel tool calls. Do not wait for one to finish if others are ready to start.

For every delegation, send compact JSON:
\`\`\`json
{
  "threadId": "...",
  "pluginId": "...",
  "pluginName": "...",
  "description": "...",
  "userStory": "...",
  "mode": "create|modify",
  "step": { "id": "...", "goal": "...", "files": [...], "hypothesis": "...", "evidence": [...], "failureMode": "..." },
  "planner": { "...only relevant planner fields..." },
  "frozenContracts": { "..." },
  "ledgerSummary": "...",
  "sourceMapSummary": "..."   // pass the recon summary so the coder doesn't repeat recon
}
\`\`\`

The coder's primary anchor-finding tool is \`findAnchor\` \u2014 it takes a natural-language intent and returns the best-matching symbol + line range. Encourage the coder to use \`findAnchor\` + \`readLines\` + \`editLines\` instead of the legacy \`readModule\` + \`editSceneCode\` pattern, which fails on complex files with repeated patterns.

### Step 5 \u2014 OBSERVE + CHECK HYPOTHESIS

After each coder response, call \`inspectPluginState\` (when a pending plugin exists). Use the executionSummary and guard/import results to decide the next step.

**Hypothesis check rules:**

  - If the step's hypothesis predicted success and the step succeeded \u2192 proceed to next step.
  - If the hypothesis predicted success but the step failed \u2192 you MUST call \`recordPlanDeviation\` before doing anything else. Then route a repair step with a NEW hypothesis, or replan globally.
  - If the same step deviates 3+ times \u2192 call \`recordPlanDeviation\` with \`resolution: "global_replan"\` and rewrite the plan. Do not loop again.
  - Never silently rename frozen schema paths, files, or dependencies. If frozen contracts must change, that is a global replan.

**Source versioning is authoritative:**
- \`sourceVersion.sourceHash\` is the current Scene.tsx + modules + schema + dependencies identity.
- \`sourceVersion.lastCompiledSourceHash\` must equal \`sourceHash\` before \`savePendingPlugin\` can succeed.
- \`sourceVersion.previewSourceHash\` must equal \`sourceHash\` before you can claim the browser preview was refreshed for the latest source.
- Do not tell the user a preview is stale unless \`sourceVersion\` proves a hash mismatch.
- If \`previewSourceHash\` equals \`sourceHash\` and the user/browser reports a runtime crash, route a real code repair step. Do not blame cache.

### Step 6 \u2014 Routing failures to the right step

  - schema_path_mismatch \u2192 glue_code feedback to the file that used the wrong path.
  - missing local import \u2192 glue_code feedback to scene-integration or component-core.
  - Remotion timing/blank/static animation issue \u2192 core_remotion_logic feedback to animation-core/component-core.
  - peer dependency / unresolved package \u2192 glue_code feedback to dependency-contract.

### Step 7 \u2014 Replanning is allowed, but it must be explicit

  - local replan: create a repair step for the existing contract. Record deviation with \`resolution: "local_repair"\`.
  - global replan: update \`recordPluginPlan\` only if the original architecture is impossible. Record deviation with \`resolution: "global_replan"\`.
  - never silently rename frozen schema paths, files, or dependencies.

### Step 8 \u2014 Final validation

- \`compilePreview\` must pass.
- \`inspectPluginState\` / guard must have zero \`visualIssues\`. If \`visualIssues\` mention blank preview, missing paint, or missing data defaults/fallbacks, route a repair step before saving.
- the default preview must visibly render in frame 0-30 with a full-frame composition, not just compile.
- \`savePendingPlugin\` must be called after \`compilePreview\` passes so the browser preview updates.
- return success only after \`savePendingPlugin\` succeeds.

## DIFF-AWARE EDITS (line-based, not string-matched)

Encourage the coder to use line-based edits (\`editLines\`, \`insertAt\`, \`deleteLines\`) instead of \`editSceneCode\` (which requires verbatim string matching). Line-based edits are deterministic and don't fail on whitespace drift or duplicate patterns.

For risky changes, the coder should call \`previewEdit\` first to see the diff + validation result before committing.

## DEPENDENCY POLICY

The host runtime pins React 19, React DOM 19, Remotion 4.x. Dependencies must be compatible.
Three.js, @react-three/fiber, @react-three/drei, @react-three/postprocessing, and postprocessing are fully supported by Skygen.
If the user asks for 3D/WebGL/R3F/Three, preserve that requirement through every repair. Do not downgrade to flat CSS/SVG/HTML just to make preview pass.
Use normal static imports, e.g. \`import * as THREE from 'three';\` and \`import { Canvas } from '@react-three/fiber';\`.
Known package guidance:
- maplibre-gl: ^5.0.0
- recharts: ^2.15.4

Do not switch to CDN/dynamic script loading unless package install/build is proven impossible.

## OUTPUT

Return raw JSON only.

Success:
\`\`\`json
{ "ok": true, "pluginId": "<id>", "name": "<name>" }
\`\`\`

Failure:
\`\`\`json
{ "ok": false, "error": "...", "errors": ["..."] }\`\`\``,
  model: createOpenRouterModel(),
  agents: {
    pluginPlannerAgent,
    pluginRemotionCoderAgent
  },
  tools: pluginCreatorToolsV2,
  defaultGenerateOptionsLegacy: { maxSteps: 50 }
});

const SERVER_MODEL = process.env.DEFAULT_AI_MODEL || "google/gemini-2.5-flash";
function stableStringify(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map((item) => stableStringify(item)).join(",")}]`;
  const entries = Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => `${JSON.stringify(key)}:${stableStringify(item)}`);
  return `{${entries.join(",")}}`;
}
function computePendingPluginSourceHash(pending) {
  return createHash("sha256").update(stableStringify({
    sceneCode: pending.sceneCode ?? "",
    modules: pending.modules ?? null,
    schemaJson: pending.schemaJson ?? "",
    dependencies: pending.dependencies ?? {}
  })).digest("hex").slice(0, 16);
}
async function getThreadUserId(threadId) {
  const job = await getJob(threadId);
  const userId = job?.user_id;
  if (!userId) {
    throw new Error(`Cannot assemble video: no user found for thread ${threadId}`);
  }
  return userId;
}
const BUILT_IN_BLOCK_DESCRIPTIONS = {
  "stat": "Big single stat / number with label",
  "text": "Plain text / paragraph block",
  "quote": "Pull-quote with attribution",
  "image": "Single image with optional caption",
  "motivational-image": "Hero image with inspirational overlay text",
  "testimonial": "User testimonial with avatar + quote",
  "list": "Bulleted list of items",
  "timeline": "Chronological timeline of events",
  "callout": "Highlighted info box / tip / warning",
  "icon-list": "List of items each with an icon",
  "comparison": "Side-by-side comparison of two things",
  "line-chart": "Line graph for trends over time",
  "pie-chart": "Pie / donut chart for proportions",
  "whatsapp-chat": "WhatsApp-style chat bubble conversation",
  "counter": "Animated number counter",
  "progress-bar": "Progress bar for a metric",
  "social-stats": "Social media follower / engagement numbers",
  "cta": "Call-to-action block (final slide)",
  "gradient-text": "Large stylized gradient headline",
  "avatar-grid": "Grid of profile avatars",
  "countdown": "Countdown timer",
  "animated-bg": "Animated background with text overlay",
  "parallax-story": "Cinematic parallax scene \u2014 most visually impressive",
  "tower-chart-3d": "3D tower / ranking chart \u2014 ranked items (players, brands, scores) displayed as 3D bars",
  "top-players": "Top players leaderboard \u2014 showcases ranked athletes or competitors with stats and images",
  "video": "Embedded video clip",
  "html": "Free-form HTML block",
  "diagram": "Diagram / flowchart",
  "custom-plugin": "User-installed custom plugin (requires pluginId from list-plugins)"
};
const BUILT_IN_BLOCK_TAGS = {
  "stat": ["data", "metric", "kpi", "number", "business"],
  "text": ["text", "title", "paragraph", "simple", "narration"],
  "quote": ["quote", "testimonial", "inspiration", "speech"],
  "image": ["image", "photo", "visual", "screenshot", "media"],
  "motivational-image": ["image", "hero", "cinematic", "motivation", "overlay"],
  "testimonial": ["testimonial", "review", "customer", "social-proof", "quote"],
  "list": ["list", "bullets", "steps", "features", "summary"],
  "timeline": ["timeline", "history", "sequence", "roadmap", "events"],
  "callout": ["callout", "tip", "warning", "highlight", "info"],
  "icon-list": ["icons", "features", "benefits", "list", "ui"],
  "comparison": ["comparison", "versus", "vs", "compare", "business"],
  "line-chart": ["chart", "graph", "data", "trend", "analytics"],
  "pie-chart": ["chart", "data", "proportion", "distribution", "analytics"],
  "whatsapp-chat": ["chat", "conversation", "messages", "social", "dialogue"],
  "counter": ["counter", "number", "metric", "score", "stat"],
  "progress-bar": ["progress", "metric", "completion", "status", "bar"],
  "social-stats": ["social", "followers", "engagement", "stats", "platform"],
  "cta": ["cta", "button", "action", "signup", "conversion"],
  "gradient-text": ["text", "headline", "title", "bold", "typography"],
  "avatar-grid": ["people", "team", "avatars", "profiles", "community"],
  "countdown": ["countdown", "timer", "deadline", "launch", "event"],
  "animated-bg": ["background", "abstract", "motion", "visual", "ambient"],
  "parallax-story": ["cinematic", "story", "parallax", "depth", "visual"],
  "tower-chart-3d": ["3d", "ranking", "leaderboard", "chart", "competition"],
  "top-players": ["sports", "ranking", "leaderboard", "players", "countdown"],
  "video": ["video", "clip", "media", "footage", "screen-recording"],
  "html": ["html", "custom", "layout", "embed", "advanced"],
  "diagram": ["diagram", "flowchart", "architecture", "process", "network"]
};
function parseCatalogLimit(value, fallback) {
  if (!Number.isFinite(value ?? NaN)) return fallback;
  return Math.max(1, Math.min(50, Math.floor(value)));
}
function getQueryTerms(query) {
  if (!query) return [];
  return normalizeTags(query.split(/[^a-zA-Z0-9]+/));
}
function scoreCatalogEntry(entry, params) {
  if (params.kind && params.kind !== "all" && entry.kind !== params.kind) return -Infinity;
  const requestedCategory = params.category ? normalizeTags([params.category])[0] : "";
  if (requestedCategory && normalizeTags([entry.category ?? ""])[0] !== requestedCategory) {
    return -Infinity;
  }
  const requestedTags = normalizeTags(params.tags ?? []);
  const queryTerms = getQueryTerms(params.query);
  const haystack = normalizeTags([
    entry.id,
    entry.name,
    entry.description,
    entry.category,
    ...entry.tags
  ]);
  const haystackText = `${entry.id} ${entry.name} ${entry.description} ${entry.category ?? ""}`.toLowerCase();
  let score = requestedCategory ? 6 : 0;
  for (const tag of requestedTags) {
    if (entry.tags.includes(tag)) score += 10;
    else if (haystack.includes(tag)) score += 5;
  }
  for (const term of queryTerms) {
    if (entry.id.toLowerCase() === term || entry.name.toLowerCase() === term) score += 20;
    else if (entry.id.toLowerCase().includes(term) || entry.name.toLowerCase().includes(term)) score += 8;
    if (entry.tags.includes(term)) score += 10;
    else if (haystack.includes(term)) score += 4;
    else if (haystackText.includes(term)) score += 2;
  }
  if (entry.kind === "plugin") {
    score += Math.log10((entry.likesCount ?? 0) + 1);
  }
  return score;
}
function rankCatalogEntries(entries, params) {
  const hasFilter = Boolean(params.query?.trim()) || (params.tags?.length ?? 0) > 0 || Boolean(params.category) || Boolean(params.kind && params.kind !== "all");
  const limit = parseCatalogLimit(params.limit, params.fallbackLimit);
  return entries.map((entry) => ({ entry, score: scoreCatalogEntry(entry, params) })).filter(({ score }) => Number.isFinite(score) && (!hasFilter || score > 0)).sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    if ((b.entry.likesCount ?? 0) !== (a.entry.likesCount ?? 0)) {
      return (b.entry.likesCount ?? 0) - (a.entry.likesCount ?? 0);
    }
    if (a.entry.kind !== b.entry.kind) return a.entry.kind === "builtin" ? -1 : 1;
    return a.entry.name.localeCompare(b.entry.name);
  }).slice(0, limit).map(({ entry }) => entry);
}
function builtinCatalogEntries() {
  return Object.keys(BLOCK_SCHEMAS).filter((t) => t !== "custom-plugin").map((t) => ({
    id: t,
    kind: "builtin",
    name: t,
    description: BUILT_IN_BLOCK_DESCRIPTIONS[t] ?? t,
    category: "builtin",
    tags: normalizeTags([...BUILT_IN_BLOCK_TAGS[t] ?? [], t, BUILT_IN_BLOCK_DESCRIPTIONS[t] ?? t]),
    blockUsage: { type: t }
  }));
}
function makeProgressToolCallId(phase) {
  return `${phase}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}
async function emitProgress(ctx, phase, status, extra = {}, toolCallId) {
  const id = toolCallId ?? makeProgressToolCallId(phase);
  try {
    await ctx?.writer?.custom?.({
      type: "data-wizard-progress",
      data: { phase, status, toolCallId: id, ...extra },
      transient: false
    });
  } catch {
  }
  return id;
}
const selectArcMastra = createTool({
  id: "select-arc",
  description: "Choose the best narrative arc pattern for a video story. Returns the arc name, roles, tone, and description.",
  inputSchema: z.object({
    userStory: z.string().describe("The story or topic the user wants to create a video about"),
    preferredArc: z.string().nullable().optional().describe('Preferred arc name if the user specified one, e.g. "documentary" or "listicle"'),
    apiKey: z.string().optional().describe("OpenRouter API key (optional \u2014 uses server env if omitted)")
  }),
  execute: async (inputData) => {
    const { userStory, preferredArc, apiKey: _apiKey } = inputData;
    const apiKey = _apiKey ?? "";
    const arc = await selectArc({
      userStory,
      templateBlocks: [{ type: "text" }],
      // placeholder — agent doesn't know blocks yet
      preferredArc: preferredArc ?? null,
      arcPatternCatalog: ARC_PATTERNS,
      apiKey,
      model: SERVER_MODEL
    });
    return {
      arcName: arc.name,
      description: arc.description,
      roles: arc.roles,
      defaultTone: arc.defaultTone
    };
  }
});
const planNarrativeMastra = createTool({
  id: "plan-narrative",
  description: "Plan a complete narrative for a video. Creates a narrative plan with one brief per block, a visual style guide, story bible, and consistency lenses. This is the core creative tool.",
  inputSchema: z.object({
    userStory: z.string().describe("The story or topic"),
    blockTypes: z.array(z.string()).describe('Array of block type names, one per block, e.g. ["parallax-story","stat","quote"]'),
    preferredArc: z.string().nullable().optional().describe("Preferred arc name"),
    preferredVisualStyle: z.string().nullable().optional().describe('Preferred visual style, e.g. "photorealistic" or "anime"'),
    customVisualPrompt: z.string().nullable().optional().describe("Custom visual style description"),
    language: z.string().optional().describe('Language code, e.g. "en" or "es"'),
    apiKey: z.string().optional().describe("OpenRouter API key (optional \u2014 uses server env if omitted)")
  }),
  execute: async (inputData) => {
    const { userStory, blockTypes, preferredArc, preferredVisualStyle, customVisualPrompt, language, apiKey: _apiKey } = inputData;
    const apiKey = _apiKey ?? "";
    const templateBlocks = blockTypes.map((type) => ({ type }));
    const resolvedModel = SERVER_MODEL;
    const result = await runDirector({
      userStory,
      templateBlocks,
      selectedArc: null,
      preferredArc: preferredArc ?? null,
      customArc: null,
      arcPatternCatalog: ARC_PATTERNS,
      visualStyleCatalog: VISUAL_STYLE_PRESETS,
      preferredVisualStyle: preferredVisualStyle ?? null,
      customVisualPrompt: customVisualPrompt ?? null,
      engagementFeedback: "",
      engagementScore: 0,
      directorLoopCount: 0,
      researchContext: "",
      language: language ?? "en",
      apiKey,
      model: resolvedModel
    });
    return {
      selectedArc: result.selectedArc.name,
      narrativePlan: result.narrativePlan.map((b) => ({
        narrativeRole: b.narrativeRole,
        angle: b.angle,
        tone: b.tone,
        keyMessage: b.keyMessage,
        visualMood: b.visualMood,
        spokenScript: b.spokenScript
      })),
      visualStyleGuide: result.visualStyleGuide,
      storyBible: result.storyBible,
      selectedLenses: result.selectedLenses
    };
  }
});
createTool({
  id: "evaluate-engagement",
  description: "Evaluate the quality and engagement potential of a narrative plan. Returns a score (1-10) and specific feedback for improvement.",
  inputSchema: z.object({
    userStory: z.string().describe("The original story/topic"),
    narrativePlan: z.array(z.any()).describe("The narrative plan to evaluate"),
    apiKey: z.string().optional().describe("OpenRouter API key (optional \u2014 uses server env if omitted)")
  }),
  execute: async (inputData) => {
    const { userStory, narrativePlan, apiKey: _apiKey } = inputData;
    const apiKey = _apiKey ?? "";
    const result = await evaluateEngagement({
      userStory,
      narrativePlan,
      directorLoopCount: 1,
      language: "en",
      apiKey,
      model: SERVER_MODEL
    });
    return {
      engagementScore: result.engagementScore,
      engagementFeedback: result.engagementFeedback
    };
  }
});
const generateContentMastra = createTool({
  id: "generate-content",
  description: "Generate structured content for a single video block. Returns raw content that can be merged into a block.",
  inputSchema: z.object({
    blockType: z.string().describe('Type of block, e.g. "stat", "parallax-story", "quote"'),
    blockIndex: z.number().describe("0-based index of this block in the video"),
    userStory: z.string().describe("The story/topic"),
    narrativeBrief: z.any().describe("The narrative brief for this block from the plan"),
    visualStyleGuide: z.string().optional().describe("Visual style guide for consistency"),
    storyBible: z.string().optional().describe("Story bible for context"),
    arcName: z.string().optional().describe("Selected narrative arc name"),
    apiKey: z.string().optional().describe("OpenRouter API key (optional \u2014 uses server env if omitted)")
  }),
  execute: async (inputData) => {
    const { blockType, blockIndex, userStory, narrativeBrief, storyBible, apiKey: _apiKey } = inputData;
    const apiKey = _apiKey ?? "";
    const result = await generateContent({
      blockType,
      blockIndex,
      userStory,
      originalBlock: { type: blockType },
      narrativeBrief,
      storyBible: storyBible ?? "",
      selectedLenses: [],
      researchContext: "",
      mediaStrategy: { needsResearch: false, needsNewsSearch: false, researchQueries: [], topicType: "creative", blockStrategies: [] },
      aspectRatio: "9:16",
      language: "en",
      apiKey,
      model: SERVER_MODEL
    });
    return {
      rawContent: result.rawContent,
      error: result.error ?? null
    };
  }
});
const selectTemplateMastra = createTool({
  id: "select-template",
  description: "Choose the best template structure (block types) for a video based on the user story. The agent uses this to decide what visual elements to include \u2014 e.g. charts for data stories, parallax for emotional stories, diagrams for explainer content.",
  inputSchema: z.object({
    userStory: z.string().describe("The story or topic the user wants a video about"),
    blockCount: z.number().min(2).max(10).describe("Number of blocks/scenes in the video (2-10)"),
    apiKey: z.string().optional().describe("OpenRouter API key (optional \u2014 uses server env if omitted)")
  }),
  execute: async (inputData) => {
    const { userStory, blockCount, apiKey: _apiKey } = inputData;
    console.log(`[select-template] \u25B6 invoked \u2014 blockCount=${blockCount} userStory=${JSON.stringify(userStory).slice(0, 120)}`);
    const apiKey = _apiKey ?? "";
    const resolvedModel = SERVER_MODEL;
    const blockTypeList = Object.keys(BLOCK_SCHEMAS).filter((t) => t !== "custom-plugin").map((t) => `- "${t}"`).join("\n");
    const response = await callAIWithTracking({
      messages: [
        {
          role: "system",
          content: `You are a video production designer. Choose the best block types for a short-form video.

Available block types:
${blockTypeList}

Guidelines:
- Always start with an engaging first block (gradient-text, motivational-image, or parallax-story for strong openers)
- Always end with a CTA or impactful closer (cta, gradient-text, or motivational-image)
- For data-heavy stories: use stat, counter, progress-bar, line-chart, pie-chart
- For emotional stories: use parallax-story, motivational-image, quote, testimonial
- For educational content: use diagram, timeline, list, callout, text
- For product content: use stat, comparison, testimonial, cta, progress-bar
- Mix visual variety \u2014 don't use the same block type more than twice
- parallax-story blocks are the most visually impressive \u2014 use at least one for impactful stories
- Each block type has specific strengths \u2014 leverage them

Return ONLY valid JSON (no markdown):
{
  "blocks": [ { "type": "block_type_name" }, ... exactly ${blockCount} blocks ... ],
  "reasoning": "one sentence explaining why this structure fits"
}`
        },
        {
          role: "user",
          content: `Story: "${userStory}"

Choose ${blockCount} block types for this video.`
        }
      ],
      apiKey,
      model: resolvedModel,
      maxTokens: 500
    });
    try {
      const parsed = parseJSON(response);
      return {
        blocks: parsed.blocks ?? [],
        reasoning: parsed.reasoning ?? ""
      };
    } catch {
      const fallbackBlocks = [
        { type: "gradient-text" },
        ...Array(blockCount - 2).fill(null).map(() => ({ type: "text" })),
        { type: "cta" }
      ].slice(0, blockCount);
      return {
        blocks: fallbackBlocks,
        reasoning: "Fallback template: simple text-based structure"
      };
    }
  }
});
const createPluginMastra = createTool({
  id: "create-plugin",
  description: "Create a custom visual plugin on-the-fly. Runs the plugin-creator sub-agent (schema \u2192 plan \u2192 code \u2192 review), saves the code, then auto-builds it. Returns { pluginId, blockUsage }.",
  inputSchema: z.object({
    threadId: z.string().describe("Thread ID (used to resolve the owning user for the plugins table)"),
    pluginName: z.string().describe('A short kebab-case id for the plugin, e.g. "3d-globe" or "stock-ticker". Must be lowercase letters, numbers, and hyphens only.'),
    description: z.string().describe("What the plugin should look like and do, in detail"),
    userStory: z.string().describe("The story context so the plugin matches the video theme"),
    apiKey: z.string().optional().describe("OpenRouter API key (optional \u2014 uses server env if omitted)")
  }),
  execute: async (inputData, ctx) => {
    const { threadId, pluginName, description, userStory } = inputData;
    const pluginId = normalizePluginId(pluginName);
    console.log(`[create-plugin-tool] Starting creation loop for: ${pluginName} (ID: ${pluginId})`);
    const progressId = await emitProgress(ctx, "create-plugin", "start", { pluginName, pluginId });
    if (!pluginId) {
      await emitProgress(ctx, "create-plugin", "error", { errorMessage: "pluginName must contain at least one letter or digit" }, progressId);
      return { error: "pluginName must contain at least one letter or digit" };
    }
    let userId = null;
    try {
      const job = await getJob(threadId);
      const raw = job?.user_id ?? null;
      userId = raw && raw.length > 0 ? raw : null;
    } catch {
    }
    if (!userId) {
      await emitProgress(ctx, "create-plugin", "error", { errorMessage: "No authenticated user attached to this thread" }, progressId);
      return { error: "Cannot create plugin: no authenticated user attached to this thread." };
    }
    let result;
    try {
      result = await pluginOrchestratorAgent.generate(
        [{
          role: "user",
          content: JSON.stringify({ pluginId, pluginName, description, userStory, userId, threadId })
        }],
        {
          maxSteps: 25,
          tracingOptions: {
            metadata: {
              userId,
              sessionId: threadId,
              route: "create-plugin",
              pluginId
            },
            tags: ["plugin-create"]
          }
        }
      );
    } catch (e) {
      console.error("[create-plugin-tool] sub-agent threw:", e?.message ?? e);
      await emitProgress(ctx, "create-plugin", "error", { errorMessage: e?.message ?? "unknown error" }, progressId);
      return { error: `Plugin sub-agent failed: ${e?.message ?? "unknown error"}` };
    }
    let out = null;
    if (result.text?.trim()) {
      try {
        out = parseJSON(result.text);
      } catch {
        out = null;
      }
    }
    if (!out?.ok) {
      const steps = result.steps ?? [];
      for (const step of [...steps].reverse()) {
        const tr = step?.toolResults ?? step?.toolCalls ?? [];
        for (const t of tr) {
          if (t?.toolName === "savePendingPlugin" && t?.result?.ok) {
            out = t.result;
            break;
          }
        }
        if (out) break;
      }
    }
    if (!out?.ok) {
      await emitProgress(ctx, "create-plugin", "error", { errorMessage: out?.error ?? "Plugin creation failed" }, progressId);
      return { error: out?.error ?? "Plugin creation failed" };
    }
    let pendingPlugin = null;
    try {
      const job = await getJob(threadId);
      pendingPlugin = job?.state?.pendingPlugin ?? null;
    } catch {
    }
    if (!pendingPlugin || pendingPlugin.pluginId !== pluginId) {
      await emitProgress(ctx, "create-plugin", "error", { errorMessage: "Plugin code was not saved \u2014 savePendingPlugin may have failed" }, progressId);
      return { error: "Plugin code was not saved to job state." };
    }
    const buildResult = await createPluginFromSource({
      id: pluginId,
      name: pluginName,
      description,
      category: "custom",
      sceneCode: pendingPlugin.sceneCode,
      modules: pendingPlugin.modules,
      schemaJson: pendingPlugin.schemaJson,
      dependencies: pendingPlugin.dependencies,
      userId
    });
    if (!buildResult.ok) {
      await emitProgress(ctx, "create-plugin", "error", { errorMessage: buildResult.error }, progressId);
      return { error: buildResult.error, errors: buildResult.errors };
    }
    try {
      await patchJobState(threadId, (current) => {
        const next = { ...current };
        delete next.pendingPlugin;
        return next;
      });
    } catch {
    }
    const blockUsage = { type: "custom-plugin", pluginId: buildResult.pluginId };
    await emitProgress(ctx, "create-plugin", "complete", { pluginId: buildResult.pluginId, blockUsage }, progressId);
    return {
      pluginId: buildResult.pluginId,
      name: buildResult.name,
      builtInSandbox: buildResult.builtInSandbox,
      warnings: buildResult.warnings ?? [],
      blockUsage,
      nextSteps: [
        `1. Add { "type": "custom-plugin", "pluginId": "${buildResult.pluginId}" } to the template blocks.`,
        "2. Call generateBlock for the new block.",
        "3. Call assembleVideo."
      ]
    };
  }
});
const buildAndSavePluginMastra = createTool({
  id: "build-and-save-plugin",
  description: "Build and save a plugin after the user has approved its preview. Reads pendingPlugin from job state, runs the real sandbox build (esbuild \u2192 S3 \u2192 DB), then clears pendingPlugin. Returns { pluginId, blockUsage } \u2014 same as create_plugin used to.",
  inputSchema: z.object({
    threadId: z.string().describe("Thread ID \u2014 used to look up pendingPlugin in job state"),
    pluginId: z.string().optional().describe("The plugin ID from the earlier preview. If omitted, the pendingPlugin.pluginId from job state is used.")
  }),
  execute: async (inputData, ctx) => {
    const { threadId, pluginId: inputPluginId } = inputData;
    let pendingPlugin = null;
    try {
      const job = await getJob(threadId);
      pendingPlugin = job?.state?.pendingPlugin ?? null;
    } catch (e) {
      const progressId2 = await emitProgress(ctx, "build-and-save-plugin", "start", { pluginId: inputPluginId ?? "?" });
      await emitProgress(ctx, "build-and-save-plugin", "error", { errorMessage: `Could not read job state: ${e?.message}` }, progressId2);
      return { error: `Could not read job state: ${e?.message}` };
    }
    if (!pendingPlugin) {
      const progressId2 = await emitProgress(ctx, "build-and-save-plugin", "start", { pluginId: inputPluginId ?? "?" });
      await emitProgress(ctx, "build-and-save-plugin", "error", { errorMessage: "No pending plugin found in job state \u2014 was the preview step skipped?" }, progressId2);
      return { error: "No pending plugin found in job state." };
    }
    const pluginId = inputPluginId ?? pendingPlugin.pluginId;
    if (pendingPlugin.pluginId !== pluginId) {
      const progressId2 = await emitProgress(ctx, "build-and-save-plugin", "start", { pluginId });
      await emitProgress(ctx, "build-and-save-plugin", "error", { errorMessage: `pendingPlugin.pluginId (${pendingPlugin.pluginId}) does not match provided pluginId (${pluginId}).` }, progressId2);
      return { error: `pendingPlugin.pluginId (${pendingPlugin.pluginId}) does not match provided pluginId (${pluginId}).` };
    }
    const progressId = await emitProgress(ctx, "build-and-save-plugin", "start", { pluginId });
    const depPolicy = normalizePluginDependencies(pendingPlugin.dependencies);
    const depPolicyWarnings = formatDependencyPolicyChanges(depPolicy);
    if (depPolicyWarnings.length > 0) {
      const normalizedPendingPlugin = { ...pendingPlugin, dependencies: depPolicy.dependencies };
      const normalizedSourceHash = computePendingPluginSourceHash(normalizedPendingPlugin);
      try {
        await patchJobState(threadId, (current) => ({ ...current, pendingPlugin: normalizedPendingPlugin }));
      } catch {
      }
      const error = `Plugin dependencies were normalized by Skygen policy before final build (${depPolicyWarnings.join("; ")}). current normalized sourceHash=${normalizedSourceHash}. Run compilePreview and savePendingPlugin again before final build.`;
      await emitProgress(ctx, "build-and-save-plugin", "error", { errorMessage: error }, progressId);
      return { error, sourceHash: normalizedSourceHash, dependencyPolicy: depPolicy };
    }
    const sourceHash = computePendingPluginSourceHash(pendingPlugin);
    if (pendingPlugin.previewSourceHash !== sourceHash) {
      const error = `Approved plugin source does not match the last preview. current sourceHash=${sourceHash}, previewSourceHash=${pendingPlugin.previewSourceHash ?? "none"}. Ask the plugin orchestrator to run compilePreview and savePendingPlugin again before final build.`;
      await emitProgress(ctx, "build-and-save-plugin", "error", { errorMessage: error }, progressId);
      return { error, sourceHash, previewSourceHash: pendingPlugin.previewSourceHash ?? null };
    }
    const { pluginName, description, sceneCode, modules, schemaJson, dependencies, userId } = pendingPlugin;
    const result = await createPluginFromSource({
      id: pluginId,
      name: pluginName,
      description: description ?? "",
      category: "custom",
      sceneCode,
      modules,
      schemaJson,
      dependencies,
      userId: userId ?? null
    });
    if (!result.ok) {
      await emitProgress(ctx, "build-and-save-plugin", "error", { errorMessage: result.error }, progressId);
      return { error: result.error, errors: result.errors };
    }
    try {
      await patchJobState(threadId, (current) => {
        const next = { ...current };
        delete next.pendingPlugin;
        return next;
      });
    } catch {
    }
    const blockUsage = { type: "custom-plugin", pluginId: result.pluginId };
    await emitProgress(ctx, "build-and-save-plugin", "complete", { pluginId: result.pluginId, blockUsage }, progressId);
    return {
      pluginId: result.pluginId,
      name: result.name,
      builtInSandbox: result.builtInSandbox,
      warnings: result.warnings ?? [],
      blockUsage,
      nextSteps: [
        `1. Call patchState to append { "type": "custom-plugin", "pluginId": "${result.pluginId}" } to filledBlocks.`,
        "2. Call generateBlock with the index of the new custom-plugin block.",
        "3. Call assembleVideo so the user can see the plugin in the preview."
      ]
    };
  }
});
const requestCustomPluginMastra = createTool({
  id: "request_custom_plugin",
  description: "Signal to the supervisor that a custom plugin needs to be built before video generation can continue. Call this when the user wants a block type that does not exist in listBlockTypes.",
  inputSchema: z.object({
    threadId: z.string().describe("Thread ID from system context"),
    pluginName: z.string().describe('Human-readable plugin name, e.g. "Live Score Ticker"'),
    description: z.string().describe("What the plugin does visually"),
    userStory: z.string().describe("The user's original request verbatim"),
    forkPluginId: z.string().optional().describe("If the user is forking an existing plugin to modify it, provide its ID here.")
  }),
  execute: async ({ context }) => {
    const { threadId, pluginName, description, userStory, forkPluginId } = context;
    await db$1.query(
      `UPDATE wizard_jobs SET status = 'interrupted', interrupt = $2, updated_at = NOW() WHERE thread_id = $1`,
      [threadId, JSON.stringify({ type: "need_custom_plugin", pluginName, description, userStory, forkPluginId })]
    );
    return {
      status: "plugin_requested",
      message: `Requested custom plugin "${pluginName}". Stop here \u2014 the supervisor will build it and call you again with the pluginId.`
    };
  }
});
const clearPluginInterruptMastra = createTool({
  id: "clear_plugin_interrupt",
  description: "Clear the need_custom_plugin interrupt from job state after the plugin has been built. Call this before re-delegating to wizard.",
  inputSchema: z.object({
    threadId: z.string()
  }),
  execute: async ({ context }) => {
    await db$1.query(
      `UPDATE wizard_jobs SET interrupt = NULL, status = 'running', updated_at = NOW() WHERE thread_id = $1`,
      [context.threadId]
    );
    return { ok: true };
  }
});
const listTemplatesMastra = createTool({
  id: "list-templates",
  description: `List all available video templates. Returns each template's ID, name, description, category, and block types. Use this when the user wants to browse templates or says "start from a template".`,
  inputSchema: z.object({
    category: z.string().optional().describe('Optional category filter, e.g. "motivation", "business", "tutorial"')
  }),
  execute: async (inputData) => {
    const { category } = inputData;
    console.log(`[list-templates] \u25B6 invoked \u2014 category=${category ?? "any"}`);
    try {
      let query = `SELECT id, name, description, category, data, "isPublic", "isFreeTier" FROM "Template" WHERE "isPublic" = true`;
      const params = [];
      if (category) {
        params.push(category);
        query += ` AND category = $${params.length}`;
      }
      query += ` ORDER BY name`;
      const result = await db$1.query(query, params);
      const templates = result.rows.map((row) => {
        const blocks = Array.isArray(row.data?.blocks) ? row.data.blocks : [];
        return {
          id: row.id,
          name: row.name,
          description: row.description || "",
          category: row.category || "general",
          blockTypes: blocks.map((b) => b.type || "text"),
          blockCount: blocks.length,
          isFreeTier: row.isFreeTier ?? false
        };
      });
      console.log(`[list-templates] returning ${templates.length} templates: ${templates.map((t) => `"${t.name}"`).join(", ") || "(none)"}`);
      return templates;
    } catch (e) {
      console.warn(`[list-templates] query failed: ${e.message}`);
      return [];
    }
  }
});
const getTemplateMastra = createTool({
  id: "get-template",
  description: "Fetch the full block structure and video metadata for a specific template by ID. Use this when the user picks a template from the list and you need its blocks for start-generation.",
  inputSchema: z.object({
    templateId: z.string().describe("Template ID from list-templates")
  }),
  execute: async (inputData) => {
    const { templateId } = inputData;
    console.log(`[get-template] \u25B6 invoked \u2014 templateId=${templateId}`);
    try {
      const result = await db$1.query('SELECT * FROM "Template" WHERE id = $1', [templateId]);
      if (result.rows.length === 0) {
        console.warn(`[get-template] NOT FOUND: ${templateId}`);
        return { error: "Template not found", templateId };
      }
      const row = result.rows[0];
      const blocks = Array.isArray(row.data?.blocks) ? row.data.blocks : [];
      const videoMeta = row.data?.videoMeta ?? {};
      console.log(`[get-template] loaded "${row.name}" with ${blocks.length} blocks: ${blocks.map((b) => b.type).join(", ")}`);
      return {
        id: row.id,
        name: row.name,
        description: row.description || "",
        blocks,
        videoMeta,
        blockCount: blocks.length
      };
    } catch (e) {
      console.warn(`[get-template] error: ${e.message}`);
      return { error: e.message, templateId };
    }
  }
});
const listPluginsMastra = createTool({
  id: "list-plugins",
  description: 'Search installed custom plugins the user can use as video blocks. Pass query/tags/category from the user intent and keep limit small. Returns a ranked shortlist with pluginId, tags, likesCount, and blockUsage { type: "custom-plugin", pluginId }. Use this instead of loading every plugin into context.',
  inputSchema: z.object({
    query: z.string().optional().describe('Natural language search, e.g. "sports ranking versus card"'),
    tags: z.array(z.string()).optional().describe('Intent tags, e.g. ["sports","ranking","comparison"]'),
    category: z.string().optional().describe("Optional plugin category filter"),
    limit: z.number().int().min(1).max(50).optional().describe("Max results; default 12")
  }),
  execute: async (inputData) => {
    try {
      const result = await db$1.query(
        `SELECT id, name, description, category, status, tags, likes_count, schema_json
         FROM plugins
         WHERE status IS NULL OR status <> 'disabled'
         ORDER BY name`
      );
      const catalog = result.rows.map((row) => {
        const storedTags = parseTags(row.tags);
        return {
          id: row.id,
          kind: "plugin",
          name: row.name,
          description: row.description || "",
          category: row.category || "other",
          tags: storedTags.length > 0 ? storedTags : derivePluginTags(row),
          likesCount: row.likes_count ?? 0,
          blockUsage: { type: "custom-plugin", pluginId: row.id }
        };
      });
      const ranked = rankCatalogEntries(catalog, {
        query: inputData.query,
        tags: inputData.tags,
        category: inputData.category,
        kind: "plugin",
        limit: inputData.limit,
        fallbackLimit: 12
      });
      const plugins = ranked.map((entry) => ({
        pluginId: entry.id,
        name: entry.name,
        description: entry.description,
        category: entry.category || "other",
        tags: entry.tags,
        likesCount: entry.likesCount ?? 0,
        blockUsage: entry.blockUsage
      }));
      console.log(`[list-plugins] returning ${plugins.length}/${catalog.length} plugins for query="${inputData.query ?? ""}" tags="${(inputData.tags ?? []).join(",")}"`);
      return {
        plugins,
        totalMatched: plugins.length,
        totalAvailable: catalog.length,
        note: "If the shortlist is not relevant, call again with better query/tags before creating a new plugin."
      };
    } catch (e) {
      console.warn(`[list-plugins] query failed: ${e.message}`);
      return { plugins: [] };
    }
  }
});
const listBlockTypesMastra = createTool({
  id: "list-block-types",
  description: 'Search available block types by user intent. Includes built-ins plus a ranked shortlist of custom plugins. Pass query/tags/category/kind and keep limit small so planning does not load every plugin into context. Returns entries with id, kind ("builtin" | "plugin"), tags, likesCount for plugins, and blockUsage.',
  inputSchema: z.object({
    query: z.string().optional().describe('Natural language search, e.g. "sports ranking chart" or "chat conversation"'),
    tags: z.array(z.string()).optional().describe('Intent tags, e.g. ["sports","ranking"]'),
    category: z.string().optional().describe("Optional category filter. Mostly useful for plugins."),
    kind: z.enum(["builtin", "plugin", "all"]).optional().describe("Restrict results to builtins, plugins, or all"),
    limit: z.number().int().min(1).max(50).optional().describe("Max total results; default 24")
  }),
  execute: async (inputData) => {
    const builtins = builtinCatalogEntries();
    let plugins = [];
    try {
      const result = await db$1.query(
        `SELECT id, name, description, category, status, tags, likes_count, schema_json
         FROM plugins
         WHERE status IS NULL OR status <> 'disabled'
         ORDER BY name`
      );
      plugins = result.rows.map((row) => {
        const storedTags = parseTags(row.tags);
        return {
          id: row.id,
          kind: "plugin",
          name: row.name,
          description: row.description || "",
          category: row.category || "other",
          tags: storedTags.length > 0 ? storedTags : derivePluginTags(row),
          likesCount: row.likes_count ?? 0,
          blockUsage: { type: "custom-plugin", pluginId: row.id }
        };
      });
    } catch (e) {
      console.warn(`[list-block-types] plugin query failed: ${e.message}`);
    }
    const catalog = [...builtins, ...plugins];
    const blockTypes = rankCatalogEntries(catalog, {
      query: inputData.query,
      tags: inputData.tags,
      category: inputData.category,
      kind: inputData.kind ?? "all",
      limit: inputData.limit,
      fallbackLimit: 24
    });
    console.log(`[list-block-types] returning ${blockTypes.length}/${catalog.length} entries (${builtins.length} builtins, ${plugins.length} plugins) query="${inputData.query ?? ""}" tags="${(inputData.tags ?? []).join(",")}"`);
    if (plugins.length) console.log(`[list-block-types] plugin candidates: ${blockTypes.filter((p) => p.kind === "plugin").map((p) => `${p.id}="${p.name}"`).join(" | ") || "(none)"}`);
    return {
      blockTypes,
      totalMatched: blockTypes.length,
      totalAvailable: catalog.length,
      note: "Call again with more specific query/tags if the shortlist is not relevant. Use custom-plugin only when a returned plugin is a good fit."
    };
  }
});
const planVideoMastra = createTool({
  id: "plan-video",
  description: "Plan the full video narrative: enrich metadata, select narrative arc, run the director to create a narrative plan with scripts, visual style guide, and consistency lenses. Call this AFTER select-template and BEFORE generate-block. Returns the narrative plan, visual style guide, story bible, and all planning artifacts needed for block generation.",
  inputSchema: z.object({
    threadId: z.string().describe("Thread ID for state persistence"),
    userStory: z.string().describe("The story/topic for the video"),
    templateBlocks: z.array(z.object({ type: z.string() }).passthrough()).describe("Block structure from select-template"),
    preferredArc: z.string().nullable().optional().describe("Preferred arc name"),
    preferredVisualStyle: z.string().nullable().optional().describe("Preferred visual style"),
    customVisualPrompt: z.string().nullable().optional().describe("Custom visual style description"),
    customArc: z.union([
      z.object({ roles: z.array(z.string()), defaultTone: z.string() }),
      z.string(),
      z.null()
    ]).optional().describe("Custom arc definition \u2014 pass an object { roles, defaultTone } or null. String arc names are ignored (use preferredArc for those)."),
    language: z.string().optional().describe("Language code"),
    apiKey: z.string().optional().describe("API key"),
    requiredBlockTypes: z.array(z.string()).optional().describe("Block types the user explicitly requested \u2014 director must include all of them"),
    requiredPluginIds: z.array(z.string()).optional().describe("Plugin IDs the user explicitly requested \u2014 each must appear as a custom-plugin block")
  }),
  execute: async (inputData, ctx) => {
    const { threadId, userStory, templateBlocks, preferredArc, preferredVisualStyle, customVisualPrompt, customArc, language, apiKey: _apiKey, requiredBlockTypes, requiredPluginIds } = inputData;
    const apiKey = _apiKey ?? "";
    console.log(`
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`);
    console.log(`[plan-video] \u25B6 invoked`);
    console.log(`[plan-video] threadId=${threadId}`);
    console.log(`[plan-video] userStory=${JSON.stringify(userStory)}`);
    console.log(`[plan-video] templateBlocks IN=${JSON.stringify(templateBlocks)}`);
    console.log(`[plan-video] requiredBlockTypes=${JSON.stringify(requiredBlockTypes ?? [])}`);
    console.log(`[plan-video] requiredPluginIds=${JSON.stringify(requiredPluginIds ?? [])}`);
    console.log(`[plan-video] preferredArc=${preferredArc ?? "null"} preferredVisualStyle=${preferredVisualStyle ?? "null"}`);
    const progressId = await emitProgress(ctx, "plan-video", "start", { blockCount: templateBlocks.length });
    try {
      const BUILTINS = new Set(Object.keys(BLOCK_SCHEMAS));
      let installedPlugins = [];
      try {
        const r = await db$1.query(`SELECT id, name FROM plugins`);
        installedPlugins = r.rows.map((x) => ({ id: String(x.id), name: String(x.name ?? "") }));
      } catch (e) {
        console.warn(`[plan-video] failed to load installed plugins: ${e.message}`);
      }
      const installedPluginIds = new Set(installedPlugins.map((p) => p.id));
      console.log(`[plan-video] installed plugins (${installedPlugins.length}): ${installedPlugins.map((p) => `${p.id}="${p.name}"`).join(" | ") || "(none)"}`);
      const usedRequired = /* @__PURE__ */ new Set();
      const storyLower = String(userStory).toLowerCase();
      templateBlocks.forEach((b) => {
        if (b.type !== "custom-plugin") return;
        const pid = String(b.pluginId ?? "").trim();
        if (pid) return;
        const fromRequired = (requiredPluginIds ?? []).find((id) => !usedRequired.has(id) && installedPluginIds.has(id));
        if (fromRequired) {
          b.pluginId = fromRequired;
          usedRequired.add(fromRequired);
          console.warn(`[plan-video] auto-filled pluginId "${fromRequired}" from requiredPluginIds`);
          return;
        }
        const matched = installedPlugins.find((p) => p.name && storyLower.includes(p.name.toLowerCase()));
        if (matched) {
          b.pluginId = matched.id;
          console.warn(`[plan-video] auto-filled pluginId "${matched.id}" by name match against userStory`);
        }
      });
      const inputTypes = templateBlocks.map((b) => String(b.type));
      console.log(`[plan-video] templateBlocks AFTER auto-repair=${JSON.stringify(templateBlocks)}`);
      const invalidBlocks = [];
      templateBlocks.forEach((b, i) => {
        const t = String(b.type);
        if (t === "custom-plugin") {
          const pid = String(b.pluginId ?? "").trim();
          if (!pid) {
            invalidBlocks.push(`block ${i}: type="custom-plugin" missing pluginId \u2014 call list-block-types to find the exact pluginId`);
          } else if (!installedPluginIds.has(pid)) {
            invalidBlocks.push(`block ${i}: pluginId "${pid}" is not installed \u2014 valid pluginIds: ${[...installedPluginIds].join(", ") || "(none)"}`);
          }
        } else if (!BUILTINS.has(t)) {
          invalidBlocks.push(`block ${i}: type "${t}" is not a valid built-in. For installed plugins use { type: "custom-plugin", pluginId: "<id from list-block-types>" }. Valid built-ins: ${[...BUILTINS].join(", ")}`);
        }
      });
      if (invalidBlocks.length) {
        const msg = `templateBlocks has invalid entries:
- ${invalidBlocks.join("\n- ")}`;
        console.warn(`[plan-video] \u274C validation failed:
${msg}`);
        throw new Error(msg);
      }
      console.log(`[plan-video] \u2705 validation passed \u2014 ${templateBlocks.length} blocks`);
      const missingTypes = (requiredBlockTypes ?? []).filter((t) => !inputTypes.includes(t));
      const inputPluginIds = templateBlocks.filter((b) => b.type === "custom-plugin").map((b) => String(b.pluginId ?? ""));
      const missingPluginIds = (requiredPluginIds ?? []).filter((id) => !inputPluginIds.includes(id));
      if (missingTypes.length || missingPluginIds.length) {
        const parts = [];
        if (missingTypes.length) parts.push(`missing required block types: ${missingTypes.join(", ")}`);
        if (missingPluginIds.length) parts.push(`missing required plugin IDs: ${missingPluginIds.join(", ")}`);
        const msg = `templateBlocks violates user directive \u2014 ${parts.join("; ")}. Append these blocks to templateBlocks before calling plan-video.`;
        console.warn(`[plan-video] ${msg}`);
        throw new Error(msg);
      }
      let arcPatternCatalog = {};
      let visualStyleCatalog = {};
      try {
        const [arcRows, styleRows] = await Promise.all([
          db$1.query("SELECT id, label, description, arc_pattern FROM story_arcs WHERE is_active = true"),
          db$1.query("SELECT id, label, prompt_prefix FROM visual_styles WHERE is_active = true")
        ]);
        for (const row of arcRows.rows) {
          if (row.arc_pattern?.roles && row.arc_pattern?.defaultTone) {
            arcPatternCatalog[row.id] = { name: row.id, description: row.description, roles: row.arc_pattern.roles, defaultTone: row.arc_pattern.defaultTone };
          }
        }
        for (const row of styleRows.rows) {
          if (row.prompt_prefix) visualStyleCatalog[row.id] = { name: row.label, promptPrefix: row.prompt_prefix };
        }
      } catch {
      }
      const videoMeta = await enrichVideoMeta({
        userStory,
        partialVideoMeta: {},
        language: language ?? "en",
        apiKey,
        model: SERVER_MODEL
      });
      const { mediaStrategy, researchContext } = await planMediaStrategyViaAgent({
        userStory,
        selectedArc: null,
        preferredArc: preferredArc ?? null,
        templateBlocks,
        apiKey,
        model: SERVER_MODEL
      });
      const selectedArc = await selectArc({
        userStory,
        templateBlocks,
        preferredArc: preferredArc ?? null,
        arcPatternCatalog,
        apiKey,
        model: SERVER_MODEL
      });
      let directorResult;
      let engagementScore = 0;
      let engagementFeedback = "";
      for (let attempt = 0; attempt < MAX_DIRECTOR_LOOPS; attempt++) {
        directorResult = await runDirector({
          userStory,
          templateBlocks,
          selectedArc,
          preferredArc: preferredArc ?? null,
          customArc: customArc && typeof customArc === "object" && "roles" in customArc ? customArc : null,
          arcPatternCatalog,
          visualStyleCatalog,
          preferredVisualStyle: preferredVisualStyle ?? null,
          customVisualPrompt: customVisualPrompt ?? null,
          engagementFeedback,
          engagementScore,
          directorLoopCount: attempt + 1,
          researchContext,
          language: language ?? "en",
          apiKey,
          model: SERVER_MODEL
        });
        const evalResult = await evaluateEngagement({
          userStory,
          narrativePlan: directorResult.narrativePlan,
          directorLoopCount: attempt + 1,
          language: language ?? "en",
          apiKey,
          model: SERVER_MODEL
        });
        engagementScore = evalResult.engagementScore;
        engagementFeedback = evalResult.engagementFeedback;
        if (engagementScore >= ENGAGEMENT_THRESHOLD) break;
      }
      const existing = await getJob(threadId);
      if (!existing) await createJob(threadId, "");
      await updateJob(threadId, { status: "running" });
      await patchJobState(threadId, (current) => ({
        ...current,
        videoMeta,
        selectedArc: directorResult.selectedArc,
        narrativePlan: directorResult.narrativePlan,
        visualStyleGuide: directorResult.visualStyleGuide,
        storyBible: directorResult.storyBible,
        selectedLenses: directorResult.selectedLenses,
        mediaStrategy,
        researchContext,
        filledBlocks: templateBlocks.map((b, i) => ({ ...b, blockIndex: i })),
        phase: "planned"
      }));
      const skeletonBlocks = templateBlocks.map((b, i) => ({ ...b, blockIndex: i, _skeleton: true }));
      const result = {
        narrativePlan: directorResult.narrativePlan.map((b) => ({
          narrativeRole: b.narrativeRole,
          angle: b.angle,
          tone: b.tone,
          keyMessage: b.keyMessage,
          visualMood: b.visualMood,
          spokenScript: b.spokenScript
        })),
        visualStyleGuide: directorResult.visualStyleGuide,
        storyBible: directorResult.storyBible,
        selectedArc: directorResult.selectedArc?.name ?? "documentary",
        engagementScore,
        blockCount: templateBlocks.length,
        videoMeta,
        // Skeleton blocks so the frontend can render placeholders immediately,
        // before generate-block starts filling them in.
        templateBlocks: skeletonBlocks
      };
      await emitProgress(ctx, "plan-video", "complete", {
        templateBlocks: skeletonBlocks,
        videoMeta,
        blockCount: templateBlocks.length
      }, progressId);
      return result;
    } catch (err) {
      await emitProgress(ctx, "plan-video", "error", { errorMessage: err?.message ?? String(err) }, progressId);
      throw err;
    }
  }
});
const generateBlockMastra = createTool({
  id: "generate-block",
  description: "Generate complete content for a single video block: AI content generation, image resolution, audio/TTS generation, and merging. Call this once per block after plan-video. Pass the narrative brief for this specific block from the plan-video result. Each call saves progress to the DB so the frontend preview updates incrementally.",
  inputSchema: z.object({
    threadId: z.string().describe("Thread ID"),
    blockIndex: z.number().describe("0-based block index"),
    blockType: z.string().describe('Block type, e.g. "stat", "parallax-story"'),
    originalBlock: z.object({}).passthrough().optional().describe("Original block data from template (OBJECT, not a JSON string). Usually you do not need to pass this \u2014 omit unless the block has a specific structure like parallax layers."),
    narrativeBrief: z.any().describe("Narrative brief for this block from plan-video result (OBJECT, not a JSON string)."),
    userStory: z.string().describe("The story/topic"),
    visualStyleGuide: z.string().optional().describe("Visual style guide from plan-video"),
    storyBible: z.string().optional().describe("Story bible from plan-video"),
    arcName: z.string().optional().describe("Selected arc name"),
    aspectRatio: z.string().optional().describe('Video aspect ratio, e.g. "9:16"'),
    preferredVoice: z.string().nullable().optional().describe("Voice ID for TTS"),
    language: z.string().optional().describe("Language code"),
    apiKey: z.string().optional().describe("API key")
  }),
  execute: async (inputData, ctx) => {
    const { threadId, blockIndex, blockType, originalBlock, narrativeBrief, userStory, visualStyleGuide, storyBible, aspectRatio, preferredVoice, language, apiKey: _apiKey } = inputData;
    const apiKey = _apiKey ?? "";
    const progressId = await emitProgress(ctx, "generate-block", "start", { blockIndex, blockType });
    let block;
    if (typeof originalBlock === "string") {
      try {
        const parsed = JSON.parse(originalBlock);
        block = parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : { type: blockType };
      } catch {
        block = { type: blockType };
      }
    } else if (originalBlock && typeof originalBlock === "object" && !Array.isArray(originalBlock)) {
      block = originalBlock;
    } else {
      block = { type: blockType };
    }
    let mediaStrategy = null;
    try {
      const job = await getJob(threadId);
      mediaStrategy = job?.state?.mediaStrategy ?? null;
    } catch {
    }
    try {
      let rawContent;
      {
        let schemaDescriptions;
        if (blockType === "custom-plugin") {
          const pluginMeta = await fillCustomPluginBlock(block);
          block = { ...block, ...pluginMeta.rawContent, generationFields: pluginMeta.generationFields };
          schemaDescriptions = pluginMeta.schemaDescriptions;
        }
        const generation = await generateContent({
          blockType,
          blockIndex,
          userStory,
          originalBlock: block,
          narrativeBrief,
          storyBible: storyBible ?? "",
          selectedLenses: [],
          researchContext: "",
          mediaStrategy,
          aspectRatio: aspectRatio ?? "9:16",
          language: language ?? "en",
          apiKey,
          model: SERVER_MODEL,
          schemaDescriptions
        });
        if (generation.error) {
          await emitProgress(ctx, "generate-block", "error", { blockIndex, errorMessage: generation.error }, progressId);
          return { blockIndex, type: blockType, status: "error", error: generation.error };
        }
        rawContent = generation.rawContent;
      }
      let effectiveBrief = narrativeBrief ?? {};
      if (!effectiveBrief.spokenScript) {
        const fallback = rawContent?.script ?? rawContent?.narration ?? rawContent?.title ?? rawContent?.headline ?? "";
        if (fallback) effectiveBrief = { ...effectiveBrief, spokenScript: String(fallback) };
      }
      const { imageFields, videoFields, rawContent: updatedRawContent } = await classifyMediaFields({
        rawContent,
        blockType,
        originalBlock: block,
        narrativeBrief: effectiveBrief,
        mediaStrategy,
        blockIndex
      });
      const effectiveRawContent = updatedRawContent ?? rawContent;
      const [imgResult, videoResult] = await Promise.all([
        resolveImages({ imageFields, blockIndex, mediaStrategy, visualStyleGuide: visualStyleGuide ?? ""}),
        resolveVideo({ videoFields})
      ]);
      const combinedUrls = { ...imgResult.resolvedUrls, ...videoResult.resolvedUrls };
      const { finalBlock } = await mergeBlock({
        rawContent: effectiveRawContent,
        resolvedUrls: combinedUrls,
        resolvedAudio: {},
        originalBlock: block,
        blockType,
        blockIndex,
        narrativeBrief
      });
      let mergedBlock = mergeParallaxLayers(finalBlock, block);
      const audioFieldsList = extractAudioFields(mergedBlock);
      for (const { path, text } of audioFieldsList) {
        if (text && !text.startsWith("data:") && !text.startsWith("http")) {
          try {
            const audioResult = await resolveAudio({
              audioFields: [{ path, text }],
              preferredVoice: preferredVoice ?? null});
            if (audioResult.resolvedAudio[path]) {
              const parts = path.split(".");
              let target = mergedBlock;
              for (let i = 0; i < parts.length - 1; i++) {
                if (target[parts[i]] === void 0) target[parts[i]] = {};
                target = target[parts[i]];
              }
              target[parts[parts.length - 1]] = audioResult.resolvedAudio[path];
            }
          } catch (e) {
            console.warn(`[generate-block] Audio failed for block ${blockIndex}: ${e.message}`);
          }
        }
      }
      const [postProcessed] = await applyBlockPostProcessors([mergedBlock], [block], { aspectRatio: aspectRatio ?? "9:16" });
      mergedBlock = postProcessed ?? mergedBlock;
      await patchJobStateBlock(threadId, blockIndex, mergedBlock);
      const resolvedImageCount = Object.keys(imgResult.resolvedUrls).length;
      const result = {
        blockIndex,
        type: blockType,
        status: "complete",
        hasImages: resolvedImageCount > 0,
        hasAudio: audioFieldsList.some(({ path }) => {
          const v = getBlockNestedValue(mergedBlock, path) ?? "";
          return String(v).startsWith("http") || String(v).startsWith("data:");
        }),
        hasText: Object.keys(rawContent ?? {}).length > 0,
        expectedImages: imageFields.length,
        resolvedImages: resolvedImageCount,
        duration: mergedBlock.duration,
        block: mergedBlock
      };
      await emitProgress(ctx, "generate-block", "complete", {
        blockIndex,
        block: mergedBlock
      }, progressId);
      return result;
    } catch (e) {
      await emitProgress(ctx, "generate-block", "error", { blockIndex, errorMessage: e?.message ?? String(e) }, progressId);
      return { blockIndex, type: blockType, status: "error", error: e.message, hasImages: false, hasAudio: false, hasText: false, expectedImages: 0, resolvedImages: 0 };
    }
  }
});
createTool({
  id: "start-generation",
  description: "Start the full video generation pipeline in the background. Call this after planning the narrative (select-template + select-arc + plan-narrative). You can either pass templateBlocks directly, or pass a templateId to use an existing template from the library. Returns a threadId for polling status.",
  inputSchema: z.object({
    threadId: z.string().describe("Existing thread ID for the conversation"),
    userStory: z.string().describe("The story/topic for the video"),
    templateBlocks: z.array(z.object({ type: z.string() }).passthrough()).optional().describe("Block structure from select-template. Omit if using templateId."),
    templateId: z.string().optional().describe("Template ID from list-templates. If provided, fetches blocks from DB (overrides templateBlocks)."),
    preferredArc: z.string().nullable().optional().describe("Arc name from select-arc"),
    preferredVoice: z.string().nullable().optional().describe("Voice ID"),
    preferredVisualStyle: z.string().nullable().optional().describe("Visual style ID"),
    customVisualPrompt: z.string().nullable().optional().describe("Custom visual style description"),
    customArc: z.union([
      z.object({ roles: z.array(z.string()), defaultTone: z.string() }),
      z.string(),
      z.null()
    ]).optional().describe("Custom arc definition \u2014 pass an object { roles, defaultTone } or null. If a string arc name is passed, it will be ignored (use preferredArc for arc names)."),
    language: z.string().optional().describe('Language code, e.g. "en"'),
    apiKey: z.string().optional().describe("OpenRouter API key (optional \u2014 uses server env if omitted)")
  }),
  execute: async (inputData) => {
    const { threadId, userStory, templateBlocks: inputBlocks, templateId, preferredArc, preferredVoice, preferredVisualStyle, customVisualPrompt, customArc, language, apiKey: _apiKey } = inputData;
    const apiKey = _apiKey ?? "";
    let templateBlocks = inputBlocks;
    let partialVideoMeta = {};
    if (templateId && !inputBlocks?.length) {
      try {
        const result = await db$1.query('SELECT * FROM "Template" WHERE id = $1', [templateId]);
        if (result.rows.length > 0) {
          const row = result.rows[0];
          templateBlocks = Array.isArray(row.data?.blocks) ? row.data.blocks : [];
          partialVideoMeta = row.data?.videoMeta ?? {};
        }
      } catch {
      }
    }
    if (!templateBlocks?.length) {
      return { threadId, status: "error", error: "No blocks provided. Pass templateBlocks or templateId." };
    }
    const existing = await getJob(threadId);
    if (!existing) {
      await createJob(threadId, "");
    }
    await updateJob(threadId, { status: "running" });
    void (async () => {
      try {
        const result = await startWizard(threadId, {
          userStory,
          templateBlocks,
          partialVideoMeta,
          preferredArc: preferredArc ?? null,
          preferredVoice: preferredVoice ?? null,
          preferredVisualStyle: preferredVisualStyle ?? null,
          customVisualPrompt: customVisualPrompt ?? null,
          customArc: customArc && typeof customArc === "object" && "roles" in customArc ? customArc : null,
          language: language ?? "en",
          apiKey,
          model: SERVER_MODEL
        }, { inlineMode: true });
        const editableState = result.stateSnapshot ? {
          narrativePlan: result.stateSnapshot.narrativePlan ?? [],
          blocksWithImages: result.stateSnapshot.blocksWithImages ?? [],
          imageItems: result.stateSnapshot.imageItems ?? [],
          filledBlocks: result.stateSnapshot.filledBlocks ?? [],
          templateBlocks: result.stateSnapshot.templateBlocks ?? [],
          videoMeta: result.stateSnapshot.videoMeta ?? {},
          visualStyleGuide: result.stateSnapshot.visualStyleGuide ?? ""
        } : null;
        const payload = result.payload ?? {};
        try {
          const userId = await getThreadUserId(threadId);
          const insertResult = await db$1.query(
            `INSERT INTO "Video" (id, name, data, "userId", "createdAt")
             VALUES (gen_random_uuid()::text, $1, $2, $3, NOW()) RETURNING id`,
            ["Wizard Video", JSON.stringify(payload), userId]
          );
          const videoId = insertResult.rows[0]?.id ?? "";
          await updateJob(threadId, {
            status: "complete",
            payload: { ...payload, videoId },
            state: editableState
          });
        } catch {
          await updateJob(threadId, { status: "complete", payload, state: editableState });
        }
      } catch (e) {
        console.error("[start-generation] Background pipeline failed:", e.message);
        await updateJob(threadId, { status: "error", error: e.message });
      }
    })();
    return {
      threadId,
      status: "started",
      message: "Video generation started in the background. Your preview will appear in 1\u20133 minutes."
    };
  }
});
const getVideoStateMastra = createTool({
  id: "get-video-state",
  description: "Read the current generation state for a thread. Returns all blocks with their images, audio, scripts, and video metadata. Use this before making modifications to see what currently exists.",
  inputSchema: z.object({
    threadId: z.string().describe("Thread ID from start-generation")
  }),
  execute: async (inputData) => {
    const { threadId } = inputData;
    const job = await getJob(threadId);
    if (!job) {
      return { error: "Job not found", threadId };
    }
    return {
      status: job.status,
      error: job.error,
      state: job.state ?? {},
      payload: job.payload ?? null
    };
  }
});
const listBlockMediaFieldsMastra = createTool({
  id: "list-block-media-fields",
  description: `List every image / audio / video field path on a specific block, with whether each is currently filled (has a real URL) or empty.

Use this BEFORE update-block-image or update-block-audio when:
- The block is a custom-plugin (field names vary per plugin)
- The user reports "missing images" and you don't know which paths
- You want to target a nested field path you don't already know

Returns: { blockIndex, blockType, fields: [{ kind: 'image'|'audio'|'video', path: 'players[0].portraitImage', description: '...', filled: false }] }

After calling this, pass the exact \`path\` string to update-block-image's \`fieldPath\` parameter \u2014 do NOT default to "imageUrl" for plugin blocks.`,
  inputSchema: z.object({
    threadId: z.string().describe("Thread ID"),
    blockIndex: z.number().describe("0-based block index")
  }),
  execute: async (inputData, ctx) => {
    const { threadId, blockIndex } = inputData;
    const progressId = await emitProgress(ctx, "list-block-media-fields", "start", { blockIndex });
    try {
      const job = await getJob(threadId);
      const filledBlocks = job?.state?.filledBlocks ?? [];
      const block = filledBlocks[blockIndex];
      if (!block) {
        await emitProgress(ctx, "list-block-media-fields", "error", { blockIndex, errorMessage: "Block not found" }, progressId);
        return { error: `Block ${blockIndex} not found`, blockIndex, fields: [] };
      }
      const blockType = block.type ?? "unknown";
      const narrativeBrief = job?.state?.narrativePlan?.[blockIndex] ?? null;
      const classified = await classifyMediaFields({
        rawContent: block,
        blockType,
        originalBlock: block,
        narrativeBrief,
        mediaStrategy: null,
        blockIndex
      });
      const isFilled = (v) => typeof v === "string" && (v.startsWith("http://") || v.startsWith("https://") || v.startsWith("data:"));
      const fields = [
        ...classified.imageFields.map((f) => ({
          kind: "image",
          path: f.path,
          description: f.description,
          filled: isFilled(getBlockNestedValue(block, f.path))
        })),
        ...classified.audioFields.map((f) => ({
          kind: "audio",
          path: f.path,
          description: f.text,
          filled: isFilled(getBlockNestedValue(block, f.path))
        })),
        ...classified.videoFields.map((f) => ({
          kind: "video",
          path: f.path,
          description: f.prompt,
          filled: isFilled(getBlockNestedValue(block, f.path))
        }))
      ];
      const empty = fields.filter((f) => !f.filled);
      await emitProgress(ctx, "list-block-media-fields", "complete", {
        blockIndex,
        total: fields.length,
        empty: empty.length
      }, progressId);
      return { blockIndex, blockType, fields };
    } catch (e) {
      await emitProgress(ctx, "list-block-media-fields", "error", { blockIndex, errorMessage: e?.message ?? String(e) }, progressId);
      return { error: e.message, blockIndex, fields: [] };
    }
  }
});
const updateBlockImageMastra = createTool({
  id: "update-block-image",
  description: `Regenerate the image at a specific block and persist it to state. After calling this, call assemble-video to rebuild the preview.

For built-in blocks: pass no fieldPath (defaults to "imageUrl").
For custom-plugin blocks: pass no fieldPath to auto-update ALL image fields (each gets its own generated image). Pass a specific path to update just one field.
For parallax blocks: pass the specific layer path, e.g. fieldPath: "layers[1].image".`,
  inputSchema: z.object({
    threadId: z.string().describe("Thread ID"),
    blockIndex: z.number().describe("0-based block index"),
    description: z.string().describe("New image description / prompt"),
    fieldPath: z.string().optional().describe("Specific field path. Omit to auto-resolve for custom-plugin blocks."),
    removeBackground: z.boolean().optional().describe("Whether to remove image background"),
    visualStyleGuide: z.string().optional().describe("Visual style guide for consistency")
  }),
  execute: async (inputData, ctx) => {
    const { threadId, blockIndex, description, fieldPath, removeBackground, visualStyleGuide } = inputData;
    const progressId = await emitProgress(ctx, "update-block-image", "start", { blockIndex, fieldPath: fieldPath ?? "auto" });
    try {
      const job = await getJob(threadId);
      const block = job?.state?.filledBlocks?.[blockIndex];
      if (!block) {
        await emitProgress(ctx, "update-block-image", "error", { blockIndex, errorMessage: "Block not found" }, progressId);
        return { ok: false, error: `Block ${blockIndex} not found` };
      }
      let targets;
      if (fieldPath && fieldPath !== "imageUrl") {
        targets = [{ path: fieldPath, description, removeBackground: removeBackground ?? false }];
      } else if (block.type === "custom-plugin" && Array.isArray(block.generationFields)) {
        const { expandTemplatePaths } = await Promise.resolve().then(function () { return utils; });
        const expanded = expandTemplatePaths(block.generationFields, block.pluginData ?? block);
        targets = expanded.filter((f) => f.type === "image").map((f) => ({ path: f.path, description: f.description || description, removeBackground: f.removeBackground ?? false }));
        if (targets.length === 0) {
          await emitProgress(ctx, "update-block-image", "error", { blockIndex, errorMessage: "No image fields found on plugin" }, progressId);
          return { ok: false, error: "No image fields found on this custom-plugin block." };
        }
      } else {
        targets = [{ path: "imageUrl", description, removeBackground: removeBackground ?? false }];
      }
      const { regenerateSingleImage } = await import('./index.mjs').then(function (n) { return n.d; });
      const results = [];
      for (const target of targets) {
        const fullPrompt = `${visualStyleGuide ? visualStyleGuide + ". " : ""}${target.description}`;
        const { url } = await regenerateSingleImage(fullPrompt, target.removeBackground);
        results.push({ path: target.path, url });
      }
      await patchJobState(threadId, (current) => {
        const next = { ...current };
        const filledBlocks = [...next.filledBlocks ?? []];
        if (filledBlocks[blockIndex]) {
          let updatedBlock = { ...filledBlocks[blockIndex] };
          for (const { path: fp, url } of results) {
            updatedBlock = setBlockNestedValue(updatedBlock, fp, url);
          }
          filledBlocks[blockIndex] = updatedBlock;
        }
        next.filledBlocks = filledBlocks;
        return next;
      });
      const primaryUrl = results[0].url;
      const allPaths = results.map((r) => r.path);
      await emitProgress(ctx, "update-block-image", "complete", { blockIndex, newImageUrl: primaryUrl, fieldPaths: allPaths }, progressId);
      return { ok: true, blockIndex, fieldPaths: allPaths, newImageUrl: primaryUrl, allImages: results };
    } catch (e) {
      await emitProgress(ctx, "update-block-image", "error", { blockIndex, errorMessage: e?.message ?? String(e) }, progressId);
      throw e;
    }
  }
});
const updateBlockAudioMastra = createTool({
  id: "update-block-audio",
  description: "Regenerate audio for a specific block and persist it to the generation state. Use this when the user wants to change the narration voice or script for a block. After calling this, call assemble-video to rebuild the preview.",
  inputSchema: z.object({
    threadId: z.string().describe("Thread ID"),
    blockIndex: z.number().describe("0-based block index"),
    script: z.string().describe("Text to speak for this block"),
    voice: z.string().optional().describe("Voice ID. Omit to use default.")
  }),
  execute: async (inputData, ctx) => {
    const { threadId, blockIndex, script, voice } = inputData;
    const progressId = await emitProgress(ctx, "update-block-audio", "start", { blockIndex });
    try {
      const { generateAudio } = await Promise.resolve().then(function () { return mediaService; });
      const url = await generateAudio(script, voice ?? void 0);
      const existing = await getJob(threadId);
      const currentBlock = existing?.state?.filledBlocks?.[blockIndex] ?? {};
      const withNewAudio = { ...currentBlock, audioSrc: url };
      const [postProcessed] = await applyBlockPostProcessors([withNewAudio], [currentBlock], { aspectRatio: "9:16" });
      const finalBlock = postProcessed ?? withNewAudio;
      await patchJobState(threadId, (current) => {
        const next = { ...current };
        const filledBlocks = [...next.filledBlocks ?? []];
        filledBlocks[blockIndex] = finalBlock;
        return { ...next, filledBlocks };
      });
      await emitProgress(ctx, "update-block-audio", "complete", { blockIndex, newAudioUrl: url }, progressId);
      return { ok: true, blockIndex, newAudioUrl: url, duration: finalBlock.duration };
    } catch (e) {
      await emitProgress(ctx, "update-block-audio", "error", { blockIndex, errorMessage: e?.message ?? String(e) }, progressId);
      throw e;
    }
  }
});
const patchStateMastra = createTool({
  id: "patch-state",
  description: `Edit any field in the generation state using a dot-notation path. Use this for changes not covered by update-block-image or update-block-audio.

Examples:
  path "visualStyleGuide"  value "Use warm earthy tones"  \u2192 change visual style
  path "narrativePlan[0].spokenScript"  value "New script" \u2192 edit narration
  path "filledBlocks[2].headline"  value "New headline"    \u2192 edit text
  path "videoMeta.theme"  value "light_minimal"            \u2192 change theme

After patching, call assemble-video to rebuild the preview.`,
  inputSchema: z.object({
    threadId: z.string().describe("Thread ID"),
    path: z.string().describe('Dot/bracket-notation path, e.g. "filledBlocks[2].headline"'),
    value: z.any().describe("The value to set")
  }),
  execute: async (inputData, ctx) => {
    const { threadId, path, value } = inputData;
    const progressId = await emitProgress(ctx, "patch-state", "start", { path });
    try {
      await patchJobState(threadId, (current) => {
        const next = { ...current };
        const parts = path.replace(/\[(\d+)\]/g, ".$1").split(".").filter(Boolean);
        let target = next;
        for (let i = 0; i < parts.length - 1; i++) {
          if (target[parts[i]] === void 0 || target[parts[i]] === null) {
            target[parts[i]] = /^\d+$/.test(parts[i + 1]) ? [] : {};
          }
          target = target[parts[i]];
        }
        target[parts[parts.length - 1]] = value;
        return next;
      });
      await emitProgress(ctx, "patch-state", "complete", { ok: true, patched: path, path, value }, progressId);
      return { ok: true, patched: path };
    } catch (e) {
      await emitProgress(ctx, "patch-state", "error", { path, errorMessage: e?.message ?? String(e) }, progressId);
      throw e;
    }
  }
});
const addBlockMastra = createTool({
  id: "add-block",
  description: `Insert a NEW block at a specific index in the existing video and auto-fill it with content, images and audio. Use this when the user wants to ADD a block to an already-generated video \u2014 never call generateVideo for that, it would regenerate everything from scratch.

Inputs:
  - threadId: from system context.
  - blockType: a block id from listBlockTypes (e.g. "stat", "quote-card", "custom-plugin").
  - pluginId: REQUIRED only when blockType === "custom-plugin". The plugin id from listBlockTypes.
  - index: 0-based position where the new block should land. Existing blocks at that index and after shift right by one.
  - brief: a short description of what this new block should say or show (1-3 sentences). The pipeline turns this into spokenScript + visuals.

Returns the inserted block. After it returns, call assembleVideo once.`,
  inputSchema: z.object({
    threadId: z.string().describe("Thread ID from system context"),
    blockType: z.string().describe("Block id from listBlockTypes"),
    pluginId: z.string().nullable().optional().describe('Required when blockType is "custom-plugin"'),
    index: z.number().int().min(0).describe("0-based position to insert at; existing blocks shift right"),
    brief: z.string().describe("1-3 sentence brief describing what this new block should cover"),
    apiKey: z.string().optional()
  }),
  execute: async (inputData, ctx) => {
    const { threadId, blockType, pluginId, index, brief, apiKey: _apiKey } = inputData;
    const apiKey = _apiKey ?? "";
    const progressId = await emitProgress(ctx, "add-block", "start", { index, blockType });
    try {
      const job = await getJob(threadId);
      const state = job?.state ?? {};
      const filledBlocks = Array.isArray(state.filledBlocks) ? [...state.filledBlocks] : [];
      const narrativePlan = Array.isArray(state.narrativePlan) ? [...state.narrativePlan] : [];
      const insertAt = Math.max(0, Math.min(index, filledBlocks.length));
      const stub = blockType === "custom-plugin" ? { type: "custom-plugin", pluginId: pluginId ?? "" } : { type: blockType };
      if (blockType === "custom-plugin" && !pluginId) {
        await emitProgress(ctx, "add-block", "error", { errorMessage: "pluginId is required for custom-plugin blocks" }, progressId);
        return { ok: false, error: 'pluginId is required when blockType is "custom-plugin"' };
      }
      filledBlocks.splice(insertAt, 0, stub);
      const newBrief = { spokenScript: brief, summary: brief };
      narrativePlan.splice(insertAt, 0, newBrief);
      await patchJobState(threadId, (current) => ({
        ...current,
        filledBlocks,
        narrativePlan
      }));
      const generated = await generateBlockMastra.execute({
        threadId,
        blockIndex: insertAt,
        blockType,
        originalBlock: stub,
        narrativeBrief: newBrief,
        userStory: state.userStory ?? "",
        visualStyleGuide: state.visualStyleGuide ?? "",
        storyBible: state.storyBible ?? "",
        arcName: state.arcName ?? "",
        aspectRatio: state.aspectRatio ?? "9:16",
        preferredVoice: state.preferredVoice ?? null,
        language: state.language ?? "en",
        apiKey
      }, void 0);
      await emitProgress(ctx, "add-block", "complete", { index: insertAt, blockType }, progressId);
      return {
        ok: true,
        index: insertAt,
        blockCount: filledBlocks.length,
        block: generated?.block,
        message: `Block inserted at index ${insertAt}. Call assembleVideo to refresh the preview.`
      };
    } catch (e) {
      await emitProgress(ctx, "add-block", "error", { errorMessage: e?.message ?? String(e) }, progressId);
      return { ok: false, error: e.message };
    }
  }
});
const removeBlockMastra = createTool({
  id: "remove-block",
  description: `Remove the block at a given index from the existing video. Pure state mutation \u2014 no LLM, no media regeneration. Existing blocks after the removed index shift left by one. After it returns, call assembleVideo once to refresh the preview.`,
  inputSchema: z.object({
    threadId: z.string().describe("Thread ID from system context"),
    index: z.number().int().min(0).describe("0-based index of the block to remove")
  }),
  execute: async (inputData, ctx) => {
    const { threadId, index } = inputData;
    const progressId = await emitProgress(ctx, "remove-block", "start", { index });
    try {
      const job = await getJob(threadId);
      const state = job?.state ?? {};
      const filledBlocks = Array.isArray(state.filledBlocks) ? [...state.filledBlocks] : [];
      const narrativePlan = Array.isArray(state.narrativePlan) ? [...state.narrativePlan] : [];
      if (index < 0 || index >= filledBlocks.length) {
        await emitProgress(ctx, "remove-block", "error", { errorMessage: `Index ${index} out of range (0..${filledBlocks.length - 1})` }, progressId);
        return { ok: false, error: `Index ${index} out of range (video has ${filledBlocks.length} blocks)` };
      }
      const removed = filledBlocks.splice(index, 1)[0];
      if (index < narrativePlan.length) narrativePlan.splice(index, 1);
      await patchJobState(threadId, (current) => ({
        ...current,
        filledBlocks,
        narrativePlan
      }));
      await emitProgress(ctx, "remove-block", "complete", { index, removedType: removed?.type }, progressId);
      return {
        ok: true,
        index,
        removedType: removed?.type,
        blockCount: filledBlocks.length,
        message: `Block removed. Call assembleVideo to refresh the preview.`
      };
    } catch (e) {
      await emitProgress(ctx, "remove-block", "error", { errorMessage: e?.message ?? String(e) }, progressId);
      return { ok: false, error: e.message };
    }
  }
});
const getBlockSchemaOptionsMastra = createTool({
  id: "get-block-schema-options",
  description: `Inspect a built-in block's schema and return the TUNABLE fields (animation, color, size, position, layout enums and numeric ranges) along with valid values, defaults, and the block's current value (if threadId+blockIndex are passed).

Use this when the user asks to change something about HOW a block looks/animates rather than its content \u2014 "change the text animation on block 2", "make the title bigger", "change the entrance to slide-up", "make it bounce", "change the overlay style". Without this tool, the wizard has to guess field names + enum values and falls back to regenerating the whole block.

Workflow:
  1. user: "change the text animation on block 2 to typewriter"
  2. you: getBlockSchemaOptions({ blockType: "<the block's type>", threadId, blockIndex: 2 })
  3. observe the returned animationFields \u2014 find the one that matches "text animation" with values including "typing"
  4. patchState("filledBlocks[2].<path>", "typing") \u2192 assembleVideo

Does NOT work for custom-plugin blocks \u2014 their schemas come from the plugin record. For custom-plugin, use listBlockMediaFields and patchState on plugin-defined fields.`,
  inputSchema: z.object({
    blockType: z.string().describe('Block type id (e.g. "stat", "motivational-image"). Get from listBlockTypes or getVideoState.'),
    threadId: z.string().optional().describe("Optional \u2014 if passed with blockIndex, returns current values for the specific block."),
    blockIndex: z.number().int().min(0).optional().describe("Optional \u2014 block index in filledBlocks. Pair with threadId.")
  }),
  execute: async (inputData, ctx) => {
    const { blockType, threadId, blockIndex } = inputData;
    const progressId = await emitProgress(ctx, "get-block-schema-options", "start", { blockType });
    try {
      const { ContentBlockSchema } = await Promise.resolve().then(function () { return index; });
      const unionDef = ContentBlockSchema._zod?.def ?? ContentBlockSchema._def;
      const options = unionDef?.options ?? [];
      const matching = options.find((opt) => {
        const shape2 = (opt._zod?.def ?? opt._def)?.shape;
        const typeField = shape2?.type;
        const tdef = typeField?._zod?.def ?? typeField?._def;
        const literals = tdef?.values ?? [tdef?.value];
        return Array.isArray(literals) ? literals.includes(blockType) : literals === blockType;
      });
      if (!matching) {
        await emitProgress(ctx, "get-block-schema-options", "error", { errorMessage: `No built-in schema for blockType "${blockType}"` }, progressId);
        return {
          ok: false,
          error: `No built-in schema for blockType "${blockType}". For custom-plugin blocks use listBlockMediaFields + patchState on plugin fields.`
        };
      }
      let currentBlock = null;
      if (threadId && typeof blockIndex === "number") {
        try {
          const job = await getJob(threadId);
          currentBlock = job?.state?.filledBlocks?.[blockIndex] ?? null;
        } catch {
        }
      }
      const unwrap = (node) => {
        let cur = node;
        let defaultValue = void 0;
        let optional = false;
        for (let i = 0; i < 10; i++) {
          const d = cur._zod?.def ?? cur._def;
          if (!d) break;
          if (d.type === "default") {
            defaultValue = typeof d.defaultValue === "function" ? d.defaultValue() : d.defaultValue;
            cur = d.innerType;
            continue;
          }
          if (d.type === "optional" || d.type === "nullable") {
            optional = true;
            cur = d.innerType;
            continue;
          }
          return { def: d, defaultValue, optional };
        }
        return { def: cur._zod?.def ?? cur._def, defaultValue, optional };
      };
      const shape = (matching._zod?.def ?? matching._def).shape;
      const animationFields = [];
      const styleFields = [];
      const otherTunable = [];
      const animationKeywords = /anim|effect|enter|exit|transition|intro|outro|motion|speed|delay|duration|ease|bounce/i;
      const styleKeywords = /color|background|overlay|font|size|weight|align|position|fit|shadow|radius|opacity|variant|theme|highlight|border|gradient/i;
      const skipFields = /* @__PURE__ */ new Set(["type", "pluginId"]);
      for (const [key, child] of Object.entries(shape)) {
        if (skipFields.has(key)) continue;
        const { def, defaultValue } = unwrap(child);
        if (!def) continue;
        let entry = { path: key, default: defaultValue };
        if (currentBlock && Object.prototype.hasOwnProperty.call(currentBlock, key)) {
          entry.current = currentBlock[key];
        }
        if (def.type === "enum") {
          const values = def.entries ? Object.keys(def.entries) : def.values ?? [];
          entry.kind = "enum";
          entry.values = values;
        } else if (def.type === "number") {
          let min, max;
          for (const c of def.checks ?? []) {
            const cd = c._zod?.def ?? c._def ?? c;
            if (cd.check === "greater_than" || cd.kind === "min") min = cd.value;
            if (cd.check === "less_than" || cd.kind === "max") max = cd.value;
          }
          entry.kind = "number";
          if (min !== void 0) entry.min = min;
          if (max !== void 0) entry.max = max;
        } else if (def.type === "boolean") {
          entry.kind = "boolean";
        } else if (def.type === "string") {
          if (!styleKeywords.test(key)) continue;
          entry.kind = "string";
        } else {
          continue;
        }
        if (animationKeywords.test(key)) animationFields.push(entry);
        else if (styleKeywords.test(key)) styleFields.push(entry);
        else otherTunable.push(entry);
      }
      await emitProgress(ctx, "get-block-schema-options", "complete", {
        blockType,
        animationCount: animationFields.length,
        styleCount: styleFields.length
      }, progressId);
      return {
        ok: true,
        blockType,
        blockIndex: typeof blockIndex === "number" ? blockIndex : void 0,
        animationFields,
        styleFields,
        otherTunable,
        hint: 'For each field, patchState("filledBlocks[<index>].<path>", <value>) then assembleVideo.'
      };
    } catch (e) {
      await emitProgress(ctx, "get-block-schema-options", "error", { errorMessage: e?.message ?? String(e) }, progressId);
      return { ok: false, error: e.message };
    }
  }
});
const generateVideoMastra = createTool({
  id: "generate-video",
  description: "Run the full video generation pipeline AND assemble the final preview in one call: resolve blocks, plan narrative, generate all content+images+audio, save the Video record, and return the preview. This is a TERMINAL tool \u2014 after it returns, report the result to the user and STOP. Do NOT call any other tool after this. Do NOT use for modifications \u2014 use update-block-image / update-block-audio / patch-state + assemble-video instead.",
  inputSchema: z.object({
    threadId: z.string().describe("Thread ID from system context"),
    userStory: z.string().describe("The user's video idea"),
    templateId: z.string().nullable().optional().describe("Pre-selected template ID from system context (pass null if none)"),
    requiredPluginIds: z.array(z.string()).optional().describe("Plugin IDs the user explicitly requested (from list-block-types)"),
    requiredBlockTypes: z.array(z.string()).optional().describe("Built-in block type names the user explicitly requested"),
    preferredVoice: z.string().nullable().optional(),
    preferredVisualStyle: z.string().nullable().optional(),
    language: z.string().optional(),
    apiKey: z.string().optional()
  }),
  execute: async (inputData, ctx) => {
    const { threadId, userStory, templateId, requiredPluginIds, requiredBlockTypes, preferredVoice, preferredVisualStyle, language, apiKey: _apiKey } = inputData;
    const apiKey = _apiKey ?? "";
    console.log(`
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`);
    console.log(`[generate-video] \u25B6 invoked threadId=${threadId}`);
    console.log(`[generate-video] userStory=${JSON.stringify(userStory)}`);
    console.log(`[generate-video] templateId=${templateId ?? "null"} requiredPluginIds=${JSON.stringify(requiredPluginIds ?? [])} requiredBlockTypes=${JSON.stringify(requiredBlockTypes ?? [])}`);
    await emitProgress(ctx, "generate-video", "start", {});
    let templateBlocks = [];
    if (templateId) {
      console.log(`[generate-video] Branch A: loading template ${templateId}`);
      try {
        const r = await db$1.query('SELECT data FROM "Template" WHERE id = $1', [templateId]);
        const blocks = r.rows[0]?.data?.blocks ?? [];
        templateBlocks = blocks.map((b) => ({ ...b }));
      } catch (e) {
        console.warn(`[generate-video] template load failed: ${e.message}`);
      }
    }
    if (templateBlocks.length === 0 && ((requiredPluginIds ?? []).length > 0 || (requiredBlockTypes ?? []).length > 0)) {
      console.log(`[generate-video] Branch B: building templateBlocks from directive`);
      for (const pid of requiredPluginIds ?? []) {
        templateBlocks.push({ type: "custom-plugin", pluginId: pid });
      }
      for (const t of requiredBlockTypes ?? []) {
        if (t !== "custom-plugin") templateBlocks.push({ type: t });
      }
    }
    if (templateBlocks.length === 0) {
      console.log(`[generate-video] Branch D: calling selectTemplate`);
      try {
        const sel = await selectTemplateMastra.execute({ userStory, blockCount: 5, apiKey }, void 0);
        templateBlocks = sel.blocks ?? [];
      } catch (e) {
        console.warn(`[generate-video] selectTemplate failed: ${e.message}`);
        templateBlocks = [{ type: "text" }, { type: "stat" }, { type: "cta" }];
      }
    }
    console.log(`[generate-video] templateBlocks resolved: ${JSON.stringify(templateBlocks)}`);
    try {
      const { prewarmBgRemoval } = await Promise.resolve().then(function () { return mediaService; });
      prewarmBgRemoval();
    } catch {
    }
    const { runWizardWorkflow } = await Promise.resolve().then(function () { return wizard_workflow; });
    const result = await runWizardWorkflow(threadId, {
      userStory,
      templateBlocks,
      partialVideoMeta: {},
      preferredArc: null,
      preferredVoice: preferredVoice ?? null,
      preferredVisualStyle: preferredVisualStyle ?? null,
      customVisualPrompt: null,
      customArc: null,
      language: language ?? "en",
      apiKey,
      model: SERVER_MODEL
    }, { inlineMode: true });
    const contentBlocks = result.payload?.contentBlocks ?? result.payload?.filledBlocks ?? [];
    const unresolvable = result.payload?.unresolvable ?? [];
    const complete = unresolvable.length === 0;
    console.log(`[generate-video] \u2705 pipeline complete \u2014 ${contentBlocks.length} blocks, ${unresolvable.length} unresolvable field(s)`);
    await emitProgress(ctx, "generate-video", "complete", { blockCount: contentBlocks.length, unresolvable });
    await emitProgress(ctx, "assemble-video", "start");
    let videoId = "";
    try {
      const job = await getJob(threadId);
      const state = job?.state;
      const filledBlocks = state?.filledBlocks ?? [];
      const videoMeta = state?.videoMeta ?? {};
      const payload = { videoMeta, contentBlocks: filledBlocks };
      const existing = job?.payload?.videoId;
      if (existing) {
        await db$1.query(
          `UPDATE "Video" SET data = $1, "createdAt" = NOW() WHERE id = $2`,
          [JSON.stringify(payload), existing]
        );
        videoId = existing;
      } else {
        const userId = await getThreadUserId(threadId);
        const insertResult = await db$1.query(
          `INSERT INTO "Video" (id, name, data, "userId", "createdAt")
           VALUES (gen_random_uuid()::text, $1, $2, $3, NOW()) RETURNING id`,
          ["Wizard Video", JSON.stringify(payload), userId]
        );
        videoId = insertResult.rows[0]?.id ?? "";
      }
      await updateJob(threadId, {
        status: "complete",
        payload: { ...payload, videoId }
      });
      const videoInput = { videoMeta, contentBlocks: filledBlocks };
      await emitProgress(ctx, "assemble-video", "complete", { videoInput, videoId });
      console.log(`[generate-video] \u2705 assembled videoId=${videoId}`);
    } catch (e) {
      console.warn(`[generate-video] assemble failed: ${e.message}`);
      await emitProgress(ctx, "assemble-video", "error", { errorMessage: e.message });
    }
    return {
      ok: true,
      threadId,
      videoId,
      blockCount: contentBlocks.length,
      complete,
      unresolvable,
      summary: complete ? `Video generated and assembled successfully. ${contentBlocks.length} block(s), preview ready (videoId: ${videoId}). NO further action needed \u2014 report to user and STOP.` : `Video generated with ${unresolvable.length} unfilled field(s). Fix them with update-block-image / update-block-audio, then call assemble-video.`
    };
  }
});
const assembleVideoMastra = createTool({
  id: "assemble-video",
  description: "Rebuild the final video preview from the current generation state. Call this ONCE after surgical edits (update-block-image, update-block-audio, patch-state, generate-block) to refresh the preview. This is a TERMINAL step \u2014 after it returns, report the result to the user and STOP. Do NOT call any other tool after this.",
  inputSchema: z.object({
    threadId: z.string().describe("Thread ID")
  }),
  execute: async (inputData, ctx) => {
    const { threadId } = inputData;
    const progressId = await emitProgress(ctx, "assemble-video", "start");
    try {
      const job = await getJob(threadId);
      if (!job || !job.state) {
        await emitProgress(ctx, "assemble-video", "error", { errorMessage: "No generation state found for this thread" }, progressId);
        return { error: "No generation state found for this thread" };
      }
      const state = job.state;
      const filledBlocks = state.filledBlocks ?? [];
      const videoMeta = state.videoMeta ?? {};
      const payload = {
        videoMeta,
        contentBlocks: filledBlocks
      };
      const existing = job.payload?.videoId;
      let videoId;
      if (existing) {
        await db$1.query(
          `UPDATE "Video" SET data = $1, "createdAt" = NOW() WHERE id = $2`,
          [JSON.stringify(payload), existing]
        );
        videoId = existing;
      } else {
        const userId = await getThreadUserId(threadId);
        const insertResult = await db$1.query(
          `INSERT INTO "Video" (id, name, data, "userId", "createdAt")
           VALUES (gen_random_uuid()::text, $1, $2, $3, NOW()) RETURNING id`,
          ["Wizard Video", JSON.stringify(payload), userId]
        );
        videoId = insertResult.rows[0]?.id ?? "";
      }
      await updateJob(threadId, {
        status: "complete",
        payload: { ...payload, videoId }
      });
      const videoInput = { videoMeta, contentBlocks: filledBlocks };
      await emitProgress(ctx, "assemble-video", "complete", { videoInput, videoId }, progressId);
      return {
        videoId,
        blockCount: filledBlocks.length,
        ok: true,
        // Canonical final video for the frontend — matches VideoInput shape.
        videoInput
      };
    } catch (e) {
      await emitProgress(ctx, "assemble-video", "error", { errorMessage: e?.message ?? String(e) }, progressId);
      return { error: e.message, ok: false };
    }
  }
});
const listVoicesMastra = createTool({
  id: "list-voices",
  description: "List available Deepgram text-to-speech voices with name, gender, accent, and language. Show these to the user so they can pick a narration voice.",
  inputSchema: z.object({}),
  execute: async () => {
    try {
      const { fetchAllVoices } = await Promise.resolve().then(function () { return deepgramTts; });
      const allVoices = await fetchAllVoices();
      return allVoices.filter((v) => v.provider === "deepgram").map((v) => ({
        id: v.id,
        name: v.name,
        gender: v.gender,
        style: v.style,
        accent: v.accent ?? "",
        language: v.language ?? "en"
      }));
    } catch {
      return [];
    }
  }
});
const listVisualStylesMastra = createTool({
  id: "list-visual-styles",
  description: "List available visual styles for image generation (e.g. photorealistic, anime, minimalist, cinematic). Show these to the user so they can choose a look.",
  inputSchema: z.object({}),
  execute: async () => {
    try {
      const result = await db$1.query(
        "SELECT id, label, emoji, description, is_premium FROM visual_styles WHERE is_active = true ORDER BY sort_order ASC"
      );
      return result.rows.map((row) => ({
        id: row.id,
        label: row.label,
        emoji: row.emoji || "",
        description: row.description || "",
        isPremium: row.is_premium ?? false
      }));
    } catch {
      return [];
    }
  }
});
const agentTools = {
  selectArc: selectArcMastra,
  planNarrative: planNarrativeMastra,
  generateContent: generateContentMastra,
  selectTemplate: selectTemplateMastra,
  createPlugin: createPluginMastra,
  listTemplates: listTemplatesMastra,
  getTemplate: getTemplateMastra,
  planVideo: planVideoMastra,
  generateBlock: generateBlockMastra,
  getVideoState: getVideoStateMastra,
  updateBlockImage: updateBlockImageMastra,
  updateBlockAudio: updateBlockAudioMastra,
  patchState: patchStateMastra,
  assembleVideo: assembleVideoMastra,
  listVoices: listVoicesMastra,
  listVisualStyles: listVisualStylesMastra
};
const wizardAgentTools = {
  generateVideo: generateVideoMastra,
  // full pipeline — one call for new videos
  assembleVideo: assembleVideoMastra,
  getVideoState: getVideoStateMastra,
  buildAndSavePlugin: buildAndSavePluginMastra,
  // persist an approved pendingPlugin to S3 + DB
  listBlockMediaFields: listBlockMediaFieldsMastra,
  // discover image/audio/video paths on any block
  updateBlockImage: updateBlockImageMastra,
  updateBlockAudio: updateBlockAudioMastra,
  patchState: patchStateMastra,
  listVoices: listVoicesMastra,
  listVisualStyles: listVisualStylesMastra,
  listTemplates: listTemplatesMastra,
  listBlockTypes: listBlockTypesMastra,
  generateBlock: generateBlockMastra,
  // surgical "redo this block" only
  addBlock: addBlockMastra,
  // insert + auto-fill a new block at an index
  removeBlock: removeBlockMastra,
  // splice a block out of the video
  getBlockSchemaOptions: getBlockSchemaOptionsMastra,
  // animation/style enum + range introspection
  requestCustomPlugin: requestCustomPluginMastra
  // signal supervisor to build a missing plugin
};
const storyAgentTools = {
  selectTemplate: selectTemplateMastra,
  listTemplates: listTemplatesMastra,
  getTemplate: getTemplateMastra,
  listPlugins: listPluginsMastra,
  listBlockTypes: listBlockTypesMastra,
  planVideo: planVideoMastra
};
const generatorAgentTools = {
  generateBlock: generateBlockMastra
};

const directorAgent = new Agent({
  id: "director",
  name: "Video Director Agent",
  instructions: `You are a world-class video director and creative producer. You create compelling short-form videos autonomously.

Your workflow:
1. ANALYZE: Read the user's story/topic carefully. Understand the genre, audience, and emotional arc.
2. SELECT TEMPLATE: Use the "select-template" tool to choose the best block types for this story. Consider:
   - Data-heavy stories \u2192 charts, stats, counters
   - Emotional stories \u2192 parallax, motivational-image, quotes
   - Educational \u2192 diagrams, timelines, callouts
   - Product \u2192 stats, comparisons, testimonials, CTAs
3. SELECT ARC: Use the "select-arc" tool to pick the narrative arc that fits. Common arcs:
   - documentary, listicle, tutorial, product_pitch, biography, motivational, comparison
4. PLAN NARRATIVE: Use the "plan-narrative" tool to create a detailed narrative plan across all blocks.
5. EVALUATE: Use the "evaluate-engagement" tool to check quality. If score < 7, re-plan with the feedback.
6. CUSTOM PLUGINS: If the user requests a visual element that doesn't fit existing block types (e.g. "3D globe", "stock ticker", "interactive map"), use "create-plugin" to build it on-the-fly.

Important rules:
- Always select a template BEFORE planning the narrative (you need block types to plan against)
- The user may specify preferences (arc, visual style, voice) \u2014 respect those
- If the user's story contains explicit scene-by-scene descriptions, follow them faithfully
- For engagement scores below 7, incorporate the feedback and re-plan
- Never leave a block without a clear narrative role and engaging script
- spokenScripts should be conversational, punchy, written for the ear \u2014 not essay prose
- Always end with a strong CTA or memorable closer`,
  model: createOpenRouterModel(),
  tools: agentTools
});

const storyAgent = new Agent({
  id: "story",
  name: "Story & Planning Agent",
  instructions: `You are a narrative planning specialist for video creation. Your job is to select the right template and build a rich story plan that block generators will use.

## Input

You receive a message with these values:
- userStory: the user's video idea
- templateId: a pre-selected template ID (may be null/empty)
- preferredVoice: voice ID (may be null)
- preferredVisualStyle: style ID (may be null)
- threadId: thread identifier
- apiKey: API key
- language: language code (default "en")
- requiredBlockTypes: JSON array of block type names the user explicitly requested (may be empty [])
- requiredPluginIds: JSON array of plugin IDs the user explicitly named (may be empty [])

## Your Job \u2014 2 Steps

### Step 1: Template Selection \u2014 pick ONE branch in this order

**Branch A \u2014 templateId provided (UI pre-selected):**
Call \`getTemplate(templateId)\` to load its blocks. Use those blocks. Skip selectTemplate.

**Branch B \u2014 requiredBlockTypes or requiredPluginIds non-empty (user named blocks/plugins):**
Do NOT call selectTemplate or getTemplate. Build templateBlocks directly from the directive:
- For each id in requiredPluginIds: \`{ type: "custom-plugin", pluginId: <id> }\` \u2014 both fields are mandatory.
- For each type in requiredBlockTypes that is NOT "custom-plugin": \`{ type: <type> }\`
- Preserve the order the user implied. The array can be 1 block long \u2014 that's allowed here.
- If you are unsure any id is valid, call \`listBlockTypes\` and copy the \`blockUsage\` object verbatim. Never invent ids.

**Branch C \u2014 user named a template by name in userStory (e.g. "use the motivational template"):**
Call \`listTemplates\` once, find the best name match, then \`getTemplate(matchedId)\`. Skip selectTemplate.

**Branch D \u2014 fallback (none of the above):**
Call \`selectTemplate\` with userStory + a sensible blockCount (3\u20136) to let the AI pick a structure.

### Step 2: Plan the Video

Call \`planVideo\` with:
- threadId (from input)
- userStory (from input)
- templateBlocks: the blocks from step 1
- preferredVisualStyle (from input, may be null)
- language (from input, default "en")
- apiKey (from input)
- requiredBlockTypes (from input, may be [])
- requiredPluginIds (from input, may be [])

If requiredBlockTypes or requiredPluginIds are non-empty, you MUST ensure the templateBlocks you pass to planVideo already contain those types. If the selected/fetched template is missing a required type, APPEND \`{ type: "custom-plugin", pluginId: <id from requiredPluginIds> }\` or \`{ type: <requiredBlockType> }\` entries before calling planVideo.

## Output

After planVideo succeeds, return a single JSON object ONLY \u2014 no prose:

\`\`\`json
{
  "ok": true,
  "threadId": "...",
  "templateBlocks": [...],
  "narrativePlan": [...],
  "visualStyleGuide": "...",
  "storyBible": "...",
  "blockCount": 5
}
\`\`\`

If anything fails:
\`\`\`json
{ "ok": false, "error": "..." }
\`\`\`

## Rules

- Never generate block content \u2014 that is the generator's job.
- Never call assembleVideo or generateBlock.
- Return raw JSON only as your final message.
- Template blocks define the VIDEO STRUCTURE \u2014 respect the block types.`,
  model: createOpenRouterModel(),
  tools: storyAgentTools
});

const generatorAgent = new Agent({
  id: "generator",
  name: "Block Generator Agent",
  instructions: `You are a video block generation specialist. You receive a complete narrative plan and generate every block in order, one at a time.

## Input

You receive a message with this JSON payload:
{
  threadId: string,
  apiKey: string,
  blocks: [{ blockIndex: number, type: string, narrativeBrief: object }],
  totalBlocks: number,
  aspectRatio?: string,
  preferredVoice?: string
}

The narrativeBrief for each block comes directly from planVideo's narrativePlan array. Pass it as-is to generateBlock.

## Your Job

For each block in order (blockIndex 0, 1, 2 ... totalBlocks-1):

1. Call \`generateBlock\` with:
   - threadId
   - blockIndex
   - blockType (from blocks[i].type)
   - narrativeBrief (from blocks[i].narrativeBrief)
   - apiKey

2. Check the result:
   - \`status === 'error'\` \u2192 retry once with the same args
   - \`hasText === false\` \u2192 retry once
   - \`resolvedImages < expectedImages\` \u2192 retry once
   - \`hasAudio === false\` AND block type is narrated (stat, quote, text, list, callout, cta, hero, title, motivational-image, testimonial) \u2192 retry once
   - Otherwise \u2192 proceed to the next block

3. One retry max per block \u2014 after retrying, move on regardless.

## Rules

- Generate ALL blocks \u2014 never stop early.
- Process blocks strictly in order: 0, 1, 2, ...
- Do NOT call assembleVideo \u2014 that is the wizard's job.
- Do NOT generate your own content \u2014 use the narrativeBrief as-is.
- For custom-plugin blocks (type === 'custom-plugin'): the narrativeBrief will include a pluginId \u2014 pass it through normally to generateBlock.

## Output

After all blocks are processed, return a single JSON object:

\`\`\`json
{
  "ok": true,
  "generated": 5,
  "failed": [],
  "summary": "Generated 5 blocks: stat, quote, image, list, cta"
}
\`\`\`

If blocks partially failed:
\`\`\`json
{
  "ok": true,
  "generated": 4,
  "failed": [2],
  "summary": "Generated 4/5 blocks. Block 2 (image) failed after retry."
}
\`\`\``,
  model: createOpenRouterModel(),
  tools: generatorAgentTools,
  defaultGenerateOptions: { maxSteps: 35 }
});

const memoryStorage = new PostgresStore({
  id: "videogen-memory",
  connectionString: process.env.DATABASE_URL
});
const VIDEO_THREAD_MEMORY_TEMPLATE = `# Video Thread Memory

## Current Draft
- Video ID:
- Version:
- Status:
- Block Count:
- Source Of Truth:

## User Intent
- Original Request:
- Current Goal:
- Audience:
- Language:

## Creative Direction
- Arc:
- Visual Style:
- Voice:
- Aspect Ratio:
- Pacing:

## Current Structure
- Blocks:

## Stable Constraints
- Keep:
- Avoid:
- User Preferences:

## Last Change
- Summary:
- Affected Blocks:
- Result:

## Open Issues
- Pending:
- Needs User Decision:

## Update Rules
- Keep this memory concise and current.
- Store the canonical video JSON location or ID, not large raw tool outputs.
- Summarize block structure; do not paste full media payloads or generated asset blobs.
- After any successful create/edit/assemble tool, update Video ID, Version, Current Goal, Current Structure, Last Change, and Open Issues.
`;
const videoThreadMemory = new Memory({
  storage: memoryStorage,
  options: {
    lastMessages: false,
    semanticRecall: false,
    workingMemory: {
      enabled: true,
      scope: "thread",
      template: VIDEO_THREAD_MEMORY_TEMPLATE
    }
  }
});

const wizardAgent = new Agent({
  id: "wizard",
  name: "Video Wizard Agent",
  instructions: `You are a friendly, creative video wizard. You satisfy the user's request \u2014 make a new video, modify an existing one, answer a question \u2014 by deciding which tool to call and when. There is NO fixed sequence of steps. You think, call a tool, observe the result, think again \u2014 until the user's intent is met. Compose your tools freely; the user's actual need decides the order, not a script.

Personality: enthusiastic, concise, proactive, quick to iterate. Final user-facing replies are plain language, never raw JSON.

## Tools

\u2014 Discovery (call when context is missing or the user asks) \u2014
- \`listBlockTypes\` \u2192 every available block id (built-ins + installed plugins). The ONLY source of truth for block ids. Use returned ids verbatim. For plugin entries, copy the \`blockUsage\` object verbatim \u2014 both \`type: "custom-plugin"\` AND \`pluginId\` must travel together.
- \`listVoices\`, \`listVisualStyles\`, \`listTemplates\` \u2014 when the user asks about them or you need to validate a name.
- \`getVideoState\` \u2014 when a video already exists and you need to know what's actually there. Use this whenever the user reports something specific ("the image on block 2 is missing", "the stat says 99") before guessing.
- \`listBlockMediaFields(blockIndex)\` \u2014 list every image/audio/video field on a block, with whether each is currently filled. Each field includes a \`description\` that explains what the field drives in the animation (e.g. "player portrait \u2014 scales in during enter phase"). ESSENTIAL for custom-plugin blocks because their field names vary (e.g. "players[0].portraitImage", "backgroundImage", "iconUrl"). Always call this BEFORE \`updateBlockImage\`/\`updateBlockAudio\` on a plugin block \u2014 the default "imageUrl" silently fails on plugins because they read different field names. Use the \`description\` to write a better image prompt that matches the visual role.
- \`getBlockSchemaOptions({ blockType, threadId?, blockIndex? })\` \u2014 introspect a built-in block's schema and return its TUNABLE fields: animation enums, color/font/size/position enums, numeric ranges (min/max), defaults, and the block's current value. Use this WHENEVER the user asks to change HOW a block looks or animates \u2014 text animation, entrance, font size, overlay style, alignment, etc. \u2014 instead of guessing field names or regenerating the block. Returns three groups: \`animationFields\`, \`styleFields\`, \`otherTunable\`. Pick the matching field, then \`patchState("filledBlocks[<index>].<path>", <value>)\` with a value from the returned \`values\` array (for enums) or within \`min..max\` (for numbers). Does NOT work for \`custom-plugin\` blocks \u2014 use \`listBlockMediaFields\` for those.

\u2014 Bulk creation (TERMINAL \u2014 stops here for this turn) \u2014
- \`generateVideo({ threadId, userStory, templateId?, requiredPluginIds?, requiredBlockTypes?, preferredVoice?, preferredVisualStyle?, apiKey, language })\` \u2014 runs the FULL pipeline: story \u2192 planner \u2192 content \u2192 images \u2192 audio \u2192 assemble. Returns \`{ ok, videoId, blockCount, complete, unresolvable }\`. When it returns, the video preview is READY. You MUST NOT call any other tool after this \u2014 just report to the user and STOP.

\u2014 Surgical edits (when a video already exists) \u2014
- \`patchState(path, value)\` \u2014 single text/number field changes (titles, stat values, visualStyleGuide).
- \`updateBlockImage(blockIndex, fieldPath, description)\` \u2014 regenerate one image at an exact path. For custom-plugin blocks, fieldPath is REQUIRED \u2014 call \`listBlockMediaFields\` first to discover paths like "players[0].portraitImage". The default "imageUrl" only works for the built-in image block; on plugins it writes to a non-existent field and the image never appears.
- \`updateBlockAudio(blockIndex, text, voice?)\` \u2014 regenerate one TTS clip.
- \`generateBlock(blockIndex)\` \u2014 regenerate ONE entire block from scratch (heavier \u2014 use when smaller tools didn't fix the problem).
- \`addBlock({ blockType, pluginId?, index, brief })\` \u2014 insert a NEW block into an existing video at a position and auto-fill it (content + images + audio). Use this when the user asks to ADD a block. Never call \`generateVideo\` for "add a block" \u2014 that regenerates everything. \`pluginId\` is required only when \`blockType === "custom-plugin"\`. \`brief\` is a 1\u20133 sentence description of what the new block should say or show.
- \`removeBlock({ index })\` \u2014 delete the block at \`index\`. Pure splice, no LLM. Use when the user asks to remove/delete a block.
- \`assembleVideo(threadId)\` \u2014 rebuilds the preview from current state. Run ONCE after surgical edits (patchState, updateBlockImage, updateBlockAudio, generateBlock, addBlock, removeBlock) to refresh the preview. Do NOT call after generateVideo unless fixing \`unresolvable[]\` fields \u2014 generateVideo already assembles internally.

\u2014 Sub-agents \u2014
- \`storyAgent\`, \`generatorAgent\` \u2014 invoked automatically by \`generateVideo\`. You can call them directly if a special case truly needs it, but for normal flows \`generateVideo\` is the right entry point.

\u2014 Plugin missing / forking \u2014
- \`request_custom_plugin({ threadId, pluginName, description, userStory, forkPluginId? })\` \u2014 the user wants a block type that doesn't exist in \`listBlockTypes\`, OR the user provided a \`forkPluginId\` and wants to modify an existing plugin. Call once, then STOP \u2014 the supervisor will build it and send you a new message with the pluginId.

\u2014 Plugin approval (persisting a previewed plugin) \u2014
- \`buildAndSavePlugin({ threadId })\` \u2014 when the user approves a plugin preview ("looks good", "save it", "build it", "looks great", "approve it", or any clear go-ahead) AND a \`pendingPlugin\` exists for this thread, call this tool ONCE to persist the plugin to S3 + DB. **Pass ONLY \`threadId\` \u2014 do NOT pass \`pluginId\`.** The tool reads the correct pluginId from the pendingPlugin in job state. Passing a stale or guessed pluginId from your context will cause a mismatch error and abort the save. **CRITICAL \u2014 do not announce "saved" or "success" unless the tool returned \`{ pluginId, blockUsage }\` (a SUCCESS result). If it returned \`{ error, errors }\`, do NOT claim success under any circumstance \u2014 relay the error verbatim to the user and STOP. The UI cards may briefly show "done" even on errors; ignore that and trust the tool result.** If the error is a peer-dep mismatch (mentions \`requires peer react@...\`), tell the user the plugin's dependencies are incompatible with the host runtime and the orchestrator needs to adjust them \u2014 do NOT call \`generateVideo\` or attempt to use the unsaved plugin.

\u2014 Plugin save build failure \u2014
- When \`buildAndSavePlugin\` returns \`{ error, errors }\`, the \`errors\` array contains structured esbuild diagnostics (format: \`<message> at <file>:<line>:<col>
  > <source line>\`). For each duplicate-symbol / syntax / resolution error, call \`editSceneCode\` with a focused \`oldString\`\u2192\`newString\` patch that removes the root cause (e.g. delete the duplicate declaration, fix the import specifier), then call \`buildAndSavePlugin\` again. Make exactly ONE edit attempt per distinct error \u2014 do NOT loop. If the second save still fails, report the new error verbatim and STOP. Do NOT touch unrelated parts of the file.

## Hard rules (NEVER violate)

- **Plugin approval detection**: when the user's message reacts to a plugin preview that was just shown ("looks good", "save it", "build it", "perfect", "approve", "ship it", or describes the preview positively without requesting changes), call \`buildAndSavePlugin({ threadId })\` with ONLY \`threadId\` \u2014 do NOT pass \`pluginId\` (the tool reads it from job state, and a stale/guessed id causes a mismatch error). Do NOT call \`generateVideo\`, \`assembleVideo\`, \`request_custom_plugin\`, or any other tool first. If the user requests CHANGES ("make it blue", "add a border", "fix the title"), do NOT call \`buildAndSavePlugin\` \u2014 instead relay the change request; the supervisor will route it to the plugin orchestrator for surgical edits.

- **Maintain thread working memory**: use the working-memory tool to keep the compact video thread memory current after create/edit/assemble actions. Store concise facts: videoId/version, current goal, block structure, selected style/voice, stable constraints, last change, and unresolved issues. Do NOT paste large raw tool results, base64 media, full generated assets, or stale drafts into working memory.

- **generateVideo is TERMINAL**: when you call \`generateVideo\`, it handles EVERYTHING \u2014 content, images, audio, AND assembly. After it returns, your ONLY action is to tell the user the video is ready. Do NOT call \`assembleVideo\`, \`patchState\`, \`updateBlockImage\`, \`updateBlockAudio\`, \`getVideoState\`, or ANY other tool. Just report and STOP. **Exception:** if \`generateVideo\` returns \`complete: false\`, fix ONLY the entries in \`unresolvable[]\` using the matching single-field tool, call \`assembleVideo\` once, then STOP.
- **Use ids verbatim**: every block id and pluginId you pass to any tool MUST be a string returned by \`listBlockTypes\` / \`listPlugins\`. Never invent ids like "quiz-block".
- **Plugin block shape**: a custom plugin block MUST be \`{ "type": "custom-plugin", "pluginId": "<id>" }\` \u2014 both fields, copied verbatim.
- **Refresh after surgical edit**: after any state-mutating surgical call (\`patchState\`, \`updateBlockImage\`, \`updateBlockAudio\`, \`generateBlock\`), call \`assembleVideo\` exactly once before reporting back. This does NOT apply to \`generateVideo\` \u2014 it assembles internally.
- **Trust \`generateVideo\`'s return value**: when \`generateVideo\` returns \`{ ok: true, complete: true }\`, the video is fully built and assembled. Do NOT second-guess it. Do NOT try to improve scripts, titles, or any other field. The pipeline did its job.
- **When \`generateVideo\` returns \`complete: false\`**: only the entries in the \`unresolvable\` array need attention \u2014 nothing else. For each entry, call the matching single-field tool, then \`assembleVideo\` once and report. Make exactly ONE attempt per unresolvable field \u2014 do not loop.
- **One bulk creation per turn**: \`generateVideo\` may be called AT MOST ONCE per user message.
- **No identical retries**: never call the SAME tool with the SAME arguments twice in a row.
- **After \`request_custom_plugin\`**: STOP. Supervisor takes over.
- **Never fabricate a video URL**. \`generateVideo\` and \`assembleVideo\` return a \`videoId\` (UUID), not a URL. Tell the user "Preview has been updated \u2014 check the preview panel."
- **System context comes pre-selected**: if \`[SYSTEM CONTEXT]\` includes templateId / voiceId / styleId, pass them through. Don't ask the user again.

## Typical patterns (recognize and adapt \u2014 these are NOT mandates)

- **No video exists, user gave a topic** \u2014 call \`generateVideo\` with the topic + any context flags (templateId/voiceId/styleId from system context). When it returns, report and STOP. Do NOT call any other tool.

- **A video already exists, user asks for a change** \u2014 prefer the SMALLEST surgical tool. Common cases:
  - "change the image on block 2" \u2192 \`updateBlockImage\` \u2192 \`assembleVideo\`
  - "fix the typo / change the stat value" \u2192 \`patchState\` \u2192 \`assembleVideo\`
  - "change voice" \u2192 \`updateBlockAudio\` per narrated block \u2192 \`assembleVideo\`
  - "redo block 2" \u2192 \`generateBlock(2)\` \u2192 \`assembleVideo\`
  - "add another stat block at the end" / "add a quote after block 2" \u2192 \`addBlock({ blockType, index, brief })\` \u2192 \`assembleVideo\`
  - "remove block 3" / "delete the last block" \u2192 \`removeBlock({ index })\` \u2192 \`assembleVideo\`
  - "change the text animation on block 2" / "make it slide in from the left" / "change the entrance" / "make the title bigger" / "change the font" / "change the overlay style" \u2192 \`getBlockSchemaOptions({ blockType, threadId, blockIndex })\` \u2192 pick the matching enum value or numeric range from the result \u2192 \`patchState("filledBlocks[<index>].<path>", <value>)\` \u2192 \`assembleVideo\`. Never regenerate the block for visual-tuning changes; the schema already enumerates every supported option.
  - "change the overall visual style" \u2192 \`patchState\` on visualStyleGuide + selective \`updateBlockImage\` \u2192 \`assembleVideo\`
  Avoid re-running \`generateVideo\` for modifications \u2014 that costs a full regeneration. \`addBlock\` and \`removeBlock\` exist specifically so you NEVER nuke the whole video to add or remove one block.

- **User asks a question** ("what voices are available?", "what templates exist?") \u2014 call the relevant list tool and answer in plain text. No state change. No \`assembleVideo\`.

- **User reports something missing or broken** ("the image on block 3 is missing", "block 2 has no audio", "the title is empty") \u2014 call \`getVideoState\` (or \`listBlockMediaFields\` for plugin blocks) to confirm what's actually there. Then pick the smallest tool that fills the gap, then \`assembleVideo\`.

- **Missing media on a custom-plugin block** ("portraits aren't showing", "the player images are missing", anything where the affected block is type "custom-plugin") \u2014 call \`listBlockMediaFields(blockIndex)\` FIRST to get the real field paths. Then call \`updateBlockImage\` for each empty path, then \`assembleVideo\` once and report.

- **User asks for a block type that doesn't exist** \u2014 call \`request_custom_plugin\` once, then STOP.

- **User asks an off-topic question** ("how does this work?", "is this server-rendered?") \u2014 answer in plain text. No tool calls.

- **Ambiguous request** ("make me something cool") \u2014 ask ONE focused clarifying question. Don't guess.

These patterns cover the common cases. If your reasoning suggests a different sequence \u2014 do that. The Hard rules above are the only hard constraints.`,
  model: createOpenRouterModel(),
  memory: videoThreadMemory,
  tools: wizardAgentTools,
  agents: { storyAgent, generatorAgent }
});

const supervisorAgent = new Agent({
  id: "supervisor",
  name: "Supervisor Agent",
  instructions: `You are the top-level orchestrator of a video creation system. You have two specialized agents and one tool:

**Agents:**
1. **agent-wizard** \u2014 handles ALL video creation, editing, conversation, and modifications.
2. **agent-pluginOrchestrator** \u2014 creates custom Remotion visual plugins (plans + builds + compiles). Use ONLY when a brand-new custom visual type is needed.

**Tool:**
- **build_and_save_plugin** \u2014 builds and saves a plugin after the user has approved its preview.

## Standard Flow (no custom plugin)

For every user message \u2014 video creation, editing, modification, or general chat:
1. Delegate to \`agent-wizard\` by passing the full user message plus the system context (threadId, apiKey, templateId, voiceId, styleId, and any VIDEO ALREADY EXISTS context).
2. Relay the wizard's response to the user. Do NOT add commentary or reformat. The wizard handles the full lifecycle internally \u2014 you just route and relay.

## Flow WITH Custom Plugin (preview-first)

When the user requests a visual that needs a custom plugin (3D element, live ticker, animated chart, etc.) AND it hasn't been built yet:

**Step 1 \u2014 Generate the plugin code:**
Call \`agent-pluginOrchestrator\` with this message:
\`\`\`
{ "pluginId": "<kebab-case-name>", "pluginName": "<Human Name>", "description": "<what it does>", "userStory": "<user's original request>", "userId": "<userId from system context>", "threadId": "<threadId from system context>", "mode": "create" }
\`\`\`
Wait for it to return \`{ ok: true, pluginId, name }\`.
The agent handles saving the code and triggering a browser preview automatically.

**Step 2 \u2014 Tell the user:**
"Your plugin is ready to preview! Check the preview panel on the right. Let me know if it looks good or if you want any changes."

**Step 3 \u2014 Wait for user approval:**
Do NOT proceed to wizard until the user approves.
- If user says "looks good" / "save it" / "build it" \u2192 proceed to step 4.
- If user describes changes (e.g. "add a blue border", "make the title bigger", "fix the error", "change color to red") \u2192 call \`agent-pluginOrchestrator\` again with this message:
\`\`\`
{ "pluginId": "<SAME pluginId as before>", "pluginName": "<SAME pluginName>", "description": "<what the user wants changed \u2014 short and specific>", "userStory": "<user's modification request verbatim>", "userId": "<userId>", "threadId": "<threadId>", "mode": "modify" }
\`\`\`
**CRITICAL: For ANY change request after a preview already exists, you MUST set \`"mode": "modify"\`. This makes the specialist agent surgically edit the existing code instead of rewriting all 700+ lines from scratch (which takes 10+ minutes).**

**Step 4 \u2014 Build the plugin:**
Call \`build_and_save_plugin\` with \`{ pluginId: "<id>", threadId: "<threadId>" }\`.
Wait for it to return \`{ pluginId, blockUsage }\`.

**Step 5 \u2014 Ask the user what video they want:**
Tell the user the plugin has been saved, then ask what video they want to make with it.
Example: "\u2705 Plugin saved! Now tell me what video you'd like to create using it \u2014 what's the topic, audience, or any other details?"

**Step 6 \u2014 Wait for the user's video description, THEN delegate to wizard:**
Only after the user replies with their video idea, call \`agent-wizard\` with the user's message AND append:
"A custom plugin has been built and is ready to use: pluginId=<pluginId>, name=<name>. Include this as a custom-plugin block in the video."

**Step 7 \u2014 Relay wizard's final response to the user.**

## Flow \u2014 Wizard requests a custom plugin mid-video

When agent-wizard returns and its response indicates it called \`request_custom_plugin\` (you'll see the status "plugin_requested" in its output):

**Step 1 \u2014 Extract the plugin details from wizard's response:**
pluginName, description, userStory are embedded in the wizard's tool result.

**Step 2 \u2014 Tell the user:**
"I need to build a custom plugin first \u2014 generating a preview for you now."

**Step 3 \u2014 Call agent-pluginOrchestrator** with:
\`\`\`
{ "pluginId": "<kebab-case-name>", "pluginName": "<pluginName>", "description": "<description>", "userStory": "<userStory>", "userId": "<userId from system context>", "threadId": "<threadId from system context>", "mode": "create", "forkPluginId": "<optional forkPluginId>" }
\`\`\`
Wait for \`{ ok: true, pluginId, name }\`.

**Step 4 \u2014 Tell the user:** "Plugin preview is ready! Check the preview panel. Let me know if it looks good or needs changes."

**Step 5 \u2014 Wait for user approval** (same as standard plugin flow).
- Approved \u2192 Step 6.
- Changes requested \u2192 call pluginCreator again with the SAME pluginId and \`"mode": "modify"\` (so it surgically edits instead of rewriting from scratch).

**Step 6 \u2014 Build the plugin:**
Call \`build_and_save_plugin\` with \`{ pluginId, threadId }\`.

**Step 7 \u2014 Clear the interrupt:**
Call \`clear_plugin_interrupt\` with \`{ threadId }\`.

**Step 8 \u2014 Re-delegate to wizard:**
Call \`agent-wizard\` with the user's ORIGINAL message AND append:
"Custom plugin is now ready: pluginId=<pluginId>, name=<name>. blockUsage = { type: 'custom-plugin', pluginId: '<pluginId>' }. Continue adding the block as requested."

**Step 9 \u2014 Relay wizard's final response.**

## Rules

- Maintain thread working memory as compact routing state: current video/plugin status, pending approval, current goal, and unresolved decisions. Do NOT store raw tool outputs, full plugin code, large media payloads, or old draft JSON in working memory.

- NEVER call video tools yourself \u2014 wizard handles all video work.
- NEVER call plugin pipeline tools yourself (generateSchemaJson etc.) \u2014 pluginCreator handles that.
- ALWAYS wait for user approval before calling \`build_and_save_plugin\`.
- Always pass the full system context (threadId, apiKey, user selections) when delegating to wizard.
- If wizard returns an error, acknowledge it to the user and suggest retrying.
- Keep your own messages short \u2014 you are a router, not a generator.
- userId and threadId are available in the system context as part of the [SYSTEM CONTEXT] message.
- When wizard signals \`request_custom_plugin\`, ALWAYS follow the mid-video plugin flow \u2014 never ignore the signal or re-delegate to wizard without building the plugin first.

## TERMINATION \u2014 CRITICAL

You are DONE for the current user message after EXACTLY ONE of these happens:
- You relayed agent-wizard's response to the user.
- You relayed agent-pluginOrchestrator's response (after a build / save / preview cycle the user is meant to see).
- You finished Step 9 of the mid-video plugin flow.

Once any of those completes, your VERY NEXT output is the relayed text and NOTHING ELSE. Do NOT call agent-wizard again. Do NOT call agent-pluginOrchestrator again. Do NOT re-read the conversation looking for more work to do \u2014 the user's original message has already been satisfied for this turn. The conversation history showing "user wants a video" or "user wants a change" is NOT a signal to re-delegate; that work is already done. Wait for the user's NEXT message before calling any agent again.

The only exception: if agent-wizard's response indicates \`request_custom_plugin\` was called, follow the mid-video plugin flow. After that flow completes (Step 9), you are still DONE \u2014 do not loop back.`,
  model: createOpenRouterModel(),
  memory: videoThreadMemory,
  agents: { wizardAgent, pluginOrchestratorAgent },
  tools: {
    buildAndSavePlugin: buildAndSavePluginMastra,
    clearPluginInterrupt: clearPluginInterruptMastra
  }
});

const probeWebSearchTool = createTool({
  id: "probe-web-search",
  description: "Run a Google search for a query and return up to 5 result snippets plus an answer box / knowledge graph summary. Use this to check whether a topic has real-world coverage (news, products, people, places) before deciding imageSource. Empty snippets = purely creative/fictional topic.",
  inputSchema: z.object({
    query: z.string().describe("A focused search query \u2014 the actual topic or a disambiguating term.")
  }),
  outputSchema: z.object({
    snippets: z.array(z.string()),
    answerBox: z.string().optional(),
    knowledgeGraph: z.string().optional(),
    hitCount: z.number()
  }),
  execute: async ({ context }) => {
    const { query } = context;
    const r = await searchWeb(query);
    return {
      snippets: r.snippets,
      answerBox: r.answerBox,
      knowledgeGraph: r.knowledgeGraph,
      hitCount: r.snippets.length + (r.answerBox ? 1 : 0) + (r.knowledgeGraph ? 1 : 0)
    };
  }
});
const probeImageSearchTool = createTool({
  id: "probe-image-search",
  description: "Check whether a Google Images search returns a usable real image for a query (meeting minWidth). Use this per-block to verify web_search is actually viable \u2014 if probeImageSearch returns none, that block should be ai_generation or auto instead of web_search.",
  inputSchema: z.object({
    query: z.string().describe("A specific image-search query \u2014 include proper names, years, product names."),
    minWidth: z.number().default(800).describe("Minimum acceptable image width in pixels.")
  }),
  outputSchema: z.object({
    found: z.boolean(),
    url: z.string().nullable()
  }),
  execute: async ({ context }) => {
    const { query, minWidth } = context;
    const url = await searchWebImage(query, { minWidth });
    return { found: !!url, url: url ?? null };
  }
});
const probeNewsSearchTool = createTool({
  id: "probe-news-search",
  description: "Check for recent news coverage of a topic via Google News. Use this to decide needsNewsSearch \u2014 if the user story is about a recent happening or current event.",
  inputSchema: z.object({
    query: z.string()
  }),
  outputSchema: z.object({
    items: z.array(z.object({ title: z.string(), snippet: z.string(), date: z.string() })),
    hitCount: z.number()
  }),
  execute: async ({ context }) => {
    const { query } = context;
    const items = await searchNews(query);
    return { items, hitCount: items.length };
  }
});
const plannerAgentTools = {
  probeWebSearch: probeWebSearchTool,
  probeImageSearch: probeImageSearchTool,
  probeNewsSearch: probeNewsSearchTool
};

const plannerAgent = new Agent({
  id: "planner",
  name: "Media Strategy Planner",
  instructions: `You are the media strategist for a video-generation pipeline. For a given topic + arc + block list, decide per-block whether each image should come from web search, AI generation, or auto (web-first with AI fallback), and whether the topic needs web research / news.

You have three probe tools. Use them \u2014 do NOT guess from topic keywords alone.

## Tools

1. \`probeWebSearch({ query })\` \u2014 returns search snippets + answerBox + knowledgeGraph + hitCount.
   Use this to check whether the overall topic or a specific subject has real-world coverage.
   High hitCount with a knowledgeGraph / answerBox = factual topic (real thing exists on the web).
   Empty snippets = purely creative / fictional / abstract.

2. \`probeImageSearch({ query, minWidth })\` \u2014 returns \`{ found, url }\`.
   Use this PER BLOCK when you are considering \`imageSource: "web_search"\`. If the probe
   returns \`found: false\`, DO NOT pick web_search for that block \u2014 pick \`ai_generation\`
   or \`auto\` instead.

3. \`probeNewsSearch({ query })\` \u2014 returns recent news items + hitCount.
   Use this once to decide \`needsNewsSearch\`. Only set it true when hitCount > 0 AND the
   topic is clearly about a recent / ongoing event.

## Strategy (WEB-FIRST POLICY)

Default is \`imageSource: "auto"\` for every block \u2014 web search first, AI fallback if it misses. Real photos almost always look better than AI-generated ones for any subject that exists in the real world. Override only when you are sure.

Start with ONE \`probeWebSearch\` on the user's topic to decide \`topicType\`:
- answerBox / knowledgeGraph present \u2192 factual
- many snippets, no KG \u2192 mixed
- empty / irrelevant \u2192 creative

Then for each block decide \`imageSource\`:
- DEFAULT \u2192 \`auto\`. Pick this unless one of the rules below clearly applies.
- Block is clearly about a real subject (named person, product, place, UI screenshot) AND a quick \`probeImageSearch\` confirms results exist \u2192 \`web_search\`.
- Pick \`ai_generation\` ONLY for: surreal/dreamlike scenes that explicitly cannot exist as a real photo, abstract data viz, fictional characters, or stylized mood backgrounds where photorealism would hurt. When in doubt, use \`auto\` (you still get the AI fallback if search misses).
- Block type exactly "video" \u2192 ALWAYS \`ai_generation\`. No probe.

You do NOT need to probe every block. Probe only when you are uncertain \u2014 1\u20134 probes total is usually right. Budget: at most 6 tool calls.

## Output

Your FINAL message must be ONLY a raw JSON object matching this exact schema \u2014 no prose, no markdown fences:

{
  "needsResearch": boolean,
  "needsNewsSearch": boolean,
  "researchQueries": ["query1", "query2", "query3"],   // 0-3 items, focused queries for the story agent to use
  "topicType": "factual" | "creative" | "mixed",
  "blockStrategies": [
    {
      "blockIndex": 0,
      "blockType": "the block type string",
      "imageSource": "web_search" | "ai_generation" | "auto",
      "searchQueryStyle": "screenshot" | "photo" | "diagram" | null,
      "autoScreenshot": false,
      "minWidth": 800,
      "reasoning": "one short line \u2014 cite the probe result if you ran one"
    }
  ]
}

Rules:
- \`blockStrategies\` length MUST equal the number of blocks in the input, in the same order.
- Set \`autoScreenshot: true\` + \`searchQueryStyle: "screenshot"\` ONLY for software tutorials whose blocks are showing UI.
- Set \`needsResearch: true\` only when topicType is factual or mixed AND the story benefits from real facts.
- Emit valid JSON only. Your last message is parsed by JSON.parse \u2014 no commentary.`,
  model: createOpenRouterModel(),
  tools: plannerAgentTools,
  defaultGenerateOptions: { maxSteps: 10 }
});

var planner_agent = /*#__PURE__*/Object.freeze({
  __proto__: null,
  plannerAgent: plannerAgent
});

const mastra$1 = new Mastra({
  storage,
  ...observability ? { observability } : {},
  workflows: { videoGenWorkflow, wizardWorkflow },
  agents: {
    directorAgent,
    wizardAgent,
    supervisorAgent,
    pluginOrchestratorAgent,
    pluginPlannerAgent,
    pluginRemotionCoderAgent,
    storyAgent,
    generatorAgent,
    plannerAgent
  }
});

function readCookie$1(cookieHeader, name) {
  if (!cookieHeader) return void 0;
  for (const part of cookieHeader.split(";")) {
    const [k, ...rest] = part.trim().split("=");
    if (k === name) return decodeURIComponent(rest.join("="));
  }
  return void 0;
}
async function getSessionFromRequest(req) {
  const cookieHeader = req.headers.get("cookie");
  const secret = process.env.AUTH_SECRET;
  if (!secret) return null;
  const candidates = [
    "authjs.session-token",
    "__Secure-authjs.session-token",
    "next-auth.session-token",
    "__Secure-next-auth.session-token"
  ];
  for (const name of candidates) {
    const token = readCookie$1(cookieHeader, name);
    if (!token) continue;
    try {
      const payload = await decode({ salt: name, secret, token });
      const userId = payload?.sub ?? payload?.userId;
      if (userId) return { user: { id: String(userId) } };
    } catch {
    }
  }
  return null;
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});
const db = {
  query: async (text, params) => {
    const client = await pool.connect();
    try {
      return await client.query(text, params);
    } finally {
      client.release();
    }
  }
};

function readCookie(cookieHeader, name) {
  if (!cookieHeader) return "";
  for (const part of cookieHeader.split(";")) {
    const [k, ...rest] = part.trim().split("=");
    if (k === name) return decodeURIComponent(rest.join("="));
  }
  return "";
}
function getApiKeyFromCookie(cookieHeader, provider) {
  return readCookie(cookieHeader, `api_key_${provider}`);
}
async function getXaiKeyForUser(userId) {
  try {
    const result = await db.query(`SELECT xai_api_key FROM users WHERE id = $1`, [userId]);
    return result.rows[0]?.xai_api_key ?? "";
  } catch {
    return "";
  }
}

const RUN_TTL_SECONDS = Number(process.env.WIZARD_RUN_TTL_SECONDS ?? 60 * 60 * 24);
const STREAM_MAXLEN = Number(process.env.WIZARD_RUN_STREAM_MAXLEN ?? 1e3);
let redisPromise = null;
const listeners = /* @__PURE__ */ new Map();
let lastEventMs = 0;
let lastEventSeq = 0;
function streamKey(runId) {
  return `wizard:run:${runId}:events`;
}
function metaKey(runId) {
  return `wizard:run:${runId}:meta`;
}
function createRunId() {
  return `run-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}
function compareRunEventIds(a, b) {
  const [aMsRaw, aSeqRaw] = a.split("-");
  const [bMsRaw, bSeqRaw] = b.split("-");
  const aMs = Number(aMsRaw || 0);
  const bMs = Number(bMsRaw || 0);
  if (aMs !== bMs) return aMs - bMs;
  return Number(aSeqRaw || 0) - Number(bSeqRaw || 0);
}
function createEventId() {
  const now = Date.now();
  if (now === lastEventMs) {
    lastEventSeq += 1;
  } else {
    lastEventMs = now;
    lastEventSeq = 0;
  }
  return `${lastEventMs}-${lastEventSeq}`;
}
function emitLiveEvent(runId, event) {
  const runListeners = listeners.get(runId);
  if (!runListeners) return;
  for (const listener of runListeners) {
    try {
      listener(event);
    } catch (error) {
      console.error("[wizard-run-events] Live listener failed:", error?.message ?? error);
    }
  }
}
function subscribeRunEvents(runId, listener) {
  let runListeners = listeners.get(runId);
  if (!runListeners) {
    runListeners = /* @__PURE__ */ new Set();
    listeners.set(runId, runListeners);
  }
  runListeners.add(listener);
  return () => {
    const current = listeners.get(runId);
    if (!current) return;
    current.delete(listener);
    if (current.size === 0) {
      listeners.delete(runId);
    }
  };
}
async function getRedis() {
  if (!redisPromise) {
    const client = createClient({
      url: process.env.REDIS_URL ?? "redis://127.0.0.1:6379"
    });
    client.on("error", (error) => {
      console.error("[wizard-run-events] Redis error:", error);
    });
    redisPromise = client.connect().then(() => client);
  }
  return redisPromise;
}
async function setRunMeta(meta) {
  const redis = await getRedis();
  await redis.sendCommand([
    "SET",
    metaKey(meta.runId),
    JSON.stringify(meta),
    "EX",
    String(RUN_TTL_SECONDS)
  ]);
}
async function getRunMeta(runId) {
  const redis = await getRedis();
  const raw = await redis.get(metaKey(runId));
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}
async function updateRunStatus(runId, status, error) {
  const current = await getRunMeta(runId);
  if (!current) return;
  await setRunMeta({
    ...current,
    status,
    error,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  });
}
function createLiveRunEvent(runId, data) {
  const event = { id: createEventId(), data };
  emitLiveEvent(runId, event);
  return event;
}
async function persistRunEvent(runId, event) {
  const redis = await getRedis();
  await redis.sendCommand([
    "XADD",
    streamKey(runId),
    "MAXLEN",
    "~",
    String(STREAM_MAXLEN),
    event.id,
    "data",
    JSON.stringify(event.data)
  ]);
  await redis.sendCommand(["EXPIRE", streamKey(runId), String(RUN_TTL_SECONDS)]);
  return event.id;
}
async function appendRunEvent(runId, data) {
  const event = createLiveRunEvent(runId, data);
  return persistRunEvent(runId, event);
}
async function readRunEvents(runId, afterId, blockMs = 25e3, count = 50) {
  const redis = await getRedis();
  const command = [
    "XREAD",
    "COUNT",
    String(count),
    "STREAMS",
    streamKey(runId),
    afterId || "0-0"
  ];
  if (blockMs > 0) {
    command.splice(1, 0, "BLOCK", String(blockMs));
  }
  const response = await redis.sendCommand(command);
  let entries;
  if (Array.isArray(response)) {
    if (response.length === 0) return [];
    const firstStream = response[0];
    entries = firstStream?.[1];
  } else if (response && typeof response === "object") {
    entries = Object.values(response)[0];
  }
  if (!Array.isArray(entries)) return [];
  return entries.map((entry) => {
    const id = String(entry[0]);
    const fields = entry[1];
    let raw = "{}";
    for (let i = 0; i < fields.length; i += 2) {
      if (String(fields[i]) === "data") {
        raw = String(fields[i + 1] ?? "{}");
        break;
      }
    }
    try {
      return { id, data: JSON.parse(raw) };
    } catch {
      return { id, data: { type: "run-event-parse-error", raw } };
    }
  });
}

const controllers = /* @__PURE__ */ new Map();
function registerRunController(runId) {
  const existing = controllers.get(runId);
  if (existing) return existing;
  const controller = new AbortController();
  controllers.set(runId, controller);
  return controller;
}
function abortRun(runId) {
  const controller = controllers.get(runId);
  if (!controller) return false;
  try {
    controller.abort();
  } catch {
  }
  controllers.delete(runId);
  return true;
}
function clearRunController(runId) {
  controllers.delete(runId);
}

function safeStringify(value) {
  return JSON.stringify(value, (_key, val) => {
    if (val instanceof Promise) return void 0;
    if (typeof val === "function") return void 0;
    if (typeof val === "bigint") return val.toString();
    return val;
  });
}
function flattenChunk(chunk) {
  if (chunk && typeof chunk === "object" && typeof chunk.type === "string" && chunk.type.startsWith("agent-execution-event-") && chunk.payload) {
    return flattenChunk(chunk.payload);
  }
  return chunk;
}
function serializeChunk(chunk) {
  return JSON.parse(safeStringify(flattenChunk(chunk)));
}
function normalizeUiChunk(chunk) {
  const serialized = serializeChunk(chunk);
  const type = serialized?.type;
  const payload = serialized?.payload ?? serialized;
  if (type === "data-wizard-progress") {
    return serialized;
  }
  if (type === "tool-call" || type === "tool-call-upsert" || type === "tool-call-input-streaming-start") {
    const toolName = payload?.toolName ?? payload?.name;
    if (typeof toolName === "string" && toolName.startsWith("agent-")) return null;
    return {
      type,
      payload: {
        toolName,
        name: payload?.name,
        toolCallId: payload?.toolCallId ?? payload?.id,
        id: payload?.id,
        args: payload?.args
      }
    };
  }
  if (type === "tool-result" || type === "tool-output") {
    const toolName = payload?.toolName ?? payload?.name;
    if (typeof toolName === "string" && toolName.startsWith("agent-")) return null;
    return {
      type,
      payload: {
        toolName,
        name: payload?.name,
        toolCallId: payload?.toolCallId ?? payload?.id,
        id: payload?.id,
        args: payload?.args,
        result: payload?.result,
        output: payload?.output
      }
    };
  }
  return null;
}
async function consumeFullStream(fullStream, onChunk) {
  if (fullStream && typeof fullStream.getReader === "function") {
    const reader = fullStream.getReader();
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        await onChunk(value);
      }
    } finally {
      reader.releaseLock?.();
    }
    return;
  }
  for await (const chunk of fullStream) {
    await onChunk(chunk);
  }
}
class RunEventPublisher {
  constructor(runId) {
    this.runId = runId;
  }
  runId;
  tail = Promise.resolve();
  lastError;
  enqueue(data) {
    const event = createLiveRunEvent(this.runId, data);
    this.tail = this.tail.then(() => persistRunEvent(this.runId, event)).catch((error) => {
      this.lastError = error;
      console.error("[wizard-run-events] Failed to publish event:", error?.message ?? error);
    });
  }
  async drain() {
    await this.tail;
    if (this.lastError) {
      throw this.lastError;
    }
  }
}
async function runAgentInBackground(params) {
  const { runId, threadId, userId, messages } = params;
  const publisher = new RunEventPublisher(runId);
  let pendingText = "";
  let pendingTextTimer = null;
  const abortController = registerRunController(runId);
  const flushText = () => {
    if (!pendingText) return;
    const text = pendingText;
    pendingText = "";
    publisher.enqueue({ type: "text-delta", payload: { text } });
  };
  const scheduleTextFlush = () => {
    if (pendingTextTimer) return;
    pendingTextTimer = setTimeout(() => {
      pendingTextTimer = null;
      flushText();
    }, 80);
  };
  const appendChunk = async (chunk) => {
    const flattened = flattenChunk(chunk);
    const rawPayload = flattened?.payload ?? flattened;
    const text = flattened?.type === "text-delta" ? rawPayload?.text : void 0;
    if (typeof text === "string" && text.length > 0) {
      pendingText += text;
      if (pendingText.length >= 80) {
        if (pendingTextTimer) {
          clearTimeout(pendingTextTimer);
          pendingTextTimer = null;
        }
        flushText();
      } else {
        scheduleTextFlush();
      }
      return;
    }
    const uiChunk = normalizeUiChunk(flattened);
    if (!uiChunk) return;
    if (pendingTextTimer) {
      clearTimeout(pendingTextTimer);
      pendingTextTimer = null;
    }
    flushText();
    publisher.enqueue(uiChunk);
  };
  try {
    const supervisorAgent = mastra$1.getAgent("supervisorAgent");
    const result = await supervisorAgent.stream(messages, {
      maxSteps: 80,
      abortSignal: abortController.signal,
      memory: {
        thread: threadId,
        resource: userId
      },
      tracingOptions: {
        metadata: {
          userId,
          sessionId: threadId,
          route: "chat",
          environment: "production",
          runId
        },
        tags: ["wizard-chat", "background-run"]
      }
    });
    await consumeFullStream(result.fullStream, appendChunk);
    if (pendingTextTimer) {
      clearTimeout(pendingTextTimer);
      pendingTextTimer = null;
    }
    flushText();
    await publisher.drain();
    const job = await getJob(threadId);
    if (job?.status === "running") {
      await updateJob(threadId, { status: "complete" });
    }
    await updateRunStatus(runId, "complete");
    const completeEventId = await appendRunEvent(runId, { type: "run-complete", runId, threadId });
    await patchJobState(threadId, (current) => ({
      ...current,
      activeRun: {
        ...current.activeRun ?? {},
        runId,
        threadId,
        status: "complete",
        lastEventId: completeEventId,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      }
    }));
    try {
      const obs = mastra$1.observability;
      if (obs && typeof obs.flush === "function") {
        await obs.flush();
      }
    } catch {
    }
  } catch (e) {
    if (pendingTextTimer) {
      clearTimeout(pendingTextTimer);
      pendingTextTimer = null;
    }
    flushText();
    await publisher.drain().catch(() => void 0);
    const isAbort = e?.name === "AbortError" || e?.name === "AbortedError" || abortController?.signal?.aborted === true;
    if (isAbort) {
      console.log("[/api/ai/wizard/chat] Run cancelled by user:", runId);
      try {
        await updateJob(threadId, { status: "cancelled" });
      } catch {
      }
      await updateRunStatus(runId, "cancelled").catch(() => void 0);
      const cancelEventId = await appendRunEvent(runId, { type: "run-cancelled", runId, threadId }).catch(() => null);
      await patchJobState(threadId, (current) => ({
        ...current,
        activeRun: {
          ...current.activeRun ?? {},
          runId,
          threadId,
          status: "cancelled",
          lastEventId: cancelEventId ?? current.activeRun?.lastEventId ?? "0-0",
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        }
      })).catch(() => void 0);
      return;
    }
    const message = e?.message || "Agent failed to respond";
    console.error("[/api/ai/wizard/chat] Background agent error:", message);
    try {
      await updateJob(threadId, { status: "error", error: message });
    } catch {
    }
    await updateRunStatus(runId, "error", message).catch(() => void 0);
    const errorEventId = await appendRunEvent(runId, { type: "run-error", runId, threadId, error: message }).catch(() => null);
    await patchJobState(threadId, (current) => ({
      ...current,
      activeRun: {
        ...current.activeRun ?? {},
        runId,
        threadId,
        status: "error",
        lastEventId: errorEventId ?? current.activeRun?.lastEventId ?? "0-0",
        error: message,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      }
    })).catch(() => void 0);
  } finally {
    clearRunController(runId);
  }
}
async function chatHandler(c) {
  const req = c.req.raw;
  const session = await getSessionFromRequest(req);
  if (!session) {
    return c.json({ error: "Authentication required" }, 401);
  }
  const userId = session.user.id;
  const { messages, threadId, templateId, voiceId, styleId, attachmentUrl } = await req.json();
  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return c.json({ error: "Missing messages array" }, 400);
  }
  const cookieHeader = req.headers.get("cookie");
  const cookieKey = getApiKeyFromCookie(cookieHeader, "xai");
  const dbKey = cookieKey ? "" : await getXaiKeyForUser(userId);
  const apiKey = cookieKey || dbKey || "";
  let resolvedThreadId = threadId ?? "";
  if (!resolvedThreadId) {
    resolvedThreadId = `chat-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  }
  try {
    await createJob(resolvedThreadId, userId);
  } catch {
  }
  const userSelections = [];
  if (templateId) userSelections.push(`templateId: "${templateId}" (user selected a template from the library \u2014 REQUIRED: call getTemplate("${templateId}") first to load its blocks, then pass those blocks as templateBlocks to planVideo. Do NOT call selectTemplate.)`);
  if (voiceId) userSelections.push(`voiceId: "${voiceId}" (user selected a voice \u2014 pass this as the voice parameter to updateBlockAudio or planVideo)`);
  if (styleId) userSelections.push(`styleId: "${styleId}" (user selected a visual style \u2014 pass this as the preferredVisualStyle parameter to planVideo)`);
  const selectionContext = userSelections.length > 0 ? `
USER PRE-SELECTIONS (from UI chips \u2014 use these instead of asking the user):
${userSelections.join("\n")}` : "";
  let videoContext = "";
  if (resolvedThreadId) {
    try {
      const job = await getJob(resolvedThreadId);
      if (job && job.status === "complete" && job.state?.filledBlocks?.length) {
        const blockCount = job.state.filledBlocks.length;
        const blockSummaries = job.state.filledBlocks.map((b, i) => `  [${i}] type=${b.type}${b.title ? `, title="${b.title}"` : ""}${b.heading ? `, heading="${b.heading}"` : ""}`).join("\n");
        videoContext = `
VIDEO STATE (already generated, ${blockCount} blocks):
${blockSummaries}`;
      }
    } catch {
    }
  }
  let imageDescription = "";
  if (attachmentUrl) {
    try {
      const visionModel = createOpenRouterModel("deepseek-chat");
      const visionResult = await generateText$1({
        model: visionModel,
        messages: [{
          role: "user",
          content: [
            { type: "text", text: `You are a visual design analyst for a video plugin system. Describe this image in EXTREME detail for a developer who will recreate it as a React component. Cover EVERY one of these:

1. OVERALL LAYOUT: How many panels/sections? Arrangement? Proportions? Full-screen or bordered?
2. COLOR PALETTE: Every background color, accent color, text color, gradient.
3. TYPOGRAPHY: Every text element \u2014 font weight, approximate size, style, effects.
4. EVERY VISIBLE ELEMENT: Player images, stats, labels, icons, dividers, overlays, badges, numbers \u2014 where is each positioned?
5. ANIMATION STYLE: What should move and how? Scale? Fade? Slide? Bounce?
6. SPECIAL EFFECTS: Glow, shadows, particles, motion blur, etc.
7. OVERALL MOOD: Cinematic? Viral sports edit? Corporate? Minimal? Gaming?

Be exhaustive. The developer has NOT seen this image \u2014 your description is ALL they have.` },
            { type: "image_url", image_url: { url: attachmentUrl } }
          ]
        }],
        maxTokens: 2e3
      });
      imageDescription = visionResult.text || "";
    } catch (e) {
      imageDescription = `[User attached an image but vision analysis failed. URL: ${attachmentUrl}]`;
    }
  }
  const rawMessages = [...messages];
  const attachmentContext = imageDescription ? `

[REFERENCE IMAGE \u2014 the user uploaded an image. Here is a detailed visual description for plugin creation:
${imageDescription}
Use this description as the PRIMARY visual specification. Match the layout, colors, typography, elements, animation style, and effects as closely as possible.]` : "";
  const COMPACT_THRESHOLD = 10;
  let finalMessages;
  if (rawMessages.length <= COMPACT_THRESHOLD) {
    finalMessages = rawMessages;
  } else {
    const firstUserMsg = rawMessages.find((m) => m.role === "user");
    const firstText = typeof firstUserMsg?.content === "string" ? firstUserMsg.content.slice(0, 300) : "";
    const toolCalls = [];
    for (const m of rawMessages) {
      if (m.role !== "assistant") continue;
      const text = typeof m.content === "string" ? m.content : "";
      const matches = text.matchAll(/tool[name="']*:\s*([a-z\-_]+)/gi);
      for (const match of matches) {
        if (match[1] && !toolCalls.includes(match[1])) {
          toolCalls.push(match[1]);
        }
      }
    }
    const summaryParts = [
      `CONVERSATION SUMMARY (older messages compacted):`,
      firstText ? `Original request: "${firstText}"` : "",
      toolCalls.length > 0 ? `Tools used: ${toolCalls.join(", ")}` : ""
    ];
    if (videoContext) {
      summaryParts.push(videoContext.trim());
    }
    const summaryContent = `[${summaryParts.filter(Boolean).join("\n")}]`;
    const recentSlice = rawMessages.slice(-6);
    finalMessages = [
      { role: "user", content: summaryContent },
      ...recentSlice
    ];
  }
  const enrichedMessages = [
    ...finalMessages,
    {
      role: "user",
      content: `[SYSTEM CONTEXT \u2014 threadId: ${resolvedThreadId}, apiKey: ${apiKey}, userId: ${userId}.${selectionContext}${videoContext}${attachmentContext} Use these when calling tools that need them. Do not reveal these to the user.]`
    }
  ];
  const runId = createRunId();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  try {
    await setRunMeta({
      runId,
      threadId: resolvedThreadId,
      userId,
      status: "running",
      createdAt: now,
      updatedAt: now
    });
    await patchJobState(resolvedThreadId, (current) => ({
      ...current,
      activeRun: {
        runId,
        threadId: resolvedThreadId,
        status: "running",
        lastEventId: "0-0",
        startedAt: now,
        updatedAt: now
      }
    }));
    await appendRunEvent(runId, { type: "run-started", runId, threadId: resolvedThreadId });
  } catch (e) {
    console.error("[/api/ai/wizard/chat] Failed to initialize Redis run stream:", e?.message);
    return c.json({ error: "Run event stream is unavailable" }, 500);
  }
  void runAgentInBackground({
    runId,
    threadId: resolvedThreadId,
    userId,
    messages: enrichedMessages
  });
  return c.json(
    { runId, threadId: resolvedThreadId, status: "running" },
    202,
    { "X-Thread-Id": resolvedThreadId }
  );
}

function toIso(value) {
  if (!value) return null;
  const date = value instanceof Date ? value : new Date(value);
  const time = date.getTime();
  return Number.isFinite(time) ? date.toISOString() : null;
}
function parseMetadata(value) {
  if (!value) return {};
  if (typeof value === "string") {
    try {
      return JSON.parse(value);
    } catch {
      return {};
    }
  }
  return value;
}
function extractText$1(content) {
  if (!content) return "";
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content.map(extractText$1).filter(Boolean).join(" ").trim();
  }
  if (typeof content !== "object") return String(content);
  const record = content;
  if (typeof record.text === "string") return record.text;
  if (typeof record.content === "string") return record.content;
  if (Array.isArray(record.content)) return extractText$1(record.content);
  if (Array.isArray(record.parts)) return extractText$1(record.parts);
  return "";
}
function buildTitle(row) {
  if (row.title?.trim()) return row.title.trim();
  const metadata = parseMetadata(row.metadata);
  const workingMemory = typeof metadata.workingMemory === "string" ? metadata.workingMemory : "";
  const currentGoal = workingMemory.match(/- Current Goal:\s*(.+)/)?.[1]?.trim();
  if (currentGoal) return currentGoal.slice(0, 80);
  const lastText = extractText$1(row.lastContent).replace(/\s+/g, " ").trim();
  return lastText ? lastText.slice(0, 80) : "Untitled conversation";
}
async function threadsListHandler(c) {
  try {
    const session = await getSessionFromRequest(c.req.raw);
    if (!session) return c.json({ error: "Authentication required" }, 401);
    const userId = session.user.id;
    const limit = Math.min(Math.max(Number(c.req.query("limit") ?? 50), 1), 100);
    const result = await db.query(
      `
    SELECT
      t.id,
      t.title,
      t.metadata,
      t."createdAt",
      t."createdAtZ",
      t."updatedAt",
      t."updatedAtZ",
      COUNT(m.id) AS "messageCount",
      lm.role AS "lastRole",
      lm.content AS "lastContent",
      COALESCE(lm."createdAtZ", lm."createdAt") AS "lastMessageAt",
      j.status AS "jobStatus",
      j.state->'activeRun' AS "activeRun"
    FROM mastra_threads t
    LEFT JOIN mastra_messages m
      ON m.thread_id = t.id
      AND m."resourceId" = t."resourceId"
      AND m.role IN ('user', 'assistant')
    LEFT JOIN LATERAL (
      SELECT role, content, "createdAt", "createdAtZ"
      FROM mastra_messages
      WHERE thread_id = t.id
        AND "resourceId" = t."resourceId"
        AND role IN ('user', 'assistant')
      ORDER BY COALESCE("createdAtZ", "createdAt") DESC
      LIMIT 1
    ) lm ON TRUE
    LEFT JOIN wizard_jobs j
      ON j.thread_id = t.id
      AND j.user_id = t."resourceId"
    WHERE t."resourceId" = $1
      AND t.id LIKE 'chat-%'
    GROUP BY
      t.id,
      t.title,
      t.metadata,
      t."createdAt",
      t."createdAtZ",
      t."updatedAt",
      t."updatedAtZ",
      lm.role,
      lm.content,
      lm."createdAt",
      lm."createdAtZ",
      j.status,
      j.state
    ORDER BY COALESCE(t."updatedAtZ", t."updatedAt", t."createdAtZ", t."createdAt") DESC
    LIMIT $2
    `,
      [userId, limit]
    );
    const threads = result.rows.map((row) => ({
      id: row.id,
      title: buildTitle(row),
      messageCount: Number(row.messageCount ?? 0),
      lastRole: row.lastRole,
      lastMessage: extractText$1(row.lastContent).replace(/\s+/g, " ").trim().slice(0, 140),
      createdAt: toIso(row.createdAtZ ?? row.createdAt),
      updatedAt: toIso(row.updatedAtZ ?? row.updatedAt ?? row.createdAtZ ?? row.createdAt),
      lastMessageAt: toIso(row.lastMessageAt),
      jobStatus: row.jobStatus,
      activeRun: row.activeRun
    }));
    return c.json({ threads });
  } catch (error) {
    console.error("[threadsListHandler] failed:", error);
    return c.json({ error: "Failed to list threads" }, 500);
  }
}

function extractText(content) {
  if (!content) return "";
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content.map(extractText).filter(Boolean).join("\n").trim();
  }
  if (typeof content !== "object") return String(content);
  const record = content;
  if (typeof record.text === "string") return record.text;
  if (typeof record.content === "string") return record.content;
  if (Array.isArray(record.content)) return extractText(record.content);
  if (Array.isArray(record.parts)) return extractText(record.parts);
  return "";
}
function isPublicChatRole(role) {
  return role === "user" || role === "assistant";
}
async function threadMessagesHandler(c) {
  const session = await getSessionFromRequest(c.req.raw);
  if (!session) return c.json({ error: "Authentication required" }, 401);
  const userId = session.user.id;
  const threadId = c.req.param("threadId");
  const memoryStore = await storage.getStore("memory");
  if (!memoryStore) {
    return c.json({ error: "Memory storage is unavailable" }, 500);
  }
  const thread = await memoryStore.getThreadById({ threadId });
  if (!thread || thread.resourceId !== userId) {
    return c.json({ error: "Thread not found" }, 404);
  }
  const result = await memoryStore.listMessages({
    threadId,
    resourceId: userId,
    perPage: false,
    orderBy: { field: "createdAt", direction: "ASC" }
  });
  const messages = result.messages.filter((message) => isPublicChatRole(message.role)).map((message) => ({
    id: message.id,
    role: message.role,
    content: extractText(message.content),
    timestamp: new Date(message.createdAt).getTime()
  })).filter((message) => message.content.trim().length > 0).filter((message) => !message.content.startsWith("[SYSTEM CONTEXT"));
  return c.json({
    thread: {
      id: thread.id,
      title: thread.title ?? null,
      createdAt: thread.createdAt,
      updatedAt: thread.updatedAt
    },
    messages
  });
}

function sseEncode(event) {
  if (event.comment) return `: ${event.comment}

`;
  const lines = [];
  if (event.id) lines.push(`id: ${event.id}`);
  lines.push(`data: ${JSON.stringify(event.data ?? {})}`);
  return `${lines.join("\n")}

`;
}
async function runEventsHandler(c) {
  const req = c.req.raw;
  const session = await getSessionFromRequest(req);
  if (!session) {
    return c.json({ error: "Authentication required" }, 401);
  }
  const runId = c.req.param("runId");
  const meta = await getRunMeta(runId);
  if (!meta) {
    return c.json({ error: "Run not found or expired" }, 404);
  }
  if (meta.userId !== session.user.id) {
    return c.json({ error: "Forbidden" }, 403);
  }
  const url = new URL(req.url);
  let lastId = req.headers.get("last-event-id") || url.searchParams.get("after") || "0-0";
  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const liveQueue = [];
      let wake = null;
      let terminal = false;
      const unsubscribe = subscribeRunEvents(runId, (event) => {
        liveQueue.push(event);
        wake?.();
        wake = null;
      });
      const send = (event) => {
        controller.enqueue(encoder.encode(sseEncode(event)));
      };
      const waitForLiveEvent = (ms) => {
        if (liveQueue.length > 0) return Promise.resolve("event");
        return new Promise((resolve) => {
          const timer = setTimeout(() => {
            if (wake === notify) wake = null;
            resolve("timeout");
          }, ms);
          const notify = () => {
            clearTimeout(timer);
            resolve("event");
          };
          wake = notify;
        });
      };
      const sendRunEvent = (event) => {
        if (compareRunEventIds(event.id, lastId) <= 0) return;
        lastId = event.id;
        send(event);
        const type = event.data?.type;
        if (type === "run-complete" || type === "run-error" || type === "run-cancelled") {
          terminal = true;
        }
      };
      const replayRedisBacklog = async () => {
        while (!req.signal.aborted && !terminal) {
          const events = await readRunEvents(runId, lastId, 0, 100);
          if (events.length === 0) return;
          for (const event of events) {
            sendRunEvent(event);
            if (terminal) return;
          }
        }
      };
      try {
        send({
          data: {
            type: "run-meta",
            runId: meta.runId,
            threadId: meta.threadId,
            status: meta.status
          }
        });
        await replayRedisBacklog();
        while (!req.signal.aborted && !terminal) {
          while (liveQueue.length > 0 && !terminal) {
            const event = liveQueue.shift();
            if (event) sendRunEvent(event);
          }
          if (terminal) break;
          const result = await waitForLiveEvent(15e3);
          if (result === "timeout") {
            await replayRedisBacklog();
            if (!terminal && liveQueue.length === 0) {
              send({ data: { type: "keepalive", ts: Date.now() } });
            }
          }
        }
      } catch (error) {
        send({
          data: {
            type: "run-error",
            runId,
            threadId: meta.threadId,
            error: error?.message || "Run event stream failed"
          }
        });
      } finally {
        unsubscribe();
        if (wake) {
          wake();
          wake = null;
        }
        controller.close();
      }
    }
  });
  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Thread-Id": meta.threadId,
      "X-Run-Id": runId
    }
  });
}

async function runCancelHandler(c) {
  const req = c.req.raw;
  const session = await getSessionFromRequest(req);
  if (!session) {
    return c.json({ error: "Authentication required" }, 401);
  }
  const runId = c.req.param("runId");
  const meta = await getRunMeta(runId);
  if (!meta) {
    return c.json({ error: "Run not found or expired" }, 404);
  }
  if (meta.userId !== session.user.id) {
    return c.json({ error: "Forbidden" }, 403);
  }
  if (meta.status === "complete" || meta.status === "error" || meta.status === "cancelled") {
    return c.json({ ok: true, runId, status: meta.status, alreadyTerminal: true });
  }
  const aborted = abortRun(runId);
  if (!aborted) {
    await updateRunStatus(runId, "cancelled").catch(() => void 0);
    await appendRunEvent(runId, { type: "run-cancelled", runId, threadId: meta.threadId }).catch(() => null);
    return c.json({ ok: true, runId, status: "cancelled", orphaned: true });
  }
  return c.json({ ok: true, runId, status: "cancelled" });
}

const apiRoutes = [registerApiRoute("/wizard/chat", {
  method: "POST",
  handler: chatHandler
}), registerApiRoute("/wizard/threads", {
  method: "GET",
  handler: threadsListHandler
}), registerApiRoute("/wizard/threads/:threadId", {
  method: "GET",
  handler: threadMessagesHandler
}), registerApiRoute("/wizard/runs/:runId/events", {
  method: "GET",
  handler: runEventsHandler
}), registerApiRoute("/wizard/runs/:runId/cancel", {
  method: "POST",
  handler: runCancelHandler
})];
const mastra = new Mastra({
  storage,
  ...observability ? {
    observability
  } : {},
  workflows: {
    videoGenWorkflow,
    wizardWorkflow
  },
  agents: {
    directorAgent,
    wizardAgent,
    supervisorAgent,
    pluginOrchestratorAgent,
    pluginPlannerAgent,
    storyAgent,
    generatorAgent,
    plannerAgent
  },
  server: {
    port: Number(process.env.PORT ?? 4111),
    apiRoutes
  }
});

export { ARC_PATTERNS as A, CONSISTENCY_LENS_CONFIGS as C, agentTools as a, applyBlockPostProcessors as b, callAIWithTracking as c, directorAgent as d, mastra$1 as e, wizardAgent as f, getTokenTotal as g, wizardWorkflow as h, mastra as m, regenerateSingleImage as r, videoGenWorkflow as v, withTokenTracking as w };
