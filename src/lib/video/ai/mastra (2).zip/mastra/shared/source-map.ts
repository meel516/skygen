import { createHash } from 'crypto';
import {
  deriveAST,
  type PluginAST,
  type FileAST,
  type ExportInfo,
} from '../tools/code-ast';

// ============================================================================
// SOURCE MAP — semantic tree view of a plugin's source code
//
// The source map is the orchestrator's RECON artifact. It is produced BEFORE
// planning in modify mode (and recommended in create mode once a skeleton
// exists) so the planner can reference real files, real symbols, real line
// ranges, and real data-field usages instead of guessing.
//
// Components:
//   - FileSummary: per-file role + exports + sections + imports + hash
//   - SymbolIndex: name → file + line range, for findSymbol
//   - DataFieldUsages: reverse index from data.<field> → every read site
//   - PerFileHashes: file content hash for diff-aware recompilation
//
// The source map is cached on pendingPlugin.sourceMap and re-derived
// whenever any file changes. Each FileSummary.hash is independent so callers
// can answer "did this file change?" without re-hashing everything.
// ============================================================================

export interface FileSummary {
  path: string;
  totalLines: number;
  /** Semantic role, e.g. "hero reveal animation" or "MapLibre camera controller" */
  role: string;
  /** How the role was derived — 'agent' means explicitly set via setFileRole */
  roleSource: 'jsdoc' | 'section' | 'filename' | 'agent' | 'unknown';
  exports: ExportInfo[];
  sections: { name: string; lines: [number, number] }[];
  imports: { specifier: string; kind: 'local' | 'external'; resolved?: string; line: number }[];
  /** sha256(fileContent).slice(0,16) — for diff tracking */
  hash: string;
}

export interface SymbolIndexEntry {
  name: string;
  kind: ExportInfo['type'];
  file: string;
  lines: [number, number];
}

export interface DataFieldUsage {
  /** Field name without `data.` prefix, e.g. "players" */
  field: string;
  /** Full access path as it appears in code, e.g. "data.players[0].name" */
  path: string;
  file: string;
  line: number;
  lineText: string;
}

export interface SourceMap {
  version: 1;
  pluginId: string;
  generatedAt: string;
  files: FileSummary[];
  symbols: SymbolIndexEntry[];
  dataFieldUsages: DataFieldUsage[];
  /** file path → hash, mirroring files[].hash for fast lookup */
  perFileHashes: Record<string, string>;
  /** Top-level hash of all files combined, for "did anything change?" checks */
  overallHash: string;
}

// ─── Role extraction ────────────────────────────────────────────────────────

const FILENAME_ROLE_HINTS: Array<{ pattern: RegExp; role: string }> = [
  { pattern: /^Scene\.tsx$/, role: 'composition root' },
  { pattern: /theme\./i, role: 'theme tokens (colors, fonts, spacing)' },
  { pattern: /animations?\./i, role: 'animation timeline helpers' },
  { pattern: /components?\./i, role: 'shared sub-components' },
  { pattern: /layout\./i, role: 'positioning / AbsoluteFill structure' },
  { pattern: /utils?\./i, role: 'utility helpers' },
  { pattern: /map/i, role: 'map / geographic layer' },
  { pattern: /chart/i, role: 'chart / data visualization' },
  { pattern: /camera/i, role: 'camera controller' },
  { pattern: /particle/i, role: 'particle system' },
];

function extractRoleFromJSDoc(code: string): string | null {
  // Match: /** @role hero reveal animation */ or // @role: hero reveal animation
  const m = code.match(/(?:\/\*\*?|\/\/)\s*@role\s*[:\s]\s*([^\n*]+)/);
  return m ? m[1].trim() : null;
}

function extractRoleFromFirstSection(fileAst: FileAST): string | null {
  if (fileAst.sections.length === 0) return null;
  return fileAst.sections[0].name;
}

function deriveRoleFromFilename(filePath: string): string {
  for (const hint of FILENAME_ROLE_HINTS) {
    if (hint.pattern.test(filePath)) return hint.role;
  }
  const base = filePath.split('/').pop() ?? filePath;
  return `module (${base})`;
}

function deriveFileRole(filePath: string, code: string, fileAst: FileAST): { role: string; roleSource: FileSummary['roleSource'] } {
  const jsdoc = extractRoleFromJSDoc(code);
  if (jsdoc) return { role: jsdoc, roleSource: 'jsdoc' };

  const section = extractRoleFromFirstSection(fileAst);
  if (section) return { role: section, roleSource: 'section' };

  return { role: deriveRoleFromFilename(filePath), roleSource: 'filename' };
}

// ─── Per-file hash ──────────────────────────────────────────────────────────

function hashFile(content: string): string {
  return createHash('sha256').update(content).digest('hex').slice(0, 16);
}

function hashOverall(entries: Array<{ path: string; hash: string }>): string {
  const stable = entries
    .slice()
    .sort((a, b) => a.path.localeCompare(b.path))
    .map((e) => `${e.path}:${e.hash}`)
    .join('|');
  return createHash('sha256').update(stable).digest('hex').slice(0, 16);
}

// ─── Import resolution (mirrors plugin-run-ledger logic but lighter) ─────────

function classifyImport(specifier: string): 'local' | 'external' {
  return specifier.startsWith('.') || specifier.startsWith('/') ? 'local' : 'external';
}

const IMPORT_LINE_REGEX = /^\s*import\s+(?:type\s+)?(?:[\s\S]*?\s+from\s+)?['"]([^'"]+)['"]/;

function extractImportsWithLines(code: string): { specifier: string; line: number }[] {
  const out: { specifier: string; line: number }[] = [];
  const lines = code.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(IMPORT_LINE_REGEX);
    if (m && m[1]) out.push({ specifier: m[1], line: i + 1 });
  }
  return out;
}

function resolveLocalPath(fromFile: string, specifier: string, modulePaths: Set<string>): string | undefined {
  const baseDir = fromFile.includes('/') ? fromFile.slice(0, fromFile.lastIndexOf('/')) : '';
  const join = (a: string, b: string) => (a ? `${a}/${b}` : b);
  const candidates: string[] = [];
  const parts = (baseDir ? join(baseDir, specifier) : specifier).split('/');
  const cleaned: string[] = [];
  for (const p of parts) {
    if (!p || p === '.') continue;
    if (p === '..') { cleaned.pop(); continue; }
    cleaned.push(p);
  }
  const base = cleaned.join('/');
  for (const ext of ['', '.ts', '.tsx', '.js', '.jsx']) {
    candidates.push(`${base}${ext}`);
  }
  for (const ext of ['.ts', '.tsx', '.js', '.jsx']) {
    candidates.push(`${base}/index${ext}`);
  }
  return candidates.find((c) => modulePaths.has(c));
}

// ─── Data field usage extraction ─────────────────────────────────────────────

/**
 * Scan every module for `data.<field>` access patterns and return one entry
 * per occurrence. This is the reverse index the planner uses to answer
 * "if I rename `players` to `athletes`, which files/lines break?"
 */
function extractDataFieldUsages(modules: Record<string, string>): DataFieldUsage[] {
  const usages: DataFieldUsage[] = [];
  // Match data.<identifier> with optional chained access. Capture the first identifier.
  // We deliberately keep this conservative — false negatives are fine, false positives are not.
  const pattern = /\bdata\.([A-Za-z_$][A-Za-z0-9_$]*)/g;

  for (const [file, code] of Object.entries(modules)) {
    const lines = code.split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      let m: RegExpExecArray | null;
      pattern.lastIndex = 0;
      while ((m = pattern.exec(line)) !== null) {
        const field = m[1];
        // Capture the surrounding access path, e.g. "data.players[0].name"
        const after = line.slice(m.index);
        const pathMatch = after.match(/^data\.[A-Za-z_$][A-Za-z0-9_$]*(?:\[[^\]]*\]|\.[A-Za-z_$][A-Za-z0-9_$]*)*/);
        usages.push({
          field,
          path: pathMatch ? pathMatch[0] : `data.${field}`,
          file,
          line: i + 1,
          lineText: line.trim(),
        });
      }
    }
  }

  return usages;
}

// ─── Main entry ─────────────────────────────────────────────────────────────

export interface DeriveSourceMapOptions {
  /** Optional agent-supplied role overrides: { "features/hero/index.tsx": "hero reveal" } */
  roleOverrides?: Record<string, string>;
  /** Plugin id from pendingPlugin.pluginId */
  pluginId?: string;
}

export function deriveSourceMap(
  modules: Record<string, string>,
  options: DeriveSourceMapOptions = {},
): SourceMap {
  const ast: PluginAST = deriveAST(modules);
  const modulePaths = new Set(Object.keys(modules));
  const files: FileSummary[] = [];
  const symbols: SymbolIndexEntry[] = [];
  const perFileHashes: Record<string, string> = {};

  for (const [path, code] of Object.entries(modules)) {
    const fileAst = ast.files[path];
    if (!fileAst) continue;

    const roleOverride = options.roleOverrides?.[path];
    const roleInfo = roleOverride
      ? { role: roleOverride, roleSource: 'agent' as const }
      : deriveFileRole(path, code, fileAst);

    const imports = extractImportsWithLines(code).map(({ specifier, line }) => {
      const kind = classifyImport(specifier);
      const resolved = kind === 'local' ? resolveLocalPath(path, specifier, modulePaths) : undefined;
      return { specifier, kind, resolved, line };
    });

    const hash = hashFile(code);
    perFileHashes[path] = hash;

    files.push({
      path,
      totalLines: fileAst.totalLines,
      role: roleInfo.role,
      roleSource: roleInfo.roleSource,
      exports: fileAst.exports,
      sections: fileAst.sections,
      imports,
      hash,
    });

    for (const exp of fileAst.exports) {
      symbols.push({
        name: exp.name,
        kind: exp.type,
        file: path,
        lines: exp.lines,
      });
    }
  }

  const overallHash = hashOverall(files.map((f) => ({ path: f.path, hash: f.hash })));
  const dataFieldUsages = extractDataFieldUsages(modules);

  return {
    version: 1,
    pluginId: options.pluginId ?? 'unknown',
    generatedAt: new Date().toISOString(),
    files,
    symbols,
    dataFieldUsages,
    perFileHashes,
    overallHash,
  };
}

// ─── Diff helpers ────────────────────────────────────────────────────────────

export interface SourceMapDiff {
  added: string[];
  removed: string[];
  changed: string[];   // path present in both, hash differs
  unchanged: string[];
}

export function diffSourceMaps(before: SourceMap | null, after: SourceMap): SourceMapDiff {
  if (!before) {
    return {
      added: after.files.map((f) => f.path),
      removed: [],
      changed: [],
      unchanged: [],
    };
  }

  const beforeHashes = before.perFileHashes;
  const afterHashes = after.perFileHashes;
  const beforePaths = new Set(Object.keys(beforeHashes));
  const afterPaths = new Set(Object.keys(afterHashes));

  const added: string[] = [];
  const removed: string[] = [];
  const changed: string[] = [];
  const unchanged: string[] = [];

  for (const p of afterPaths) {
    if (!beforePaths.has(p)) added.push(p);
    else if (beforeHashes[p] !== afterHashes[p]) changed.push(p);
    else unchanged.push(p);
  }
  for (const p of beforePaths) {
    if (!afterPaths.has(p)) removed.push(p);
  }

  return { added, removed, changed, unchanged };
}

// ─── Pretty-printers for the agent ───────────────────────────────────────────

export function summarizeSourceMap(sm: SourceMap): string {
  const lines: string[] = [];
  lines.push(`SOURCE MAP (overall ${sm.overallHash}, ${sm.files.length} file(s), ${sm.symbols.length} symbol(s), ${sm.dataFieldUsages.length} data-field usage(s))`);
  for (const f of sm.files) {
    const exportNames = f.exports.map((e) => `${e.name}${e.type === 'default' ? '(default)' : ''}`).join(', ') || '—';
    const unresolved = f.imports.filter((i) => i.kind === 'local' && !i.resolved);
    lines.push(`  • ${f.path} [${f.hash}] (${f.totalLines} lines) — ${f.role}`);
    lines.push(`    exports: ${exportNames}`);
    if (unresolved.length > 0) {
      lines.push(`    ⚠ unresolved local imports: ${unresolved.map((u) => u.specifier).join(', ')}`);
    }
  }
  if (sm.dataFieldUsages.length > 0) {
    const byField = new Map<string, number>();
    for (const u of sm.dataFieldUsages) {
      byField.set(u.field, (byField.get(u.field) ?? 0) + 1);
    }
    const fieldSummary = [...byField.entries()].map(([f, c]) => `${f}(${c})`).join(', ');
    lines.push(`  data fields read: ${fieldSummary}`);
  }
  return lines.join('\n');
}
