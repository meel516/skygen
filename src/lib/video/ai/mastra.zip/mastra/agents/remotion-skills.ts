// Remotion official skills reference — injected into all plugin specialist agents.
// Source: https://github.com/remotion-dev/skills

export const REMOTION_SKILLS = `
## REMOTION REFERENCE (Official Skills)

### Core: Timing & Interpolation

\`interpolate(frame, inputRange, outputRange, options)\` maps a frame number to a value.
- Always clamp: \`{ extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }\`
- Use \`Easing.out\` for enter animations (starts fast, decelerates into place)
- Use \`Easing.in\` for exit animations
- Bézier easing: \`Easing.bezier(x1, y1, x2, y2)\` — matches CSS cubic-bezier syntax
  - Crisp UI entrance: \`Easing.bezier(0.22, 1, 0.36, 1)\`
  - Editorial fade: \`Easing.bezier(0.45, 0, 0.55, 1)\`
  - Playful overshoot: \`Easing.bezier(0.34, 1.56, 0.64, 1)\`
- Named presets: \`Easing.quad\`, \`Easing.cubic\`, \`Easing.sin\`, \`Easing.exp\`, \`Easing.circle\`
  combined with \`.in\`, \`.out\`, \`.inOut\`
- Derive multiple animated properties from a SINGLE normalized progress (0→1):
  \`\`\`ts
  const progress = interpolate(frame, [0, enterFrames], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const opacity = progress;
  const scale = interpolate(progress, [0, 1], [0.8, 1]);
  \`\`\`

\`spring({ frame, fps, config })\` — bouncy physics animation.
- Returns 0→1 (approximately). Config: \`{ stiffness: 80–200, damping: 15–25 }\`
- Higher stiffness = faster/snappier. Higher damping = less bounce.
- Use for enter animations that need a natural overshoot feel.

### Core: Sequencing

\`<Sequence from={N} durationInFrames={N}>\` — delays and limits child visibility.
- Inside a Sequence, \`useCurrentFrame()\` counts from 0 (local time, not global).
- \`layout="none"\` to avoid wrapping in AbsoluteFill.
- \`premountFor={N}\` — preloads component N frames before it appears.
- Nesting: inner Sequence trims start, outer Sequence adds delay.
  \`\`\`tsx
  <Sequence from={30}> // delay 30 frames
    <Sequence from={-15}> // trim first 15 frames of animation
      <MyComponent />
    </Sequence>
  </Sequence>
  \`\`\`

\`<Series>\` — arranges children sequentially without overlap.
- Children use \`<Series.Sequence durationInFrames={N}>\`
- Negative \`offset\` creates overlaps between sequences.

Stagger multi-element entries:
\`\`\`ts
const opacity = interpolate(frame, [i * 5, enterFrames + i * 5], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
\`\`\`

### Images

\`<Img src={url} style={...} />\` — Remotion's image component (use instead of <img>).
- Blocks rendering until loaded (important for Lambda render accuracy).
- \`objectFit: 'cover' | 'contain' | 'fill'\`
- For frame-by-frame sequences: \`<Img src={staticFile(\`frames/frame\${frame}.png\`)}\` />\`
- Get dimensions: \`getImageDimensions(url)\` returns \`{ width, height }\`

### Videos

\`<Video src={url} style={...} />\` — frame-accurate video (use instead of <video>).
- \`trimBefore={N}\` / \`trimAfter={N}\` — trim frames from start/end.
- \`playbackRate={2}\` — speed (no reverse).
- \`loop\` — infinite loop.
- \`muted\` — silence.
- \`volume={0.5}\` or volume callback: \`volume={(f) => interpolate(f, [0, 30], [0, 1])}\`
- Wrap in \`<Sequence from={30}>\` to delay start.

### Audio

\`<Audio src={url} />\` — synced audio.
- Same \`trimBefore\`, \`trimAfter\`, \`playbackRate\`, \`loop\`, \`muted\`, \`volume\` as Video.
- Wrap in \`<Sequence>\` to delay.

### Transitions (TransitionSeries)

\`<TransitionSeries>\` from \`@remotion/transitions\` — manages scene transitions.
- Built-in presentations: \`fade()\`, \`slide()\`, \`wipe()\`, \`flip()\`, \`clockWipe()\`
- Timing: \`linearTiming({ durationInFrames })\` or \`springTiming({ config })\`
- Transitions OVERLAP adjacent scenes → total duration is SHORTER than sum of parts.
  Example: two 60-frame scenes + 15-frame transition = 105 total frames.
\`\`\`tsx
<TransitionSeries>
  <TransitionSeries.Sequence durationInFrames={60}><SceneA /></TransitionSeries.Sequence>
  <TransitionSeries.Transition presentation={fade()} timing={linearTiming({ durationInFrames: 15 })} />
  <TransitionSeries.Sequence durationInFrames={60}><SceneB /></TransitionSeries.Sequence>
</TransitionSeries>
\`\`\`

### Text Animations

Typewriter effect — always use string slicing, NEVER per-character opacity:
\`\`\`ts
const charsToShow = Math.floor(interpolate(frame, [0, enterFrames], [0, text.length], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }));
const visible = text.slice(0, charsToShow);
\`\`\`

Word highlight — interpolate background-color or opacity per word based on frame position.

### Fonts

Google Fonts (recommended — type-safe, auto-blocks render):
\`\`\`ts
import { loadFont } from '@remotion/google-fonts/Inter';
const { fontFamily } = loadFont();
// use fontFamily in style={{ fontFamily }}
\`\`\`
Call \`loadFont()\` at module level (top of file), not inside component.
Specify weights/subsets for smaller bundles: \`loadFont('normal', { subsets: ['latin'], weights: ['400', '700'] })\`

Local fonts (from public/ folder):
\`\`\`ts
import { loadFont } from '@remotion/fonts';
await loadFont({ family: 'MyFont', url: staticFile('MyFont.woff2'), weight: '400' });
\`\`\`

### Measuring Text

\`measureText({ text, fontFamily, fontSize, fontWeight })\` from \`@remotion/layout-utils\`
- Results are cached — safe to call repeatedly.
- Load font BEFORE measuring.
- Use \`validateFontIsLoaded: true\` to catch font loading issues.
- Use \`outline\` instead of \`border\` to avoid layout differences.

\`fitText({ text, withinWidth, fontFamily, fontWeight })\` — find optimal font size for a container.

### Measuring DOM Nodes

Remotion applies a \`scale()\` transform — \`getBoundingClientRect()\` values are scaled.
Fix:
\`\`\`ts
import { useCurrentScale } from 'remotion';
const scale = useCurrentScale();
const rect = ref.current.getBoundingClientRect();
const realWidth = rect.width / scale;
const realHeight = rect.height / scale;
\`\`\`

### GIFs / Animated Images

\`<AnimatedImage src={url} width={N} height={N} />\` from \`@remotion/gif\`
- \`fit\`: 'fill' | 'contain' | 'cover'
- \`playbackRate\`: speed multiplier
- \`loop\`: 'loop' | 'pause-after-finish' | 'clear-after-finish'
- Get duration: \`getGifDurationInSeconds(url)\`

### Audio Visualization

\`useWindowedAudioData({ src, frame, fps, windowDurationInSeconds })\` from \`@remotion/media-utils\`

Spectrum bars:
\`\`\`ts
const data = useWindowedAudioData({ src: staticFile('audio.mp3'), frame, fps, windowDurationInSeconds: 1 });
const bars = visualizeAudio({ fps, frame, audioData: data, numberOfSamples: 64 }); // powers of 2: 32-1024
// bars[i] is 0-1, lower indices = bass frequencies
\`\`\`

Waveform: \`visualizeAudioWaveform()\` + \`createSmoothSvgPath()\`

Bass reactivity:
\`\`\`ts
const bassValues = bars.slice(0, 4);
const bassIntensity = bassValues.reduce((a, b) => a + b, 0) / bassValues.length;
\`\`\`

Pass \`frame\` as a prop to child components — don't call \`useCurrentFrame()\` separately inside them.
Sample counts MUST be powers of 2. Apply logarithmic scaling to low frequencies for balanced visuals.

### Lottie

\`\`\`ts
import Lottie from 'lottie-react'; // declare in deps
const lottieRef = useRef(null);
useEffect(() => { lottieRef.current?.goToAndStop(frame, true); }, [frame]);
<Lottie lottieRef={lottieRef} animationData={lottieJson} loop autoplay={false} />
\`\`\`
- \`animationData\` MUST be a JS object (never a URL string). Embed minimal inline JSON if no file provided.
- Sync to Remotion frame via \`goToAndStop(frame, true)\` inside useEffect.

### 3D (React Three Fiber)

\`\`\`ts
import { Canvas, useFrame } from '@react-three/fiber'; // declare in deps
import { Text, Box, Sphere, Cylinder, OrbitControls } from '@react-three/drei'; // declare in deps
\`\`\`
- MUST wrap in \`<ThreeCanvas width={width} height={height}>\` from \`@remotion/three\` OR plain \`<Canvas>\` at 100%×100%.
- Animations MUST be driven by \`useCurrentFrame()\`. Using \`useFrame\` alone causes flicker during rendering.
- Pass frame as prop into Canvas children, read inside useFrame:
  \`\`\`tsx
  function Mesh({ syncFrame }: { syncFrame: number }) {
    const ref = useRef<THREE.Mesh>(null);
    useFrame(() => { if (ref.current) ref.current.rotation.y = syncFrame * 0.02; });
    return <mesh ref={ref}><boxGeometry /><meshStandardMaterial /></mesh>;
  }
  // Inside Scene:
  const frame = useCurrentFrame();
  <Canvas><ambientLight /><directionalLight position={[10,10,5]} /><Mesh syncFrame={frame} /></Canvas>
  \`\`\`
- \`<Sequence layout="none">\` inside ThreeCanvas.
- Primitives only: Box, Sphere, Cylinder, Torus, Text. No GLTF/GLB.

### Maps (MapLibre GL JS + Turf)

Use MapLibre for deterministic map animations: route reveals, flight paths, markers, labels, and camera movement.

\`\`\`ts
import maplibregl, { type GeoJSONSource, type Map } from 'maplibre-gl'; // declare in deps
import * as turf from '@turf/turf'; // declare in deps
import 'maplibre-gl/dist/maplibre-gl.css';
\`\`\`

- Dependencies: \`maplibre-gl\` and \`@turf/turf\`. Do NOT install \`@types/maplibre-gl\`; MapLibre ships types.
- Coordinates are always \`[longitude, latitude]\`.
- Use GeoJSON sources + MapLibre layers for lines, markers, and labels. Avoid DOM Marker elements unless explicitly requested.
- Disable nondeterminism: \`interactive: false\`, \`fadeDuration: 0\`, \`attributionControl: false\`, and \`canvasContextAttributes: { preserveDrawingBuffer: true }\`.
- Use \`delayRender()\` / \`continueRender()\` for initial map load and per-frame map updates.
- Before continuing the initial render: add sources/layers, apply frame-0 camera using \`jumpTo()\`, then wait for \`idle\`.
- Do NOT add \`mapInstance.remove()\` cleanup; it can interfere with Remotion rendering.
- Default style: \`https://demotiles.maplibre.org/style.json\` unless the user asks for another valid MapLibre style URL.
- For geodesic flight routes, use Turf \`greatCircle()\`, \`length()\`, \`along()\`, and \`lineSliceAlong()\`; keep slices non-empty with \`Math.max(0.001, distance * progress)\`.
- For visually straight map lines, use a simple GeoJSON \`LineString\` between points instead of \`greatCircle()\`.
- For camera motion, prefer \`map.calculateCameraOptionsFromTo(cameraLngLat, cameraAltitudeMeters, targetLngLat)\`.
- Separate \`targetRoute\` from \`cameraRoute\`; animate travel progress separately from camera altitude for zoom-out / travel / zoom-in motion.
- Per frame: update the GeoJSON source with \`source.setData(...)\`, call \`map.jumpTo(...)\`, wait for \`idle\`, then \`continueRender(handle)\`; call \`map.triggerRepaint()\` if camera values may be unchanged.
- Marker dots and labels should be map-native layers; make label sizes large enough for video resolution.
- Rendering WebGL maps should use single concurrency and ANGLE: \`remotion render --gl=angle --concurrency=1\`.

### Transparent Video Export

ProRes (for video editing software):
- imageFormat: png, pixelFormat: yuva444p10le, codec: prores, profile: 4444

WebM/VP9 (for browser):
- imageFormat: png, pixelFormat: yuva420p, codec: vp9

### calculateMetadata (dynamic composition config)

\`\`\`ts
export const calculateMetadata: CalculateMetadataFunction<Props> = async ({ props, abortSignal }) => {
  const duration = await getVideoDuration(props.videoSrc);
  return { durationInFrames: Math.round(duration * props.fps), props };
};
\`\`\`
Returns any of: durationInFrames, width, height, fps, props, defaultOutName, defaultCodec.

### Schema Description Rules (CRITICAL for content generation)

The \`description\` field in every schema property is read by the content-generation LLM when filling your plugin with real data. Write it to tell the LLM **what the field is AND how it is used in animation**, so generated values make sense visually.

Prefer motion-graphics language in schema descriptions: opening beat, build beat, connect beat, accent beat, resolve beat, background drift, camera push, parallax, trace, sweep, pulse, glow, and living motion. If an older example says "enter phase", treat that as a timing hint only, not as the creative structure.

Bad description: \`"The player's name"\`
Good description: \`"Player display name — shown as large headline, springs into position during enter phase"\`

Bad description: \`"A number"\`
Good description: \`"Stat value — animates counting up from 0 to this value over the enter phase using interpolate"\`

Bad description: \`"Background image"\`
Good description: \`"Full-bleed background image — visible throughout all phases, no animation, should be a wide scenic or stadium shot"\`

Pattern per field type:
- Text/headline: \`"<what it is> — <where it appears on screen>, <enter animation> during enter phase"\`
- Number/stat: \`"<what it is> — counts up from 0 → value using interpolate over enter phase"\`
- Image (bg): \`"<what it is> — full-bleed background, no animation, <style guidance>"\`
- Image (fg): \`"<what it is> — fades/scales in during enter phase, positioned <where>"\`
- Audio: \`"<what it is> — narrated voiceover, spoken aloud"\`
- Color: \`"<what it is> — used for <element name> color, e.g. accent bar, text highlight"\`
- Array item: \`"One entry in <array name> — rendered as <card/bar/row>, animates with stagger delay based on index"\`

### CSS Rules (CRITICAL)

- CSS transitions (\`transition: ...\`) are FORBIDDEN — they won't render correctly.
- Tailwind animation classes are FORBIDDEN.
- Use ONLY \`useCurrentFrame()\` + \`interpolate()\` / \`spring()\` for all animations.
- No \`setInterval\`, \`setTimeout\`, \`requestAnimationFrame\` — Remotion drives the clock.
`;
